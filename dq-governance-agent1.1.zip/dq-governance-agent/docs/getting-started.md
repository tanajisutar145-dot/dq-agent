# Getting started

TCS DataTrustAI watches the quality of your data across Databricks, Snowflake, Spark, Cognite Data Fusion, AWS and Azure. It also governs that data, and explains everything through an AI agent.

It does five jobs:

1. **Finds problems:** it profiles your tables, proposes quality rules, and runs them inside each platform.
2. **Explains them:** related failures become one incident, traced to the table where the problem started.
3. **Helps fix them:** it suggests fixes and opens tickets. Changes to data run only when a person clicks them, and rules go live only after review.
4. **Governs the data:** it handles personal-data detection, masking and retention policies, data contracts, and compliance evidence.
5. **Talks to you:** an agent answers questions like "why is the billing table failing?" from real check results.

## Key concepts

| Term | Meaning |
|---|---|
| **Dataset** | A table, view or time series in one of your platforms. Each has an owner, a steward, a domain, and can be certified |
| **Rule** | One quality check, for example `kwh must be between 0 and 500`. Rules are **proposed**, **active** or **disabled** |
| **Dimension** | The kind of quality a rule measures: completeness, validity, uniqueness, consistency, integrity, timeliness, accuracy, volume, schema or plausibility |
| **Check result** | The outcome of running a rule once: pass, fail, warn or error, with a pass rate and a message |
| **Score** | 0-100 for a dataset, a dimension or a domain. Green ≥ 95, amber 80-94, red < 80 |
| **Incident** | One or more failures that share a root cause, with severity, assignee, evidence and a timeline |
| **Root cause** | The table furthest upstream that is also failing, for a related reason |
| **Draft rule** | A rule that has been saved but is not running. An administrator reviews and activates it |
| **Policy** | A governance rule written as code, such as "mask personal data" or "certified datasets need a contract" |
| **Contract** | An agreed schema and quality promise for a dataset (Open Data Contract Standard), checkable in CI |

## A 10-minute tour with the demo

The demo is a small power-utility lakehouse: smart-meter readings, customers, billing, finance and transformer sensors. Five problems are planted in it. TCS DataTrustAI finds all of them on its own.

1. **Start it.**
   ```bash
   python -m dqga demo
   ```
   ```bash
   python -m dqga serve
   ```
   Then open http://127.0.0.1:8000.

   **Add the demo to the app you already use** (keeps your datasets, rules and settings; adds a DuckDB demo next to them, so the Overview, Insights and the rest have content). Either click **Settings > Maintenance > Load demo data** (about a minute), or stop the server and run:
   ```bash
   python -m dqga demo --add
   ```
   Use the platform picker to switch between your platforms and the demo. Delete the `demo` connection in Settings > Connections to remove it. Plain `python -m dqga demo` (without `--add`) recreates the whole app database.

   **A separate full demo that doesn't touch your real setup:** `config.demo.yaml` has its own app database (`data/demo.db`) and a local DuckDB warehouse, and needs no sign-in:
   ```bash
   python -m dqga --config config.demo.yaml demo
   ```
   ```bash
   python -m dqga --config config.demo.yaml serve --port 8770
   ```
   The demo data fills every screen: five open incidents and 30 days of resolved ones, two weeks of run history, schedules, rules in every review state (drafts, waiting, approved, rejected), pending and decided approvals, custom Overview metrics with trends, reference files, anomalies and insights. Stop the server before rebuilding: `demo` recreates the app database and the warehouse.

   The first visit shows **Set up TCS DataTrustAI**, where you create the administrator account. After that, everyone uses **Sign in**, or **Create an account**, which an administrator approves in the **Admin console**.
2. **Overview.**
   - The overall score, open incidents by severity, and policy violations.
   - The score trend, the newest open incidents, and how many rules are in review.
3. **Explore > Incidents:** open the **critical** incident on `bronze.ami_raw`.
   - One substation's meters stopped sending readings.
   - The daily table downstream is grouped under the same incident, rather than raising its own.
   - The lineage view outlines the root cause in red and lists billing and finance as at risk.
4. **Ask the agent:** click **Ask agent** and send "why did this happen?". It answers from the evidence and shows which tools it used.
5. **Fix it:**
   - Ask "propose a fix". The fix options are listed.
   - Run one from the incident (**Run now**) or under **Fixes**.
6. **AI Rule Studio:**
   - Type `voltage must be between 200 and 260`, then **Draft and dry-run**.
   - The rule is dry-run on your platform before you save it as a draft. Send the draft for approval; an administrator activates it.
7. **Export:** in **Export rules**, pick a format such as Soda or dbt and download it. Your other tools can run the same rules.
8. **Governance > Sensitive data:** names, emails, phones and addresses were detected in `silver.customers`. **Tag** them, then enforce the masking policy from **Governance > Policies**.
9. **Deploy:** choose **Databricks Apps** to see how to run the app inside your workspace.

## Connect your own data

- **Databricks:** follow [Set up with Databricks](databricks-setup.md), either locally against your workspace or as a Databricks App.
- **Other platforms:** add a connection under **Settings > Connections**, or in `config.yaml`. See [Configuration](configuration.md#connection-examples).
- Then on each important table: **Profile**, then **Suggest rules**, then save the ones you want as drafts, send them for approval, and have an administrator activate them in the Review queue, then **Run checks**.

## Who uses what

| Role | Typical pages |
|---|---|
| **Data steward** | Incidents, Governance, AI Rule Studio, the agent |
| **Data engineer** | Dataset pages (Profile, Rules, Lineage), AI Rule Studio export, contracts in CI |
| **Data owner** | Incidents assigned to them, dataset Overview (ownership, certification) |
| **Risk and compliance** | Governance > Compliance, Policies, Settings > Audit |
| **Platform admin** | Admin console (users and roles), Settings (connections, environment, scheduler), Deploy |
| **Leadership** | Overview (scores, trend, incidents) |

## Next steps

- [Features reference](features.md): everything the app can do and how to use it.
- [UI guide](ui-guide.md): every page and button.
- [Configuration and environment](configuration.md): config files, `.env`, environment variables.
- [CLI and API reference](api-cli.md): automation and CI.
