# Features reference

Every capability of TCS DataTrustAI, with what it does, where to find it, and how to use it. Most features can also be used by asking the agent, or through the [CLI and API](api-cli.md). For button-by-button detail, see the [UI guide](ui-guide.md).

## At a glance

| Area | Features |
|---|---|
| [Connect and discover](#connect-and-discover) | 7 connectors, catalog sync, profiling |
| [Quality rules](#quality-rules) | 15 rule types, 10 dimensions, AI rule generation, reference library, Plain-English rule (plain English), Manual rule builder, dry run on the platform, draft-review-activate lifecycle, versions |
| [Monitoring](#monitoring) | Batched check runs, scores, Overview filters and custom metrics, platform picker, anomaly detection, time-series checks, rule schedules and run history, cost-aware scheduler |
| [Incidents and response](#incidents-and-response) | Root-cause grouping, severity, alerts, tickets, feedback learning |
| [Impact analysis](#impact-analysis) | Data-issue and schema-change impact, score, breaking contracts, owners to notify |
| [Insights](#insights) | Recurring incidents, failure timing, hotspots, root-cause patterns, learnings |
| [Governance](#governance) | Sensitive-data detection, tag write-back, policies, standards, violation scans, contracts, glossary, audit |
| [Rule export](#rule-export) | 10 formats, from DQX and Lakeflow to Soda, dbt and Great Expectations |
| [Lineage](#lineage) | Platform lineage, OpenLineage, dbt, manual edges |
| [The agent](#the-agent) | 26 tools, 7 model options chosen in Settings > LLM, suggestions you apply |
| [Users and access](#users-and-access) | Sign-up, sign-in, administrator sign-in, roles, Admin console, SSO |
| [Platform and operations](#platform-and-operations) | Configuration, dataset grouping, `.env`, demo data, deployment targets, security, persistence |

## Connect and discover

### Connections

Connect each platform once, then everything else works the same across all of them.

| Platform | Runs checks | Metadata and lineage | Writes back |
|---|---|---|---|
| Databricks | SQL warehouse | Unity Catalog, `system.access` lineage | Unity Catalog tags, column masks |
| Snowflake | Warehouse SQL | INFORMATION_SCHEMA, ACCESS_HISTORY lineage | Object tags, masking policies, Data Metric Functions |
| Apache Spark | `spark.sql` (EMR, Synapse, Fabric, open source) | Catalog; lineage via OpenLineage | - |
| Cognite Data Fusion | Time-series checks on datapoints | Time series, assets, extraction pipeline runs | Time series metadata, DQ events |
| AWS Glue | Athena | Glue Data Catalog | Lake Formation tags; native Glue DQ rulesets |
| Azure Purview | Pair with a SQL connector | Purview Data Map search and lineage | Purview classifications |
| DuckDB | Local SQL | Demo lineage and tags | Demo tags |

**Where:** Settings > Connections. **How:**
1. **Add a connection:** pick a type, adjust the example config, then save.
2. **Test** it.
3. **Sync** it.

Keep secrets in environment variables with `*_env` keys. See [Configuration](configuration.md#connection-examples).

### Catalog sync

This pulls tables, columns, tags and lineage from every connection. Existing owners, domains and rules are kept.

**Where:** Catalog > **Sync catalog**, or **Sync** on a connection. **CLI:** `python -m dqga sync`.

### Profiling

Profiling computes statistics inside the platform, one scan per batch of columns: row count, null %, distinct count, min/max, mean, standard deviation, 5th/50th/95th percentiles, string lengths, top values for low-cardinality columns, and string shape patterns (for example `AAA-999999`). It also runs sensitive-data detection.

**Where:** dataset page > **Profile**; results on the **Profile** tab. **Agent:** "profile customers".

A small sample of string values is read to infer patterns and detect personal data. Those values stay in memory: they're never stored or sent to an LLM.

## Quality rules

### Rule types

| Type | Dimension | Checks that | Key settings | Example |
|---|---|---|---|---|
| `not_null` | completeness | values are present | min pass rate | `kwh` ≥ 99% populated |
| `accepted_values` | validity | value is in a list | `values` | `status` in active, inactive |
| `range` | validity | number or date is within bounds | `min`, `max` | `kwh` between 0 and 50 |
| `regex` | validity | value fully matches a pattern | `pattern` | `meter_id` matches `MTR-[0-9]{6}` |
| `length` | validity | text length is within bounds | `min`, `max` | `postcode` 5-8 characters |
| `not_future` | validity | timestamp isn't in the future | - | `reading_ts` not in the future |
| `custom_sql` | validity | a SQL condition is true for each row | `expression` | `end_ts >= start_ts` |
| `unique` | uniqueness | no duplicate keys | `columns` | (`meter_id`, `reading_date`) unique |
| `freshness` | timeliness | the newest record is recent enough | `max_age_hours` | loaded within 3 hours |
| `row_count` | volume | row count is within bounds | `min`, `max` | at least 1,000 rows |
| `referential` | integrity | every key exists in a reference table | `ref_table`, `ref_column` | `customer_id` exists in customers |
| `reconciliation` | consistency | an aggregate matches another table's | `expression`, `ref_table`, `ref_expression`, `tolerance_pct` | billed kWh = daily kWh ± 0.5% |
| `schema` | schema | expected columns exist with expected types | `expected_columns` | catches dropped or retyped columns |
| `anomaly` | volume | a metric stays in its learned range | `metric`, `sensitivity` | row count vs 4-week baseline |
| `timeseries` | plausibility | sensor data behaves physically | `check`, `id_column`, `ts_column`, `value_column` | no sensor flatlined > 6h |

Row-level rules (`not_null` through `custom_sql`), `unique` and `row_count` accept an optional `where` scope, for example `"where": "event_date >= current_date() - INTERVAL 1 DAY"`. This keeps checks on big tables cheap.

### Quality dimensions

| Dimension | Question it answers |
|---|---|
| Completeness | Is everything that should be there, there? |
| Validity | Do values follow format, range and domain rules? |
| Uniqueness | Is each real-world thing recorded once? |
| Consistency | Do the same facts agree across tables? |
| Integrity | Do relationships between tables hold (no orphan keys)? |
| Timeliness | Is the data recent enough for its use? |
| Accuracy | Does it match a trusted reference? |
| Volume | Did the expected amount of data arrive? |
| Schema | Did the structure change unexpectedly? |
| Plausibility | Is sensor or OT data physically believable? |

### AI rule generation

Proposes rules by combining eight kinds of evidence. Each proposal has a confidence score, its sources, the evidence in plain words, and a dry run on current data.

- **Uses the app's LLM.** Discovery asks the model chosen in [Settings > LLM](#the-agent). With no model, or one that can't be reached, it stops with an error that links to Settings > LLM; untick **Use the AI model** to run statistical discovery only. The model is also told the dataset's SQL dialect and given guidance for writing SQL rules (prefer specific rule types, one read-only boolean expression for `custom_sql`, handle NULLs, respect types, never invent limits).
- **Dry run on the platform.** Every candidate runs on the dataset's own platform (Databricks, Snowflake, ...), whichever connection it belongs to, and the page says how many ran and how many couldn't. Platforms that can't run SQL say so.
- **Drafts only.** Accepted proposals are saved as drafts. See [Rule lifecycle](#rule-lifecycle-severity-and-versions).
- **Reference library.** Models, ontologies, glossaries, master data and business documents (PDF needs `pypdf`, which is in the requirements) are parsed into facts and used as evidence and model context. A rule someone wrote down beats a model's guess.

| Source | What it uses | Example proposal |
|---|---|---|
| Semantic type | Column meaning from name, type and values: identifiers, emails, phones, amounts, quantities, percentages, coordinates, country and currency codes, event and load timestamps, categories | `amount ≥ 0` ("monetary values shouldn't be negative; none seen in 2,000 values") |
| Statistics | The current profile | `segment` in (residential, commercial, industrial) |
| History | Ranges that held across stored profiles, null-rate ceilings, learned volume and its variation, observed lateness | "Null rate stayed at or below 0.08% over 28 checks; alert if it doubles" |
| Relationship | Cross-column facts that hold in the data, like time order and min ≤ max | `reading_ts <= ingested_at` ("holds in 100% of 141,000 rows") |
| Business context | Sentences in dataset and column descriptions and in linked glossary definitions (read with the plain-English parser), plus domain conventions | "Voltage must be between 180 and 280" from the description |
| Learned | The same rule on the same column name in other datasets | "Teams already apply this rule to customer_id in meters, billing_mart" |
| Observability | Volume, schema snapshot, category-mix drift (PSI) and outlier-rate monitors | "Schema matches today's 7 columns" |
| LLM | Business rules from metadata and statistics, when a model is configured. Never raw rows | (depends on the model) |
| Glossary | Business terms mapped to the dataset or one of its columns: a definition that states a rule ("must be between 0 and 100") is read like a plain-English rule | "Business term 'Meter reading': must not be negative" (term Meter reading) |
| Contract | The dataset's active data contract: each promise (required or unique column, quality term, freshness SLA) that no active rule covers yet | "customer_id is unique (contract customer v2.1)" |
| Policy | Policies that apply to the dataset: a retention policy sets the retention rule (the strictest period wins); a certification policy tags the proposals that bring a certified dataset up to its minimum rules; a masking policy tags the governance rules that protect the columns it covers | "Rows no older than 400 days (policy meter-data-retention)" |
| Standard | A control of a standard you tick (GDPR, SOX, ISO 8000, DAMA) that is not met yet: up to three proposals in the dimensions that help it are tagged | "Helps ISO 8000 8000-8: completeness" |

**Governance context.** The business glossary, contracts and policies are on by default, standards are opt-in; tick what to include under **Governance context** in the AI context. The glossary, contracts and policies produce proposals without a model, so they work with the built-in generator too. When a model is configured it also receives them as requirements (names, definitions, thresholds and text, never data values) and is asked to cite the contract, policy or business term in each rule's reason; proposals that cite one are tagged with it. Every proposal carries a **source tag** (Glossary, Contract, Policy or Standard, with the contract, policy or control named under it), and the result lists the context that was used.

**How proposals are scored:**
- Confidence rises when sources agree and when the dry run passes.
- It falls when the rule fails on today's data, or when a similar rule here was marked a false positive.
- Rules you already have are skipped. Explicit business statements are kept even if an automatic rule of the same type exists.
- **Coverage by dimension** shows the gain.

**Where:** AI Rule Studio > **AI rule generation**. **Agent:** "discover rules for customers". **API:** `POST /api/assets/{id}/discover`, then `/discover/accept`.

### Quick suggestions from the profile

**Suggest rules** on a dataset page saves the statistics-based proposals directly. For example:
- `not_null` where there are no nulls.
- `unique` on key-like columns.
- `accepted_values` on low-cardinality columns.
- `range` with a 50% margin around what has been seen.
- `freshness` on load timestamps.
- `regex` for emails and consistent formats.
- `referential` when a key column also exists in another table.
- Anomaly monitors for volume, null rate, mean and category mix.

With an LLM configured, it also proposes business rules from metadata and statistics, never raw rows. Every suggestion includes **why** and arrives as **proposed**.

**Where:** dataset page > **Suggest rules**, then the **Rules** tab or AI Rule Studio > **Waiting for review**. **Agent:** "suggest rules for billing_mart".

### Plain-English rule

Write requirements the way you'd say them, one per line. Each is turned into a rule, explained back to you ("Validity: kwh ≥ 0"), dry-run on the platform, and shown with **Save as draft**: nothing is stored until you save it. Drafts are sent for approval and activated by an administrator.

The built-in parser needs no LLM. It works by intent rather than fixed sentences:
- It finds columns anywhere in the sentence, including human names ("meter id", "reading timestamp") and small typos.
- It understands:
  - comparisons, including negations and strict versus inclusive bounds;
  - ranges, lists, percentages of rows, and time windows;
  - formats (email, URL, UUID, phone, digits, upper and lower case, starts or ends with);
  - lengths, ordering between columns, references to other tables, not-equal values, and table volume.

Examples:
- `kwh cannot be negative` · `kWh must not exceed 500` · `kwh should be above zero` · `voltage should be less than 260`
- `Voltage must be between 200 and 260 volts` · `voltage must be between 200 and 260 for at least 99.5% of rows`
- `Every reading must have a meter id` · `at least 99% of kwh values must be populated`
- `no duplicate meter_id and reading_ts` · `substation must be one of SUB-01, SUB-02 or SUB-07`
- `reading timestamp must not be in the future` · `reading_ts must be before ingested_at` · `discount must be less than amount`
- `customer_id must exist in customers` · `data must be refreshed every 6 hours` (uses the load timestamp)
- `meter_id must start with MTR-` · `meter_id must be 10 characters long` · `substation must not be 'SUB-99'` · `table must have at least 1,000 rows`

If a line can't be read, the message says which columns were recognized and suggests phrasings using the dataset's own columns. With an LLM configured, anything else is passed to the model.

**Where:** AI Rule Studio > Rule generation > **Plain-English rule**, or the dataset **Rules** tab. **Agent:** "kwh must be between 0 and 40 on ami_raw".

### Manual rule builder and dry run

Pick a type, column, severity and minimum pass rate, then edit the parameters (an example fills in for each type). **Dry run** runs the rule on the dataset's platform without saving it, and shows where it ran, how long it took and the queries. Platforms that can't run SQL return an error instead of a guess.

**Where:** AI Rule Studio > Rule generation > **Manual rule builder**.

### Rule lifecycle, severity and versions

- **Lifecycle:** **draft** (saved) → **in review** (sent for approval) → **approved** → **active**; an administrator can instead **reject** with a reason, which sends it back to the author. **Disabled** rules can be re-enabled by an administrator. Only active rules run.
  - Rule generation never activates anything: it only saves drafts and dry-runs.
  - **Saved rules** lets the author **Edit** and **Send for approval**. The **Review queue** lets an administrator **Approve**, **Reject**, **Activate** (or **Approve and activate**), after a **Dry run** on the platform.
  - Only administrators approve, reject, activate, or change a live rule. Monitor packs and contract imports by a steward arrive as drafts. The server enforces this, not only the screens.
- **Severity:** critical, high, medium or low. It weights the score and sets incident severity.
- **Minimum pass rate:** for example 0.99 lets 1% of rows fail before the check fails.
- **Versions:** every change creates a new version, with who changed it and why. Available via `GET /api/rules/{id}/history`.

## Monitoring

### Running checks

- All row-level rules on a table run in **one scan**.
- Other rules run their own aggregate queries.
- Only counts and metrics come back from the platform, not data.

**Where:** dataset page > **Run checks**, Overview > **Run due checks**, or automatically on schedule. **Agent:** "run checks on meters". **CLI:** `python -m dqga run [--asset name]` exits 1 if any check fails, so it works as a CI gate.

### Scores

A dataset's score is the severity-weighted average of each active rule's latest pass rate:
- weights are critical 4, high 3, medium 2, low 1;
- a failing row-level check counts at most 50%, so any failure visibly lowers the score;
- a failing aggregate check (freshness, anomaly, schema...) counts 0;
- checks that errored are left out.

Dimension and domain scores use the same method. Score history drives the 30-day trend.

### Anomaly detection

The `anomaly` rule learns the normal range of a metric:
- `row_count`, `null_rate`, `mean`, `distinct_count` or `freshness_hours` use a robust median and MAD, so outliers don't skew the baseline.
- **Seasonality:** with 3+ weeks of history it compares like with like (Mondays with Mondays). Otherwise it uses the last 28 points.
- It needs 7 points before alerting; until then it reports "learning baseline".
- `sensitivity` (default 3) sets how far is unusual. Lower means more alerts.
- `distribution_psi` compares the category mix to a baseline using the population stability index (default threshold 0.2).
- `outlier_rate` tracks the share of values beyond 3× the interquartile range. While the baseline is being learned, it fails above an absolute ceiling (`max_rate`, default 1%).

**Anomalies page:**
- **Feed:** across all datasets, it scans every stored metric and lists **spikes** and **drops** (outside the expected band), **level shifts** (the median of the last 5 points is well outside the previous 20), and failing anomaly or sensor monitors.
- **Severity** accounts for how unusual the value is, certification, and downstream reach.
- **Coverage:** shows which datasets have no monitoring; **Start monitoring** adds a monitor pack (volume, lateness, null-rate drift, outliers, category drift, schema snapshot) in one click.

**Dataset Anomalies tab:** charts every metric with the **expected range shaded** and anomalies marked. The band at each point is learned from earlier points only.

**API:** `GET /api/anomalies`, `GET /api/assets/{id}/anomalies`, `POST /api/assets/{id}/monitor`.

### Industrial time-series checks

The `timeseries` rule works on sensor tables (one row per reading) and on Cognite time series:

| `check` | Finds | Settings |
|---|---|---|
| `gaps` | missing data longer than expected | `expected_interval_s` (default: median), `tolerance` (default 3×) |
| `flatline` | a stuck sensor reporting the same value | `flatline_s` (default 6h) |
| `spikes` | sudden jumps | `spike_z` (default 8, robust z-score of changes) |
| `bounds` | physically impossible values | `min`, `max` |
| `monotonic` | out-of-order or duplicate timestamps | - |
| `sampling_rate` | sampling drift | `expected_interval_s`, `tolerance_pct` |

With `id_column` (for example `sensor_id`), results are per sensor: "212 of 3,000 meters flatlined". `lookback_days` defaults to 7.

### Scheduler

Every `tick_seconds`, it runs rules that are due (`default_interval_minutes`, or per-rule `schedule_minutes`):
- **Change-aware:** it skips tables whose platform change marker hasn't moved since the last check. Freshness checks still run.
- **Cost-aware:** it ranks tables by severity × (1 + downstream tables) × 2 if certified, divided by estimated seconds.
- **Budget:** it stops at `daily_budget_seconds` of compute.

**Where:** Settings > **Scheduler** shows the plan, priorities and budget used; **Run tick now** runs it immediately. **CLI:** `python -m dqga tick`.

### Rule schedules and run history

**Operate > Runs:**
- **Run rules now** for a rule set, a minimum severity, all datasets or one (the platform picker narrows it), with a preview of how many rules and datasets will run and roughly how long it takes.
- **Schedules** run the matching active rules every N minutes or hours, or at a time of day (UTC) on chosen weekdays. Rules in an enabled schedule follow it; other rules keep the default interval. Scheduled runs share the daily budget. They need the background scheduler on (`scheduler.enabled`).
- **Run history** lists every run with what started it (Run now and who, a schedule, the agent, an Insights refresh, a re-check after a fix), checks, failures and outcome; click a run to see each check. **API:** `/api/rules/run`, `/api/schedules`, `/api/runs`.

### Overview, platform picker and grouping

- **Overview** has Summary, Rules and Incidents tabs with one filter bar (time window, platform, group, dataset, severity, rule set), sortable charts with a table view and drill-down, and **custom metrics** (a measure or a read-only SQL query, with target, warning level and trend).
- **Platform picker.** Overview, Insights, Anomalies, Impact analysis (and its Lineage tab), Incidents and Catalog share one platform choice, listing only platforms with an enabled connection; each page then shows only that platform's datasets.
- **Dataset grouping.** The group (called Domain by default) comes from a table tag, the catalog, the schema, the connection or the owner, with a label you choose, set in `grouping:` in `config.yaml`. Which groups count as critical or financial, and per-group hints for rule discovery, are config too: nothing assumes an industry. A group typed on a dataset page is kept through syncs.

## Incidents and response

### Root-cause grouping

When checks fail, TCS DataTrustAI walks **upstream** through lineage, but only through tables that are also failing for a reason that could cause the symptom. For example, missing kWh downstream can come from missing values, volume, lateness or schema problems upstream, but not from orphan keys. The furthest such table is the **root cause**. Every failure with the same root on the same day joins **one incident**.

An incident resolves itself when all its checks pass again.

**Where:** Incidents, and the incident page (summary, evidence timeline, lineage around the root, failing checks with the SQL to find failing rows).

### Severity

The base is the highest severity among the failing rules. It goes up one level if 10 or more tables are downstream, and up one more if the dataset is certified (up to critical).

### Alerts

New incidents at or above `notifications.min_severity` (default high) are sent to:
- **Slack** (incoming webhook);
- **Microsoft Teams** (Workflows webhook, Adaptive Card);
- **email** (SMTP).

Every alert is logged under Settings > **Notifications**, including ones skipped because no channel is configured.

### Tickets

**Open ticket** on an incident creates a Jira issue or ServiceNow incident, with the evidence, affected tables and downstream impact. It runs as soon as you click. With no ticketing configured, you get a preview of the payload instead.

### Intelligent corrections (auto-correct)

Risk-scored corrections with undo are not available in this version. It is switched off with `features.fixes_and_quarantine: false` in config.yaml (the default); the code is kept so it can be switched back on.

### Quarantine management

Moving, copying or splitting bad rows into a quarantine table is not available in this version. It is switched off with `features.fixes_and_quarantine: false` in config.yaml (the default); the code is kept so it can be switched back on.

### Other fixes

Each incident also suggests these actions, in the platform's own SQL:

| Fix | What it does | Reversible |
|---|---|---|
| **Dedupe** | Keeps the first row per key | On Databricks via time travel |
| **Re-run job** | Triggers the Databricks job in the dataset's `pipeline_job_id` tag | Yes |
| **Notify owner** | Asks the source or OT owner to check a sensor, extractor or producer | Yes |

**Guardrails:**
- Every fix counts the affected rows first.
- Automatic fixes need `remediation.auto_enabled`, an allow-listed action type, and fewer rows than `max_rows_auto`. They never run on certified datasets.
- Anything outside these limits is skipped and logged; a person can run it from the incident.

### Feedback learning

**Was this alert right?** on an incident, or **False positive** on a rule, tunes the rules:

| Feedback | Effect |
|---|---|
| **False positive** | Anomaly rules get less sensitive (+0.5). Threshold rules get a *proposed* new threshold. After 3 false positives with no confirmed issues, disabling the rule is *proposed* |
| **Real issue** | Anomaly rules get slightly more sensitive |
| **Expected change** | The anomaly baseline restarts from now, for example after a planned migration |

Alert precision and noisy rules are shown under Explore > **Patterns and Insights** (Learnings).

## Impact analysis

Answers "what breaks if this is wrong, or if we change it?"

- **Scenarios:**
  - a **data quality problem** in a dataset (optionally limited to columns);
  - **dropping columns**;
  - **changing column types**.
- **Downstream reach:** every dataset reachable through lineage, with hops, owner, domain, certification, score and open incidents.
  - For column scenarios, the affected downstream columns come from column-level lineage. Where the platform doesn't provide it, columns are matched by name and labelled that way.
- **What's involved:**
  - active rules on the dataset that use the columns;
  - rules elsewhere that reference this dataset;
  - downstream rules on the same columns;
  - contracts (**breaking** for drops and type changes);
  - retention and masking policies tied to the columns.
- **Impact score** 0-100, with a level from low to critical. It weighs each downstream dataset by certification and domain criticality (finance, billing, regulatory, risk), discounted by distance, then adds affected rules, breaking contracts and certification of the source.
- **Owners to tell**, with **Notify owners** to send the summary through the configured alert channels (audited).

**Where:** a dataset's **Impact** tab (then **Open the full analysis**), or **Impact** on an incident. **Agent:** "what is the impact of dropping customer_id in meters?". **API:** `GET /api/impact?asset_id=&columns=&change=data|drop|retype`, `POST /api/impact/notify`.

## Insights

AI-written patterns, learnings and recommendations. The app computes the facts (recurring incidents per source and their usual day and cause, failure timing, hotspots, flaky and noisy rules, feedback); the LLM chosen in Settings > LLM writes them up.

- **Deterministic around the model.** Facts are computed in code and numbered. The instructions are built in and versioned. The model answers in a fixed JSON structure at temperature 0, every statement must cite facts, and any statement with a number that is not in the facts is dropped. The result is saved against a fingerprint of the facts, so unchanged data shows the same text whichever model is configured.
- **Three sections:** Insights (what is happening), Learnings (what the app learned from feedback and rule tuning), Recommendations (next steps with links).
- **Privacy:** the model sees counts, percentages, weekdays, causes and dataset names only, never rows.
- **No model:** the page asks you to configure one; nothing is guessed.
- **Refresh insights** syncs metadata and can run due checks first; it does not call the model.

**Where:** **Explore > Patterns and Insights**; the platform picker gives each platform its own saved text. **Agent:** "what patterns have you found?". **API:** `GET /api/ai-insights`, `POST /api/ai-insights/generate`; the computed facts are in `GET /api/insights?days=30`.

## Governance

### Sensitive-data detection

Detection combines column names with value patterns, and uses checksums where they exist (Luhn for card numbers).

| Sensitivity | Labels |
|---|---|
| Restricted | `ssn`, `credit_card`, `iban`, `passport`, `national_id` |
| Confidential | `email`, `phone`, `person_name`, `address`, `date_of_birth` |
| Internal | `ip_address`, `geo_location`, `customer_ref` |

**Scans.** A scan profiles each dataset (a small local sample, held in memory only) and stores the label, sensitivity and confidence of each column it recognises. Dismissed columns stay dismissed. Scan all datasets (or one platform, or only datasets never scanned) by hand, on a schedule, or right after a catalog sync; the last scan, its new columns and any datasets that failed are shown on the page. Datasets on a disabled connection are skipped.

**Where:** dataset page > **Rescan sensitive data**; Governance > **Sensitive data** for all datasets, with filters and bulk **Tag selected** / **Not PII**; Explore > Datasets shows a **Sensitive** column and a **Has sensitive data** filter. **Tag** writes the label to the platform; **Not PII** dismisses it. Neither needs a separate approval.

### Tag write-back

Approved tags are written natively:
- Unity Catalog tags (`ALTER TABLE ... SET TAGS`);
- Snowflake object tags;
- Lake Formation LF-tags;
- Purview classifications;
- Cognite time series metadata.

### Policies

Policies are written as code in `policies.yaml`, or created under Governance > **Policies** by an administrator, with no review step:
- **Suggest** proposes policies from your data (detected sensitive columns, missing owners, certified datasets, financial domains), from a reference standard, and from uploaded standard documents. Documents are read only when a model is configured, and only names and counts are sent, never data values.
- **Plain-English policy** turns a sentence such as "certified datasets must keep a DQ score of at least 95" into a policy. Common sentences are read by the built-in parser; others by the configured model, with fixed guidance.
- **Manual creation** is a form, with a JSON editor for anything it does not cover.

Everything is validated before saving: the type, severity, fields and sensitive-data labels, and any domain, column or name pattern must exist in your catalog. Each proposal shows how many violations it would raise now.

| Type | Requires | Can enforce |
|---|---|---|
| `masking` | Sensitive columns must be masked | Unity Catalog column mask, Snowflake masking policy, masked view (demo) |
| `retention` | Rows older than `max_age_days` are purged | `DELETE` older rows |
| `ownership` | `owner` (and `steward`) are set | - |
| `quality_gate` | Score ≥ `min_score` | - |
| `classification_required` | The dataset has been profiled and classified | - |
| `certification` | Certified datasets have an owner, a contract, and ≥ `min_rules` rules | - |
| `contract_required` | The dataset has a data contract | - |

A policy may have a `description`. It targets datasets with `applies_to`: `all`, `domain`, `fqn_pattern`, `certified`, `platform` or `classification`. **Enforce** runs the exact SQL at once; the statements and result are kept in the action history and audit log.

#### Policy scans and violations

A scan evaluates every enabled policy and keeps the result: the violations, when it ran, who or what started it, and counts by severity and policy. Compared with the previous scan, each violation is **new** or unchanged and the scan counts the violations that were **resolved**. The first scan has nothing to compare with. The last 100 scans are kept. Scans run on demand or on a schedule (every N minutes or hours, or daily at a time on chosen weekdays, UTC), and read metadata only.

**Where:** Operate > Explore > **Violations**. **API:** `POST /api/policy-scans/run`, `GET /api/policy-scans/latest`.

```yaml
- id: pii-masking
  type: masking
  applies_to: {classification: [email, phone, person_name]}
  labels: [email, phone, person_name]
  except_group: pii_readers
```

### Data contracts

These follow the Open Data Contract Standard (ODCS v3).
- **Generate** a contract from a dataset's active rules and ownership, edit it, then **Save as contract**.
- **Import** a contract: it creates the rules, owners and freshness SLA.
- **Validate against live schema** finds breaking changes (dropped or retyped columns) and warnings (additive or nullability changes).
- **CI gate:** `python -m dqga contract-check contract.yaml` exits 1 on breaking changes.

**Where:** dataset **Contract** tab; Governance > **Contracts**.

### Compliance evidence and standards

Each framework's controls are shown as met, partial or gap, scored from facts the app tracks: ownership, classification, masking, retention, rule coverage, lineage, contracts, incident response and audit trail.
- GDPR (Articles 5(1)(d), 5(1)(e), 25, 30, 32)
- SOX IT general controls
- NERC CIP (CIP-011, CIP-004, CIP-010, CIP-007)
- ISO 8000
- DAMA-DMBOK

Next to each standard the app shows which policy types cover it, and **Suggest policies for** it proposes the missing ones. Uploaded standards (reference kind "Policy or regulation") feed Suggest when a model is configured.

This is mapping guidance to organize evidence, not legal advice.

**Where:** Governance > **Standards**. **Agent:** "GDPR report".

### Business glossary

Business terms (definition, domain, synonyms) are linked to the datasets they describe. **Sync to Neo4j** mirrors terms, datasets, rules, owners and lineage into a graph.

### Ownership and certification

Set owner, steward and domain, and mark a dataset certified, on its **Overview** tab. Certification raises incident severity and turns on the certification policy. Governance > **Ownership** shows coverage and the datasets with no owner.

### Audit

There is no approvals inbox: tags, policy enforcement, corrections, remediation and tickets run when a person clicks them, and rules go live through the review queue. Every action (who, what, when) is in Settings > **Audit**. The user comes from the SSO header (`X-Forwarded-Email`) on Databricks Apps.

## Rules as files

Rules can be kept as files, which suits a repository, code review and CI. This works without any repository: download the files, edit them, import them back.

- **Format:** one YAML file per dataset (for example `dq-rules/utility/silver/customers.yaml`), with `format: datatrustai-rules/1`, the dataset's full name and a list of rules. Each rule has a `key` (type, column and name), its type, column, parameters, dimension, severity, threshold, category, description and schedule. Files hold names, thresholds and descriptions, never data values. Active and disabled rules are exported; drafts only when you ask.
- **Download:** AI Rule Studio > Rule catalog > **Download rule files** (one file for the chosen dataset, or a zip for all datasets), or `python -m dqga rules-export`.
- **Import:** **Import rule files…** reads .yaml files or a zip and shows what would happen before anything is saved. Everything arrives as **drafts** for the normal review. A new rule becomes a draft; a changed draft is updated; a changed live rule is saved as a new draft proposing the change, and the live rule stays as it is; an unchanged rule is skipped. Rules that are in the app but not in the files are only listed. Nothing is ever deleted or changed while live.
- **Matching:** a rule is matched by its `key`, which comes from its type, column and name, so renaming a rule in a file makes it a new rule. The dataset must be named in full and exist in the catalog.
- **Checks:** an unknown dataset, column or rule type, a bad format or YAML that does not parse is reported, and nothing is saved while any file or rule is invalid.
- **Git (optional, GitHub):** with `features: git_sync: true`, administrators connect a repository in **Settings > Git**, and **Export to Git…** in the Rule catalog writes the rule files in one commit. The default is a **pull request** from a new branch, so nothing changes on the base branch until it is merged; the other option commits straight to the base branch (never forced). Files are added or updated and nothing in the repository is deleted. If the repository already matches, nothing is committed. It uses the GitHub REST API over HTTPS (no git program, no clone). The access token (a fine-grained token with Contents and Pull requests read and write on one repository is enough) is stored encrypted and never returned. GitHub Enterprise works through the API address setting. Without the feature flag, or without a repository, none of this appears and the app works as before. Importing the merged files back is by download and **Import rule files…** for now.
- **CI:** `python -m dqga rules-validate dq-rules/` checks the files against the catalog and exits 1 on any problem. `rules-import PATH` previews, and `--apply` saves drafts.

## Rule export

Export rules to the tools your teams already run. Rules a format can't express are listed by name, never dropped silently.

| Format | File | Best for |
|---|---|---|
| Databricks DQX | `.yaml` | PySpark jobs and Lakeflow pipelines using `databrickslabs/dqx` |
| Databricks Lakeflow expectations | `.sql` | Declarative pipelines (`CONSTRAINT ... EXPECT`) |
| SQL validation queries | `.sql` | Any SQL editor or scheduler, in the dataset's own dialect |
| Great Expectations (GX 1.x) | `.json` | GX Core expectation suites |
| Soda (SodaCL) | `.yml` | soda-core scans |
| dbt tests | `.yml` | dbt `schema.yml` (uses dbt_utils and dbt_expectations) |
| PyDeequ | `.py` | Deequ on Spark, EMR or Glue |
| Snowflake Data Metric Functions | `.sql` | Native Snowflake DQ monitoring |
| AWS Glue DQDL | `.dqdl` | Glue Data Quality rulesets |
| TCS DataTrustAI JSON | `.json` | Backup, or moving rules between environments |

**Where:** AI Rule Studio > **Rule catalog**: tick rules and click **Export selected** to export exactly those (any status; one dataset gives a file, several give a zip), or **Export a whole dataset**. Also the dataset **Rules** tab. Choose a dataset (or **All datasets**) and a **Format**, then **Copy**, **Download**, or **All formats (.zip)**. **Agent:** "export soda for meters". **CLI:** `python -m dqga export --asset <name> --target soda`.

## Lineage

Lineage drives root-cause analysis, blast radius, incident severity and scheduling priority. It comes from:
- Databricks `system.access.table_lineage` and `column_lineage`;
- Snowflake ACCESS_HISTORY;
- Purview lineage;
- OpenLineage events (Spark, Airflow);
- dbt `manifest.json`;
- edges you add by hand.

**Where:** Impact analysis > **Lineage** (the whole graph across platforms) and each dataset's **Lineage** tab. Nodes are colored by health, with a platform-colored stripe.

## The agent

Ask in plain language from any page. It knows the dataset or incident you're looking at.

**Its 26 tools:** rule discovery, anomalies, impact analysis, insights, and:
- overview
- search datasets
- dataset details
- profile
- list rules
- run checks
- lineage
- incidents
- incident details
- root cause
- metric history
- policies
- compliance
- glossary
- export rules
- export contract
- suggest rules
- rule from text
- find PII
- propose fixes
- open ticket
- record feedback

How it behaves:
- **Facts come only from tools.** Each answer shows which tools ran.
- **It does not change data.** Corrections, remediation and tagging are suggestions for a person to apply. Rules it creates are drafts for the review queue. Opening a ticket is the only action it runs.
- **It never sees raw rows,** only schemas, profile statistics (including the most common values per column), aggregates and the reference-file summary.

**Models.** One LLM serves the whole app: the agent, AI rule generation, Plain-English rule and rule suggestions. Administrators manage it in **Settings > LLM**: a list of saved connections (name, provider, model, key status) with one **in use**, **Add**, **Edit**, **Test**, **Use** and **Delete**, and a **Test connection** button that sends a one-word request and reports a rejected key, a wrong model or an unreachable service. API keys are stored encrypted (key from `DQGA_SECRET_KEY`, or `data/.secret_key`) and never shown again. The `llm:` section of config.yaml is the fallback when no saved connection is in use.

| Provider | Notes |
|---|---|
| none (`rules`, default) | No LLM; a built-in router answers common questions; AI rule generation needs a model |
| `databricks` | Model Serving: the model is the serving endpoint name (not a Unity Catalog path), using the app's service principal or your token |
| `ollama` | Local models |
| `anthropic` | Anthropic API, called over HTTP (no extra package) |
| `anthropic_bedrock` | Anthropic models on AWS Bedrock (needs `anthropic` and `boto3`) |
| `gemini` | Google Gemini with an AI Studio API key |
| `openai_compatible` | OpenAI, Azure OpenAI / AI Foundry, vLLM or similar |

If the model fails, it falls back to the router and says so.

## Users and access

### Sign-in modes

| `auth.mode` | Who signs in, and how | Use it for |
|---|---|---|
| `local` (default) | Built-in accounts: sign-up, sign-in, and a separate administrator sign-in | Laptops, VMs, containers |
| `sso` | The platform's single sign-on. The app trusts `X-Forwarded-Email` and creates the account on first visit | Databricks Apps (default in `config.databricks.yaml`) or behind an SSO proxy |
| `none` | Nobody signs in; everyone has full access | Single-user demos and tests |

### Accounts and sign-up

- **First run:** the first visit shows **Set up TCS DataTrustAI**, which creates the administrator. There are no default passwords. For unattended installs, set `DQGA_ADMIN_EMAIL` and `DQGA_ADMIN_PASSWORD`, or run `python -m dqga create-user --role admin`.
- **Sign-up** (`auth.signup`):
  - `approval` (default): new accounts wait for an administrator;
  - `open`: new accounts work immediately;
  - `disabled`: only administrators create accounts.
- **Administrator sign-in** only lets administrator accounts in, and opens the Admin console.

### Roles

| Role | Can |
|---|---|
| **admin** | Everything, plus approving, rejecting and activating rules, changing live rules, the LLM, the Admin console, adding connections, saving policies, Settings > Environment, resetting data, loading the demo, and deploy packages |
| **steward** | Monitor, profile, author rules (save drafts and send them for approval), triage incidents, approve changes, governance |
| **viewer** | See everything and ask the agent, but not change anything |

The server enforces roles on every request, not only in the UI. New sign-ups and SSO users get `auth.default_role` (steward by default). In SSO mode, emails in `auth.admins` become administrators; if that list is empty, the first person to open the app does.

### Admin console

Administrators can:
- approve or reject sign-ups;
- change roles;
- disable or enable accounts;
- reset passwords (a one-time temporary password, plus a forced change at next sign-in);
- unlock locked accounts;
- delete accounts;
- add users directly.

The last active administrator can't be removed. See [UI guide](ui-guide.md#admin-console).

### Security

- **Passwords:**
  - hashed with PBKDF2-HMAC-SHA256 (600,000 iterations, random salt);
  - at least 10 characters, with letters and numbers;
  - can't contain your name or email, or be a common password.
- **Sessions:**
  - random 256-bit tokens in an HttpOnly, SameSite=Lax cookie (Secure over HTTPS);
  - only a hash of each token is stored;
  - they expire after `auth.session_hours` (12 by default).
- **Lockout:** after `auth.max_failed_logins` (5) wrong passwords, the account locks for `auth.lockout_minutes` (15). Error messages never reveal whether an email has an account.
- **CSRF:** every change must carry `X-Requested-With: DataTrustAI`, on top of SameSite cookies.
- **Audit:** sign-ins, failed sign-ins, lockouts, sign-ups, approvals, role changes, resets and deletions are all in Settings > Audit.

## Platform and operations

### Configuration and environment variables

Values resolve in this order: real environment variables, then `.env`, then `config.yaml` (with `${VAR}` references), then defaults. `DQGA__SECTION__KEY` overrides any setting. Settings > **Environment** shows what's set, with secrets hidden. See [Configuration](configuration.md).

### Demo data

A ready-made utility lakehouse (smart meters, customers, billing, finance, sensors) on a local DuckDB file, with incidents, anomalies, insights, run history, schedules, rules in every review state, approvals, custom metrics and reference files, so every screen has content.
- **Into the app you already use:** Settings > Maintenance > **Load demo data**, or `python -m dqga demo --add`. Your datasets, rules and settings are not touched; delete the `demo` connection to remove it.
- **A separate copy:** `python -m dqga --config config.demo.yaml demo`, then `serve --port 8770`, with its own database.
- Plain `python -m dqga demo` recreates the whole app database: don't use it against real platforms.

### Deployment targets

Deploy chooses between six targets, each with steps and a package download:
- Databricks Apps
- Snowpark Container Services
- Azure Container Apps
- AWS App Runner
- Docker / Kubernetes
- local or VM

Targets are defined in `dqga/deploy_targets.yaml`: add an entry to offer a new platform. See [Set up with Databricks](databricks-setup.md).

### Security model

- **Sign-in and roles.** See [Users and access](#users-and-access).
- **Read-only by default.** Changes run only when a person clicks them (rules go through review), and every one is audited.
- **Safe SQL.** User-written SQL is limited to read-only boolean expressions, identifiers are validated, and values are escaped.
- **Secrets stay in environment variables.** The UI never shows them, and the app package and container image never include `.env`.
- **On Databricks Apps,** the app queries as its service principal, so anyone who can open the app sees what the service principal can read.

### Persistence

The app's own data (rules and their review history, results, runs, schedules, incidents, approvals, settings such as the LLM connections, audit) lives in SQLite by default. Use Postgres in production, or `DQGA_DATABASE_URL=lakebase` for Databricks Lakebase on Databricks Apps.
