# Configuration and environment

## Files

| File | Purpose |
|---|---|
| `config.yaml` | Main configuration for local, VM and container runs |
| `config.demo.yaml` | A self-contained demo: its own app database (`data/demo.db`) and a local DuckDB utility warehouse, no sign-in. Use `--config config.demo.yaml demo` to build it. Never touches your real setup |
| `config.databricks.yaml` | Configuration used when running as a Databricks App (set by `app.yaml`) |
| `.env` | Your environment variables. Copy it from `.env.example`. Never commit it; it's never packaged |
| `policies.yaml` | Governance policies, loaded into the app on startup |
| `app.yaml`, `databricks.yml` | Databricks App runtime and bundle |
| `dqga/deploy_targets.yaml` | Platforms offered on the Deploy page |
| `docs/index.yaml` | Documents shown in the in-app Guide |

## How values are resolved

From highest priority to lowest:

1. **Real environment variables.** On Databricks Apps these come from `app.yaml` and app resources. In containers they come from the platform's settings.
2. **`.env`.** It never overrides a variable that's already set, and empty values are ignored. It's looked up at `$DQGA_ENV_FILE`, then `./.env`, the project root, and next to the config file. Use `--env-file <path>` on the CLI, or `DQGA_ENV_FILE=none` to turn it off.
3. **`config.yaml`.** Any value can reference a variable as `${VAR}` or `${VAR:-default}`. A value that is only a reference becomes a number or true/false where it looks like one.
4. **Built-in defaults.**

Two more ways to set values:

- **Secrets via `*_env` keys.** Instead of `token: dapi...`, write `token_env: DATABRICKS_TOKEN`, so the secret stays in the environment.
- **Override any setting** with `DQGA__SECTION__KEY=value`, for example `DQGA__SCHEDULER__ENABLED=false` or `DQGA__REMEDIATION__MAX_ROWS_AUTO=500`.

Shortcuts: `DQGA_CONFIG` (config file path), `DQGA_DATABASE_URL`, `DQGA_LLM_PROVIDER`, `DQGA_LLM_MODEL`, `DQGA_LLM_BASE_URL`.

**Settings > Environment** shows:
- where the app runs;
- which `.env` files were loaded and which config file is in use;
- every known variable, whether it's set, and where it came from.

Secret values are never shown. Restart the app after changing `.env`.

## config.yaml reference

### app

| Key | Default | Meaning |
|---|---|---|
| `name` | TCS DataTrustAI | Display name |
| `database_url` | `sqlite:///data/dqga.db` | App database: SQLite, `postgresql+psycopg://...`, or `lakebase` |
| `db_schema` | none | Postgres or Lakebase schema for the app's tables (use `dqga`) |
| `quarantine_schema` | `dq_quarantine` | Where quarantined rows are copied |
| `actor` | `steward` | User name when no SSO header is present |

### llm

| Key | Default | Meaning |
|---|---|---|
| `provider` | `rules` | `rules`, `databricks`, `ollama`, `anthropic`, `anthropic_bedrock`, `gemini`, `openai_compatible` |
| `model` | `qwen2.5:7b` | Model, or Model Serving endpoint name |
| `base_url` | `http://localhost:11434` | Ollama or OpenAI-compatible endpoint |
| `api_key_env` | none | Environment variable that holds the API key |
| `max_steps` | 8 | Tool calls per question |
| `timeout_s` | 120 | Request timeout |
| `api_version`, `azure` | - | Azure OpenAI: API version, and `azure: true` to use the `api-key` header |
| `aws_region` | - | `anthropic_bedrock` region |

The LLM can also be chosen in the app, in **Settings > LLM**, where administrators keep a list of saved connections (one is in use) and test each one. Saved connections are stored in the app database (the API key encrypted) and takes precedence over `llm:` here and over `DQGA_LLM_*`; **Use config.yaml instead** removes it. The encryption key comes from `DQGA_SECRET_KEY` when set, otherwise from the file `data/.secret_key`, created on first use. On Databricks Apps or in a container, set `DQGA_SECRET_KEY` so saved keys survive a restart, or keep the key in an environment variable and enter its name instead.

### features

| Key | Default | Meaning |
|---|---|---|
| `git_sync` | `false` | Shows Settings > Git and **Export to Git…** in the Rule catalog, to write rule files to a GitHub repository. Off: those screens and the `/api/git` endpoints are absent (404). Rule files can always be downloaded and imported by hand |
| `fixes_and_quarantine` | `false` | Corrections, auto-correct and quarantine of bad rows. Off: the page, the incident actions, the agent tools, the `/api/fixes` and `/api/quarantine` endpoints, the demo data and any mention in the AI insights are all hidden, and nothing is corrected automatically. The `remediation` keys for corrections and quarantine below apply only when it is on |

### grouping

How datasets are grouped across the app: the Overview filter and heat map, incident charts, the Catalog column and policies. It used to be called the domain and was assumed to be a utility's; nothing is assumed now.

| Key | Default | Meaning |
|---|---|---|
| `label` | `Domain` | What the UI calls it: `Domain`, `Business unit`, `Data product`... |
| `source` | `tag` | Where a dataset's group comes from: `tag` (a table tag), `catalog`, `schema`, `connection` or `owner` |
| `tag` | `domain` | Tag name when `source` is `tag` (Unity Catalog or Snowflake tag) |
| `critical` | `[]` | Groups whose breakage counts double in impact analysis and that count as critical in compliance |
| `financial` | `[]` | Groups the governance rules treat as financial data (retention rules) |
| `hints` | `{}` | `{group: sentence}`, business context for AI rule generation, for example `finance: amounts must never be negative` |

A group typed on a dataset page is kept through syncs; clearing it hands the dataset back to `source`. After changing `source`, restart and use **Settings > Connections > Dataset grouping > Re-apply to all datasets**. The bundled `config.yaml` sets the demo's utility values; the lists are empty by default.

### scheduler

| Key | Default | Meaning |
|---|---|---|
| `enabled` | true in `config.yaml` | Run checks in the background |
| `tick_seconds` | 300 | How often to look for due checks |
| `default_interval_minutes` | 60 | How often each rule runs, unless the rule sets `schedule_minutes` |
| `daily_budget_seconds` | 3600 | Maximum compute seconds per day for scheduled checks |
| `change_aware` | true | Skip tables that haven't changed (freshness still runs) |

### notifications

| Key | Default | Meaning |
|---|---|---|
| `min_severity` | `high` | Lowest incident severity that sends an alert |
| `base_url` | `http://127.0.0.1:8000` | Link target in alerts |
| `slack_webhook_env` | `DQ_SLACK_WEBHOOK` | Slack incoming webhook |
| `teams_webhook_env` | `DQ_TEAMS_WEBHOOK` | Teams Workflows webhook |
| `smtp` | none | `{host, port, from, to: [...], user_env, password_env, starttls}` |

### ticketing

| Key | Meaning |
|---|---|
| `provider` | `none` (preview only), `jira`, or `servicenow` |
| Jira | `base_url_env`, `user_env`, `api_token_env`, `project_key`, `issue_type` |
| ServiceNow | `instance_url_env`, `user_env`, `password_env`, `assignment_group` |

### remediation

| Key | Default | Meaning |
|---|---|---|
| `auto_enabled` | false | Allow fixes without approval, within the limits below |
| `allowed_auto_actions` | `[quarantine]` | Fix types that may run automatically |
| `max_rows_auto` | 10000 | Larger automatic fixes and quarantine batches are skipped (a person can run them) |
| `auto_correct_low_risk` | false (true in the demo `config.yaml`) | Apply low-risk corrections automatically after a failing check, then re-check |
| `auto_correct_max_rows` | 1000 | Corrections larger than this are at least medium risk |
| `quarantine_retention_days` | 30 | Quarantine batches are purged after this many days (0 keeps them) |

### auth

| Key | Default | Meaning |
|---|---|---|
| `mode` | `local` | `local` (built-in accounts), `sso` (trust `X-Forwarded-Email`, used on Databricks Apps), `none` (no sign-in) |
| `signup` | `approval` | `approval` (an administrator approves new accounts), `open`, or `disabled` |
| `default_role` | `steward` | Role for new sign-ups and SSO users: `admin`, `steward` or `viewer` |
| `session_hours` | 12 | How long a sign-in lasts |
| `max_failed_logins` | 5 | Wrong passwords before the account locks |
| `lockout_minutes` | 15 | How long it stays locked |
| `min_password_length` | 10 | Minimum password length (letters and numbers are always required) |
| `admins` | `[]` | SSO mode: emails that become administrators. If empty, the first user does |

Bootstrap an administrator without the setup screen by setting `DQGA_ADMIN_EMAIL` and `DQGA_ADMIN_PASSWORD` (and optionally `DQGA_ADMIN_NAME`). Remove the password from the environment after the first start.

### governance, profiling, timeseries

| Key | Default | Meaning |
|---|---|---|
| `governance.policies_file` | `policies.yaml` | Policies to load |
| `governance.neo4j` | none | `{uri_env, user_env, password_env, database}` for glossary sync |
| `governance.retention_days` | 2555 (7 years) | Retention period for proposed Data governance retention rules, unless a policy reference file states one |
| `governance.llm_context_chars` | 8000 | Most characters of reference-file context sent to the model per request |
| `profiling.sample_rows` | 500 | Rows sampled for patterns and personal-data detection |
| `profiling.max_top_value_columns` | 15 | Columns that get top-value lists |
| `profiling.column_batch` | 20 | Columns per profiling query |
| `timeseries.max_rows` | 200000 | Maximum readings fetched per time-series check |

## Connection examples

Add these under `connections:`, or paste the inner settings as JSON under Settings > Connections > **Add a connection**.

**Databricks:**

```yaml
- name: databricks
  type: databricks
  host_env: DATABRICKS_HOST            # not needed on Databricks Apps
  token_env: DATABRICKS_TOKEN          # or `profile: <cli profile>` for OAuth; omit on Databricks Apps
  warehouse_id: ${DATABRICKS_WAREHOUSE_ID}
  catalogs: [main]
  schemas: [bronze, silver, gold]      # optional
  column_lineage: true
  lineage_days: 30
```

**Snowflake (key-pair):**

```yaml
- name: snowflake
  type: snowflake
  account_env: SNOWFLAKE_ACCOUNT
  user_env: SNOWFLAKE_USER
  private_key_file_env: SNOWFLAKE_KEY_FILE
  warehouse: COMPUTE_WH
  role: DQ_READER
  databases: [ANALYTICS]
```

**Cognite Data Fusion:**

```yaml
- name: cdf
  type: cognite
  project_env: CDF_PROJECT
  base_url: https://westeurope-1.cognitedata.com
  tenant_id_env: AZURE_TENANT_ID
  client_id_env: CDF_CLIENT_ID
  client_secret_env: CDF_CLIENT_SECRET
  timeseries_limit: 2000
```

**AWS Glue and Athena:**

```yaml
- name: aws
  type: aws_glue
  region: eu-west-1
  databases: [lake]
  athena_output: s3://my-athena-results/
  glue_role_arn_env: GLUE_DQ_ROLE_ARN
```

**Azure Purview** (catalog and lineage; pair it with a SQL connection for checks):

```yaml
- name: purview
  type: azure_purview
  account: my-purview
  tenant_id_env: AZURE_TENANT_ID
  client_id_env: PURVIEW_CLIENT_ID
  client_secret_env: PURVIEW_CLIENT_SECRET
```

**Apache Spark:**

```yaml
- name: spark
  type: spark
  master: local[*]              # or `databricks_connect: true`
  databases: [default]
```

## LLM examples

**Databricks Model Serving:**

```yaml
llm: {provider: databricks, model: <serving-endpoint-name>}
```

The model is the endpoint name shown under **Serving** (for example `databricks-meta-llama-3-3-70b-instruct`), not a Unity Catalog model path such as `system.ai.<model>`. The app calls `/serving-endpoints/<name>/invocations`.

**Local Ollama:**

```yaml
llm: {provider: ollama, model: qwen2.5:7b, base_url: http://localhost:11434}
```

**Google Gemini** (a Gemini API key from Google AI Studio; called through Google's OpenAI-compatible endpoint):

```yaml
llm: {provider: gemini, model: gemini-2.5-flash, api_key_env: GEMINI_API_KEY}
```

**Anthropic** (called over HTTP; no extra package needed. Only `anthropic_bedrock` needs `pip install anthropic boto3`):

```yaml
llm: {provider: anthropic, model: claude-sonnet-5-5, api_key_env: ANTHROPIC_API_KEY}
```

**Azure OpenAI / AI Foundry:**

```yaml
llm:
  provider: openai_compatible
  base_url: https://<resource>.openai.azure.com/openai/deployments/<deployment>
  api_version: 2024-10-21
  azure: true
  api_key_env: AZURE_OPENAI_KEY
```

## Environment variables

`.env.example` lists every variable, grouped by platform:
- **App:** `DQGA_*`
- **Access:** `DQGA_ADMIN_EMAIL`, `DQGA_ADMIN_PASSWORD`, `DQGA_ADMIN_NAME`
- **Databricks:** `DATABRICKS_HOST`, `DATABRICKS_TOKEN`, `DATABRICKS_CONFIG_PROFILE`, `DATABRICKS_WAREHOUSE_ID`
- **Snowflake:** `SNOWFLAKE_*`
- **Cognite:** `CDF_*`, `AZURE_TENANT_ID`
- **Azure:** `PURVIEW_*`, `AZURE_OPENAI_KEY`
- **AWS:** `AWS_PROFILE`, `AWS_REGION`, `GLUE_DQ_ROLE_ARN`
- **LLM:** `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `OPENAI_API_KEY`; `DQGA_SECRET_KEY` (encrypts API keys saved in Settings > LLM)
- **Alerts:** `DQ_SLACK_WEBHOOK`, `DQ_TEAMS_WEBHOOK`, `SMTP_*`
- **Ticketing:** `JIRA_*`, `SNOW_*`
- **Graph:** `NEO4J_*`

Databricks Apps and Lakebase set their own variables: `DATABRICKS_APP_NAME`, `DATABRICKS_APP_PORT`, `DATABRICKS_CLIENT_ID`, `DATABRICKS_CLIENT_SECRET`, `PGHOST`, `PGUSER` and `PGDATABASE`.
