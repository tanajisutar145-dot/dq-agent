The LLM is used in four places, always through the one connection in Settings > LLM. Everything it returns is checked by the app before anything is saved.

**1. AI rule discovery (the main use)**
- **What is sent:** the table name and description, the row count, and for each column the profile statistics: data type, null rate, distinct count, min, max, mean, the most common values and detected patterns. If reference files apply to the dataset, a text summary of them is added too, capped at 8,000 characters by default (`governance.llm_context_chars`).
- **What isn't sent:** the rows themselves. The most common values per column are real values, so they do leave the app. Keep that in mind for sensitive columns.
- **What it must return:** JSON in the form `{"rules": [...]}`.
- **Validation:** each rule is checked against the app's own rule types and columns. Invalid or unknown rules are dropped silently, and columns that don't exist are rejected.
- **Scoring:** valid rules join the other evidence sources (statistics, history, reference files and so on) at a base confidence of 0.7. Rules from several sources are merged and agreeing sources raise the score.
- **Dry run:** every candidate is dry-run on your platform, and the result adjusts the confidence.
- **Saving:** you save the ones you want as drafts; nothing is stored automatically.
- **Without a model:** discovery stops with an error unless you untick **Use the AI model**.

**2. Describe a rule (plain English)**
The built-in parser tries first. The model is only a fallback when the parser can't read the sentence; it is asked for one rule as JSON, which goes through the same validation and dry run. With no model configured, only the built-in parser runs.

**3. Suggest rules (dataset page button)**
This uses the same suggestion call as discovery, mixed with the statistical suggestions.

**4. The agent panel**
The model runs the tool loop that answers your questions. The agent only suggests changes; it runs nothing except opening a ticket. With no model it uses a built-in keyword router.

**What the model never does:** it doesn't run SQL against your data, activate rules, or change anything. Rules it proposes become drafts, and only an administrator can approve and activate them.

--------------------

The app uses two kinds of database, and they do different jobs.

**1. The app's own database (rules, results, incidents, settings, users).**
- **Default:** SQLite, a single file at `data/dqga.db`, set by `app.database_url: sqlite:///data/dqga.db` in `config.yaml`. It is created automatically on first start and new columns are added automatically when you upgrade.
- **Production option:** any SQLAlchemy URL works. Postgres is the recommended one, for example `postgresql+psycopg://...` (the driver is in `requirements.txt`).
- **Databricks Apps:** set `database_url: lakebase` to use Lakebase, which is Postgres on Databricks. The app reads the `PG*` variables that Databricks supplies and refreshes its OAuth token itself. I haven't tested this on a real Databricks App.
- **Override:** you can also set the URL with `DQGA_DATABASE_URL` in `.env`.

It holds datasets, rules and their history, check results, runs, schedules, incidents, action history, users and sessions, the audit log, settings such as the LLM connections (API keys encrypted), reference files, quarantine and fix records.

**2. The data being checked (not the app's database).**
Your data stays on its platform: Databricks, Snowflake, Spark, and so on. The app only sends it queries. The demo warehouse is a local DuckDB file, `data/utility.duckdb`, which is demo data only.

**Optional:** Neo4j is used only to sync glossary terms. It isn't needed for the app to run.

Resetting the app data in Settings > Maintenance clears only the app's own database, never your platforms.

---------------------------------------------

There are only two real config files, and each is used in a different place. The other copies are my test setups.

**In the project folder**
- **`config.yaml`** is the default for running on your machine. It is set up for the demo: DuckDB demo connection, scheduler on, utility grouping values, and so on.
- **`config.databricks.yaml`** is used when the app runs as a Databricks App. `app.yaml` points the app at it with an environment variable. It differs from `config.yaml` in the places a deployed app needs: no demo connection, a note to use Lakebase instead of the local SQLite file, no model required, and the background scheduler off. The deploy package includes both, so the same code runs in either place.
- **`policies.yaml`** is a different kind of file. It holds governance policies as code, not app settings.
- **`app.yaml`** and **`databricks.yml`** configure the Databricks deployment itself (start command, resources). They aren't app settings either.

**Outside the project**
I created copies of `config.yaml` in a temporary scratch folder to test against a throwaway database, so your real data and settings weren't touched. They have no effect on your app, and nothing in the project depends on them.

**Which one is used**
The app picks the file with `--config <path>`, or `DQGA_CONFIG` in `.env`, and falls back to `config.yaml`. Any value can also be overridden by an environment variable (`DQGA__SECTION__KEY`), so you rarely need a third file. If you only run locally, you can ignore `config.databricks.yaml`.

-----------------------------------

The chatbot only sees what its tools return. It doesn't have blanket access to your databases, platforms or project files.

**What it can read**
Its 28 tools mostly read the app's own database and answer from it:
- **Health and datasets:** overall scores and the group heat map, dataset details with columns and latest check results, and the open incidents with their root-cause evidence.
- **Rules and runs:** the rules on a dataset, and the history of metrics such as row count and null rate.
- **Governance:** lineage, policy checks, compliance evidence, glossary terms and data contracts.
- **Findings:** anomalies, impact analysis, insights and quarantine status.

**What it can do on your platforms**
- **Run checks and profile:** it can run a dataset's active checks, and profile a dataset (which reads statistics and looks for sensitive columns). These send read-only queries to your platform.
- **Dry runs:** drafting a rule from text runs it on the platform and returns the result.
- **No SQL of its own:** it has no tool for writing or running arbitrary SQL. It can only trigger the checks and statistics the app already defines.

**What it can change**
- **Suggestions only:** rules it suggests become drafts, and tagging and fixes are listed for a person to apply.
- **Feedback:** recording feedback on a rule or incident is the only thing it does directly.
- **Activating rules:** only an administrator can approve and activate a rule in the review queue.

**What the language model sees**
It sees your question, the tool results from the steps above (including the dataset, rule and incident details they return), and some chat history. It doesn't see your whole database, your project files or your platform tables. If an LLM isn't working, a built-in keyword router answers using the same tools.

**What it doesn't have**
It can't browse your connected platforms freely, read tables you haven't synced, or see data outside what its tools return. Reference files are used for rule generation, not for the chat.

----------------------------------------------------------------------------------------------

Insights are computed in plain code from data the app already stores, so no LLM is involved. The code is `dqga/insights.py`, behind `GET /api/insights`. Each time you open the page it works everything out fresh.

**Inputs**
- **Check results:** every stored check outcome in the last 30 days.
- **Incidents:** the incident list, including their root causes and downstream impact.
- **Feedback and rules:** your feedback on rules and incidents, and the rules themselves.
- **Corrections and quarantine:** corrections applied and rows quarantined or released.

If the platform picker is set, all of this is limited to that platform's datasets.

**What it works out**
- **Failure timing:** it counts failed checks by weekday and hour, giving the heat map and the "most failures on Mondays" style findings.
- **Hotspots:** datasets ranked by number of failed checks, with a failure rate.
- **Failure types:** which quality dimension fails most.
- **Recurring incidents:** it groups incidents by root dataset. A source with two or more incidents is "recurring", with its usual weekday, the most common cause, average time to fix, and how many datasets downstream were hit.
- **Source impact:** which sources' problems reach the most downstream datasets.
- **Flaky rules:** rules that flip between pass and fail at least three times across at least four runs.
- **Learnings:** alert precision from your true/false-positive feedback, noisy rules (marked false positive at least twice and never confirmed), the tuning each piece of feedback caused, and counts of corrections, quarantined rows and rules by origin.

**Highlights**
It then turns the strongest findings into up to 8 plain-language sentences with a suggested action. For example, "ami_raw caused 5 incidents in 30 days, most often on Mondays. Usual cause: late or failed load upstream." Each one follows a fixed template:
- **When it appears:** each template shows only when its condition is met, such as a repeat source, a weekday with at least twice the average failures, or an hour holding at least a quarter of failures.
- **Advice text:** the advice is fixed per case, for example a freshness SLA suggestion for Monday failures.

**Why a page can look empty**
- **Few checks or incidents yet:** a new database has little to find. Run checks a few times first.
- **Repeats needed:** recurring incidents need at least two incidents on the same source.
- **Feedback and corrections:** the learnings need those actions to exist.

**Refresh insights** doesn't change how insights are computed. It syncs metadata and can run checks first, so there is fresh data to analyse. The demo data seeds 30 days of history so every part has content.

The model isn't used here. The agent can answer "what patterns have you found?" by reading these same results.