# Set up TCS DataTrustAI with Databricks

There are two ways to use TCS DataTrustAI with Databricks. Both are also described on the app's **Deploy** page:

- **Path A, run locally against your workspace.** The fastest way to try it on real tables (about 15 minutes).
- **Path B, deploy as a Databricks App.** The team setup: SSO, no personal tokens, runs next to your data.

Do Path A first if you can. It confirms access and permissions before you deploy anything.

---

## What you need

| Requirement | Why | How to check |
|---|---|---|
| Unity Catalog workspace | Metadata, tags, masks, and lineage all come from Unity Catalog | Catalog Explorer shows your catalogs |
| A SQL warehouse (serverless recommended) | Runs profiling and checks | Compute > SQL warehouses. Serverless starts in seconds; classic can take minutes, so the first check feels slow |
| `system.access` system schema enabled | Lineage (`system.access.table_lineage`, `column_lineage`) | Run `SELECT * FROM system.access.table_lineage LIMIT 1`. If it fails, ask an account admin to enable it, for example `databricks system-schemas enable <metastore-id> access` |
| Databricks CLI, recent version | Login and deployment | `databricks --version`. Upgrade if `bundle validate` doesn't recognise `apps` |
| Python 3.10+ | Local run | `python --version` |
| Path B only: Databricks Apps enabled | Hosting | Compute > Apps is visible |
| Path B, recommended: a Lakebase database instance | Keeps rules, incidents, action history and audit across restarts | Compute > Lakebase / database instances |

Find your **warehouse ID** under Compute > SQL warehouses > your warehouse > Connection details. The HTTP path ends in `/sql/1.0/warehouses/<warehouse-id>`.

---

## Path A: run locally against your workspace

### 1. Install

```bash
cd C:\tms-code\dq-governance-agent
.venv\Scripts\activate
pip install -r requirements.txt
pip install -e .
```

### 2. Log in

Choose one:

**OAuth (recommended, no long-lived token):**

```bash
databricks auth login --host https://<your-workspace-url> --profile dq
```

**Personal access token:** create one under Settings > Developer > Access tokens. Then put it in `.env` (copy `.env.example` to `.env`):

```
DATABRICKS_HOST=https://<your-workspace-url>
DATABRICKS_TOKEN=<token>
DATABRICKS_WAREHOUSE_ID=<warehouse-id>
```

`.env` is loaded at startup, never overrides variables already set in your shell, and is excluded from the Databricks App package. **Settings > Environment** in the UI confirms which variables were picked up, without showing secret values.

### 3. Create a local config

Copy `config.yaml` to `config.local.yaml`. In the copy, replace the `connections:` section with:

```yaml
connections:
  - name: databricks
    type: databricks
    profile: dq                         # if you used OAuth login; otherwise remove this line
    # host_env: DATABRICKS_HOST         # if you used a token
    # token_env: DATABRICKS_TOKEN
    warehouse_id: ${DATABRICKS_WAREHOUSE_ID}   # read from .env or the environment
    catalogs: [main]                    # catalogs to monitor
    schemas: [bronze, silver, gold]     # optional: start small
    column_lineage: true
```

Keep the demo `duckdb` connection too if you want both.

### 4. Start and connect

```bash
python -m dqga --config config.local.yaml serve
```

Open http://127.0.0.1:8000, then:

1. Go to **Settings > Connections** and click **Test** on `databricks`. You should see "Connected as <you> (catalog ...)".
2. Click **Sync**. Your tables appear under **Explore > Datasets** and lineage on each dataset's **Lineage** tab.
3. Continue with "First run" below.

Locally, the agent queries as **you**, so it sees exactly what you can see.

---

## Path B: deploy as a Databricks App

The app runs as its own **service principal**. Databricks injects its OAuth credentials, so no tokens are stored anywhere. Users sign in with workspace SSO, and their email is recorded in the audit log. The top bar shows **Databricks Apps** when it's running there.

### 0. Get the app package

Choose one:
- On the app's **Deploy** page (running locally), click **Download the Databricks App package (.zip)**.
- Run `python -m dqga package-app`, which writes `dist/tcs-datatrustai-databricks-app.zip`.
- Deploy straight from this project folder.

The package holds only what the app needs: code, `app.yaml`, the bundle, configs and docs. It never includes `.env`, data, the venv or tests. Extract it and run the steps below inside the extracted `tcs-datatrustai` folder.

### 1. Configure

Edit `config.databricks.yaml`:

- `connections[0].catalogs`: the catalogs to monitor (and optionally `schemas`)
- `notifications`: Slack/Teams webhooks, if you want alerts (see step 3)
- `llm`: leave as `rules`, or use Model Serving (see "Agent with an LLM")

### 2. Persistent storage with Lakebase (recommended)

Without this, the app keeps its state in SQLite on the container's disk. That disk is wiped on every restart or redeploy.

1. Create a Lakebase database instance, or reuse one.
2. In `databricks.yml`, uncomment the `database` resource and set `instance_name`.
3. In `app.yaml`, uncomment `DQGA_DATABASE_URL` with the value `lakebase`.

The app then reads the injected `PGHOST`, `PGUSER` and related variables, and logs in with a fresh OAuth token for each connection. It creates its tables in the Postgres schema `dqga` (set by `app.db_schema`).

### 3. Secrets for alerts (optional)

Create a secret scope and store the webhook URL:

```bash
databricks secrets create-scope dq-agent
```

```bash
databricks secrets put-secret dq-agent slack_webhook
```

Then uncomment the `slack-webhook` resource in `databricks.yml` and the `DQ_SLACK_WEBHOOK` env entry in `app.yaml`. Teams works the same way: add a `teams-webhook` resource and the `DQ_TEAMS_WEBHOOK` env entry.

### 4. Deploy

```bash
databricks bundle validate --var warehouse_id=<warehouse-id>
```

```bash
databricks bundle deploy -t dev --var warehouse_id=<warehouse-id>
```

```bash
databricks bundle run tcs_datatrustai -t dev
```

The last command starts the app and prints its URL. You can also find it under Compute > Apps > `tcs-datatrustai`.

**Without bundles:**
1. Upload the extracted package to `/Workspace/Users/<you>/tcs-datatrustai`, for example with `databricks workspace import-dir ./tcs-datatrustai /Workspace/Users/<you>/tcs-datatrustai`.
2. Create an app named `tcs-datatrustai`.
3. Add a SQL warehouse resource with the key **`sql-warehouse`** and Can use permission.
4. Deploy with `databricks apps deploy tcs-datatrustai --source-code-path /Workspace/Users/<you>/tcs-datatrustai`.

### 5. Grant the app's service principal access

Find the service principal's application ID on the app's page (Authorization / service principal), or with `databricks apps get tcs-datatrustai` (field `service_principal_client_id`). A metastore or catalog admin then runs these grants.

**Read-only (required):**

```sql
-- data to monitor (inherits to schemas and tables)
GRANT USE CATALOG, USE SCHEMA, SELECT ON CATALOG main TO `<sp-application-id>`;

-- lineage
GRANT USE CATALOG ON CATALOG system TO `<sp-application-id>`;
GRANT USE SCHEMA ON SCHEMA system.access TO `<sp-application-id>`;
GRANT SELECT ON TABLE system.access.table_lineage TO `<sp-application-id>`;
GRANT SELECT ON TABLE system.access.column_lineage TO `<sp-application-id>`;
```

**Write-back (only for the actions you plan to use; they run as soon as someone clicks them):**

```sql
-- tags (PII tags, DQ status tags)
GRANT APPLY TAG ON CATALOG main TO `<sp-application-id>`;

-- quarantine: admin pre-creates the schema, the app writes into it
CREATE SCHEMA IF NOT EXISTS main.dq_quarantine;
GRANT USE SCHEMA, CREATE TABLE, SELECT, MODIFY ON SCHEMA main.dq_quarantine TO `<sp-application-id>`;
-- quarantine also deletes the bad rows from the source table:
GRANT MODIFY ON TABLE main.<schema>.<table> TO `<sp-application-id>`;

-- column masks (masking policy enforcement): the app creates a masking function
-- and attaches it, which needs CREATE FUNCTION on the schema plus ownership or
-- MANAGE on the table
GRANT CREATE FUNCTION ON SCHEMA main.<schema> TO `<sp-application-id>`;
```

The warehouse permission (Can use) comes from the app resource automatically.

### 6. Control who can use the app

On the app's page, open Permissions and give **Can use** to your data stewards and engineers.

Inside the app, `config.databricks.yaml` sets `auth.mode: sso`. Workspace single sign-on is the login, so users don't see a separate sign-in screen, and each person's account is created on their first visit.
- **Administrators:** list emails under `auth.admins`; if the list is empty, the first person to open the app becomes the administrator.
- **Everyone else** gets `auth.default_role` (steward). Change roles, or disable people, in the **Admin console**.

The app queries Unity Catalog **as its service principal**, not as the signed-in user. Anyone who can open the app sees profiles, check results, and failing-row queries for everything the service principal can read. Keep the audience to people allowed to see that data.

### 7. Verify

1. Open the app URL. The top bar should show **Databricks Apps**.
2. Go to **Settings > Connections** and click **Test** on `databricks`. You should see "Connected as <service principal>".
3. Click **Sync**. The tables from your catalogs appear under **Explore > Datasets**.
4. Open **Settings > Scheduler**. It should say "On", with your budget.
5. **Settings > Environment** lists what Databricks injected: `DATABRICKS_APP_NAME`, `DATABRICKS_WAREHOUSE_ID`, and `PGHOST` if you attached Lakebase.
4. Continue with "First run".

---

## First run (both paths)

1. **Catalog:** open a table you know well.
2. **Profile:** see null rates, ranges and patterns on the **Profile** tab.
3. **Suggest rules:** the agent proposes rules from the profile.
4. **Rules tab:** review them, then use **AI Rule Studio > Saved rules > Send for approval**. An administrator approves and activates them in the **Review queue**.
5. **Run checks:** results and the score appear on **Overview**. Failures open incidents.
6. **Find PII:** sensitive columns show on **Governance > Sensitive data**. Tagging them in Unity Catalog runs as soon as you click **Tag**.
7. Repeat for the tables that matter most (gold and certified first), and set **Owner / Steward / Domain / Certified** on each dataset's Overview tab. Severity and policies use these fields.

See [ui-guide.md](ui-guide.md) for every page and workflow.

---

## Scheduling

Pick **one** scheduler:

- **In-app (default):** `scheduler.enabled: true` in `config.databricks.yaml`. It ticks every `tick_seconds` and only re-checks tables whose `last_altered` changed (freshness checks always run). It stops at `daily_budget_seconds` of warehouse time.
- **Databricks job:** uncomment the job in `databricks.yml`, set `scheduler.enabled: false`, and use Lakebase. The job must write to the same database as the app, or its results never show up in the UI.

**Keeping warehouse cost down:**

- Limit `schemas`.
- Give large-table rules a `where` scope in their params, for example `"where": "event_date >= current_date() - INTERVAL 1 DAY"`.
- Use a serverless warehouse with a short auto-stop.

---

## Agent with an LLM (optional)

The agent works without a model (`provider: rules`). To use a Databricks Model Serving endpoint:

1. In `config.databricks.yaml`:

   ```yaml
   llm:
     provider: databricks
     model: <serving-endpoint-name>
   ```

2. In `databricks.yml`, uncomment the `llm-endpoint` resource with **Can query** permission.

Auth uses the app's service principal, and the endpoint must support chat with tool calling. The model is the serving endpoint **name** from the Serving page (for example `databricks-meta-llama-3-3-70b-instruct`), not a Unity Catalog path such as `system.ai.<model>`. The model only ever sees schemas, profile statistics (including the most common values per column) and aggregates, never raw rows.

You can also pick the model in the app: **Settings > LLM** keeps a list of saved connections, tests each one, and applies the one in use across the whole app (agent, AI rule generation, Plain-English rule). Locally, Databricks Model Serving uses your `DATABRICKS_HOST` and `DATABRICKS_TOKEN`; on Databricks Apps it uses the app's service principal. Set `DQGA_SECRET_KEY` as a secret so API keys saved in the app survive a restart.

---

## Use Databricks-native DQ alongside the agent

In the **AI Rule Studio** (or a dataset's **Rules** tab), use **Export rules**:

- **Databricks DQX (YAML):** for `databrickslabs/dqx` in notebooks and jobs.
- **Lakeflow expectations (SQL):** `CONSTRAINT ... EXPECT ... ON VIOLATION DROP ROW / FAIL UPDATE` for declarative pipelines.
- **SQL validation queries:** generated in Databricks SQL. Paste them into the SQL editor, or schedule them as SQL alerts.
- **PyDeequ, Great Expectations, Soda, dbt:** if parts of your estate run those tools.

**Download all formats (.zip)** gives every format for one dataset, or for all datasets, in one file. Review the generated code against the library versions you run.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| App won't start, `No module named dqga` | Source path isn't the project root | Deploy the folder that contains `dqga/` and `app.yaml` |
| **Test** says the connection needs `http_path` or `warehouse_id` | Warehouse resource key mismatch, or the variable is missing locally | On Databricks Apps the resource key must be `sql-warehouse` (matching `valueFrom` in `app.yaml`). Locally, set `DATABRICKS_WAREHOUSE_ID` in `.env` and check **Settings > Environment** |
| Top bar says **Local** inside Databricks | The app doesn't see the Databricks Apps variables | Make sure it was deployed as a Databricks App, not run in a notebook or job |
| **Test** works, **Sync** finds 0 tables | Missing grants, or wrong `catalogs` | Run the read-only grants; check `catalogs` / `schemas` in the config |
| **Lineage** is empty | `system.access` not enabled, no grant, or no recent activity | Enable the schema and grant SELECT. Lineage covers tables read or written by UC-enabled compute in the last `lineage_days` |
| Rules and incidents vanish after redeploy | SQLite on the app's ephemeral disk | Set up Lakebase (Path B, step 2) |
| `permission denied for schema public` (Lakebase) | Postgres 16 restricts `public` | Keep `db_schema: dqga` and give the database resource **Can connect and create** permission |
| Approving a tag fails with `PERMISSION_DENIED` | No `APPLY TAG` | Grant it (write-back grants) |
| First check takes minutes | Classic warehouse starting | Use serverless, or wait for warmup |
| Checks fail after the app sat idle | Expired warehouse session | Handled: the connector reconnects once automatically. If it persists, click **Test** on Connections |
| Agent footer says `rules` | No LLM configured | Expected; see "Agent with an LLM" |
| Agent errors with an LLM configured | Endpoint not granted, or no tool-calling support | Add the `serving_endpoint` resource; use a chat model that supports tools. The agent falls back to its built-in router and says so |

## Removing it

```bash
databricks bundle destroy -t dev
```

Then drop `main.dq_quarantine` if you created it, and revoke the grants.
