# TCS DataTrustAI UI guide

## Layout

- **Left navigation:** pages are grouped:
  - **Build:** AI Rule Studio, Governance
  - **Operate:** **Overview**, **Explore** (Datasets, Incidents, Violations, Patterns and Insights) and **Runs**. Dashboards and charts are meant for your BI tool, so this group stays small
  - **Platform:** Settings, Deploy, and **Admin console** for administrators
  - **Help:** Guide and docs
- **Your initials** (top right): your account, the Admin console (administrators), the guide, and **Sign out**. A red counter shows open incidents.
- **Top bar:** where you are, a **Help** link that opens this guide at the section for the current page, where the app is running (**Local** or **Databricks Apps**), which agent model is active, and your initials (hover for your email).
- **Main area:** the page you're on.
- **Info icons (i):** next to AI Rule Studio, Runs, Governance, Policies, Contracts, Standards and Violations. The page shows one short line; click the icon for the detail and a comparison of quality rules, policies and data contracts.
- **Agent panel:** open it with **Ask DataTrustAI** (bottom right) or **Ask agent** on a dataset or incident. The agent knows which page you're on, so "why is this failing?" works without naming the table.

**One rule runs through the whole UI:** nothing changes until a person clicks it. Rules go live only after review in the AI Rule Studio. Tags, masks, retention, corrections, remediation and tickets run as soon as you click, so check the preview first; every one is written to the audit log.

**Colors:**
- Scores: green ≥ 95, amber 80-94, red < 80. Overview cards get a matching colored top edge.
- Severity, following the Azure Monitor convention: **critical** (red), **high** (orange), **medium** (amber), **low** (blue).
- Status pills: `pass`, `fail`, `warn`, `error` for checks; `open`, `ack`, `resolved`, `muted` for incidents; `proposed`, `active`, `disabled` for rules.
- Platform badges use each vendor's color: Databricks (lava red), Snowflake (sky blue), Azure Purview (Azure blue), AWS Glue (orange), Apache Spark, Cognite (indigo), DuckDB (yellow). Lineage nodes carry the same color as a stripe on the left.
- The theme follows your system's light or dark mode.

---

## Pages

**Platform picker.** Overview, Insights, Anomalies, Impact analysis (including its Lineage tab), Incidents and Catalog share one platform choice. It lists only platforms with an enabled connection; pick one and every Monitor page shows only that platform's datasets, rules, checks, incidents and patterns. The choice carries from page to page; "All connected platforms" clears it.

### Sign-in screens

When sign-in is on (`auth.mode: local`), these screens come first. The left panel shows the product; the right panel shows the form.

| Screen | When you see it | What it does |
|---|---|---|
| **Set up TCS DataTrustAI** | The very first visit, before any account exists | Creates the **administrator** account. There are no default passwords |
| **Sign in** | Every visit after that | Email and password. **Show** reveals what you typed |
| **Create an account** | Link on Sign in (unless sign-up is off) | Name, work email, password and confirmation. By default an administrator must approve new accounts, and you'll see "Request sent" |
| **Administrator sign-in** | Link at the bottom of Sign in | Same credentials, but only administrator accounts get in, and you land on the **Admin console** |
| **Choose a new password** | After an administrator creates your account or resets your password | Enter the temporary password, then your own |

Passwords need at least 10 characters with letters and numbers, and can't contain your name or email. After 5 wrong attempts the account locks for 15 minutes. Mistakes show next to the field.

On **Databricks Apps** (`auth.mode: sso`) you never see these screens: workspace single sign-on signs you in, and your account is created on your first visit.

### Your account

Open it from your initials in the top-right corner, then **Your account**. It shows your name, email, role, how you sign in, your last sign-in, and what your role can do. With a TCS DataTrustAI account you can **change your password** here. The same menu has **Sign out**.

### Admin console

For administrators only: under **Platform > Admin console** in the left pane, or after **Administrator sign-in**. A red counter shows sign-up requests waiting.

- **Summary:** users, sign-ups waiting for approval, active administrators, and signed-in sessions.
- **Sign-up requests:** choose a role, then **Approve** or **Reject**.
- **Users:**
  - change anyone's **role** from the list;
  - **Disable** or **Enable** an account (disabling signs them out);
  - **Reset password** (gives a one-time temporary password and signs them out);
  - **Unlock** an account after too many failed attempts;
  - **Delete** an account.
- **Add user:** creates an account with a temporary password, shown once with a **Copy** button. Share it privately; the user chooses their own password at first sign-in.
- **Roles:** what admin, steward and viewer can do.
- **Access settings:** sign-in mode, sign-up policy, default role, session length, lockout and password rules. Change them in `config.yaml` under `auth`.

**Safeguards:**
- You can't disable, demote or delete the last active administrator.
- You can't disable or delete yourself.
- Every action is recorded in **Settings > Audit**.

### Overview

A one-screen answer to "is anything broken, and where do I go next". The **platform picker** (top right, only platforms with an enabled connection) is the only filter.

- **Top row:** overall DQ score, open incidents (with how many are critical, high and medium; click to open them), **Rules in review** (click to open the Review queue), and freshness SLA breaches (late or missing loads).
- **Rule status row:** active rules, saved drafts, rules failing now, and disabled rules, each linking to where you act on them.
- **Score trend** for the last 30 days, next to the **open incidents**: the five newest, each linking to its incident page, and **See all**.
- **Next scheduled run** (a line under the rule status row) names the next enabled schedule and when it runs, with a link to Runs.
- **Run due checks** runs whatever is due now.

The earlier Overview with filters, Summary, Rules and Incidents tabs and custom metrics is no longer shown. The old addresses (`#/overview/rules` and so on) open this page.

### Explore

One page with three views, under one header with the platform picker. The old **Catalog**, **Incidents**, **Insights** and **Anomalies** addresses open the matching view here.

- **Datasets:** every dataset from every connection, with score, active rules (plus drafts), failing rules, open incidents, and a certified badge.
  - **Search** (press Enter); **Needs attention** shows only datasets with open incidents, failing rules or a score under 80; **No owner** shows datasets without an owner (the Owner column says "no owner"); **Has sensitive data** shows datasets with sensitive columns, and the **Sensitive** column counts them (click the number to review them in Governance > Sensitive data).
  - Click a dataset's **n open** to jump to Incidents filtered to that dataset. Click the name to open its page (Anomalies, Lineage and Impact are tabs there).
  - **Sync catalog** (administrators) pulls new tables, columns, tags and lineage from every connection.
- **Incidents:** the incident list with the fix actions. Switch between **Open**, **Resolved**, **Muted** and **All**; a chip shows an active dataset or severity filter, and **Clear filters** removes it. Click an incident to open its page.
- **Patterns and Insights:** AI-written insights, learnings and recommendations about your checks and incidents. See [Insights](#insights).

### Runs

Run rules on demand, put rule sets on a schedule, and watch what ran. Open **Runs** under Operate; the old address `#/rules/runs` opens it.

- **Tiles:** runs, checks run and failed, checks that errored (SQL or connection problems), and the next scheduled run, for the time window picked under Run history.
- **Run rules now:** pick a rule set (core, business domain, governance or all), a minimum severity, all datasets or only the dataset picked at the top, and a platform when more than one is connected. The line underneath says how many active rules on how many datasets will run, roughly how long it takes (from past runs), and which datasets are skipped because their connection is disabled. **Run now** runs them; incidents open as for any run. **Save as schedule…** turns the same picks into a schedule.
- **Checks per day:** passed, failed and errored checks per day (switch to a table with **Table**).
- **Schedules:** each schedule runs the active rules that match its selection, either every N minutes or hours, or at a time of day (UTC) on chosen weekdays. The table shows what runs, when, the next run, and the last run's outcome. Use the switch to pause or resume, **Run now** to run it straight away (the next due time doesn't move), **Edit**, **Runs** to filter the history to that schedule, and **Delete**. Rules covered by an enabled schedule follow it; other active rules keep the default interval (`scheduler.default_interval_minutes`). Scheduled runs count toward the daily compute budget. If the background scheduler is off (`scheduler.enabled: false`), a red note says so, and schedules only run when you click **Run now**.
- **Run history:** every run (one row per dataset run) with when, dataset, what started it (Run now and who, a schedule's name, the agent, an Insights refresh, a re-check after a fix), checks, failed, errored, seconds and outcome. Filter by time window, what started it, outcome and dataset. Click a run to see each check's result, pass rate, failing rows and message.

These are the runs started in this app: by hand, by a schedule, by the agent or by Refresh insights. Checks you run in DQX, Soda, Great Expectations or dbt are not shown yet. The page has a **platform picker** and a **dataset** picker at the top; the dataset picker adds a "this dataset only" choice to Run rules now and to the history filter.

### Violations

**Explore > Violations.** What your policies find wrong. A **scan** checks every enabled policy against what the app already knows about your datasets (owners and stewards, DQ scores, active rules, contracts and detected sensitive columns). It does not query your data. Every scan is kept, so violations have a "last scanned" time, a history, and a before and after.

- **Run scan** (stewards and administrators) scans now. Before the first scan the page is empty and says so.
- **Schedule:** administrators choose **Change schedule** to scan every N minutes or hours, or at a time of day (UTC) on chosen weekdays. The scheduler runs it with the other background work.
- **Tiles:** violations, **new** since the previous scan, **resolved** since the previous scan, and a count by severity. The first scan has nothing to compare with, so it shows no new or resolved.
- **Table:** filter by severity, by policy, by **New only** and by text, and by platform with the picker at the top. **Enforce** (where the platform can apply a fix) runs the exact SQL at once.
- **Scan history:** the last scans with their totals, new and resolved counts.

Policies are created in [Governance](#governance) > Policies. The Overview shows a **Policy violations** tile that opens this page.

### Insights

**Explore > Patterns and Insights.** The app computes the facts from your checks, incidents and feedback; the model you chose in Settings > LLM writes them up. Nothing here is a raw table of numbers: you see only the write-up.

- **Insights:** what is happening, most important first, each marked high, medium or low. For example, a source that keeps failing on the same weekday and the usual cause.
- **Learnings:** what the app has learned from feedback and rule tuning.
- **Recommendations:** concrete next steps, with an **Open** button that goes to the dataset, the AI Rule Studio, the Review queue or the incidents list.
- **Generate with AI** writes it (stewards and administrators; viewers see the saved text). Once written, the text is saved. While your data is unchanged it is shown as is, and the model is not called again, so switching models does not reword the page. When your data changes, the page says so and the button offers to generate again. **Regenerate** forces a rewrite.
- **Refresh insights** is separate: it syncs metadata from the connections and can run due checks, so there is fresh data to write up. It does not call the model.
- The **platform picker** gives each platform its own saved write-up.
- With no model configured, the page asks you to set one up in Settings > LLM and the button stays off.

**How it stays steady whichever model is used:**
- The facts are computed in code, numbered and rounded the same way every time.
- The instructions given to the model are built into the app and the same for every model.
- The model must answer in a fixed structure at temperature 0.
- Every statement must cite facts and may only contain numbers that appear in them. Anything else is removed, and the page says how many statements were removed.
- The model sees counts, percentages, weekdays, causes and dataset names. It never sees rows, column values or personal data.

### Anomalies

Shown on each dataset's **Anomalies** tab (the cross-dataset Anomalies page was removed; `GET /api/anomalies` still returns the full list). Unusual changes in the last 30 days:
- **spikes** and **drops** outside the expected band;
- **level shifts**: a sustained change, such as volume stepping up 40% and staying there;
- failing anomaly and sensor monitors.

Each row shows the observed value, the expected range, the change in % and a severity. The severity accounts for certification and how much depends on the dataset.

**Datasets without anomaly monitoring** lists the gaps; **Start monitoring** adds a full monitor pack in one click:
- volume;
- lateness;
- null-rate drift;
- outliers (values beyond 3× the interquartile range);
- category-mix drift;
- a schema snapshot.

Each dataset also has an **Anomalies** tab. It charts every tracked metric with its **expected range** shaded and anomalies as red dots (hover for details). The band is what the detector expected at that time, learned from earlier points only, with weekly seasonality once there are 3+ weeks of history.

### Impact analysis

Open it from a dataset's **Impact** tab (then **Open the full analysis**), or with **Impact** on a dataset or incident. It has two tabs: **Impact analysis** (below) and **[Lineage](#lineage)**.

1. **Choose a scenario:**
   - **Data quality problem in this dataset:** optionally limit it to certain columns.
   - **Drop columns**, or **Change column types:** tick the columns.
2. Click **Analyse**.

The results show:
- **Impact score** (0-100) and level. It weighs downstream distance, certified datasets, critical domains (finance, billing), affected rules and breaking contracts.
- **Downstream lineage**, colored by health.
- **Impacted datasets:**
  - hops, owner, domain, score, and open incidents;
  - for column changes, the affected downstream columns, found through column lineage or, if that isn't available, by matching column names.
- **Rules**, **contracts** (marked **breaking** for drops and type changes) and **policies** involved.
- **People to tell:** owners and stewards of everything affected. **Notify owners** sends the summary to the configured Slack, Teams or email channels, with your optional note, and records it in the audit log.

#### Lineage

The **Lineage** tab of Impact analysis shows the whole graph across platforms (for example a Cognite feed into Databricks tables). Click a dataset to open it.

- **Sync from platforms** pulls lineage again.
- **Add an edge** lets you record lineage the platforms don't capture.
- Spark/Airflow (OpenLineage) and dbt (`manifest.json`) can post lineage to the API.
- The old Lineage page address opens this tab.

### Fixes and quarantine

Corrections and quarantine of bad rows are not available in this version. It is switched off with `features.fixes_and_quarantine: false` in config.yaml (the default); the code is kept so it can be switched back on.

### Catalog

Now **Explore > Datasets** (see [Explore](#explore)). Every dataset from every connection.

- **Search** (press Enter) and filter by **platform**. The group column is called **Domain** unless `grouping.label` in config.yaml says otherwise (see [Dataset grouping](configuration.md#grouping)). The platform list only offers platforms with an enabled connection, with how many datasets each has; it's hidden when only one platform is connected.
- **Sync catalog** pulls new tables, columns, tags and lineage from all connections.
- Columns: score, active rules (+ proposed), failing rules, open incidents, certified badge.
- Click a dataset to open its page.

### Dataset page

**Header buttons:**

| Button | Does |
|---|---|
| Run checks | Runs all active rules now |
| Profile | Computes statistics in the platform and detects sensitive columns |
| Suggest rules | Proposes rules from the profile (they arrive as `proposed`) |
| Rescan sensitive data | Profiles this dataset again and re-runs sensitive-data detection (it used to be called Find PII) |
| Impact | Opens Impact analysis for this dataset |
| Ask agent | Opens the agent with this dataset as context |

**Tabs:**

| Tab | Use it to |
|---|---|
| **Overview** | See the score per dimension and the latest result of every rule. Set **Owner, Steward, Domain, Certified** and click Save. Certified datasets get stricter policies and higher incident severity |
| **Profile** | Inspect each column: type, null %, distinct count, min/max, mean, top values, or string shape patterns (`AAA-999999`) |
| **Rules** | **Plain-English rule**: write a rule in your own words (drafted and dry-run before saving). Disable or re-enable rules (drafts link to Saved rules; activation is by an administrator in the Review queue). Mark a failing rule **False positive**. **Export rules** for this dataset (see AI Rule Studio) |
| **Anomalies** | See each tracked metric with its expected range and anomalies marked, and any level shifts. **Monitor this dataset** adds a full set of anomaly monitors |
| **Lineage** | See upstream and downstream tables, colored by health. Click a node to jump to it |
| **Incidents** | See every incident this dataset is part of |
| **Governance** | Review sensitive columns (**Tag** in the platform or mark **Not PII**). See this dataset's policy violations (**Enforce** where possible) |
| **Contract** | View the current data contract and its schema-compatibility status. **Generate** an ODCS v3 contract from the active rules, edit it, and **Save as contract**. **Validate against live schema** to spot breaking changes |
| **History** | Row-count and score charts, plus the last 60 check results |

### Incidents

Now **Explore > Incidents** (see [Explore](#explore)). A triage queue. Use the tabs to filter: **Open** (open + acknowledged), **Resolved**, **Muted**, **All**. Failures with the same root cause are grouped, so one upstream outage is one incident, not one per table.

When you arrive from an Overview chart, the filters it applied (severity, dataset, domain, platform) show as chips above the list; remove one with **×**, or all with **Clear filters**.

### Incident page

From top to bottom:

1. **Header:** severity, status, assignee.
   - Buttons: **Acknowledge**, **Assign**, **Resolve / Reopen**, **Mute**, **Open ticket**, **Ask agent**.
2. **Summary box:** the root-cause candidate, a hypothesis (for example "Partial load upstream"), and the first failure.
3. **Evidence:** every failing check in time order. The red bar marks checks on the root dataset.
4. **Lineage around the root cause:** the root is outlined in red, and downstream datasets at risk are listed underneath.
5. **Failing checks:**
   - each rule's latest message;
   - **Query for failing rows**: SQL you can paste into a notebook or the SQL editor;
   - a **False positive** button per rule.
6. **Suggested fixes:**
   - **Other actions:**

     - re-running a job or notifying the source owner runs when you click **Run now**.
   - The **Impact** button in the header opens impact analysis for the root-cause dataset.
7. **Was this alert right?**
   - **Real issue** makes the rule slightly more sensitive.
   - **False positive** makes it less sensitive, or proposes a new threshold.
   - **Expected change** restarts the baseline, for example after a planned migration.
8. **Timeline:** everything that happened, and who did it.

### AI Rule Studio

Rules across all datasets. At the top right, pick a **platform** (only platforms with an enabled connection are listed) and a **dataset**; the platform narrows the datasets, the tab counts, and what Saved rules, the Review queue, and the Rule catalog show.

A rule goes through four steps, and only administrators can make it live:

1. **Draft.** Rule generation never activates anything. You save a draft or dry-run it.
2. **Send for approval** from Saved rules.
3. **Review.** An administrator approves or rejects it in the Review queue.
4. **Activate.** The administrator activates it; from then on it runs on its schedule.

AI Rule Studio has five tabs:

- **Rule generation:** AI rule generation (with its AI context), **Plain-English rule** and **Manual rule builder**, to create drafts.
- **Saved rules:** your drafts. Only **Edit** and **Send for approval**. The number on the tab is how many drafts there are.
- **Review queue:** rules sent for approval. Administrators approve, reject and activate them. The number on the tab is how many are waiting.
- **Rule catalog:** live rules (and disabled ones), with **Export selected** and **Export a whole dataset**, and **Download rule files** and **Import rule files…** for rules as YAML files, and (when Git is switched on and connected) **Export to Git…**, which opens a pull request with the rule files.
- **Reference files:** the saved [reference files](#reference-files) used as AI context.

#### Rule generation

Three tabs, one at a time (your last choice is remembered): **AI rule generation**, **Plain-English rule** and **Manual rule builder**. In AI rule generation, **AI context** is one line (which reference files are used, and how many are saved); click **Change context** to open the file list, the upload button, the mode choice and the **Governance context**, and **Hide context** to close it again.

- **AI rule generation:** click **Generate rules**.
  - **AI context**, under the title, sets which saved [reference files](#reference-files) the discovery (and Plain-English rule) reads:
    - **All saved files for this domain** (the default), **Only the saved files I pick** (tick them), or **No reference files**.
    - **Upload file** adds business documents, a glossary, master data, models or policies without leaving AI Rule Studio. The business domain is filled in with the dataset's domain, so the file becomes AI context for that domain (clear it to use the file everywhere). The file is saved to Reference files and used straight away.
    - **Governance context** (inside the AI context): tick **Business glossary** (terms mapped to the dataset or its columns: a definition that states a rule becomes a proposal; **Which terms** lists them), **Data contract** (the dataset's contract; its promises that no active rule covers become proposals), **Policies** (the enabled policies that apply to the dataset; click **Which policies** to read them) and any **Standards** (GDPR, SOX, NERC CIP, ISO 8000, DAMA: proposals that help a control you have not met yet are tagged). The glossary, contracts and policies are on by default and the choice is remembered. They work without a model; a configured model also receives them and cites them in its reasons. Each proposal's **Source** column shows a tag (Glossary, Contract, Policy or Standard) with the contract, policy or control named under it, and the line above the table says what context was used.
    - **Reference files** opens the Reference files tab.
    - The line underneath says how many facts the files hold about this dataset and for which columns. **What the model sees** shows the summary sent to the LLM. With no model configured (`llm.provider: rules`), the built-in reader turns the facts into rules; with a model, the matching facts are also sent to it as context.
  - **Hide results** folds the proposals away and **Show results** brings them back. **Reset** discards them and starts over; nothing is saved until you accept proposals.

  - **Use the AI model** (ticked by default) uses the LLM chosen in [Settings > LLM](#settings). If none is configured, or the model can't be reached, discovery **stops with an error** that links to Settings > LLM, instead of quietly running without it. Untick the box to run statistical discovery only (statistics, history, relationships, reference files and glossary).
  - **Every candidate is dry-run on the platform**, whichever platform the dataset is on, and the line above the table says how many ran and how many couldn't. Platforms that can't run SQL (Purview, Cognite) say so instead of skipping the dry runs quietly. Nothing is saved by a dry run.

  Discovery proposes rules in **three sets**:
  - **Core data:** nulls, data types, formats, keys, references, freshness, volume and schema;
  - **Business domain:** allowed values, business ranges and cross-column logic from your models, glossary, master data and business documents;
  - **Data governance:** privacy, security, retention, consent, audit trail and regulatory rules. For example: restricted identifiers (SSN, card, IBAN) are never stored in clear text; contact details only with consent; deleted records keep no personal data; no records past the retention period (taken from your policy text when it states one); audit columns are filled and maker and checker differ (SOX); regulatory classification columns are filled (NERC CIP).

  Switch between **All**, **Core data**, **Business domain** and **Data governance** with the tabs above the table. Each tab shows how many proposals it has and how many you've selected; the select-all box and **Select 80%+ that pass** apply to the tab you're on.

  Proposals come from several sources:
  - **Reference:** the reference files (the file name is shown under the source);
  - **Governance:** sensitivity from the ontology or glossary, stored classifications and column names;
  - **Semantic type:** what each column means (ids, emails, amounts, percentages, coordinates, timestamps);
  - **Statistics** (the profile);
  - **History:** ranges that held across profiles, null-rate ceilings, learned volume, observed lateness;
  - **Relationship:** cross-column facts that always hold, like `reading_ts <= ingested_at`;
  - **Business context:** sentences in dataset and column descriptions and in linked glossary terms, plus the domain;
  - **Learned:** the same rule on the same column in other datasets;
  - **Observability:** volume, schema, drift and outlier monitors;
  - **LLM**, when configured. The model only ever sees metadata;
  - **Glossary**, **Contract**, **Policy** and **Standard**: what you have already decided. See **Governance context** below.

  Each proposal shows:
  - a **confidence** score;
  - its sources;
  - the **evidence** (expand "more" for all of it);
  - a **dry run** on current data. A failing dry run means either a real issue or a rule to adjust.

  When sources disagree, a rule someone wrote down wins: a reference file or policy beats a model's guess, which beats a domain hint, which beats limits inferred from the data. For example, a glossary rule "kwh must be between 0 and 10000" replaces the observed range.

  **Coverage by dimension** shows active rules now (dark) and what the proposals add (light). Rules at 80%+ confidence that pass are pre-selected. Use **Save selected as drafts**; they wait in Saved rules. Saved rules keep their set.
- **Plain-English rule:** write rules in plain English.
  - Write one requirement per line, the way you'd say it. For example:
    - `kwh cannot be negative`
    - `voltage should be less than 260`
    - `Every reading must have a meter id`
    - `reading timestamp must not be in the future`
    - `no duplicate meter_id and reading_ts`
    - `at least 99% of kwh values must be populated`
    - `data must be refreshed every 6 hours`
    - `customer_id must exist in customers`
    - `discount must be less than amount`
  - Business terms from your glossary and models work too: with a glossary that maps "Contact Email" to `email`, `Contact Email must not be empty` becomes a not-null rule on `email`.
  - **Set** next to the button puts the rules in a set; **Detect** chooses one from the rule (sentences about privacy, retention or consent go to Data governance).
  - Each line shows how it was read (for example "Validity: kwh ≥ 0"), its set, a **dry run on the platform** (which connection it ran on, how long it took, and the queries), and **Save as draft** and **Dry run again**. Nothing is saved until you click **Save as draft**; with several lines, **Save all as drafts** saves them together.
  - If a line can't be read, the message says which columns were recognized and gives examples using this dataset's columns.
- **Manual rule builder:** pick a type (an example of its params appears), a column, severity, a minimum pass rate and, optionally, the set.
  - **Dry run on the platform** tests it without saving and shows where it ran and the queries.
  - **Save as draft** saves it in Saved rules. There is no way to go live from here.

Drafts appear in the **Saved rules** tab. After an administrator activates them, they appear in the **Rule catalog** tab.

#### Saved rules

Drafts from AI rule generation (**Save selected as drafts**), **Plain-English rule** and **Manual rule builder** (**Save as draft**), plus rules an administrator rejected. They don't run.

- Shows all datasets by default; switch to **This dataset**, or filter by set.
- Each row has only two actions: **Edit** (the Edit window also has a **Dry run**) and **Send for approval**. Tick several and use **Send selected for approval**. The note you add goes to the reviewer.
- A **rejected** rule shows the administrator's reason, who rejected it and when. Edit it and send it again; the earlier decision is cleared.
- Once sent, a rule leaves this tab and waits in the Review queue. It can't be edited there; withdraw it first.

#### Review queue

Rules sent for approval, from every dataset. Everyone can see the queue; **only administrators** approve, reject and activate.

- Filter by **Waiting for review**, **Approved, not active**, **Rejected** or **All** (each shows its count) and by **This dataset**. The platform picker at the top applies too.
- Each row shows the rule, its dataset and platform, severity, who sent it and when, and their note. **Rule details** shows its parameters. **Dry run** runs it on the platform so the reviewer can see how it behaves before deciding.
- For an administrator:
  - **Approve** accepts a rule. It stays off until someone clicks **Activate** in the Approved tab.
  - **Approve and activate** does both at once.
  - **Reject…** asks for a reason, which the author sees in Saved rules.
  - Tick several rows for **Approve selected**, **Approve and activate selected** or **Reject selected…**.
- For anyone else, the author of a waiting rule can **Withdraw** it back to a draft.
- Every step is recorded in the rule's history and in the audit log.

#### Rule catalog

- **Rules catalog:** live and disabled rules with their set, type, severity, status and last result.
  - Filter by **This dataset** or **All datasets**, by set, severity, dimension and status: **Active and disabled** (the default), **Active**, **Disabled**, or **All, including saved** (drafts, rules in review, rejected ones). The link under the header goes to the saved rules waiting to be activated.
  - **Tick rules to export:** the box at the top of the table selects all shown; **Export selected (n)** opens the export window with exactly those rules, whatever their status or dataset. One dataset gives one file; several give a zip with a folder per dataset. **Export a whole dataset** exports everything in a dataset instead.
  - Administrators can change a live rule's **Severity** right in the table; it's saved at once. Stewards see it read-only: a live rule is changed by an administrator.
  - **Edit** opens the whole rule: name, set, severity, status, type, column, dimension, minimum pass rate, params and description. **Dry run** tests the edited rule on current data before you save. Every save creates a new version (see the rule's history).
  - **Disable** a live rule (stewards and administrators) or **Enable** a disabled one (administrators). Drafts show a link to Saved rules and rules waiting for approval a link to the Review queue. The dataset page's **Rules** tab has the same table.
  - New rule options: a regex rule can be set to **must not match** (`"negate": true`), for example to catch unmasked card numbers, and a **retention** rule fails for records older than `max_age_days`.
- **Export rules** (button next to the filters) opens the export window, to run the rules in another tool.
  1. Pick a dataset, or **All datasets**. Tick **Include proposed** if you want those too; the preview says how many proposed rules are left out.
  2. Choose a format from the **Format** list. It's grouped as:
     - **Databricks:** DQX, Lakeflow expectations
     - **SQL:** SQL validation queries
     - **Open-source frameworks:** Great Expectations (GX 1.x), Soda (SodaCL), dbt tests, PyDeequ
     - **Cloud platforms:** Snowflake DMFs, AWS Glue DQDL
     - **TCS DataTrustAI:** JSON

     A one-line description of the format appears under the toolbar.
  3. The preview shows the generated code, how many rules were exported, and which rules that format can't express, if any.
  4. **Copy** or **Download** one format, or **All formats (.zip)** for every format at once. With All datasets, the zip has one folder per dataset plus a `SUMMARY.txt`. **Close** returns to the catalog.

#### Reference files

Files that tell AI Rule Studio what the data should look like, in the **Reference files** tab of AI Rule Studio. You can also upload with **Upload file** in AI rule generation. (The old Build > Reference files page now opens this tab.)

| You can add | What is read |
|---|---|
| **SQL model (DDL)**: `.sql`, `.ddl` | `CREATE TABLE` and `ALTER TABLE`: NOT NULL, primary and foreign keys, CHECK constraints, VARCHAR lengths, and column comments such as "Valid values: a\|b\|c" or "Pattern: ^...$" |
| **Ontology or SHACL**: `.ttl` | OWL classes and properties and SHACL shapes: `sh:minCount`, datatypes, `sh:pattern`, `sh:in`, ranges, lengths, `sh:class`. Annotations such as physical table and column, nullable, valid values, value pattern, business term and **sensitivity** (for example `pii_email`) |
| **UML diagram**: `.puml`, `.xmi` (images are stored for reference only) | PlantUML or XMI class diagrams: attributes, multiplicity (`[1]`, `*`), keys, enumerations |
| **XML or XSD**: `.xsd`, `.xml` | XSD restrictions (minOccurs, enumeration, pattern, lengths, ranges); in plain XML, the repeated element becomes a list of valid values |
| **Business glossary**: `.csv`, `.xlsx`, `.json` | Term and definition, plus optional column, synonyms, classification, business rule, allowed values and format columns |
| **Master or reference data**: `.csv`, `.xlsx`, `.json`, `.xml` | Each column becomes a list of valid values (up to 5,000) |
| **Business rules document**: `.docx`, `.md`, `.txt`, `.html` (`.pdf` needs the `pypdf` package) | Sentences with must, never, only, between, at least... become rule proposals |
| **Policy or regulation** | Same as a business document, but its rules go to the **Data governance** set, and a stated retention period ("must not be kept longer than seven years") sets the retention rule |

- **Add files:** choose one or more files (up to 60 MB each), what they are (or **Detect automatically**), an optional **business domain** and a description. A file with a domain is used only for datasets in that domain; leave it empty to use it everywhere. Each file is read once on upload and the result is listed straight away.
- The table shows what was read from each file (tables, terms, rows, rule sentences and facts by kind), who uploaded it and when.
- **Use by default** decides whether AI Rule Studio uses the file when the reference context is set to "all enabled files".
- **View** lists what was read, and lets you change the type, domain or description (changing the type reads the file again). **Download** returns the original file; **Read again** re-reads it; **Delete** removes it and what was read from it (rules already created stay).
- Facts on a dataset's own table count most. Matching is by table name (the last two parts, ignoring case and underscores, so `AssetRegistry`, `asset_registry` and `asset.registry` match) and by column name (`assetTag` matches `asset_tag`). Value lists, patterns, terms and sensitivity on a column with the same name in another table of the model also count, with lower confidence.
- Reference files are kept when you reset the application data, unless you untick **Keep reference files**.

### Governance

| Tab | Use it to |
|---|---|
| **Policies** | Create and manage policies (administrators; everyone else sees the list). Create one with **Suggest** (from your data, a standard or an uploaded standard), **Plain-English policy** (write a sentence) or **Manual creation** (a form, or JSON). Every proposal shows how many violations it would raise now before you save. The list shows each policy's description, scope, severity, where it came from, its violations from the last scan (click to open them in Violations), and a switch, **Edit** and **Delete**. There is no review step: an administrator saves and the policy is live. Violations themselves are in Operate > Violations |
| **Standards** | Pick GDPR, SOX, NERC CIP, ISO 8000 or DAMA and see each control as met, partial or gap, with the evidence behind it, and which kinds of policy would cover the standard (covered or missing). **Suggest policies for** the standard opens Suggest for it. **Upload a standard** adds your own policy or regulation document to the reference files; when a model is configured in Settings > LLM, Suggest reads it and proposes policies. This is mapping guidance, not legal advice. (This tab was called Compliance.) |
| **Glossary** | Manage business terms and the datasets they map to. Add terms, and use **Sync to Neo4j** if configured |
| **Contracts** | See all data contracts and their schema status. Paste ODCS YAML to import one (it creates the rules and owners) |
| **Sensitive data** | Scan for and review personal or sensitive columns across datasets. **Scan all datasets** (stewards and administrators; scoped to a platform when you pick one) profiles each dataset and detects sensitive columns; **Scan n new** scans only datasets that were never scanned. A status line shows the last scan, how many new columns it found, any datasets that could not be scanned, and the schedule; **Change schedule** (administrators) scans every N minutes or hours, or daily at a time on chosen weekdays (UTC), and can also scan new datasets right after a catalog sync. Tiles show sensitive columns, those to review, those tagged and restricted ones. Filter by platform, sensitivity, status (all, to review, tagged) and text. **Tag** writes the label to the platform; **Not PII** dismisses a false hit and a rescan will not bring it back; tick several rows to **Tag selected** or mark them **Not PII** in one go. No separate approval step is needed |

### Settings

| Tab | Use it to |
|---|---|
| **Connections** | See each connection's status (**connected**, **error**, **disabled** or **not tested**), when it was last tested and synced, and the last message; click a message to see all of it. **Test** and **Sync** each connection; the outcome is saved on the connection, so it stays visible after the page reloads. Turn a connection off or on with the **Enabled** switch: a disabled connection keeps its datasets and history, but checks, syncs and the scheduler skip it. **Delete** removes a connection, and optionally its datasets with their rules, results and incidents. Connections defined in `config.yaml` (marked **config.yaml**) come back at the next restart, so disable those instead or remove them from the file. Add a connection by picking a type: the config example fills in, and you use `*_env` keys so secrets stay in environment variables. See which LLM the agent uses. Changing connections needs the administrator role |
| **Git** | Only when `features: git_sync: true`. Administrators connect a GitHub repository (repository, base branch, rules folder, access token, and whether to open a pull request or commit), test it, and remove it. Everyone else sees the settings read-only. The token is stored encrypted and never shown again |
| **Environment** | See where the app is running, which `.env` files were loaded, which config file is in use, and every known variable grouped by platform: set or not, where it came from (`.env` or environment), and its value. Secret values are never shown. Also explains the order values are resolved in |
| **LLM** | Administrators keep a list of **saved connections**; the one marked **in use** serves the whole app (the agent, AI rule generation, Plain-English rule and rule suggestions). Each row shows name, provider, model, key status and has **Use**, **Edit**, **Test** and **Delete**; **Add connection** starts a new one. In the form, give it a name and pick a **provider** (Anthropic, Anthropic on AWS Bedrock, Google Gemini, OpenAI or Azure OpenAI or compatible, Databricks Model Serving, Ollama, or none), then fill in what it needs: model, base URL, API key (or the environment variable that holds it), region, API version. **Test connection** sends a one-word request with what's in the form, without saving, and says if the key was rejected, the URL is wrong or the service is down. **Save and use** adds it to the list and applies it across the app at once; the Agent chip at the top changes too. Keys are stored encrypted and never shown again, only the last four characters; **Use config.yaml instead** stops using any saved connection (the list stays); deleting the one in use does the same. For Databricks Model Serving the model is the serving endpoint name from the Serving page, not a Unity Catalog model path. Everyone can see what's in use; only administrators can change it |
| **Scheduler** | See whether the scheduler is on, compute used today vs budget, and the next run plan (datasets due, estimated cost, downstream impact, priority, and which are skipped because they're unchanged). **Run tick now** runs it immediately |
| **Notifications** | See every alert sent (or skipped, when no channel is configured) |
| **Audit** | See every action (who, what, when) for evidence and investigations |
| **Maintenance** | Administrators only. **Load demo data** adds a ready-made utility lakehouse (DuckDB) with incidents, insights, run history, schedules and more next to your own data, without touching it; delete the `demo` connection to remove it. (Administrators also see a **Reset app data…** button at the top of every Settings tab, which opens the same dialog.) See which database the app uses, its size, and how many rows each kind of record has. **Reset application data** clears the app's own database to start fresh. Choose whether to keep user accounts, connections and reference files, or click **Fresh start: erase everything** to untick them all, and, on SQLite, save a backup copy first (to `data/backups/`). Type `RESET` to confirm. Data on the platforms is never touched. Connections and policies from `config.yaml` and `policies.yaml` load again afterwards. If you don't keep user accounts, you're signed out and the next visit starts the first-run setup |

Messages: success messages fade after a few seconds (they pause while the pointer is on them). Error messages stay until you close them with **×**.

### Deploy

Pick a target from the **Deploy to** list, grouped as:
- **Databricks:** Databricks Apps (selected first)
- **Cloud containers:** Snowpark Container Services, Azure Container Apps, AWS App Runner
- **Self-managed:** Docker / Kubernetes, Local or VM

The page then shows only that target:
- its platform badge;
- **current** if this instance runs there;
- whether the path has been verified end to end, or is **not yet verified live**;
- a link to the platform's product page;
- **Download package (.zip)**, with the code, configs, `Dockerfile` and docs, never `.env`, data or tests;
- numbered steps with copyable commands (**Copy** on each block);
- the platform's files to review (`app.yaml`, `databricks.yml`, `Dockerfile`, and so on).

Your choice is remembered. When the app runs on Databricks Apps, a green banner confirms it, and the top bar shows **Databricks Apps**.

### Guide and docs

All documentation, inside the app:
- **Getting started:** concepts and a 10-minute tour.
- **Features reference:** every feature, where to find it, and how to use it.
- **UI guide:** this document.
- **Set up with Databricks.**
- **Configuration and environment.**
- **CLI and API reference.**

The left column lists the documents and an **On this page** outline. Click any heading's **#** to get a link to it. **Search the guide** searches every document and highlights matching sections. Prev/next links at the bottom walk through the docs in order.

The top-bar **Help** link opens the section about the page you're on. The Guide shows the same Markdown files that ship in `docs/`. To add a document, put a `.md` file there and list it in `docs/index.yaml`.

**Adding a platform:** add an entry to `dqga/deploy_targets.yaml` (id, label, group, badge color, summary, steps, files). It appears in the list without code changes, and a test checks that every entry is valid and every file it references exists.

---

## The agent panel

Type a question and press Enter.

- Each answer shows **which tools it used** (a ✓ means it worked) and which model answered.
- Answers cite rule names, numbers and timestamps from those tools.
- The agent does not change data. It suggests corrections, fixes and tags for you to apply, and saves rules as drafts. Opening a ticket is the one thing it runs, and a card in the chat shows the result.
- **New chat** starts a fresh conversation.

**Things to ask:**

| Ask | Gets you |
|---|---|
| "why is meter_readings_daily failing?" | Root cause, evidence, downstream impact |
| "show open incidents" | The triage list |
| "profile customers" | Column statistics and sensitive columns |
| "suggest rules for billing_mart" | Proposed rules, saved as drafts for the review queue |
| "kwh must be between 0 and 40 on ami_raw" | A drafted, dry-run rule, saved as a draft |
| "upstream of billing_mart" / "what is the impact of ami_raw" | Lineage with health |
| "find PII in customers" | Sensitive columns (tag them in Governance > Sensitive data) |
| "discover rules for customers" | AI rule generation, with high-confidence proposals saved as drafts |
| "show anomalies" / "any unusual spikes in ami_raw?" | The anomaly feed |
| "what is the impact of dropping customer_id in meters?" | Impact analysis for a schema change |
| "what patterns have you found?" / "insights" | Highlights, recurring incidents and learnings |
| "policy violations" | Masking, retention and ownership gaps |
| "GDPR report" / "NERC CIP compliance" | Control-by-control status |
| "propose a fix" (on an incident) | Fix options (run them from the incident) |
| "open a ticket" (on an incident) | A ticket opened for the incident |
| "this is a false positive" (on an incident) | Feedback that tunes the rules |
| "export DQX for billing_mart" | Native rule code |
| "what is billed energy?" | The glossary definition and mapped datasets |

---

## Common workflows

### Bring a new dataset under monitoring
1. **Explore** > Datasets > open the dataset.
2. **Profile**, then **Suggest rules**.
3. **Rules** tab: read each suggestion's "why"; the drafts wait in Saved rules. Edit them, then **Send for approval**, and an administrator activates them from the Review queue.
4. Add business rules with **Plain-English rule**, the ones statistics can't guess.
5. **Run checks**.
6. **Overview** tab: set owner, steward and domain, and mark it certified if consumers depend on it.

### Triage an incident
1. **Incidents** > open the highest severity first.
2. Read the summary box, then check the **Evidence** and **Lineage** to confirm the root cause.
3. **Acknowledge** and **Assign** it to the root dataset's owner.
4. Use a suggested fix (**Run now** on the incident, or **Apply correction** under Fixes), or fix it at the source.
5. **Run checks** on the root dataset. When everything passes, the incident resolves itself.
6. Give feedback: **Real issue**, **False positive**, or **Expected change**.

### Handle personal data
1. **Rescan sensitive data** on the dataset, or **Scan all datasets** and review in **Governance > Sensitive data**.
2. **Tag** confirmed columns (writes Unity Catalog tags) or mark **Not PII**.
3. **Operate > Explore > Violations**: run a scan, then **Enforce** the masking violations. That creates and attaches a column mask.

### Gate schema changes in CI
1. On the dataset's **Contract** tab, generate the contract, adjust it, and **Save as contract**.
2. Commit the YAML next to the pipeline code.
3. In CI, run `python -m dqga contract-check <contract.yaml>`. It exits 1 on breaking changes (dropped columns, changed types).

### Generate rules for a new dataset
1. **AI Rule Studio > Rule generation**: pick the dataset, then **Generate rules**.
2. Review the pre-selected proposals (80%+ confidence, passing dry run) and the evidence for each.
3. Add any with a failing dry run only after checking whether the data or the rule is wrong.
4. **Save selected as drafts**, then **Send for approval** in Saved rules. Once an administrator activates them, the coverage panel shows the gain per dimension.


### Plan a schema change
1. **Impact analysis**: pick the dataset, choose **Drop columns** or **Change column types**, and tick the columns.
2. Click **Analyse**. Review the breaking contracts, affected rules and downstream columns.
3. **Notify owners**, with a note about timing.

### Run the rules in another tool
1. Open **AI Rule Studio > Rule catalog** and click **Export rules**.
2. Pick the dataset (or **All datasets**) and the target format, for example Soda for a team that runs soda-core.
3. Check the preview, including any rules the format can't express. Then **Download**, or **All formats (.zip)** to hand one file to several teams.
4. Or ask the agent: "export soda for meters".

### Move to Databricks Apps
1. Open **Deploy**, choose **Databricks Apps** in **Deploy to**, and click **Download package (.zip)**.
2. Follow the steps on that page, or `docs/databricks-setup.md` in the package.
3. In the deployed app, check that the top bar says **Databricks Apps**, then use **Settings > Connections**: **Test**, then **Sync**.

### Cut alert noise
- Mark wrong alerts **False positive**. Anomaly rules relax, and threshold rules get a proposed new threshold.
- After 3 false positives with no confirmed issues, the agent proposes disabling the rule.
- Check **Explore > Patterns and Insights** (Learnings) for alert precision and noisy rules.
