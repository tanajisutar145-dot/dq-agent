# CLI and API reference

## Command line

Run `python -m dqga <command>`, or `datatrustai <command>` after `pip install -e .`. Global options: `--config <file>` and `--env-file <file>` (`none` disables `.env`).

| Command | What it does | Exit code |
|---|---|---|
| `demo` | Builds the demo warehouse with planted issues and seeds the app (resets demo data) | 0 |
| `serve [--host H] [--port P]` | Runs the web app and API. The port defaults to `DATABRICKS_APP_PORT`, then `PORT`, then 8000 | - |
| `sync` | Syncs catalogs and lineage from every connection | 0 |
| `run [--asset NAME]` | Runs active checks on one dataset, or on every dataset with rules | **1 if any check fails**, for CI gates |
| `demo --add` | Keep the app database and add the demo datasets next to your data (plain `demo` recreates the database) | 0 |
| `tick` | One cost- and change-aware scheduler tick | 0 |
| `export --asset NAME --target FORMAT` | Prints rules in a format: `dqx`, `lakeflow`, `sql`, `great_expectations`, `soda`, `dbt`, `pydeequ`, `snowflake_dmf`, `glue_dqdl` or `json` | 0 |
| `rules-export [--out DIR] [--asset NAME] [--drafts]` | Writes the rules as one YAML file per dataset (default folder `dq-rules/`) | 0 |
| `rules-import PATH [--apply]` | Reads a file, folder or zip of rule files. Without `--apply` it only prints what would happen; with it, saves drafts | **1 if a file or rule is invalid** (nothing is saved) |
| `rules-validate PATH` | Checks rule files against the catalog and saves nothing. Use it to gate a pull request | **1 if a file or rule is invalid** |
| `contract-check FILE` | Validates an ODCS contract against the live schema | **1 on breaking changes**, 2 if no dataset matches |
| `package-app [--out FILE]` | Builds the deployable app package (zip) | 0 |
| `create-user --email E [--name N] [--role admin\|steward\|viewer] [--password-env VAR]` | Creates an account. It prompts for the password unless `--password-env` names a variable that holds it | 1 if the email exists or the password is too weak |

Stop the server before running `demo`: the server keeps the demo warehouse file open.

**Example CI gate:**

```bash
python -m dqga contract-check contracts/billing_mart.yaml && python -m dqga run --asset main.gold.billing_mart
```

## REST API

Interactive API docs are built in. Open `/docs` (Swagger UI) or `/redoc` on any running instance.

**Authentication:**

| `auth.mode` | How API calls are authenticated |
|---|---|
| `local` | Session cookie from `POST /api/auth/login` |
| `sso` | `X-Forwarded-Email` header, set by Databricks Apps and most SSO proxies |
| `none` | No authentication |

**Rules on every call:**
- Requests that change something must send `X-Requested-With: DataTrustAI`.
- Roles are enforced: viewers can't change anything, and administrator-only endpoints return 403 for others.
- Every change is written to the audit log under the signed-in user.

### Sign-in and accounts

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/auth/config` | Public: sign-in mode, sign-up policy, whether first-run setup is needed |
| POST | `/api/auth/setup` | First run only: create the administrator `{name, email, password}` |
| POST | `/api/auth/signup` | Create an account `{name, email, password}` → `active` or `pending` |
| POST | `/api/auth/login` | `{email, password, admin}`. `admin: true` only accepts administrators. Sets the session cookie |
| POST | `/api/auth/logout` | End the session |
| GET | `/api/auth/me` | The signed-in user |
| POST | `/api/auth/password` | Change your password `{current, new}` |

### Admin console (administrators only)

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/admin/summary` | Counts and access settings |
| GET, POST | `/api/admin/users` | List users; create one `{name, email, role}` → temporary password |
| PATCH | `/api/admin/users/{id}` | `{role, status, name}`. Approve with `status: active`, reject or disable with `status: disabled` |
| POST | `/api/admin/users/{id}/reset-password` | New temporary password; signs the user out |
| POST | `/api/admin/users/{id}/unlock` | Clear a lockout |
| DELETE | `/api/admin/users/{id}` | Delete an account |
| GET | `/api/admin/maintenance` | App database type, file, size and rows per table |
| POST | `/api/admin/reset` | `{confirm: "RESET", keep_users, keep_connections, backup}`. Clears the app database (SQLite backup first when `backup` is true), then reloads `config.yaml` connections and `policies.yaml` |

### Overview and platform

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Liveness |
| GET | `/api/meta` | Rule types, export formats, frameworks, LLM, runtime, current user |
| GET | `/api/overview` | Scores, heatmap, trend, incidents, SLA breaches, custom metric tiles |
| GET | `/api/overview/options` | Filter choices for the Overview: platforms, domains, datasets, severities, rule sets, time windows |
| GET | `/api/overview/summary`, `/api/overview/rules`, `/api/overview/incidents` | The three Overview tabs, all taking `platform`, `domain`, `asset_id`, `severity`, `category` (rule set) and `days` (7, 30 or 90) |
| GET, POST | `/api/custom-metrics` | List or create custom DQ metrics `{name, measure, params, direction, target, warn_at, unit, description}` |
| GET | `/api/custom-metrics/options` | Measures, filters and their choices |
| POST | `/api/custom-metrics/preview` | Calculate a metric without saving it |
| PATCH, DELETE | `/api/custom-metrics/{id}` | Change or delete a metric (changing the measure or filters clears its history) |
| POST | `/api/custom-metrics/evaluate`, `/api/custom-metrics/{id}/evaluate` | Recalculate all metrics, or one |
| GET | `/api/settings/env` | Runtime and environment variable status (no secret values) |
| GET | `/api/deploy/targets` | Deployment targets with steps and files |
| GET | `/api/deploy/package/{target}.zip` | App package for a target |
| GET | `/api/docs`, `/api/docs/{id}` | In-app guide documents |

### Connections and datasets

| Method | Path | Purpose |
|---|---|---|
| GET, POST | `/api/connections` | List connections with `health` (ok, error, disabled, untested), `health_detail`, last test and sync; or add one (saved even if it can't start, with the error as its status) |
| POST | `/api/connections/{name}/test` | Test a connection and save the outcome (disabled ones are tested with a temporary connector) |
| PATCH | `/api/connections/{name}` | `{"enabled": false}` to disable, `{"enabled": true}` to enable. Disabled connections are skipped by checks, syncs and the scheduler |
| DELETE | `/api/connections/{name}?purge=true` | Delete a connection; with `purge`, also its datasets and their rules, results and incidents |
| POST | `/api/catalog/sync?connection=` | Sync catalog and lineage. Errors are returned per connection and saved on it; naming a disabled connection is an error |
| GET | `/api/assets?q=&domain=&platform=` | Search datasets |
| GET, PATCH | `/api/assets/{id}` | Dataset details; set owner, steward, domain, certified |
| POST, GET | `/api/assets/{id}/profile` | Profile now / latest profile |
| POST | `/api/assets/{id}/run` | Run checks |
| POST | `/api/assets/{id}/suggest` | Propose rules |
| POST | `/api/assets/{id}/classify` | Profile the dataset again and detect sensitive columns |
| GET | `/api/assets/{id}/results` | Recent check results |
| GET | `/api/assets/{id}/metrics?metric=&column=` | Metric history (`row_count`, `dq_score`, `null_rate`...) |
| GET | `/api/assets/{id}/contract` | Generated ODCS contract |

### Reference files

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/references` | List reference files (no content) |
| GET | `/api/references/kinds` | File kinds, size limit and the three rule sets |
| POST | `/api/references` | Upload `{name, content_b64, kind, domain, description}`; the file is read straight away |
| GET | `/api/references/{id}?limit=` | Details and what was read |
| GET | `/api/references/{id}/download` | The original file |
| PATCH | `/api/references/{id}` | `{kind, domain, description, enabled}`; a new kind reads the file again |
| POST | `/api/references/{id}/reparse` | Read the file again |
| DELETE | `/api/references/{id}` | Delete the file and what was read from it |
| POST | `/api/assets/{id}/reference-context` | `{reference_ids}`: facts that apply to the dataset, and the context text sent to the model |

### Rules and export

| Method | Path | Purpose |
|---|---|---|
| GET, POST | `/api/rules?asset_id=&status=&category=&severity=&dimension=` | List or create rules. `status` takes one value or several separated by commas (`active,disabled`); `platform` filters by connection type. Statuses: `proposed` (draft), `review`, `approved`, `rejected`, `active`, `disabled`. `category` is `core`, `business` or `governance` (inferred from the type when not given) |
| POST | `/api/rules/dry-run` | Run a rule on the platform without saving it. The result includes `ran_on` (platform, connection, seconds, queries, the SQL that ran). Platforms that can't run SQL return an error |
| POST | `/api/rules/nl` | Rule from a description (AI Rule Studio > **Plain-English rule**): `{asset_id, text, category, reference_ids, use_references}`. Business terms from reference files map to columns; with a model, the reference context is sent too. Nothing is saved unless `"save": true`: the response has the validated rule (`id` null) and its dry run |
| PATCH | `/api/rules/{id}` | Update any of name, category, severity, status, type, column, params, dimension, threshold, description (creates a new version; invalid values are rejected) |
| POST | `/api/rules/{id}/activate` | Activate (administrators only; the app's own screens use the review steps below) |
| GET | `/api/rules/{id}/history` | Versions and results |
| GET | `/api/rules/export?asset_id=&target=&include_proposed=&download=` | One format. With `rule_ids=1,2,3` instead of `asset_id`, exactly those rules (any status): one dataset gives the file, several give a zip (`download=true`) with a folder per dataset |
| GET, PUT, DELETE | `/api/git` | Only when `features.git_sync` is on (404 otherwise). The saved repository settings, never the token. PUT `{repo, branch, folder, mode, token, api_url}` and DELETE are admin only |
| POST | `/api/git/test` | Check the token, repository and branch (admin) |
| POST | `/api/git/export` | `{asset_ids?, include_drafts?, message?}` writes the rule files as a pull request (or a commit), steward or admin. Returns `{status, url, branch, commit, files}`; `status: unchanged` when the repository already matches |
| GET | `/api/rules/files/download?asset_id=&include_drafts=` | Rule files (YAML): one file for a dataset, or a zip with a file per dataset |
| POST | `/api/rules/files/preview` | `{files: [{name, text}], zip_b64}` what an import would do; saves nothing |
| POST | `/api/rules/files/apply` | Same body. Saves drafts; never changes a live rule and never deletes. Steward or admin |
| GET | `/api/rules/export/bundle?asset_id=&formats=&include_proposed=&rule_ids=` | Zip of many formats (omit `asset_id` for all datasets; `rule_ids` for only the selected rules) |

### Rule review (draft, review, approved, active)

Creating a rule with `POST /api/rules` saves a draft; other statuses need the administrator role. Discovery's `accept` always saves drafts (its `activate` flag is ignored). Editing a rule that is in review, approved, active or disabled needs the administrator role.

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/rules/submit` | `{rule_ids, note}`: send drafts (or rejected rules) for approval |
| POST | `/api/rules/withdraw` | `{rule_ids}`: back to a draft (the author, or an administrator) |
| GET | `/api/rules/review?status=waiting\|approved\|rejected\|all&asset_id=&platform=&category=&severity=` | The queue with counts |
| POST | `/api/rules/review/decide` | Administrators only. `{rule_ids, decision: "approve" \| "reject" \| "activate" \| "approve_activate", note}`. Rejecting needs a note; activating needs the rule approved first |

### LLM settings

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/llm` | Providers (including `gemini`) and their fields, the saved connections, the current choice, where it comes from (`app` or `config`), and whether a key is set (never the key) |
| PUT | `/api/llm` | Administrators only. Save a connection: `{name, profile_id, provider, model, base_url, api_key, api_key_env, aws_region, azure, api_version, host, clear_key, activate}`. Without `profile_id` it adds a new one; with it, updates that one (a blank `api_key` keeps the saved key). It becomes the one in use unless `activate` is false. Names are unique. The response lists `profiles` and `active_id` |
| POST | `/api/llm/profiles/{id}/activate` | Administrators only. Use that saved connection across the app |
| DELETE | `/api/llm/profiles/{id}` | Administrators only. Delete a saved connection; deleting the one in use falls back to config.yaml |
| POST | `/api/llm/test` | Administrators only. Try the same body with one small request; nothing is saved |
| DELETE | `/api/llm` | Administrators only. Stop using a saved connection (the list stays) and use config.yaml and environment variables |

AI rule generation (`POST /api/assets/{id}/discover?use_llm=true`) answers 400 when no LLM is configured and 502 when the model can't be reached; pass `use_llm=false` for statistical discovery only. Its result has `context.dry_runs` (how many candidates ran on the platform).

### Dataset grouping

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/grouping` | Label, source, groups in use, unassigned and locked datasets |
| POST | `/api/grouping/reapply` | Administrators only. Unlock every dataset and recompute its group from the configured source |

### Runs and schedules

`scope` picks active rules: `{"category": "core"|"business"|"governance"|null, "severity": minimum severity or null, "asset_ids": [...], "platform": connection type or null, "rule_ids": [...]}`. Empty lists and nulls mean "all".

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/rules/run/preview` | `{scope}` → how many rules and datasets would run, estimated seconds, datasets skipped (disabled connections) |
| POST | `/api/rules/run` | `{scope}` → run the matching active rules now (trigger `manual`) |
| GET | `/api/schedules` | Schedules with what they cover, cadence text, next and last run; plus whether the background scheduler is on |
| POST | `/api/schedules` | `{name, cadence: "interval" \| "daily", every_minutes, at_time: "HH:MM" (UTC), weekdays: [0-6], scope, enabled}` |
| PATCH | `/api/schedules/{id}` | Change any field; `{"enabled": false}` pauses |
| DELETE | `/api/schedules/{id}` | Delete (rules go back to the default interval) |
| POST | `/api/schedules/{id}/run` | Run a schedule now; its next due time doesn't move |
| GET | `/api/runs?days=&asset_id=&trigger=&status=&schedule_id=&limit=` | Run history, stats and checks per day. `status` is `ok`, `failures` or `error` |
| GET | `/api/runs/{id}` | One run with each check's result |

### Incidents and feedback

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/incidents?status=open\|resolved\|muted\|all` | List incidents; also filters by `severity`, `asset_id`, `domain` and `platform` (incidents rooted in or touching those datasets) |
| GET | `/api/incidents/{id}` | Details, evidence, fixes, timeline |
| POST | `/api/incidents/{id}/action` | `{action: ack\|assign\|resolve\|mute\|reopen\|comment, assignee, note}` |
| POST | `/api/incidents/{id}/ticket` | Open a ticket now |
| POST | `/api/incidents/{id}/remediate?index=` | Run a fix now |
| GET, POST | `/api/feedback` | Feedback log and precision; `{verdict, rule_id \| incident_id}` |

### Discovery, anomalies, corrections, quarantine, impact, insights

The corrections and quarantine endpoints (`/api/fixes`, `/api/incidents/{id}/fixes`, `/api/quarantine`) answer 404 with code `feature_off` unless `features.fixes_and_quarantine` is on (it is off by default).

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/assets/{id}/discover?use_llm=` | AI rule generation: candidates with confidence, sources, evidence, dry run, coverage, and their set (`rule_category`: core, business, governance; counts in `sets`). Optional body `{reference_ids, use_references}` picks the reference files (default: every enabled file for the dataset's domain) |
| POST | `/api/assets/{id}/discover/accept` | `{rules, activate}` saves chosen candidates |
| GET | `/api/anomalies?days=` | Anomaly feed across datasets, plus unmonitored datasets |
| GET | `/api/assets/{id}/anomalies` | Metric series with expected bands and level shifts |
| POST | `/api/assets/{id}/monitor` | Add the anomaly monitor pack |
| GET | `/api/fixes` | Correction suggestions across datasets, and history |
| GET | `/api/incidents/{id}/fixes` | Corrections for an incident |
| POST | `/api/fixes/apply` | `{fix_id, incident_id}`. Applies the correction at once (undo is available) |
| POST | `/api/fixes/{id}/undo` | `{force}` restores the snapshot |
| GET | `/api/quarantine?status=open\|all\|...` | Batches and summary |
| GET | `/api/quarantine/{id}?unmask=` | Batch with sample rows (sensitive columns masked; `unmask` for administrators) |
| POST | `/api/quarantine/plan` | `{rule_id, mode, target, clean_table}` → rows and tables |
| POST | `/api/quarantine` | Quarantine (`move`, `copy`, `split`); runs at once |
| POST | `/api/quarantine/{id}/release` | `{revalidate}`. Without re-validation is for administrators only |
| POST | `/api/quarantine/{id}/purge` | Delete the batch's rows |
| GET | `/api/impact?asset_id=&columns=&change=` | Impact analysis (`data`, `drop`, `retype`) |
| POST | `/api/impact/notify` | Send the impact summary to owners |
| GET | `/api/insights?days=&platform=` | Patterns and learnings (optionally for one platform), with `last_refresh` (when, who, what it did) |
| GET | `/api/ai-insights?platform=` | The saved AI write-up for that view (`report`: insights, learnings, recommendations with links), whether your data changed since (`fresh`), and which model would write the next one |
| POST | `/api/ai-insights/generate` | `{platform, force}`: write up the current facts with the model from Settings > LLM (stewards and administrators). Unchanged facts return the saved text without calling the model; `force` rewrites. 400 when no model is configured, 502 when it fails or returns nothing checkable |
| POST | `/api/insights/refresh` | `{"mode": "due" \| "all" \| "sync"}`: sync metadata from every enabled connection, then run due checks and schedules (`due`), every active rule (`all`), or nothing (`sync`) |

### Governance

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/governance/summary` | Coverage, sensitive data, violations |
| POST | `/api/classifications/{id}/decide` | Tag (`approve: true`) or dismiss |
| POST | `/api/classifications/decide-bulk` | `{ids, approve}` tag or dismiss several columns (one tagging step per dataset) |
| GET | `/api/pii-scans/status` | Last sensitive-data scan, datasets never scanned, columns to review or tagged, schedule |
| POST | `/api/pii-scans/run` | `{platform?, asset_ids?, only_unscanned?}` scan now; steward or admin |
| GET, PUT | `/api/pii-scans/schedule` | `{enabled, cadence, every_minutes, at_time, weekdays, after_sync}`. PUT is admin only |
| GET, POST | `/api/policies` | List policies (with description, severity, source and last-scan violation counts), or save one. A save is validated; admin only |
| PATCH, DELETE | `/api/policies/{key}` | `{enabled}` switches a policy on or off; delete it. Admin only |
| POST | `/api/policies/draft` | `{text}` a policy from plain English, validated, with `would_flag`. Nothing is saved. Admin only |
| POST | `/api/policies/suggest` | `{standards: [...], use_uploads}` suggested policies with reasons and `would_flag`. Admin only |
| GET | `/api/standards` | Each standard's controls, status and policy coverage, plus uploaded standards |
| POST | `/api/policy-scans/run` | Scan every enabled policy now; returns the scan with its violations |
| GET | `/api/policy-scans/latest` | The last scan with its violations, and the schedule |
| GET | `/api/policy-scans?limit` | Scan history (without violations) |
| GET, PUT | `/api/policy-scans/schedule` | `{enabled, cadence: interval or daily, every_minutes, at_time, weekdays}`. PUT is admin only |
| GET | `/api/policies/violations` | Evaluate all policies now, without saving a scan |
| POST | `/api/policies/enforce` | `{policy, asset_id, column}` runs the enforcement SQL now and returns the record |
| GET | `/api/compliance/{framework}` | `gdpr`, `sox`, `nerc_cip`, `iso_8000`, `dama` |
| GET, POST | `/api/contracts` | List or import (`{yaml}`) |
| POST | `/api/contracts/{id}/validate` | Check against the live schema |
| GET, POST | `/api/glossary` | Terms |
| POST | `/api/glossary/{id}/link` | Link a term to a dataset |
| POST | `/api/glossary/sync-neo4j` | Mirror to Neo4j |

### Lineage, operations and agent

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/lineage?fqn=&depth=` | Graph, or the neighbourhood of one dataset |
| POST | `/api/lineage/sync` | Pull lineage from platforms |
| POST | `/api/lineage/openlineage` | Ingest an OpenLineage run event |
| POST | `/api/lineage/dbt` | Ingest a dbt `manifest.json` |
| POST | `/api/lineage/edges` | Add an edge `{source, target}` |
| GET | `/api/scheduler`, POST `/api/scheduler/tick` | Plan and budget; run a tick |
| GET | `/api/audit`, `/api/notifications` | Audit log; alert log |
| POST | `/api/agent/chat` | `{message, session_id, context: {asset_id \| incident_id}}` |

**Examples:**

```bash
curl -s http://127.0.0.1:8000/api/overview
```

```bash
curl -s -X POST http://127.0.0.1:8000/api/rules/nl -H "Content-Type: application/json" -d "{\"asset_id\": 3, \"text\": \"kwh must be between 0 and 500\"}"
```

```bash
curl -s -o rules.zip "http://127.0.0.1:8000/api/rules/export/bundle?formats=soda,dbt,great_expectations"
```
