<#
.SYNOPSIS
  Creates a zip backup of the project's source code in the "backup" folder.

.DESCRIPTION
  Writes <project>\backup\<project>-code-backup-<yyyyMMdd-HHmmss>.zip.
  Generated, local and secret files are left out:
    folders  .venv, venv, __pycache__, .pytest_cache, .mypy_cache, .ruff_cache, node_modules, dist, build,
             *.egg-info, data (local databases and the encryption key), backup (earlier backups)
    files    .env and .env.* (but not .env.example), *.pyc, *.pyo, *.log, .secret_key, .DS_Store, Thumbs.db
  Nothing in the project is changed or deleted.

.PARAMETER ProjectRoot
  The folder to back up. Default: the parent of this script's folder (the project root).

.PARAMETER BackupDir
  Where to put the zip. Default: <ProjectRoot>\backup.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File scripts\create-code-backup.ps1
#>
[CmdletBinding()]
param(
    [string]$ProjectRoot,
    [string]$BackupDir
)

$ErrorActionPreference = "Stop"
if (-not $ProjectRoot) {
    $here = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
    $ProjectRoot = Split-Path -Parent $here
}
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$root = (Resolve-Path -LiteralPath $ProjectRoot).Path.TrimEnd("\")
$name = Split-Path -Leaf $root
if (-not $BackupDir) { $BackupDir = Join-Path $root "backup" }
New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
$BackupDir = (Resolve-Path -LiteralPath $BackupDir).Path

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$zipPath = Join-Path $BackupDir "$name-code-backup-$stamp.zip"

# Folders and files that are generated, local or secret: never backed up.
$skipDirs  = @(".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "node_modules", "dist", "build", "backup", "data")
$skipDirLike = @("*.egg-info")
$skipFiles = @(".env", ".secret_key", ".DS_Store", "Thumbs.db")
$skipFileLike = @(".env.*", "*.pyc", "*.pyo", "*.log")
$keepFiles = @(".env.example")

function Test-SkipDir([string]$dirName) {
    if ($skipDirs -contains $dirName) { return $true }
    foreach ($p in $skipDirLike) { if ($dirName -like $p) { return $true } }
    return $false
}

function Test-SkipFile([string]$fileName) {
    if ($keepFiles -contains $fileName) { return $false }
    if ($skipFiles -contains $fileName) { return $true }
    foreach ($p in $skipFileLike) { if ($fileName -like $p) { return $true } }
    return $false
}

$script:count = 0
$script:bytes = 0
$script:skipped = @()

function Add-Folder($zip, [string]$dir) {
    foreach ($item in Get-ChildItem -LiteralPath $dir -Force) {
        if ($item.PSIsContainer) {
            if (Test-SkipDir $item.Name) { continue }
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }  # do not follow links
            Add-Folder $zip $item.FullName
        }
        else {
            if (Test-SkipFile $item.Name) { continue }
            $rel = $item.FullName.Substring($root.Length + 1).Replace("\", "/")
            try {
                [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $item.FullName, "$name/$rel", [IO.Compression.CompressionLevel]::Optimal)
                $script:count++
                $script:bytes += $item.Length
            }
            catch {
                $script:skipped += "$rel ($($_.Exception.Message))"
            }
        }
    }
}

Write-Host "Backing up $root"
$zip = [IO.Compression.ZipFile]::Open($zipPath, [IO.Compression.ZipArchiveMode]::Create)
try {
    Add-Folder $zip $root
}
finally {
    $zip.Dispose()
}

$size = (Get-Item -LiteralPath $zipPath).Length
Write-Host ("Done: {0} files ({1:N1} MB) -> {2:N1} MB zip" -f $script:count, ($script:bytes / 1MB), ($size / 1MB))
Write-Host $zipPath
if ($script:skipped.Count -gt 0) {
    Write-Warning ("{0} file(s) could not be read and were left out (open or locked):" -f $script:skipped.Count)
    $script:skipped | ForEach-Object { Write-Warning "  $_" }
}
