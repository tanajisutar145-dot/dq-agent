# TCS DataTrustAI

A data quality and governance control plane with an agent on top. It profiles data,
proposes and runs checks where the data lives, groups failures into incidents with
root cause from lineage, enforces governance policies, and explains everything
through a chat agent that suggests changes for a person to apply.

Databricks is the primary platform. Snowflake, Spark, Cognite Data Fusion,
AWS (Glue / Athena / Lake Formation), and Azure (Purview) are supported through the
same connector interface. A local DuckDB demo runs the whole product offline.

**Guides** (also inside the app under **Help > Guide and docs**, with search and a context-sensitive **Help** link in the top bar):
- [Getting started](docs/getting-started.md): concepts and a 10-minute tour
- [Features reference](docs/features.md): every feature, where to find it, how to use it
- [UI guide](docs/ui-guide.md): every page, the agent panel, and step-by-step workflows
- [Set up with Databricks](docs/databricks-setup.md): run locally against your workspace, or deploy as a Databricks App (grants, Lakebase, secrets, troubleshooting)
- [Configuration and environment](docs/configuration.md): config files, `.env`, environment variables, connection examples
- [CLI and API reference](docs/api-cli.md): command line, REST endpoints, CI gates

## Quick start (local demo)

```bash
python -m venv .venv
.venv\Scripts\activate            # Windows   (source .venv/bin/activate on macOS/Linux)
pip install -r requirements.txt
pip install -e .
copy .env.example .env            # optional: fill in only what you use
python -m dqga demo               # builds a utility lakehouse with planted issues
python -m dqga serve              # http://127.0.0.1:8000
```

**Add the demo to the app you already use:** Settings > Maintenance > Load demo data (about a minute), or stop the server and run `python -m dqga demo --add`. It keeps your datasets, rules and settings and adds a DuckDB utility demo next to them (the platform picker switches between them). Delete the `demo` connection to remove it.

**Full demo, separate from your real setup.** `config.demo.yaml` has its own database (`data/demo.db`) and a local DuckDB warehouse, and needs no sign-in:

```bash
python -m dqga --config config.demo.yaml demo
```
```bash
python -m dqga --config config.demo.yaml serve --port 8770
```

The demo fills every screen: incidents (open and 30 days resolved), anomalies, insights, two weeks of run history, schedules, rules in every review state, approvals, custom Overview metrics, and reference files. Stop its server before rebuilding it. Don't run `demo` against a config that points at real platforms: it recreates the app database.

The in-app **Deploy** page has a **Deploy to** list with step-by-step instructions and a package download for each target:
- **Databricks Apps** ([details below](#deploy-on-databricks))
- Snowpark Container Services
- Azure Container Apps
- AWS App Runner
- Docker / Kubernetes (using the included `Dockerfile`)
- Local or VM

Targets are defined in `dqga/deploy_targets.yaml`; add an entry there to offer another platform, with no code changes. Only the local path has been run end to end so far. The page marks the others **not yet verified live**.

The demo plants five problems and the product finds them on its own:

| Planted issue | What you should see |
|---|---|
| AMI extractor outage: substation SUB-07 sends empty kWh for 12h | One critical incident rooted at `bronze.ami_raw`, with `gold.meter_readings_daily` grouped under it, volume anomaly (-19% vs weekly baseline), billing and finance flagged as downstream at risk |
| Meters pointing at missing customers | Referential integrity incident on `silver.meters` |
| Transformer sensors: flatline, spikes, 3h gap | Four time-series checks failing on `ot.sensor_timeseries` |
| Duplicate journal entries | Uniqueness incident on `finance.gl_revenue`, not blamed on the unrelated upstream outage |
| Customer PII | Email, phone, name, address detected; masking policy violations you can enforce |

Run the tests: `python -m pytest` (190 tests, about two minutes).

## Features

**Monitor and detect**
- Connectors with push-down execution: checks compile to SQL in each platform's dialect; only aggregates come back
- Profiling (nulls, distinct, min/max, quantiles, top values, string patterns) in one scan per column batch
- 15 rule types across 10 dimensions: completeness, validity, uniqueness, consistency, integrity, timeliness, accuracy, volume, schema, plausibility
- Row-level rules on a table are batched into a single scan
- Anomaly detection on row count, null rate, mean, distinct count, freshness, with weekly seasonality (robust median/MAD), plus PSI for category drift
- Industrial time-series checks: gaps, flatlines, spikes, physical bounds, timestamp order, sampling-rate drift
- Scores 0-100 per dataset, dimension, and group (domain, business unit, data product: configurable); 30-day trend
- Policies are created by administrators with no review step: **Suggest** (from your data, a reference standard or an uploaded standard), a **plain-English** sentence, or a form. Each shows how many violations it would raise before you save. **Violations** (under Operate) scans policies on demand or on a schedule, keeps every scan, and shows what is new and what was resolved
- AI rule generation also draws on your **business glossary, data contracts, policies and standards** (tick them under Governance context): a contract's uncovered promises and a retention policy become proposals even without a model, and every proposal carries a source tag
- Operate has three entries: a simple **Overview** (score, open incidents, rules in review, SLA breaches, trend, next scheduled run), **Explore** (Datasets, Incidents, Violations, Patterns and Insights) and **Runs** (run rules, schedule them, run history). **Violations** shows policy scans. Dashboards and charts are left to your BI tool
- Anomalies tab on each dataset: spikes, drops and sustained level shifts with expected bands, and a one-click monitor pack
- Explore > Patterns and Insights: AI-written insights, learnings and recommendations. The app computes the facts; the configured LLM writes them up under built-in guidance, and every statement must cite facts and use only numbers from them. Saved until the data changes, so switching models doesn't reword it. **Refresh insights** pulls the latest data (the computed facts, including the failure heat map, are in `GET /api/insights`)
- Impact tab on each dataset: what breaks downstream if data is wrong or a column is dropped or retyped, with contracts, rules and owners to notify
- Platform picker: one choice narrows Overview, Explore and the dataset pages to that platform's datasets

**Author rules**
- AI rule generation: proposes core, business-domain and governance rules from schema, statistics, history, relationships, reference files, glossary and other datasets (and from the configured LLM, which must be reachable unless you untick "Use the AI model"); every candidate has a confidence score, evidence, and a dry run on the platform
- Reference library: upload models, ontologies, glossaries, master data and business documents (PDF needs `pypdf`, installed with the requirements); they become rule evidence and model context
- Suggestions from the profile (heuristics) on the dataset page
- Plain-English rule: plain-English rules ("kwh must be between 0 and 500", one per line) parsed by patterns first, the LLM second, then dry-run on the platform; nothing is stored until you save it as a draft
- Rule lifecycle: draft, send for approval, review, activate. Only administrators approve, reject and activate; stewards save drafts and send them. Every step is versioned and audited
- AI Rule Studio: Rule generation, Saved rules, Review queue, Rule catalog (tick rules to export only those), Reference files; a platform picker narrows all of it
- Export rules to the tools teams already run:
  - Databricks DQX
  - Lakeflow expectations
  - SQL validation queries (in the dataset's own dialect)
  - Great Expectations (GX 1.x suite)
  - Soda (SodaCL)
  - dbt tests
  - PyDeequ
  - Snowflake Data Metric Functions
  - AWS Glue DQDL
  - lossless DataTrustAI JSON
- **Optional Git sync:** with `features: git_sync: true`, Settings > Git connects a GitHub repository and Export to Git opens a pull request with the rule files
- **Rules as files:** download the rules as one YAML file per dataset and import edited files back as drafts for review (no repository needed): AI Rule Studio > Rule catalog, `python -m dqga rules-export`, `rules-import` and `rules-validate` for CI
- Export one format, or download a zip of every format for one dataset or all of them. Use the AI Rule Studio, the Rules tab, `GET /api/rules/export/bundle`, or `python -m dqga export`. Rules a format can't express are listed, never dropped silently.

**Respond**
- Incidents grouped by root cause: walks upstream through failing assets only, so unrelated upstream failures are not blamed
- Deterministic root-cause analysis: evidence timeline, hypothesis, downstream blast radius
- Severity from rule severity, downstream count, and certification
- Alerts to Slack, Teams (Workflows webhook, Adaptive Card), email; tickets in Jira or ServiceNow (dry-run preview when not configured)
- Fix suggestions: dedupe, re-run a Databricks job, notify the source owner. Corrections and quarantine of bad rows are switched off for now (`features.fixes_and_quarantine`)
- Auto-remediation guardrails: allow-listed action types, row limit, never on certified assets, dry-run count first; anything else is skipped and logged (a person can run it from the incident)

**Govern**
- Sensitive-data detection (names, emails, phones, SSN, Luhn-validated cards, IBAN, IPs, addresses, DOB); raw sample values are never stored or sent to an LLM. Scan all datasets from Governance > Sensitive data, on a schedule or after a catalog sync, and review, tag or dismiss columns in bulk
- Tag write-back: Unity Catalog tags, Snowflake object tags, Lake Formation LF-tags, Purview classifications, CDF metadata
- Policy as code (`policies.yaml`): masking, retention, ownership, quality gates, classification, certification, contracts; enforcement SQL (UC column masks, Snowflake masking policies, retention deletes) runs when an administrator or steward clicks Enforce
- Data contracts (ODCS v3): generate, import, validate against the live schema; `python -m dqga contract-check contract.yaml` exits 1 on breaking changes for CI
- Standards (Governance > Standards): compliance evidence for GDPR, SOX ITGC, NERC CIP, ISO 8000, DAMA-DMBOK (mapping guidance, not legal advice)
- Business glossary linked to datasets, with optional Neo4j sync
- Full audit log of every change, with the acting user

**Learn and optimize**
- Feedback (false positive / real issue / expected change) tunes anomaly sensitivity, proposes threshold changes or disabling noisy rules, and resets baselines after planned changes
- Rule precision tracking
- Cost-aware, change-aware scheduler: skips tables whose platform change marker has not moved (freshness still runs), ranks by severity × downstream impact × certification ÷ cost, stops at a daily compute budget
- Rule schedules (every N minutes, or at a time on chosen weekdays) take over the rules they cover; the run history shows every run and its checks

**Agent**
- Tool-calling agent with 26 tools: overview, search, profile, run checks, lineage, root cause, metric history, policies, compliance, glossary, export, contracts, suggest and discover rules, rule from text, classify PII, remediation, tickets, anomalies, impact, insights and feedback
- Answers only from tool results; changes to data are suggestions a person applies, and new rules are drafts for review
- One LLM for the whole app, chosen in **Settings > LLM**: a list of saved connections (name, provider, model, key) with one in use, a **Test connection** button, and API keys stored encrypted (set `DQGA_SECRET_KEY` on Databricks Apps or in containers). Providers: Anthropic (called over HTTP), Anthropic on Bedrock, Google Gemini, Databricks Model Serving (the serving endpoint name; OAuth via the app's service principal), any OpenAI-compatible endpoint (OpenAI, Azure OpenAI / AI Foundry), Ollama (local). The `llm:` section of config.yaml is the fallback
- With `llm.provider: rules` (default) a built-in router answers common questions with no model at all

## Architecture

```
Web UI (vanilla JS, no build)  ──►  FastAPI /api  ──►  services
                                                        │
  agent (LLM tool loop | rule router) ── tools ─────────┤
                                                        │
  dq/        profiler · rules (compile to SQL) · runner · schedules · review · discovery · anomaly · timeseries · scoring · suggester · nl_rules · exporters
  incidents/ lineage · manager (grouping + RCA) · remediation · autofix and quarantine (switched off) · notify · ticketing
  governance/ classification · policies · contracts · compliance · glossary     impact · insights · grouping · reference · llm/ · secretbox
  learning/  feedback          scheduler.py (cost + change aware)
                                                        │
  connectors/  databricks · snowflake · spark · cognite · aws_glue · azure_purview · duckdb
                                                        │
  app DB (SQLite default, Postgres/Lakebase in production): runs, results, metrics, incidents, action history, audit
```

## Platform integration

| Platform | Run checks | Metadata and lineage | Write-back | Notes |
|---|---|---|---|---|
| Databricks | SQL warehouse (databricks-sql-connector) | Unity Catalog information_schema; `system.access.table_lineage` / `column_lineage` | UC tags, column masks | PAT or OAuth (Databricks unified auth); Jobs API for backfill fixes; deploy as a Databricks App |
| Snowflake | Warehouse SQL | INFORMATION_SCHEMA; `ACCOUNT_USAGE.ACCESS_HISTORY` lineage | Object tags, masking policies, Data Metric Functions | Key-pair, password, or SSO; reads native DMF results |
| Spark | `spark.sql` | OpenLineage listener → `POST /api/lineage/openlineage` | - | EMR, Synapse, Fabric, OSS, Databricks Connect |
| Cognite Data Fusion | Datapoints API + Python time-series checks | Time series, assets, extraction pipeline runs, hierarchy completeness | Time series metadata, DQ events | OAuth client credentials |
| AWS | Athena (Trino SQL) | Glue Data Catalog | Lake Formation LF-tags | Pushes DQDL rulesets and starts native Glue DQ runs |
| Azure | Pair with a SQL connector | Purview Data Map search + lineage | Purview classifications | azure-identity; verify the Purview API version for your account |
| dbt | - | `POST /api/lineage/dbt` with `manifest.json` | - | |

Add connections in `config.yaml` (secrets via `*_env` keys) or in the UI under Connections.

## Configuration and environment variables

Values are resolved in this order (highest wins):

1. **Real environment variables.** On Databricks Apps these come from `app.yaml` and app resources.
2. **`.env`.** Copy `.env.example` to `.env`; it never overrides real variables, and empty values are ignored. It's looked up at `$DQGA_ENV_FILE`, then `./.env`, the project root, and next to the config file. Use `--env-file <path>` on the CLI, or `DQGA_ENV_FILE=none` to disable it.
3. **`config.yaml`.** Any value can reference variables as `${VAR}` or `${VAR:-default}`, and secrets stay out through `*_env` keys (for example `token_env: DATABRICKS_TOKEN`).
4. **Built-in defaults.**

Any setting can be overridden with `DQGA__SECTION__KEY`, for example `DQGA__SCHEDULER__ENABLED=false` or `DQGA__NOTIFICATIONS__MIN_SEVERITY=critical`.

Two things are set in the app instead of the files: the LLM (**Settings > LLM**, which takes precedence over `llm:`), and the dataset grouping label and source are in the `grouping:` section of `config.yaml` (what the app calls the group, where it comes from, and which groups count as critical or financial; empty by default, so nothing assumes an industry).

**Settings > Environment** in the UI shows where the app is running, which `.env` files were loaded, and which variables are set. Secret values are never displayed.

## Deploy on Databricks

TCS DataTrustAI runs as a [Databricks App](https://www.databricks.com/product/databricks-apps): the full UI, API and agent inside your workspace. It uses the service principal's OAuth credentials and workspace SSO.

The in-app **Deploy** page offers a one-click package download. From the command line:

```bash
python -m dqga package-app
```

Full walkthrough: **[docs/databricks-setup.md](docs/databricks-setup.md)**. In short:

1. Edit `config.databricks.yaml` (catalogs, notifications, LLM).
2. Recommended: attach a Lakebase database and set `DQGA_DATABASE_URL=lakebase` in `app.yaml`. Otherwise app state is lost on every restart.
3. Deploy:

   ```bash
   databricks bundle deploy -t dev --var warehouse_id=<id>
   ```

   ```bash
   databricks bundle run tcs_datatrustai -t dev
   ```

4. Grant the app's service principal read access to your catalogs and `system.access` lineage. Add write-back grants (tags, masks) only for the actions you'll use: they run as soon as someone clicks them.
5. Open the app (the top bar shows **Databricks Apps**), then go to **Settings > Connections**: **Test**, then **Sync**.

What the deployment handles:
- The app listens on `DATABRICKS_APP_PORT`.
- It authenticates as its service principal (OAuth, no tokens).
- It reconnects automatically when a warehouse session expires.
- It reads Lakebase connection details from the injected `PG*` variables, with a fresh OAuth token per connection.

## Security model

- **Sign-in first.**
  - Locally, the first visit creates the administrator.
  - After that, people **sign in**, **create an account** (an administrator approves it by default), or use **Administrator sign-in** to reach the **Admin console**.
  - On Databricks Apps, workspace SSO is the sign-in.
  - Roles (admin, steward, viewer) are enforced by the server.
  - Passwords are PBKDF2-hashed; sessions use HttpOnly cookies; accounts lock after repeated failures; changes need a CSRF header; every sign-in is audited.
- Read-only by default. Rules go live only after review by an administrator. Tags, masks, retention, corrections and tickets run as soon as a person clicks them, and every one is audited.
- User-written SQL is limited to boolean expressions; statements, comments, and DDL/DML keywords are rejected. Identifiers are validated; values are escaped.
- The LLM sees schemas, profile statistics (including the most common values per column), aggregates and the reference-file summary, never raw rows. Rules it proposes are only drafts.
- Secrets stay in environment variables; connection configs shown in the UI hide secret fields. LLM API keys saved in the app are encrypted and shown only as their last four characters.
- Only administrators approve, reject and activate rules, edit live rules, change the LLM, reset the app data and manage connections.

## Status

Verified here:
- The full product against the DuckDB demo, and the UI in a browser.
- 187 tests: engine, end-to-end flow, API, Databricks deployment behaviour, `.env` and variable resolution, and all ten export formats. Every generated SQL validation query is executed against the demo warehouse.

Not yet verified:
- A real Databricks App deployment.
- The Databricks, Snowflake, Cognite, AWS, and Purview connectors against live accounts. They use the documented APIs but need a run against your environments. Start with **Test** and **Sync** under Settings > Connections.
