"""Databricks job entry point: one cost- and change-aware scheduler tick.

Use this when the app's in-process scheduler is disabled (scheduler.enabled: false),
so scheduled checks run on job compute instead of the app container.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(HERE, "..", "..")))
os.environ.setdefault("DQGA_CONFIG", os.path.join(HERE, "..", "..", "config.databricks.yaml"))

from dqga import services  # noqa: E402
from dqga.config import load_settings  # noqa: E402
from dqga.db import session_scope  # noqa: E402
from dqga.scheduler import tick  # noqa: E402

services.bootstrap(load_settings())
with session_scope() as db:
    print(json.dumps(tick(db), indent=2, default=str))
