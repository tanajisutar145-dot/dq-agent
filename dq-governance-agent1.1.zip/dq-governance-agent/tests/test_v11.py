"""v1.1: .env + environment variables, export formats, Databricks Apps option."""
import io
import json
import re
import zipfile

import pytest
import yaml
from sqlalchemy import select


# ------------------------------------------------------------------ environment
def test_parse_dotenv_handles_common_syntax():
    from dqga.config import parse_dotenv

    env = parse_dotenv("""
# comment
export A=1
B = "two words"
C='single # not a comment'
D=value # trailing comment
E=
not a line
9BAD=x
""")
    assert env == {"A": "1", "B": "two words", "C": "single # not a comment", "D": "value", "E": ""}


def test_load_dotenv_never_overrides_real_env_and_skips_empty(tmp_path, monkeypatch):
    from dqga.config import load_dotenv

    for k in ("DQGA_T_NEW", "DQGA_T_EXISTING", "DQGA_T_EMPTY"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("DQGA_T_EXISTING", "from-environment")
    f = tmp_path / ".env"
    f.write_text("DQGA_T_NEW=from-file\nDQGA_T_EXISTING=from-file\nDQGA_T_EMPTY=\n")
    loaded = load_dotenv(f)
    import os
    assert os.environ["DQGA_T_NEW"] == "from-file"
    assert os.environ["DQGA_T_EXISTING"] == "from-environment"
    assert "DQGA_T_EMPTY" not in os.environ and set(loaded) == {"DQGA_T_NEW"}


def test_interpolation_and_overrides(tmp_path, monkeypatch):
    from dqga.config import load_settings

    for k in ("DQGA_T_CATALOG", "DQGA_T_FLAG", "DQGA__SCHEDULER__TICK_SECONDS", "DQGA__NOTIFICATIONS__MIN_SEVERITY",
              "DQGA_T_FROM_FILE"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("DQGA_T_CATALOG", "prod_catalog")
    monkeypatch.setenv("DQGA__SCHEDULER__TICK_SECONDS", "120")
    monkeypatch.setenv("DQGA__NOTIFICATIONS__MIN_SEVERITY", "critical")
    (tmp_path / "config.yaml").write_text(
        "connections:\n  - name: x\n    type: databricks\n    catalogs: ['${DQGA_T_CATALOG}']\n"
        "    host: ${DQGA_T_MISSING:-https://default.example}\n"
        "scheduler:\n  enabled: ${DQGA_T_FLAG:-false}\n"
        "app:\n  name: ${DQGA_T_FROM_FILE}\n")
    (tmp_path / "custom.env").write_text("DQGA_T_FROM_FILE=Loaded from env file\n")
    s = load_settings(tmp_path / "config.yaml", env_file=tmp_path / "custom.env")
    c = s.data["connections"][0]
    assert c["catalogs"] == ["prod_catalog"] and c["host"] == "https://default.example"
    assert s.section("scheduler")["enabled"] is False and s.section("scheduler")["tick_seconds"] == 120
    assert s.section("notifications")["min_severity"] == "critical"
    assert s.section("app")["name"] == "Loaded from env file"
    monkeypatch.delenv("DQGA_T_FROM_FILE", raising=False)


def test_env_report_hides_secrets(monkeypatch):
    from dqga.config import Settings
    from dqga.runtime import env_report

    monkeypatch.setenv("DATABRICKS_TOKEN", "dapi-super-secret")
    monkeypatch.setenv("DATABRICKS_WAREHOUSE_ID", "abc123")
    rep = env_report(Settings({"connections": [{"token_env": "MY_CUSTOM_TOKEN"}]}, None))
    by = {v["name"]: v for v in rep["variables"]}
    assert by["DATABRICKS_TOKEN"]["set"] and by["DATABRICKS_TOKEN"]["value"] is None and by["DATABRICKS_TOKEN"]["secret"]
    assert by["DATABRICKS_WAREHOUSE_ID"]["value"] == "abc123"
    assert by["MY_CUSTOM_TOKEN"]["referenced"] and not by["MY_CUSTOM_TOKEN"]["set"]
    assert "dapi-super-secret" not in json.dumps(rep)


def test_runtime_detects_databricks_apps(monkeypatch):
    from dqga.runtime import runtime_info

    for k in ("DATABRICKS_APP_NAME", "DATABRICKS_APP_URL", "DATABRICKS_APP_PORT"):
        monkeypatch.delenv(k, raising=False)
    assert runtime_info()["platform"] == "local"
    monkeypatch.setenv("DATABRICKS_APP_NAME", "tcs-datatrustai")
    info = runtime_info()
    assert info["platform"] == "databricks_apps" and info["app_name"] == "tcs-datatrustai"


# ------------------------------------------------------------------ export formats
def _rules(db, short):
    from dqga import services as S
    from dqga.models import Rule
    a = S.find_asset(db, short)
    return a, db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status == "active")).all()


@pytest.mark.parametrize("short", ["bronze.ami_raw", "silver.meters", "gold.billing_mart", "finance.gl_revenue",
                                   "ot.sensor_timeseries"])
def test_every_format_exports_and_parses(db, short):
    from dqga.connectors import get_connector
    from dqga.dq.exporters import FORMATS, export_with_report

    a, rules = _rules(db, short)
    d = get_connector(a.connection).dialect
    for fmt in FORMATS:
        rep = export_with_report(rules, fmt, a.fqn, d)
        assert rep["code"].strip(), fmt
        assert rep["rules"] + len(rep["skipped"]) == len(rules), fmt
        body = "\n".join(l for l in rep["code"].splitlines() if not l.startswith("#"))
        if fmt in ("dqx", "soda", "dbt"):
            assert yaml.safe_load(body) is not None, fmt
        if fmt in ("great_expectations", "json"):
            json.loads(rep["code"])
        if fmt == "pydeequ":
            compile(rep["code"], "deequ.py", "exec")


def test_soda_and_dbt_content(db):
    from dqga.dq.exporters import export

    a, rules = _rules(db, "silver.meters")
    soda = yaml.safe_load("\n".join(l for l in export(rules, "soda", a.fqn).splitlines() if not l.startswith("#")))
    checks = soda["checks for meters"]
    assert "duplicate_count(meter_id) = 0" in checks
    assert "values in (customer_id) must exist in customers (customer_id)" in checks
    dbt = yaml.safe_load("\n".join(l for l in export(rules, "dbt", a.fqn).splitlines() if not l.startswith("#")))
    cols = {c["name"]: c["data_tests"] for c in dbt["models"][0]["columns"]}
    assert any("relationships" in t for t in cols["customer_id"])


def test_sql_export_runs_on_the_warehouse(db):
    """Every generated validation query must execute on the dataset's own engine."""
    from dqga.connectors import get_connector
    from dqga.dq.exporters import export

    conn = get_connector("demo")
    ran = 0
    for short in ("bronze.ami_raw", "silver.meters", "gold.billing_mart", "finance.gl_revenue", "gold.meter_readings_daily"):
        a, rules = _rules(db, short)
        code = export(rules, "sql", a.fqn, conn.dialect)
        stripped = "\n".join(re.sub(r"--.*$", "", l) for l in code.splitlines())
        for stmt in (s.strip() for s in stripped.split(";")):
            if stmt:
                conn.query(stmt)
                ran += 1
    assert ran >= 20


def test_bundle_zip_and_download_endpoints(seeded):
    from fastapi.testclient import TestClient

    from dqga.api.main import create_app
    c = TestClient(create_app(bootstrap=False))
    aid = next(a["id"] for a in c.get("/api/assets").json() if a["fqn"].endswith("silver.meters"))
    one = c.get(f"/api/rules/export?asset_id={aid}&target=soda&download=true")
    assert one.status_code == 200 and "attachment" in one.headers["content-disposition"]
    z = zipfile.ZipFile(io.BytesIO(c.get(f"/api/rules/export/bundle?asset_id={aid}").content))
    names = z.namelist()
    assert "SUMMARY.txt" in names and "meters/meters.soda.yml" in names and "meters/meters.dbt.yml" in names
    allz = zipfile.ZipFile(io.BytesIO(c.get("/api/rules/export/bundle?formats=sql,great_expectations").content))
    assert len({n.split("/")[0] for n in allz.namelist() if "/" in n}) >= 6
    assert c.get("/api/rules/export/bundle?formats=nope").status_code == 400


# ------------------------------------------------------------------ Databricks Apps option
def test_app_package_contents():
    from dqga.deploy import build_app_package

    z = zipfile.ZipFile(io.BytesIO(build_app_package()))
    names = set(z.namelist())
    for must in ("tcs-datatrustai/app.yaml", "tcs-datatrustai/databricks.yml", "tcs-datatrustai/config.databricks.yaml",
                 "tcs-datatrustai/Dockerfile", "tcs-datatrustai/dqga/deploy_targets.yaml",
                 "tcs-datatrustai/requirements.txt", "tcs-datatrustai/dqga/api/main.py", "tcs-datatrustai/dqga/web/app.js",
                 "tcs-datatrustai/docs/databricks-setup.md"):
        assert must in names, must
    assert not [n for n in names if n.endswith("/.env") or "/data/" in n or "/tests/" in n or "__pycache__" in n
                or "/.venv/" in n]


def test_meta_env_and_deploy_endpoints(seeded):
    from fastapi.testclient import TestClient

    from dqga.api.main import create_app
    c = TestClient(create_app(bootstrap=False))
    m = c.get("/api/meta", headers={"X-Forwarded-Email": "asha.patel@tcs.com"}).json()
    assert m["app"] == "TCS DataTrustAI" and m["user"] == "asha.patel@tcs.com"
    assert {"soda", "dbt", "sql", "great_expectations", "dqx", "pydeequ"} <= set(m["export_formats"])
    assert m["runtime"]["platform"] in ("local", "databricks_apps")
    env = c.get("/api/settings/env").json()
    assert any(v["name"] == "DATABRICKS_HOST" for v in env["variables"])
    dep = c.get("/api/deploy/targets").json()
    ids = [t["id"] for t in dep["targets"]]
    assert dep["default"] == "databricks_apps" and {"databricks_apps", "local", "docker"} <= set(ids)
    dbx = next(t for t in dep["targets"] if t["id"] == "databricks_apps")
    assert any(f["name"] == "databricks.yml" and "tcs_datatrustai" in f["content"] for f in dbx["files"])
    local = next(t for t in dep["targets"] if t["id"] == "local")
    assert local["current"] is (m["runtime"]["platform"] == "local")
    pkg = c.get("/api/deploy/package/docker.zip")
    assert pkg.status_code == 200 and pkg.headers["content-type"] == "application/zip"
    assert "tcs-datatrustai/Dockerfile" in zipfile.ZipFile(io.BytesIO(pkg.content)).namelist()
    assert c.get("/api/deploy/databricks-app.zip").status_code == 200
    assert c.get("/api/deploy/package/local.zip").status_code == 404
    assert c.get("/api/deploy/package/nope.zip").status_code == 404


def test_deploy_registry_is_valid_and_files_exist():
    from dqga.config import ROOT
    from dqga.deploy import load_targets

    targets = load_targets()
    assert len({t["id"] for t in targets}) == len(targets) >= 6
    assert sum(1 for t in targets if t.get("default")) == 1
    for t in targets:
        for f in t.get("files", []):
            assert (ROOT / f).is_file(), f"{t['id']} references missing file {f}"
        for s in t["steps"]:
            assert s.get("title") and (s.get("text") or s.get("commands")), t["id"]
        if t.get("docs"):
            assert (ROOT / t["docs"]).is_file()


def test_deploy_registry_accepts_new_platforms(tmp_path):
    from dqga.deploy import load_targets

    f = tmp_path / "targets.yaml"
    f.write_text("targets:\n  - {id: gcp_cloud_run, label: Google Cloud Run, group: Cloud containers, summary: x, "
                 "steps: [{title: Deploy, commands: ['gcloud run deploy --source .']}]}\n")
    assert load_targets(f)[0]["label"] == "Google Cloud Run"
    f.write_text("targets:\n  - {id: Bad Id, label: x, group: g, summary: s, steps: [{title: t, text: x}]}\n")
    with pytest.raises(ValueError):
        load_targets(f)
