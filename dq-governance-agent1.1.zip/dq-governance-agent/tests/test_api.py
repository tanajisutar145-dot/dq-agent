"""API smoke tests through FastAPI's TestClient."""
import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


def test_pages_and_meta(client):
    assert client.get("/").status_code == 200
    assert client.get("/static/app.js").status_code == 200
    m = client.get("/api/meta").json()
    assert "not_null" in m["rule_types"] and "gdpr" in m["frameworks"]


def test_overview_and_assets(client):
    o = client.get("/api/overview").json()
    assert o["assets"] == 7 and o["open_incidents"] >= 3
    assets = client.get("/api/assets").json()
    aid = next(a["id"] for a in assets if a["fqn"].endswith("gold.billing_mart"))
    d = client.get(f"/api/assets/{aid}").json()
    assert d["fqn"].endswith("billing_mart") and d["rules_active"] > 0
    assert client.get(f"/api/assets/{aid}/profile").json()["row_count"] > 0
    assert client.get(f"/api/assets/{aid}/contract").json()["yaml"].startswith("apiVersion")


def test_rule_lifecycle(client):
    assets = client.get("/api/assets").json()
    aid = next(a["id"] for a in assets if a["fqn"].endswith("bronze.ami_raw"))
    r = client.post("/api/rules/nl", json={"asset_id": aid, "text": "voltage must be between 200 and 260"}).json()
    # drafting runs the rule on the platform but stores nothing until the person saves it
    assert r["dry_run"]["status"] == "pass" and r["saved"] is False and r["rule"]["id"] is None
    assert r["dry_run"]["ran_on"]["connection"] and r["dry_run"]["ran_on"]["queries"] >= 1
    rule = client.post("/api/rules", json={"asset_id": aid, "type": r["rule"]["type"], "column": r["rule"]["column"], "params": r["rule"]["params"],
                                           "name": r["rule"]["name"], "severity": r["rule"]["severity"], "source": "nl"}).json()
    assert rule["status"] == "proposed" and rule["source"] == "nl"
    sub = client.post("/api/rules/submit", json={"rule_ids": [rule["id"]], "note": "please check the range"}).json()
    assert sub["rules"][0]["status"] == "review" and sub["rules"][0]["submit_note"] == "please check the range"
    done = client.post("/api/rules/review/decide", json={"rule_ids": [rule["id"]], "decision": "approve_activate"}).json()
    act = done["rules"][0]
    assert act["status"] == "active" and act["version"] == 3
    bad = client.post("/api/rules/nl", json={"asset_id": aid, "text": "make it nice"})
    assert bad.status_code == 400
    run = client.post(f"/api/assets/{aid}/run").json()
    assert run["checks"] > 0


def test_incident_actions_and_ticket_dry_run(client):
    incs = client.get("/api/incidents?status=all").json()
    iid = incs[0]["id"]
    d = client.get(f"/api/incidents/{iid}").json()
    assert "rca" in d and d["events"]
    assert client.post(f"/api/incidents/{iid}/action", json={"action": "ack"}).json()["status"] in ("ack", "resolved")
    res = client.post(f"/api/incidents/{iid}/ticket").json()  # runs at once, no approval step
    assert res["status"] == "approved" and res["result"]["status"] == "dry_run"


def test_governance_endpoints(client):
    g = client.get("/api/governance/summary").json()
    assert g["pii"] and "ownership_coverage" in g["facts"]
    assert client.get("/api/compliance/nerc_cip").json()["controls"]
    assert client.get("/api/glossary").json()
    assert client.get("/api/lineage").json()["edges"]
    assert "plan" in client.get("/api/scheduler").json()
    assert client.get("/api/audit").json()


def test_agent_endpoint(client):
    r = client.post("/api/agent/chat", json={"message": "show open incidents", "session_id": "api"}).json()
    assert "Open incidents" in r["answer"] or "incident" in r["answer"].lower()


def test_openlineage_and_dbt(client):
    assert client.post("/api/lineage/openlineage", json={"inputs": [{"name": "a.b.c"}], "outputs": [{"name": "a.b.d"}]}).json()["added"] == 1
    manifest = {"nodes": {"model.p.m1": {"database": "x", "schema": "s", "alias": "m1"}},
                "sources": {"source.p.r": {"database": "x", "schema": "raw", "identifier": "r"}},
                "parent_map": {"model.p.m1": ["source.p.r"]}}
    assert client.post("/api/lineage/dbt", json=manifest).json()["added"] == 1
