"""The demo data fills every screen. Seeds the demo in its own process (it replaces the app's global database)."""
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent


def test_demo_fills_every_dashboard(tmp_path):
    shutil.copy(ROOT / "policies.yaml", tmp_path / "policies.yaml")
    cfg = {"app": {"database_url": "sqlite:///data/demo.db"}, "llm": {"provider": "rules"}, "auth": {"mode": "none"},
           "connections": [{"name": "demo", "type": "duckdb", "path": "data/utility.duckdb", "catalogs": ["utility"]}],
           "scheduler": {"enabled": False},
           "remediation": {"auto_enabled": True, "allowed_auto_actions": ["quarantine"], "max_rows_auto": 10},
           "grouping": {"critical": ["finance"], "hints": {"metering": "meter readings must not be negative"}}}
    (tmp_path / "config.yaml").write_text(yaml.safe_dump(cfg))
    r = subprocess.run([sys.executable, "-m", "dqga", "--config", str(tmp_path / "config.yaml"), "--env-file", "none", "demo"],
                       capture_output=True, text=True, cwd=ROOT, timeout=600)
    assert r.returncode == 0, r.stderr[-800:]
    assert "skipped" not in r.stdout, r.stdout[-1200:]  # every part of the showcase ran
    db = sqlite3.connect(tmp_path / "data" / "demo.db")

    def n(sql):
        return db.execute(sql).fetchone()[0]

    assert n("select count(*) from assets") == 7
    assert n("select count(*) from approvals where status='pending'") == 0  # nothing waits for approval
    assert {s for (s,) in db.execute("select status from rules")} >= {"active", "proposed", "review", "approved", "rejected", "disabled"}
    assert n("select count(*) from rule_schedules") >= 3 and n("select count(*) from rule_schedules where last_status is not null") >= 1
    assert n("select count(*) from runs where ts < datetime('now','-10 days')") > 20 and {t for (t,) in db.execute("select distinct trigger from runs")} >= {"schedule", "manual", "agent"}
    assert n("select count(*) from custom_metrics") >= 5 and n("select count(*) from custom_metric_values") >= 20
    assert n("select count(*) from reference_docs where status='parsed'") == 2 and n("select count(*) from reference_facts") > 5
    assert n("select count(*) from fix_runs") == 0 and n("select count(*) from quarantine_batches") == 0  # fixes and quarantine are not offered, so not seeded
    assert n("select count(*) from approvals where kind='autofix'") == 0
    assert n("select count(*) from rules where category='governance' and status='active'") >= 1
    assert n("select count(*) from audit_log where action='insights.refreshed'") == 1
    assert n("select count(*) from incidents where status!='resolved'") >= 4 and n("select count(*) from incidents where status='resolved'") >= 8
    assert n("select count(*) from users") == 0  # the first visit still shows the first-run setup when sign-in is on


def test_demo_can_be_added_next_to_existing_data(tmp_path):
    """`demo --add` keeps what is already in the app database and never touches it."""
    import duckdb
    shutil.copy(ROOT / "policies.yaml", tmp_path / "policies.yaml")
    (tmp_path / "data").mkdir()
    con = duckdb.connect(str(tmp_path / "data" / "mine.duckdb"))
    con.execute("CREATE SCHEMA mine.main") if False else None
    con.execute("CREATE TABLE orders AS SELECT range AS order_id, 'A' AS city FROM range(50)")
    con.close()
    cfg = {"app": {"database_url": "sqlite:///data/app.db"}, "llm": {"provider": "rules"}, "auth": {"mode": "none"},
           "connections": [{"name": "mine", "type": "duckdb", "path": "data/mine.duckdb", "catalogs": ["mine"]}],
           "scheduler": {"enabled": False}}
    (tmp_path / "config.yaml").write_text(yaml.safe_dump(cfg))
    prep = ("from dqga.config import load_settings; from dqga import services as S; from dqga.db import session_scope; from sqlalchemy import select; "
            "from dqga.models import Asset; s=load_settings(r'%s','none'); S.bootstrap(s); "
            "db=__import__('contextlib').ExitStack(); ctx=session_scope(); d=ctx.__enter__(); S.sync_catalog(d); "
            "a=d.scalars(select(Asset)).first(); S.create_rule(d,a,{'type':'not_null','column':'order_id','severity':'high'},'tester',status='active'); ctx.__exit__(None,None,None); print('prepared')"
            % str(tmp_path / "config.yaml"))
    p = subprocess.run([sys.executable, "-c", prep], capture_output=True, text=True, cwd=ROOT, timeout=300)
    assert p.returncode == 0 and "prepared" in p.stdout, p.stderr[-800:]
    before = (tmp_path / "data" / "mine.duckdb").read_bytes()
    run = [sys.executable, "-m", "dqga", "--config", str(tmp_path / "config.yaml"), "--env-file", "none", "demo", "--add"]
    r = subprocess.run(run, capture_output=True, text=True, cwd=ROOT, timeout=600)
    assert r.returncode == 0 and "skipped" not in r.stdout, (r.stderr + r.stdout)[-1200:]
    db = sqlite3.connect(tmp_path / "data" / "app.db")
    assert db.execute("select count(*) from assets where connection='mine'").fetchone()[0] == 1
    assert db.execute("select count(*) from assets where connection='demo'").fetchone()[0] == 7
    mine_rules = db.execute("select status, count(*) from rules where asset_id=(select id from assets where connection='mine') group by 1").fetchall()
    assert mine_rules == [("active", 1)], mine_rules  # nothing happened to the existing dataset's rules
    assert {n for (n,) in db.execute("select name from connections")} == {"mine", "demo"}
    assert (tmp_path / "data" / "mine.duckdb").read_bytes() == before  # the user's own warehouse file is untouched
    again = subprocess.run(run, capture_output=True, text=True, cwd=ROOT, timeout=300)
    assert again.returncode != 0 and "already loaded" in (again.stderr + again.stdout)
