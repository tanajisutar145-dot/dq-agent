"""Run rules now, rule schedules (cadence, due runs, coverage), run history, and the Insights refresh."""
from datetime import timedelta

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


@pytest.fixture()
def cleanup(client):
    made = []
    yield made
    for sid in made:
        client.delete(f"/api/schedules/{sid}")


def test_preview_and_run_now_record_manual_runs(client):
    p = client.post("/api/rules/run/preview", json={"scope": {"category": "core"}}).json()
    assert p["rules"] > 0 and p["datasets"] > 0 and p["text"].startswith("Core")
    hi = client.post("/api/rules/run/preview", json={"scope": {"category": "core", "severity": "high"}}).json()
    assert hi["rules"] <= p["rules"] and "high severity and above" in hi["text"]
    one = p["by_dataset"][0]["asset_id"]
    res = client.post("/api/rules/run", json={"scope": {"asset_ids": [one]}}).json()
    assert res["datasets"] == 1 and res["checks"] > 0 and res["status"] in ("ok", "failures", "error") and len(res["runs"]) == 1
    runs = client.get(f"/api/runs?asset_id={one}&trigger=manual").json()
    assert runs["runs"][0]["id"] == res["runs"][0]["run_id"] and runs["runs"][0]["trigger_label"] == "Run now"
    assert runs["stats"]["runs"] >= 1 and len(runs["by_day"]) == 7
    d = client.get(f"/api/runs/{res['runs'][0]['run_id']}").json()
    assert len(d["checks"]) == res["checks"] and d["checks"][0]["rule"]
    order = {"error": 0, "fail": 1, "warn": 2, "pass": 3}
    assert [order[c["status"]] for c in d["checks"]] == sorted(order[c["status"]] for c in d["checks"])
    assert client.get("/api/runs/999999").status_code == 404


def test_run_now_with_nothing_matching_is_an_error(client):
    r = client.post("/api/rules/run", json={"scope": {"rule_ids": [999999]}})
    assert r.status_code == 400 and "No active rules" in r.json()["detail"]
    assert client.post("/api/rules/run/preview", json={"scope": {"category": "nope"}}).status_code == 400


def test_schedule_validation(client):
    assert client.post("/api/schedules", json={"name": "", "every_minutes": 60}).status_code == 400
    assert client.post("/api/schedules", json={"name": "x", "every_minutes": 2}).status_code == 400
    assert client.post("/api/schedules", json={"name": "x", "cadence": "daily", "at_time": "25:00"}).status_code == 400
    assert client.post("/api/schedules", json={"name": "x", "cadence": "daily", "at_time": "06:00", "weekdays": [9]}).status_code == 400


def test_cadence_maths():
    from datetime import datetime

    from dqga.dq.schedules import cadence_text, next_after
    from dqga.models import RuleSchedule

    mon = datetime(2026, 11, 16, 10, 0)  # a Monday
    s = RuleSchedule(cadence="daily", at_time="06:30", weekdays=[2, 4])
    assert next_after(s, mon) == datetime(2026, 11, 18, 6, 30) and cadence_text(s) == "Wed, Fri at 06:30 UTC"
    s = RuleSchedule(cadence="daily", at_time="11:00", weekdays=[])
    assert next_after(s, mon) == datetime(2026, 11, 16, 11, 0) and cadence_text(s) == "every day at 11:00 UTC"
    s = RuleSchedule(cadence="daily", at_time="09:00", weekdays=[0, 1, 2, 3, 4])
    assert next_after(s, mon) == datetime(2026, 11, 17, 9, 0) and cadence_text(s) == "weekdays at 09:00 UTC"
    s = RuleSchedule(cadence="interval", every_minutes=120)
    assert next_after(s, mon) == mon + timedelta(hours=2) and cadence_text(s) == "every 2 hours"


def test_schedule_lifecycle_due_run_and_coverage(client, db, cleanup):
    from dqga import scheduler
    from dqga.models import RuleSchedule, Run, utcnow

    s = client.post("/api/schedules", json={"name": "Core hourly", "every_minutes": 60, "scope": {"category": "core"}}).json()
    cleanup.append(s["id"])
    assert s["cadence_text"] == "every hour" and s["rules"] > 0 and s["next_run"]
    listed = client.get("/api/schedules").json()
    assert any(x["id"] == s["id"] for x in listed["schedules"]) and "enabled" in listed["background"]

    # rules covered by the schedule leave the default per-rule plan
    from dqga.dq.schedules import covered_rule_ids
    covered = covered_rule_ids(db)
    assert covered and all(not set(item["rules"]) & covered for item in scheduler.plan(db))

    # manual run keeps the next due time
    before = client.get("/api/schedules").json()["schedules"]
    nxt = next(x for x in before if x["id"] == s["id"])["next_run"]
    r = client.post(f"/api/schedules/{s['id']}/run").json()
    assert r["checks"] > 0
    after = next(x for x in client.get("/api/schedules").json()["schedules"] if x["id"] == s["id"])
    assert after["next_run"] == nxt and after["last_status"] in ("ok", "failures", "error") and after["last_summary"]["manual"]

    # make it due: the scheduler tick runs it and moves next_run forward
    row = db.get(RuleSchedule, s["id"])
    row.next_run = utcnow() - timedelta(minutes=1)
    db.commit()
    t = scheduler.tick(db)
    db.commit()
    assert any(x.get("schedule") == "Core hourly" for x in t["schedules"])
    db.refresh(row)
    assert row.next_run > utcnow() and db.query(Run).filter(Run.schedule_id == s["id"], Run.trigger == "schedule").count() > 0
    by_sched = client.get(f"/api/runs?schedule_id={s['id']}").json()
    assert by_sched["runs"] and all(x["schedule"] == "Core hourly" for x in by_sched["runs"])

    # disable, re-time, delete
    off = client.patch(f"/api/schedules/{s['id']}", json={"enabled": False}).json()
    assert off["enabled"] is False and off["next_run"] is None
    on = client.patch(f"/api/schedules/{s['id']}", json={"enabled": True, "cadence": "daily", "at_time": "05:15", "weekdays": [0]}).json()
    assert on["next_run"] and on["cadence_text"] == "Mon at 05:15 UTC"
    assert client.delete(f"/api/schedules/{s['id']}").json()["ok"]
    cleanup.clear()
    assert client.post(f"/api/schedules/{s['id']}/run").status_code == 404


def test_insights_refresh_records_what_it_did(client):
    assert client.post("/api/insights/refresh", json={"mode": "bogus"}).status_code == 400
    r = client.post("/api/insights/refresh", json={"mode": "sync"}).json()
    assert r["mode"] == "sync" and r["sync"]["datasets"] >= 7 and "checks" not in r
    d = client.post("/api/insights/refresh", json={"mode": "due"}).json()
    assert {"datasets", "checks", "failed", "schedules"} <= set(d["checks"])
    a = client.post("/api/insights/refresh", json={"mode": "all"}).json()
    assert a["checks"]["checks"] > 0
    ins = client.get("/api/insights").json()
    assert ins["last_refresh"]["mode"] == "all" and ins["last_refresh"]["at"]
    runs = client.get("/api/runs?trigger=refresh").json()
    assert runs["runs"] and runs["runs"][0]["trigger_label"] == "Insights refresh"
