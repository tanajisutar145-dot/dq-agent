"""Sensitive-data scans: run, status, never-scanned, dismissed columns staying dismissed, schedule, after-sync, bulk review."""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete, select


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


@pytest.fixture(autouse=True)
def _restore(seeded):
    """Leave the shared database as it was: scan state, schedule, dismissed columns and profile times."""
    from dqga.db import session_scope
    from dqga.models import Asset, AppSetting, Classification
    with session_scope() as db:
        before = {c.id: c.status for c in db.scalars(select(Classification))}
        stamps = {a.id: a.last_profiled for a in db.scalars(select(Asset))}
    yield
    with session_scope() as db:
        for c in db.scalars(select(Classification)):
            if c.id in before:
                c.status = before[c.id]
        for a in db.scalars(select(Asset)):
            a.last_profiled = stamps.get(a.id, a.last_profiled)
        db.execute(delete(AppSetting).where(AppSetting.key.in_(["pii_scan", "pii_scan_schedule"])))


def test_scan_runs_and_status_reports_it(client):
    assert client.get("/api/pii-scans/status").json()["last"] is None
    r = client.post("/api/pii-scans/run").json()
    assert r["scanned"] == 7 and r["error_count"] == 0 and r["trigger"] == "manual" and r["new"] >= 0
    st = client.get("/api/pii-scans/status").json()
    assert st["last"]["scanned"] == 7 and st["datasets"] == 7 and st["never_scanned"] == 0 and st["columns"] > 0
    assert st["columns"] == st["to_review"] + st["tagged"] and sum(st["by_sensitivity"].values()) == st["columns"]


def test_never_scanned_datasets_and_scan_only_those(client):
    from dqga.db import session_scope
    from dqga.models import Asset
    with session_scope() as db:
        a = db.scalars(select(Asset).order_by(Asset.id)).first()
        a.last_profiled = None
        fqn = a.fqn
    st = client.get("/api/pii-scans/status").json()
    assert st["never_scanned"] == 1 and st["unscanned"][0]["fqn"] == fqn
    r = client.post("/api/pii-scans/run", json={"only_unscanned": True}).json()
    assert r["scanned"] == 1 and r["only_unscanned"] is True
    assert client.get("/api/pii-scans/status").json()["never_scanned"] == 0


def test_scan_can_be_limited_to_a_platform(client):
    assert client.post("/api/pii-scans/run", json={"platform": "databricks"}).json()["scanned"] == 0
    assert client.post("/api/pii-scans/run", json={"platform": "duckdb"}).json()["scanned"] == 7


def test_dismissed_columns_stay_dismissed_after_a_rescan(client):
    pii = client.get("/api/governance/summary").json()["pii"]
    assert pii and all("platform" in c and "domain" in c for c in pii)
    cid = pii[0]["id"]
    r = client.post("/api/classifications/decide-bulk", json={"ids": [cid], "approve": False}).json()
    assert r == {"rejected": 1, "tagged": 0, "failed": []}
    before = len(client.get("/api/governance/summary").json()["pii"])
    client.post("/api/pii-scans/run")
    after = client.get("/api/governance/summary").json()["pii"]
    assert len(after) == before and cid not in {c["id"] for c in after}


def test_bulk_review_needs_a_selection(client):
    assert client.post("/api/classifications/decide-bulk", json={"ids": [], "approve": True}).status_code == 400
    assert client.post("/api/classifications/decide-bulk", json={"ids": [999999], "approve": False}).json()["rejected"] == 0


def test_assets_report_their_sensitive_columns(client):
    assets = client.get("/api/assets").json()
    assert all("sensitive_columns" in a for a in assets)
    total = len(client.get("/api/governance/summary").json()["pii"])
    assert sum(a["sensitive_columns"] for a in assets) == total and total > 0


def test_schedule_and_after_sync(client):
    s = client.put("/api/pii-scans/schedule", json={"enabled": True, "cadence": "interval", "every_minutes": 60, "after_sync": True}).json()
    assert s["enabled"] and s["after_sync"] is True and s["next_run"] and s["text"]
    assert client.put("/api/pii-scans/schedule", json={"enabled": True, "cadence": "interval", "every_minutes": 1}).status_code == 400
    from dqga.db import session_scope
    from dqga.governance import pii_scans
    from dqga.models import Asset
    with session_scope() as db:
        assert pii_scans.run_if_due(db) is None  # next run is an hour away
        a = db.scalars(select(Asset).order_by(Asset.id)).first()
        a.last_profiled = None
        db.flush()
        res = pii_scans.after_sync(db)  # only the dataset that was never scanned
        assert res["scanned"] == 1 and res["trigger"] == "sync"
    off = client.put("/api/pii-scans/schedule", json={"enabled": False, "cadence": "daily", "at_time": "06:00"}).json()
    assert off["enabled"] is False and off["after_sync"] is False
    with session_scope() as db:
        assert pii_scans.after_sync(db) is None  # not asked for


def test_schedule_runs_when_due(client):
    client.put("/api/pii-scans/schedule", json={"enabled": True, "cadence": "interval", "every_minutes": 60})
    from dqga.db import session_scope
    from dqga.governance import pii_scans
    from dqga.models import AppSetting
    with session_scope() as db:
        row = db.get(AppSetting, pii_scans.SCHEDULE_KEY)
        row.value = {**row.value, "next_run": "2000-01-01T00:00:00"}
        db.flush()
        ran = pii_scans.run_if_due(db)
        assert ran and ran["trigger"] == "schedule" and ran["scanned"] == 7


def test_schedule_change_is_admin_only():
    from dqga.api.security import is_admin_only
    assert is_admin_only("PUT", "/api/pii-scans/schedule")
    assert not is_admin_only("POST", "/api/pii-scans/run") and not is_admin_only("POST", "/api/classifications/decide-bulk")
