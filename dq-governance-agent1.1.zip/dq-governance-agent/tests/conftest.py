import os
import shutil
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parent.parent
os.environ["DQGA_ENV_FILE"] = "none"  # tests never read the developer's .env


@pytest.fixture(scope="session")
def seeded(tmp_path_factory):
    """Build the demo warehouse + app DB in a temp dir once per test session."""
    from dqga.config import load_settings
    from dqga.demo.seed import run

    d = tmp_path_factory.mktemp("dqga")
    shutil.copy(ROOT / "policies.yaml", d / "policies.yaml")
    cfg = {
        "app": {"database_url": "sqlite:///data/test.db"},
        "llm": {"provider": "rules"},
        "connections": [{"name": "demo", "type": "duckdb", "path": "data/utility.duckdb", "catalogs": ["utility"]}],
        "scheduler": {"enabled": False, "daily_budget_seconds": 3600},
        "remediation": {"auto_enabled": True, "allowed_auto_actions": ["quarantine"], "max_rows_auto": 10},
        "grouping": {"critical": ["finance", "billing", "regulatory", "risk"], "financial": ["finance", "billing", "trading"],
                     "hints": {"finance": "amounts and postings must never be negative or dated in the future",
                               "billing": "billed amounts and energy must not be negative",
                               "metering": "meter readings and consumption must not be negative",
                               "operations": "sensor readings must be physically plausible",
                               "customer": "customer contact details must be valid"}},
        "auth": {"mode": "none"},  # auth flows are tested explicitly in test_auth.py
        "features": {"fixes_and_quarantine": True},  # off by default in the product; the shared tests keep covering the code
    }
    (d / "config.yaml").write_text(yaml.safe_dump(cfg))
    settings = load_settings(d / "config.yaml")
    summary = run(settings, verbose=False, showcase=False)  # the showcase has its own test (test_showcase.py)
    return {"dir": d, "settings": settings, "summary": summary}


@pytest.fixture()
def db(seeded):
    from dqga.db import get_session

    s = get_session()
    yield s
    s.commit()
    s.close()
