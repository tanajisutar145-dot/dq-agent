"""Rules as files: export, parse, compare and import (as drafts), through the module, the API and the command line."""
import io
import zipfile

import pytest
import yaml
from fastapi.testclient import TestClient
from sqlalchemy import delete, select


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


@pytest.fixture(autouse=True)
def _restore(seeded):
    """Leave the shared database as it was: drop rules and history created by a test, undo edits to existing ones."""
    from dqga.db import session_scope
    from dqga.models import Rule, RuleHistory
    with session_scope() as db:
        before = {r.id: r.to_dict() for r in db.scalars(select(Rule))}
    yield
    with session_scope() as db:
        for r in db.scalars(select(Rule)):
            if r.id not in before:
                db.execute(delete(RuleHistory).where(RuleHistory.rule_id == r.id))
                db.delete(r)
            else:
                for k in ("name", "threshold", "severity", "status", "description", "params", "column", "dimension", "schedule_minutes"):
                    setattr(r, k, before[r.id][k])


def _customers(db):
    from dqga import services as S
    return S.find_asset(db, "silver.customers")


def _file(db, **kw):
    from dqga import rulefiles as RF
    a = _customers(db)
    path, text = RF.export_files(db, [a.id], **kw)[0]
    return a, path, text, yaml.safe_load(text)


def _import(text, name="customers.yaml"):
    return [(name, yaml.safe_dump(text) if isinstance(text, dict) else text)]


def test_export_writes_one_file_per_dataset_without_data_values(db):
    from dqga import rulefiles as RF
    files = RF.export_files(db)
    assert files and all(p.endswith(".yaml") for p, _ in files)
    a, path, text, doc = _file(db)
    assert path == "utility/silver/customers.yaml" and doc["format"] == RF.FORMAT and doc["dataset"] == a.fqn
    assert doc["rules"] and all(r["key"] and r["type"] and r["name"] for r in doc["rules"])
    assert len({r["key"] for r in doc["rules"]}) == len(doc["rules"])
    assert "id" not in doc["rules"][0] and "last_status" not in doc["rules"][0] and "status" not in doc["rules"][0]


def test_exported_files_import_back_unchanged(db):
    from dqga import rulefiles as RF
    _, _, text, _ = _file(db)
    p = RF.plan(db, [("customers.yaml", text)])
    assert not p["errors"] and p["will_save"] == 0
    assert p["totals"]["unchanged"] > 0 and p["totals"]["invalid"] == 0


def test_new_rule_becomes_a_draft_and_importing_twice_adds_nothing(db):
    from dqga import rulefiles as RF
    from dqga.models import Rule
    a, _, _, doc = _file(db)
    col = a.columns[0]["name"]
    doc["rules"].append({"key": "not_null:x:zz-file-rule", "name": "zz file rule", "type": "not_null", "column": col, "severity": "low", "threshold": 0.9})
    res = RF.apply(db, _import(doc), "tester")
    assert len(res["created"]) == 1 and not res["updated"]
    r = db.get(Rule, res["created"][0])
    assert r.status == "proposed" and r.source == "file" and r.created_by == "tester" and r.severity == "low"
    again = RF.apply(db, _import(doc), "tester")
    assert not again["created"] and not again["updated"]


def test_changed_draft_is_updated_in_place(db):
    from dqga import rulefiles as RF
    from dqga.models import Rule
    a, _, _, doc = _file(db)
    col = a.columns[0]["name"]
    doc["rules"].append({"key": "k", "name": "zz draft rule", "type": "not_null", "column": col, "threshold": 0.9})
    rid = RF.apply(db, _import(doc), "tester")["created"][0]
    doc["rules"][-1]["threshold"] = 0.5
    p = RF.plan(db, _import(doc))
    item = next(i for i in p["datasets"][0]["items"] if i["name"] == "zz draft rule")
    assert item["action"] == "update_draft" and item["changes"] == [{"field": "threshold", "from": 0.9, "to": 0.5}]
    res = RF.apply(db, _import(doc), "tester")
    assert res["updated"] == [rid] and not res["created"]
    assert db.get(Rule, rid).threshold == 0.5


def test_changing_a_live_rule_proposes_a_new_draft_and_leaves_the_live_one(db):
    from dqga import rulefiles as RF
    from dqga.models import Rule
    a, _, _, doc = _file(db)
    live = db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status == "active")).first()
    entry = next(r for r in doc["rules"] if r["name"] == live.name and r["type"] == live.type)
    old = live.threshold
    entry["threshold"] = round(old - 0.05, 3)
    p = RF.plan(db, _import(doc))
    item = next(i for i in p["datasets"][0]["items"] if i["action"] == "propose_change")
    assert item["rule_id"] == live.id and item["changes"][0]["field"] == "threshold"
    res = RF.apply(db, _import(doc), "tester")
    assert len(res["created"]) == 1
    draft = db.get(Rule, res["created"][0])
    assert draft.status == "proposed" and draft.threshold == round(old - 0.05, 3) and f"#{live.id}" in draft.reason
    assert db.get(Rule, live.id).threshold == old and db.get(Rule, live.id).status == "active"
    again = RF.plan(db, _import(doc))  # the proposal is already waiting, so a second import must not pile up more
    assert again["will_save"] == 0 or all(i["action"] != "new" for i in again["datasets"][0]["items"])


def test_rules_missing_from_the_file_are_reported_never_deleted(db):
    from dqga import rulefiles as RF
    from dqga.models import Rule
    a, _, _, doc = _file(db)
    before = len(db.scalars(select(Rule).where(Rule.asset_id == a.id)).all())
    dropped = doc["rules"].pop()
    p = RF.plan(db, _import(doc))
    assert [m["name"] for m in p["datasets"][0]["not_in_file"]] == [dropped["name"]]
    RF.apply(db, _import(doc), "tester")
    assert len(db.scalars(select(Rule).where(Rule.asset_id == a.id)).all()) == before


def test_bad_files_are_reported_not_raised(db):
    from dqga import rulefiles as RF
    a, _, _, doc = _file(db)
    p = RF.plan(db, [("broken.yaml", "a: [unclosed"), ("list.yaml", "- 1\n- 2"), ("other.yaml", "format: something/9\ndataset: x\nrules: []"),
                     ("future.yaml", "format: datatrustai-rules/9\ndataset: x\nrules: []"), ("nods.yaml", "format: datatrustai-rules/1\nrules: []"),
                     ("unknown.yaml", "format: datatrustai-rules/1\ndataset: nope.nope.nope\nrules: []")])
    assert len(p["errors"]) == 6 and not p["datasets"]
    assert any("not valid YAML" in e for e in p["errors"]) and any("not in the catalog" in e for e in p["errors"])
    doc["rules"] = [{"key": "a", "name": "bad column", "type": "not_null", "column": "no_such_column"},
                    {"key": "b", "name": "bad type", "type": "made_up", "column": a.columns[0]["name"]}]
    p = RF.plan(db, _import(doc))
    assert p["totals"]["invalid"] == 2 and p["will_save"] == 0
    assert {i["action"] for i in p["datasets"][0]["items"]} == {"invalid"}


def test_dataset_match_is_exact_not_fuzzy(db):
    from dqga import rulefiles as RF
    p = RF.plan(db, [("a.yaml", "format: datatrustai-rules/1\ndataset: customers\nrules: []")])
    assert p["errors"] and not p["datasets"]  # "customers" would fuzzy-match silver.customers elsewhere in the app; files must name it fully
    p = RF.plan(db, [("a.yaml", "format: datatrustai-rules/1\ndataset: UTILITY.SILVER.CUSTOMERS\nrules: []")])
    assert p["datasets"] and p["datasets"][0]["dataset"] == "utility.silver.customers"


def test_api_download_preview_and_apply(client, db):
    a = _customers(db)
    r = client.get("/api/rules/files/download", params={"asset_id": a.id})
    assert r.status_code == 200 and r.headers["content-disposition"].endswith('customers.yaml"') and "format: datatrustai-rules/1" in r.text
    z = client.get("/api/rules/files/download")
    names = zipfile.ZipFile(io.BytesIO(z.content)).namelist()
    assert z.headers["content-type"] == "application/zip" and "utility/silver/customers.yaml" in names
    doc = yaml.safe_load(r.text)
    doc["rules"].append({"key": "k", "name": "zz api rule", "type": "not_null", "column": a.columns[0]["name"]})
    body = {"files": [{"name": "customers.yaml", "text": yaml.safe_dump(doc)}]}
    p = client.post("/api/rules/files/preview", json=body).json()
    assert p["totals"]["new"] == 1 and p["will_save"] == 1
    assert client.get("/api/rules", params={"status": "proposed"}).json() == client.get("/api/rules", params={"status": "proposed"}).json()
    res = client.post("/api/rules/files/apply", json=body).json()
    assert len(res["created"]) == 1 and res["invalid"] == 0
    zipped = io.BytesIO()
    with zipfile.ZipFile(zipped, "w") as zf:
        zf.writestr("x/customers.yaml", yaml.safe_dump(doc))
    import base64
    p2 = client.post("/api/rules/files/preview", json={"zip_b64": base64.b64encode(zipped.getvalue()).decode()}).json()
    assert p2["totals"]["datasets"] == 1 and p2["will_save"] == 0  # the draft from above is already there


def test_api_refuses_empty_and_corrupt_uploads(client):
    assert client.post("/api/rules/files/preview", json={"files": []}).status_code == 400
    assert client.post("/api/rules/files/preview", json={"zip_b64": "AAAA"}).status_code == 400
    assert client.get("/api/rules/files/download", params={"asset_id": 999999}).status_code == 400


def test_command_line_export_validate_and_import(seeded, tmp_path, capsys):
    from dqga.cli import main
    cfg = str(seeded["dir"] / "config.yaml")
    assert main(["--config", cfg, "--env-file", "none", "rules-export", "--out", str(tmp_path)]) == 0
    f = tmp_path / "utility" / "silver" / "customers.yaml"
    assert f.exists()
    assert main(["--config", cfg, "--env-file", "none", "rules-validate", str(tmp_path)]) == 0
    doc = yaml.safe_load(f.read_text())
    doc["rules"].append({"key": "k", "name": "zz cli rule", "type": "not_null", "column": "no_such_column"})
    f.write_text(yaml.safe_dump(doc))
    assert main(["--config", cfg, "--env-file", "none", "rules-validate", str(f)]) == 1
    assert main(["--config", cfg, "--env-file", "none", "rules-import", str(f), "--apply"]) == 1  # nothing is saved when a rule is invalid
    doc["rules"][-1]["column"] = next(r["column"] for r in doc["rules"] if r.get("column"))
    f.write_text(yaml.safe_dump(doc))
    assert main(["--config", cfg, "--env-file", "none", "rules-import", str(f)]) == 0  # preview only
    from dqga.db import session_scope
    from dqga.models import Rule
    with session_scope() as db:
        assert not db.scalars(select(Rule).where(Rule.name == "zz cli rule")).first()
    assert main(["--config", cfg, "--env-file", "none", "rules-import", str(f), "--apply"]) == 0
    with session_scope() as db:
        r = db.scalars(select(Rule).where(Rule.name == "zz cli rule")).first()
        assert r and r.status == "proposed" and r.created_by == "cli"
