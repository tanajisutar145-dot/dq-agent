"""Databricks deployment behaviour that can be tested without a workspace."""
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def test_lakebase_url_from_app_env(monkeypatch):
    from dqga.db import lakebase_url

    monkeypatch.setenv("PGHOST", "instance-123.database.cloud.databricks.com")
    monkeypatch.setenv("PGUSER", "a1b2c3d4-sp-client-id")
    monkeypatch.setenv("PGDATABASE", "databricks_postgres")
    monkeypatch.delenv("PGPORT", raising=False)
    url = lakebase_url()
    assert url == ("postgresql+psycopg://a1b2c3d4-sp-client-id@instance-123.database.cloud.databricks.com:5432/"
                   "databricks_postgres?sslmode=require")
    monkeypatch.delenv("PGHOST")
    with pytest.raises(ValueError, match="PGHOST"):
        lakebase_url()


def test_port_comes_from_databricks_apps(monkeypatch):
    from dqga.cli import default_port

    monkeypatch.delenv("DATABRICKS_APP_PORT", raising=False)
    monkeypatch.delenv("PORT", raising=False)
    assert default_port() == 8000
    monkeypatch.setenv("DATABRICKS_APP_PORT", "8123")
    assert default_port() == 8123


class _Cursor:
    def __init__(self, conn):
        self.conn, self.description = conn, None

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def execute(self, sql):
        if self.conn.fail_with:
            raise self.conn.fail_with
        self.description = [("x",)]

    def fetchall(self):
        return [(1,)]


class _Conn:
    def __init__(self, fail_with=None):
        self.fail_with, self.closed = fail_with, False

    def cursor(self):
        return _Cursor(self)

    def close(self):
        self.closed = True


def _connector(monkeypatch, conns):
    from dqga.connectors.databricks import DatabricksConnector

    c = DatabricksConnector("dbx", {})
    made = []

    def fake_connect():
        if c._conn is None:
            c._conn = conns[len(made)]
            made.append(c._conn)
        return c._conn
    monkeypatch.setattr(c, "_connect", fake_connect)
    return c, made


def test_databricks_reconnects_after_session_expiry(monkeypatch):
    RequestError = type("RequestError", (Exception,), {})
    c, made = _connector(monkeypatch, [_Conn(RequestError("Invalid SessionHandle")), _Conn()])
    assert c.query("SELECT 1 AS x") == [{"x": 1}]
    assert len(made) == 2 and made[0].closed


def test_databricks_does_not_retry_sql_errors(monkeypatch):
    ServerOperationError = type("ServerOperationError", (Exception,), {})
    c, made = _connector(monkeypatch, [_Conn(ServerOperationError("TABLE_OR_VIEW_NOT_FOUND")), _Conn()])
    with pytest.raises(Exception, match="TABLE_OR_VIEW_NOT_FOUND"):
        c.query("SELECT * FROM nope")
    assert len(made) == 1


def test_model_serving_llm_uses_databricks_auth(monkeypatch):
    sdk_core = pytest.importorskip("databricks.sdk.core")
    from dqga.llm import build_llm

    class FakeConfig:  # stands in for unified auth (the real one contacts the workspace)
        def __init__(self, host=None, profile=None):
            self.host = "https://adb-123.4.azuredatabricks.net"

        def authenticate(self):
            return {"Authorization": "Bearer dapi-test"}

    monkeypatch.setattr(sdk_core, "Config", FakeConfig)
    llm = build_llm({"provider": "databricks", "model": "my-endpoint", "base_url": "http://localhost:11434"})
    url, headers = llm._endpoint()
    assert url == "https://adb-123.4.azuredatabricks.net/serving-endpoints/my-endpoint/invocations"
    assert headers["Authorization"] == "Bearer dapi-test"


def test_databricks_config_and_connector_build_offline():
    from dqga.config import load_settings
    from dqga.connectors import build_connector

    s = load_settings(ROOT / "config.databricks.yaml")
    assert s.section("app")["db_schema"] == "dqga"
    conn_cfg = s.data["connections"][0]
    c = build_connector(conn_cfg["name"], conn_cfg["type"], conn_cfg)
    assert c.describe() == {"name": "databricks", "type": "databricks", "dialect": "spark", "sql": True,
                            "tags": True, "lineage": True, "timeseries": False}


def test_app_yaml_and_bundle_agree():
    import yaml

    app = yaml.safe_load((ROOT / "app.yaml").read_text())
    bundle = yaml.safe_load((ROOT / "databricks.yml").read_text())
    keys = {r["name"] for r in bundle["resources"]["apps"]["tcs_datatrustai"]["resources"]}
    refs = {e["valueFrom"] for e in app["env"] if "valueFrom" in e}
    assert refs <= keys, f"app.yaml references resources missing from databricks.yml: {refs - keys}"
    assert app["command"][:4] == ["python", "-m", "dqga", "serve"]
    assert ".venv" in bundle["sync"]["exclude"] and "data" in bundle["sync"]["exclude"]


def test_root_answers_head_requests():
    from fastapi.testclient import TestClient

    from dqga.api.main import create_app
    assert TestClient(create_app(bootstrap=False)).head("/").status_code == 200
