"""Connection status/enable/disable/delete, application reset, schema upgrade, and custom DQ metrics."""
import duckdb
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, inspect, select, text

from dqga import connectors as C
from dqga import services as S


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


@pytest.fixture()
def scratch_conn(client, tmp_path):
    """A throwaway DuckDB connection with one table, removed (with its datasets) afterwards."""
    path = tmp_path / "scratch.duckdb"
    con = duckdb.connect(str(path))
    con.execute("CREATE SCHEMA raw")
    con.execute("CREATE TABLE raw.readings AS SELECT i AS id, CASE WHEN i % 10 = 0 THEN NULL ELSE i * 1.5 END AS kwh FROM range(100) t(i)")
    con.close()
    r = client.post("/api/connections", json={"name": "scratch", "type": "duckdb",
                                               "config": {"path": str(path), "catalogs": ["scratch"]}})
    assert r.status_code == 200, r.text
    yield "scratch"
    client.delete("/api/connections/scratch?purge=true")


def _conn(client, name):
    return next(c for c in client.get("/api/connections").json() if c["name"] == name)


# ---------------------------------------------------------------------------- connections
def test_connection_status_is_reported_and_test_result_kept(client, scratch_conn):
    c = _conn(client, scratch_conn)
    assert c["health"] == "untested" and c["enabled"] is True and c["in_config"] is False
    r = client.post(f"/api/connections/{scratch_conn}/test").json()
    assert r["ok"] is True and r["connection"]["health"] == "ok"
    c = _conn(client, scratch_conn)
    assert c["last_test_ok"] is True and c["last_test_at"] and c["health"] == "ok"
    demo = _conn(client, "demo")
    assert demo["in_config"] is True and demo["assets"] == 7


def test_failed_test_and_sync_errors_are_saved(client, tmp_path):
    bad = tmp_path / "missing_dir" / "nope.duckdb"
    client.post("/api/connections", json={"name": "broken", "type": "duckdb", "config": {"path": str(bad)}})
    try:
        c = _conn(client, "broken")
        assert c["health"] == "error"  # registration itself failed: the folder does not exist
        r = client.post("/api/connections/broken/test").json()
        assert r["ok"] is False and r["detail"]
        assert _conn(client, "broken")["last_test_ok"] is False
    finally:
        client.delete("/api/connections/broken")


def test_disable_skips_connection_and_enable_restores_it(client, scratch_conn):
    assert client.post(f"/api/catalog/sync?connection={scratch_conn}").json()["assets"] == 1
    off = client.patch(f"/api/connections/{scratch_conn}", json={"enabled": False}).json()
    assert off["health"] == "disabled" and off["enabled"] is False
    assert C.is_disabled(scratch_conn) and scratch_conn not in C.all_connectors()
    r = client.post(f"/api/catalog/sync?connection={scratch_conn}")
    assert r.status_code == 404 and "disabled" in r.json()["detail"]
    aid = next(a["id"] for a in client.get("/api/assets").json() if a["connection"] == scratch_conn)
    run = client.post(f"/api/assets/{aid}/run")
    assert run.status_code == 404 and "disabled" in run.json()["detail"]
    # a disabled connection can still be tested (with a temporary connector)
    assert client.post(f"/api/connections/{scratch_conn}/test").json()["ok"] is True
    on = client.patch(f"/api/connections/{scratch_conn}", json={"enabled": True}).json()
    assert on["enabled"] is True and on["health"] == "ok" and scratch_conn in C.all_connectors()


def test_scheduler_skips_disabled_connections(client, scratch_conn, db):
    client.post(f"/api/catalog/sync?connection={scratch_conn}")
    aid = next(a["id"] for a in client.get("/api/assets").json() if a["connection"] == scratch_conn)
    client.post("/api/rules", json={"asset_id": aid, "type": "not_null", "column": "kwh", "status": "active"})
    client.patch(f"/api/connections/{scratch_conn}", json={"enabled": False})
    from dqga import scheduler
    item = next(i for i in scheduler.plan(db) if i["asset_id"] == aid)
    assert "disabled" in item["skipped"] and not item["rules"]
    client.patch(f"/api/connections/{scratch_conn}", json={"enabled": True})


def test_delete_connection_purges_its_datasets(client, scratch_conn, db):
    client.post(f"/api/catalog/sync?connection={scratch_conn}")
    aid = next(a["id"] for a in client.get("/api/assets").json() if a["connection"] == scratch_conn)
    client.post("/api/rules", json={"asset_id": aid, "type": "not_null", "column": "kwh", "status": "active"})
    assert client.post(f"/api/assets/{aid}/run").json()["checks"] >= 1
    r = client.delete(f"/api/connections/{scratch_conn}?purge=true").json()
    assert r["assets_removed"] == 1 and r["in_config"] is False
    assert all(a["connection"] != scratch_conn for a in client.get("/api/assets").json())
    from dqga.models import CheckResult, Rule
    db.expire_all()
    assert not db.scalars(select(Rule).where(Rule.asset_id == aid)).all()
    assert not db.scalars(select(CheckResult).where(CheckResult.asset_id == aid)).all()
    assert scratch_conn not in C.all_connectors()
    assert client.get("/api/overview").json()["assets"] == 7  # the demo data is untouched


def test_connection_changes_are_admin_only():
    from dqga.api.security import is_admin_only
    assert is_admin_only("PATCH", "/api/connections/x") and is_admin_only("DELETE", "/api/connections/x")
    assert is_admin_only("POST", "/api/admin/reset") and is_admin_only("GET", "/api/admin/maintenance")
    assert not is_admin_only("GET", "/api/connections")


# ---------------------------------------------------------------------------- schema upgrade
def test_missing_columns_are_added_to_an_old_database(tmp_path):
    from dqga.db import add_missing_columns
    eng = create_engine(f"sqlite:///{(tmp_path / 'old.db').as_posix()}")
    with eng.begin() as c:
        c.execute(text("CREATE TABLE connections (id INTEGER PRIMARY KEY, name VARCHAR(100), type VARCHAR(40), "
                       "config JSON, enabled BOOLEAN, last_sync DATETIME, status VARCHAR(200))"))
        c.execute(text("INSERT INTO connections (name, type, config, enabled) VALUES ('x', 'duckdb', '{}', 1)"))
    added = add_missing_columns(eng)
    assert {"connections.last_test_ok", "connections.last_sync_error"} <= set(added)
    cols = {c["name"] for c in inspect(eng).get_columns("connections")}
    assert {"last_test_ok", "last_test_at", "last_test_detail", "last_sync_error"} <= cols
    assert add_missing_columns(eng) == []  # idempotent


# ---------------------------------------------------------------------------- reset
@pytest.fixture()
def temp_app_db(tmp_path, seeded):
    """Point the app at a scratch SQLite database for the duration of a test, then restore the shared one."""
    import dqga.db as D
    saved = (D._engine, D._Session)
    D.init_db(f"sqlite:///{(tmp_path / 'reset_me.db').as_posix()}")
    try:
        yield tmp_path
    finally:
        D._engine, D._Session = saved
        with D.session_scope() as s:
            S.register_connections(s)


def _fill(s):
    from dqga import auth
    from dqga.models import Asset, AuditLog, CustomMetric, Rule
    auth.create_user(s, "admin@example.com", "Admin", "a-Long-password-1", role="admin")
    a = Asset(connection="demo", platform="duckdb", fqn="utility.bronze.x")
    s.add(a)
    s.flush()
    s.add(Rule(asset_id=a.id, name="r", type="not_null", column="c", dimension="completeness"))
    s.add(CustomMetric(name="m", measure="avg_score", params={}))
    s.add(AuditLog(actor="t", action="x"))
    s.flush()


def test_reset_keeps_users_and_connections_and_makes_a_backup(temp_app_db):
    import dqga.db as D
    from dqga import maintenance as MT
    from dqga.models import Asset, Connection, CustomMetric, Policy, Rule, User
    with D.session_scope() as s:
        S.apply_config(s, S.get_settings())
        _fill(s)
    with D.session_scope() as s:
        r = MT.reset_app_data(s, "tester", keep_users=True, keep_connections=True, backup=True)
    assert r["ok"] and not r["signed_out"] and r["removed"]["assets"] == 1 and r["removed"]["rules"] == 1
    assert r["backup"] and (temp_app_db / "backups").exists()
    with D.session_scope() as s:
        assert not s.scalars(select(Asset)).all() and not s.scalars(select(Rule)).all()
        assert not s.scalars(select(CustomMetric)).all()
        assert len(s.scalars(select(User)).all()) == 1
        assert s.scalars(select(Connection).where(Connection.name == "demo")).first()
        assert s.scalars(select(Policy)).all()  # reloaded from policies.yaml
        log = MT.counts(s)["audit_log"]
        assert log == 1  # the trail restarts with the reset entry
    assert "demo" in C.all_connectors()


def test_full_reset_deletes_everything_and_reloads_config(temp_app_db):
    import dqga.db as D
    from dqga import maintenance as MT
    from dqga.models import Connection, User
    with D.session_scope() as s:
        S.apply_config(s, S.get_settings())
        _fill(s)
        s.add(Connection(name="added-in-ui", type="duckdb", config={"path": ":memory:"}))
    with D.session_scope() as s:
        r = MT.reset_app_data(s, "tester", keep_users=False, keep_connections=False, backup=False)
    assert r["signed_out"] and r["backup"] is None
    with D.session_scope() as s:
        assert not s.scalars(select(User)).all()
        names = {c.name for c in s.scalars(select(Connection))}
        assert names == {"demo"}  # config.yaml connections come back; ones added in the UI are gone


def test_reset_endpoint_requires_the_confirm_word(client):
    r = client.post("/api/admin/reset", json={"confirm": "please"})
    assert r.status_code == 400 and "RESET" in r.json()["detail"]
    info = client.get("/api/admin/maintenance").json()
    assert info["dialect"] == "sqlite" and info["counts"]["assets"] == 7 and info["confirm_word"] == "RESET"


# ---------------------------------------------------------------------------- custom metrics
def test_custom_metric_lifecycle(client):
    opts = client.get("/api/custom-metrics/options").json()
    assert "pass_rate" in opts["measures"] and "completeness" in opts["dimensions"] and opts["domains"]
    m = client.post("/api/custom-metrics", json={"name": "Completeness", "measure": "dimension_score",
                                                  "params": {"dimension": "completeness"}, "target": 99.9, "warn_at": 90}).json()
    assert m["last_value"] is not None and m["status"] in ("ok", "warn", "bad") and m["unit"] == "score"
    assert len(m["trend"]) == 1
    ov = client.get("/api/overview").json()
    assert any(x["id"] == m["id"] for x in ov["custom_metrics"])
    # redefining the calculation starts a fresh history
    m2 = client.patch(f"/api/custom-metrics/{m['id']}", json={"measure": "failed_checks", "params": {"window_days": 30},
                                                              "direction": "lower", "target": 0}).json()
    assert m2["measure"] == "failed_checks" and len(m2["trend"]) == 1 and m2["last_value"] >= 0
    # renaming keeps it
    m3 = client.patch(f"/api/custom-metrics/{m['id']}", json={"name": "Failed checks (30d)"}).json()
    assert m3["name"] == "Failed checks (30d)" and len(m3["trend"]) == 2
    assert client.delete(f"/api/custom-metrics/{m['id']}").json()["deleted"] == m["id"]
    assert all(x["id"] != m["id"] for x in client.get("/api/custom-metrics").json())


@pytest.mark.parametrize("measure,params", [
    ("avg_score", {}), ("pass_rate", {"window_days": 30, "severity": "high"}), ("failing_rules", {}),
    ("open_incidents", {}), ("datasets_below", {"threshold": 95}), ("rule_coverage", {}),
    ("owner_coverage", {"platform": "duckdb"}), ("certified_share", {"domain": "unassigned"}),
])
def test_every_builtin_measure_computes(client, measure, params):
    r = client.post("/api/custom-metrics/preview", json={"name": "p", "measure": measure, "params": params}).json()
    assert r["ok"], r
    assert r["value"] is None or r["value"] >= 0


def test_sql_metric_runs_on_the_connection_and_rejects_unsafe_sql(client):
    fqn = next(a["fqn"] for a in client.get("/api/assets").json() if a["fqn"].endswith("bronze.ami_raw"))
    ok = client.post("/api/custom-metrics/preview", json={"name": "rows", "measure": "sql",
                                                          "params": {"connection": "demo", "sql": f"SELECT count(*) FROM {fqn};"}}).json()
    assert ok["ok"] and ok["value"] > 0
    for bad in ("DELETE FROM x", "SELECT 1; DROP TABLE x", "SELECT 1 -- hi"):
        r = client.post("/api/custom-metrics/preview", json={"name": "x", "measure": "sql", "params": {"connection": "demo", "sql": bad}})
        assert r.status_code == 400, bad
    missing = client.post("/api/custom-metrics", json={"name": "x", "measure": "sql", "params": {"sql": "SELECT 1"}})
    assert missing.status_code == 400 and "connection" in missing.json()["detail"]
    m = client.post("/api/custom-metrics", json={"name": "Raw rows", "measure": "sql", "unit": "rows",
                                                  "params": {"connection": "demo", "sql": f"SELECT count(*) FROM {fqn}"}}).json()
    try:
        assert m["last_value"] > 0 and m["status"] == "info"
        assert client.post("/api/custom-metrics/evaluate").json()["evaluated"] >= 1
        assert len(client.post(f"/api/custom-metrics/{m['id']}/evaluate").json()["trend"]) >= 3
    finally:
        client.delete(f"/api/custom-metrics/{m['id']}")


def test_status_against_target_and_warning():
    from dqga.dq.custom_metrics import status_of
    assert status_of(99, "higher", 95, 90) == "ok"
    assert status_of(92, "higher", 95, 90) == "warn"
    assert status_of(80, "higher", 95, 90) == "bad"
    assert status_of(0, "lower", 0, 5) == "ok" and status_of(3, "lower", 0, 5) == "warn" and status_of(9, "lower", 0, 5) == "bad"
    assert status_of(5, "higher", None, None) == "info" and status_of(None, "higher", 1, None) == "nodata"
