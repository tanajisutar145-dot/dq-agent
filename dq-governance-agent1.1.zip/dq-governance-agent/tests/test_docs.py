"""The in-app Guide: manifest, API, and that every link and anchor resolves.

slug() and anchors() mirror MD.slug / heading ids in dqga/web/app.js.
"""
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def slug(s: str) -> str:
    return re.sub(r"\s+", "-", re.sub(r"[^a-z0-9\s-]", "", s.replace("`", "").replace("*", "").lower()).strip())


def anchors(markdown: str) -> set[str]:
    out, used, fence = set(), {}, False
    for line in markdown.splitlines():
        if re.match(r"^\s*```", line):
            fence = not fence
            continue
        m = None if fence else re.match(r"^(#{1,4})\s+(.*)$", line)
        if m:
            s = slug(m.group(2).strip())
            if s in used:
                used[s] += 1
                s = f"{s}-{used[s]}"
            else:
                used[s] = 0
            out.add(s)
    return out


def links(markdown: str) -> list[str]:
    text = re.sub(r"```.*?```", "", markdown, flags=re.DOTALL)
    text = re.sub(r"`[^`]*`", "", text)
    return re.findall(r"\[[^\]]+\]\(([^)\s]+)\)", text)


def test_manifest_lists_existing_docs():
    from dqga.docs import list_docs

    docs = list_docs()
    ids = [d["id"] for d in docs]
    assert ids[:2] == ["getting-started", "features"]
    assert {"ui-guide", "databricks-setup", "configuration", "api-cli"} <= set(ids)
    assert all(d["markdown"].lstrip().startswith("# ") for d in docs)


def test_every_internal_link_and_anchor_resolves():
    from dqga.docs import list_docs

    docs = list_docs()
    by_file = {d["file"]: d for d in docs}
    problems = []
    for d in docs:
        for href in links(d["markdown"]):
            if href.startswith("http"):
                continue
            target, _, anchor = href.partition("#")
            tdoc = d if not target else by_file.get(target.split("/")[-1])
            if tdoc is None:
                problems.append(f"{d['file']}: link to unknown doc {href}")
            elif anchor and anchor not in anchors(tdoc["markdown"]):
                problems.append(f"{d['file']}: missing anchor {href}")
    assert not problems, "\n".join(problems)


def test_top_bar_help_anchors_exist():
    from dqga.docs import list_docs

    js = (ROOT / "dqga" / "web" / "app.js").read_text(encoding="utf-8")
    block = re.search(r"const HELP_FOR = \{(.*?)\};", js, re.DOTALL).group(1)
    docs = {d["id"]: d for d in list_docs()}
    for ref in re.findall(r'"([\w-]+(?:/[\w-]+)?)"', block):
        doc, _, anchor = ref.partition("/")
        assert doc in docs, ref
        if anchor:
            assert anchor in anchors(docs[doc]["markdown"]), f"Help link {ref} points at a missing section"


def test_manifest_cannot_escape_docs_folder(tmp_path):
    from dqga.docs import load_index

    (tmp_path / "ok.md").write_text("# Ok\n")
    (tmp_path.parent / "secret.md").write_text("# Secret\n")
    (tmp_path / "index.yaml").write_text("docs:\n  - {id: ok, title: Ok, file: ok.md}\n"
                                        "  - {id: bad, title: Bad, file: ../secret.md}\n"
                                        "  - {id: gone, title: Gone, file: missing.md}\n")
    assert [d["id"] for d in load_index(tmp_path)] == ["ok"]


def test_docs_api(seeded):
    from fastapi.testclient import TestClient

    from dqga.api.main import create_app
    c = TestClient(create_app(bootstrap=False))
    lst = c.get("/api/docs").json()["docs"]
    assert len(lst) >= 6 and all("markdown" in d for d in lst)
    assert "markdown" not in c.get("/api/docs?content=false").json()["docs"][0]
    assert c.get("/api/docs/features").json()["title"] == "Features reference"
    assert c.get("/api/docs/nope").status_code == 404
    assert c.get("/api/docs/..%2F..%2Fconfig").status_code == 404


@pytest.mark.parametrize("phrase", ["dry run", "quarantine", "Databricks Apps", "DQGA__", "contract-check", "PSI"])
def test_features_reference_covers_key_topics(phrase):
    from dqga.docs import get_doc

    text = " ".join(get_doc(i)["markdown"] for i in ("features", "configuration", "api-cli"))
    assert phrase.lower() in text.lower()
