"""Overview tabs (Summary, Rules, Incidents) under the shared filters, and the drill-down filters they open."""
import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


def test_options_list_the_filter_choices(client):
    o = client.get("/api/overview/options").json()
    assert "duckdb" in o["platforms"] and len(o["datasets"]) == 7 and o["windows"] == [7, 30, 90]
    assert o["severities"] == ["critical", "high", "medium", "low"] and set(o["categories"]) == {"core", "business", "governance"}
    assert "metering" in o["domains"]


def test_summary_matches_the_unfiltered_overview_and_narrows(client):
    full = client.get("/api/overview").json()
    s = client.get("/api/overview/summary").json()
    assert s["assets"] == full["assets"] == 7 and s["open_incidents"] == full["open_incidents"] and s["overall"] == full["overall"]
    assert s["filters"]["days"] == 30 and client.get("/api/overview/summary?days=13").json()["filters"]["days"] == 30
    m = client.get("/api/overview/summary?domain=metering").json()
    assert 0 < m["assets"] < 7 and set(m["heatmap"]) <= {"metering"}
    high = client.get("/api/overview/summary?severity=high").json()
    assert high["open_incidents"] == high["incidents_by_severity"]["high"] and high["assets"] == 7  # severity never narrows datasets


def test_rules_tab_tiles_and_charts(client):
    r = client.get("/api/overview/rules").json()
    t = r["tiles"]
    assert t["total"] == t["active"] + t["saved"] + t["in_review"] + t["disabled"] and t["total"] > 0
    assert {x["key"] for x in r["set_severity"]} == {"core", "business", "governance"}
    assert all(0 <= x["value"] <= 100 and x["checks"] > 0 for x in r["pass_rate_by_dimension"])
    assert all(x["value"] > 0 for x in r["failing_by_dataset"])
    assert sum(sum(x["values"].values()) for x in r["source_status"]) == t["total"]
    core = client.get("/api/overview/rules?category=core").json()
    assert core["tiles"]["total"] <= t["total"] and all(sum(x["values"].values()) == 0 for x in core["set_severity"] if x["key"] != "core")
    one = client.get("/api/overview/rules?asset_id=1").json()
    assert one["tiles"]["total"] < t["total"] and all(x["key"] == 1 for x in one["failing_by_dataset"])


def test_incidents_tab_tiles_and_charts(client):
    d = client.get("/api/overview/incidents?days=7").json()
    assert len(d["opened_vs_resolved"]) == 7 and d["filters"]["days"] == 7
    assert sum(x["value"] for x in d["open_by_severity"]) == d["tiles"]["open"] == sum(x["value"] for x in d["age_buckets"])
    assert [x["key"] for x in d["age_buckets"]] == ["< 1 day", "1-3 days", "3-7 days", "1-4 weeks", "> 4 weeks"]
    assert sum(x["value"] for x in d["by_dataset"]) == sum(x["value"] for x in d["by_domain"])
    crit = client.get("/api/overview/incidents?severity=critical").json()
    assert all(x["value"] == 0 for x in crit["open_by_severity"] if x["key"] != "critical")


def test_drill_down_filters_on_incidents_and_rules(client):
    high = client.get("/api/incidents?status=all&severity=high").json()
    assert high and all(i["severity"] == "high" for i in high)
    fqn = next(a["fqn"] for a in client.get("/api/assets").json() if a["id"] == 1)
    mine = client.get("/api/incidents?status=all&asset_id=1").json()
    assert all(i["root_fqn"] == fqn or fqn in i["assets"] for i in mine)
    dom = client.get("/api/incidents?status=all&domain=finance").json()
    assert all("finance" in i["root_fqn"] or any("finance" in a for a in i["assets"]) for i in dom)
    rules = client.get("/api/rules?severity=high&dimension=completeness").json()
    assert rules and all(r["severity"] == "high" and r["dimension"] == "completeness" for r in rules)
