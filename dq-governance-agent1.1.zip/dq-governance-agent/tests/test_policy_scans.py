"""Policies you create (validated, plain English, suggested), standards, and policy scans with history and schedule."""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


@pytest.fixture(autouse=True)
def _clean(seeded):
    """Keep the shared database as it was: no test policies, scans or schedule left behind."""
    yield
    from dqga.db import session_scope
    from dqga.models import AppSetting, Policy, PolicyScan
    with session_scope() as db:
        db.execute(delete(Policy).where(Policy.key.like("t-%")))
        db.execute(delete(PolicyScan))
        db.execute(delete(AppSetting).where(AppSetting.key == "policy_scan_schedule"))


def ownership(key="t-owner", **kw):
    return {"id": key, "type": "ownership", "require": ["owner", "steward"], "applies_to": {"all": True}, **kw}


def test_validation_explains_what_is_wrong(client):
    for bad, word in [({"id": "t-x", "type": "nope", "applies_to": {"all": True}}, "Unknown policy type"),
                      ({"id": "Bad Id", "type": "ownership", "applies_to": {"all": True}}, "id of 2-60"),
                      ({"id": "t-x", "type": "ownership"}, "applies to"),
                      ({"id": "t-x", "type": "quality_gate", "applies_to": {"all": True}}, "min_score"),
                      ({"id": "t-x", "type": "masking", "applies_to": {"all": True}, "labels": ["shoe_size"]}, "Unknown sensitive-data labels"),
                      ({"id": "t-x", "type": "retention", "applies_to": {"all": True}, "column": "ts"}, "max_age_days")]:
        r = client.post("/api/policies", json=bad)
        assert r.status_code == 400 and word in r.json()["detail"], (bad, r.text)


def test_save_list_disable_delete(client):
    p = client.post("/api/policies", json=ownership(severity="low", description="Every dataset has an owner and a steward")).json()
    assert p["key"] == "t-owner" and p["severity"] == "low" and p["description"].startswith("Every dataset")
    assert client.patch("/api/policies/t-owner", json={"enabled": False}).json()["enabled"] is False
    listed = {x["key"]: x for x in client.get("/api/policies").json()}
    assert listed["t-owner"]["enabled"] is False and listed["t-owner"]["violations"] is None  # no scan yet
    assert client.delete("/api/policies/t-owner").json() == {"deleted": "t-owner"}
    assert client.delete("/api/policies/t-owner").status_code == 404


def test_plain_english_without_a_model(client):
    d = client.post("/api/policies/draft", json={"text": "every dataset needs an owner and a steward"}).json()
    assert d["spec"]["type"] == "ownership" and d["spec"]["require"] == ["owner", "steward"] and d["parser"] == "built-in"
    assert d["would_flag"]["count"] >= 0 and d["interpretation"]
    g = client.post("/api/policies/draft", json={"text": "certified datasets must keep a DQ score of at least 95, severity critical"}).json()
    assert g["spec"]["type"] == "quality_gate" and g["spec"]["min_score"] == 95 and g["spec"]["severity"] == "critical"
    m = client.post("/api/policies/draft", json={"text": "customer emails and phone numbers must be masked"}).json()
    assert m["spec"]["type"] == "masking" and set(m["spec"]["labels"]) == {"email", "phone"}
    r = client.post("/api/policies/draft", json={"text": "delete rows older than 7 years using reading_ts"}).json()
    assert r["spec"]["type"] == "retention" and r["spec"]["max_age_days"] == 2555


def test_plain_english_that_cannot_be_read(client):
    r = client.post("/api/policies/draft", json={"text": "be nice to the data"})
    assert r.status_code in (400, 502) and r.json()["detail"]
    assert client.post("/api/policies/draft", json={"text": "   "}).status_code == 400


def test_draft_rejects_names_that_do_not_exist(client):
    r = client.post("/api/policies/draft", json={"text": "delete rows older than 2 years using no_such_column"})
    assert r.status_code == 400


class StubLLM:
    def __init__(self, answer):
        self.answer = answer

    def complete_json(self, system, prompt):
        return self.answer


def test_model_policy_is_validated_against_the_catalog(seeded):
    from dqga.db import session_scope
    from dqga.governance import policy_authoring as PA
    with session_scope() as db:
        ok = PA.llm_policy(db, StubLLM({"id": "t-llm", "type": "quality_gate", "min_score": 80, "applies_to": {"domain": ["metering"]}}), "x")
        spec = PA.validate(ok)
        PA.check_against_catalog(db, spec)
        assert spec["min_score"] == 80
        bad = PA.validate({"id": "t-llm2", "type": "quality_gate", "min_score": 80, "applies_to": {"domain": ["made_up"]}})
        with pytest.raises(ValueError, match="No dataset is in the domain"):
            PA.check_against_catalog(db, bad)
        with pytest.raises(ValueError, match="cannot"):
            PA.llm_policy(db, StubLLM({"error": "cannot express that"}), "x")


def test_suggestions_come_from_standards_and_skip_existing(client):
    s = client.post("/api/policies/suggest", json={"standards": ["gdpr"]}).json()
    assert s["standards"] == ["gdpr"] and all(x["spec"]["type"] in ("masking", "retention", "classification_required", "ownership") for x in s["suggestions"])
    for x in s["suggestions"]:
        assert x["reason"] and "count" in x["would_flag"] and x["source"] in ("standard", "signals")
    if s["suggestions"]:
        first = s["suggestions"][0]["spec"]
        assert client.post("/api/policies", json={**first, "id": "t-" + first["id"]}).status_code == 200
        again = client.post("/api/policies/suggest", json={"standards": ["gdpr"]}).json()
        assert all(x["spec"]["type"] != first["type"] or x["spec"]["applies_to"] != first["applies_to"] or x["spec"].get("labels") != first.get("labels") for x in again["suggestions"])


def test_standards_list_controls_and_coverage(client):
    r = client.get("/api/standards").json()
    keys = {f["framework"] for f in r["frameworks"]}
    assert keys == {"gdpr", "sox", "nerc_cip", "iso_8000", "dama"}
    g = next(f for f in r["frameworks"] if f["framework"] == "gdpr")
    assert g["summary"]["total"] == 5 and set(g["recommended_types"]) >= {"masking", "retention"}
    assert set(g["covered_types"]) | set(g["missing_types"]) == set(g["recommended_types"])
    assert "facts" not in g and isinstance(r["uploads"], list)


def test_scan_tracks_new_and_resolved(client):
    client.post("/api/policies", json=ownership(key="t-own-scan"))
    first = client.post("/api/policy-scans/run").json()
    assert first["total"] == len(first["violations"]) and first["new_count"] == 0 and first["resolved_count"] == 0  # nothing to compare with
    assert all(v["key"] and "platform" in v and v["new"] is False for v in first["violations"])
    latest = client.get("/api/policy-scans/latest").json()
    assert latest["scan"]["id"] == first["id"]
    listed = {x["key"]: x for x in client.get("/api/policies").json()}
    assert listed["t-own-scan"]["violations"] == first["by_policy"].get("t-own-scan", 0)
    # a new policy raises new violations; removing it resolves them
    client.post("/api/policies", json={"id": "t-gate", "type": "quality_gate", "min_score": 100, "applies_to": {"all": True}})
    second = client.post("/api/policy-scans/run").json()
    added = second["by_policy"].get("t-gate", 0)
    assert added > 0 and second["new_count"] == added
    assert all(v["new"] == (v["policy"] == "t-gate") for v in second["violations"])
    client.delete("/api/policies/t-gate")
    third = client.post("/api/policy-scans/run").json()
    assert third["resolved_count"] == added and third["new_count"] == 0
    hist = client.get("/api/policy-scans").json()
    assert [h["id"] for h in hist] == [third["id"], second["id"], first["id"]] and "violations" not in hist[0]


def test_schedule_validation_and_due_run(client, seeded):
    s = client.put("/api/policy-scans/schedule", json={"enabled": True, "cadence": "interval", "every_minutes": 60}).json()
    assert s["enabled"] and s["text"] and s["next_run"]
    assert client.put("/api/policy-scans/schedule", json={"enabled": True, "cadence": "interval", "every_minutes": 1}).status_code == 400
    from dqga.db import session_scope
    from dqga.governance import scans
    with session_scope() as db:
        assert scans.run_if_due(db) is None  # next run is an hour away
        row = db.get(scans.AppSetting, scans.SCHEDULE_KEY)
        row.value = {**row.value, "next_run": "2000-01-01T00:00:00"}
        db.flush()
        ran = scans.run_if_due(db)
        assert ran and ran["scan_id"]
        assert db.get(scans.AppSetting, scans.SCHEDULE_KEY).value["next_run"] > "2000"
    assert client.get("/api/policy-scans").json()[0]["trigger"] == "schedule"
    off = client.put("/api/policy-scans/schedule", json={"enabled": False, "cadence": "daily", "at_time": "06:00"}).json()
    assert off["enabled"] is False and off["next_run"] is None


def test_policy_changes_are_admin_only():
    from dqga.api.security import is_admin_only
    for m, p in [("POST", "/api/policies"), ("POST", "/api/policies/draft"), ("PATCH", "/api/policies/x"), ("DELETE", "/api/policies/x"),
                 ("PUT", "/api/policy-scans/schedule")]:
        assert is_admin_only(m, p), (m, p)
    assert not is_admin_only("POST", "/api/policy-scans/run") and not is_admin_only("GET", "/api/standards")
