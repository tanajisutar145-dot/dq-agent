"""No approvals inbox: changes run when asked, the record is the action history."""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


def test_inbox_endpoints_and_counters_are_gone(client):
    assert client.get("/api/approvals").status_code in (404, 405)
    assert "pending_approvals" not in client.get("/api/overview").json()


def test_failed_action_is_recorded_and_raised(db):
    from dqga import services as S
    from dqga.models import Approval
    rec = S.perform(db, "ticket", "bad", {"incident_id": 999999}, "tester")
    assert rec.status == "failed" and rec.result["error"]
    with pytest.raises(ValueError):
        S.run_action(db, "ticket", "bad", {"incident_id": 999999}, "tester")
    assert not db.scalars(select(Approval).where(Approval.status == "pending")).first()


def test_tagging_a_column_runs_at_once(client):
    pii = client.get("/api/governance/summary").json()["pii"]
    r = client.post(f"/api/classifications/{pii[0]['id']}/decide", json={"approve": True}).json()
    assert r["action"]["status"] == "approved" and r["applied"] is True
