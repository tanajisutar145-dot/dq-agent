"""Sign-up, sign-in, administrator sign-in, roles, sessions, lockout, SSO."""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete

H = {"X-Requested-With": "DataTrustAI"}
ADMIN = {"name": "Asha Admin", "email": "admin@tcs.example", "password": "Str0ng-Glacier-Pass"}


@pytest.fixture()
def local_auth(seeded, monkeypatch):
    """Switch the app to built-in accounts with an empty users table; restore afterwards."""
    from dqga import auth
    from dqga.config import get_settings
    from dqga.db import session_scope
    from dqga.models import AuthSession, User

    monkeypatch.setattr(auth, "ITERATIONS", 1000)  # fast hashing in tests only
    s = get_settings()
    old = dict(s.data.get("auth") or {})
    s.data["auth"] = {**old, "mode": "local", "signup": "approval", "default_role": "steward",
                      "max_failed_logins": 3, "lockout_minutes": 15, "min_password_length": 10, "admins": []}
    with session_scope() as db:
        db.execute(delete(AuthSession))
        db.execute(delete(User))
    yield s
    s.data["auth"] = old


def client():
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False), headers=H)


def setup_admin():
    c = client()
    r = c.post("/api/auth/setup", json=ADMIN)
    assert r.status_code == 200, r.text
    return c


def test_password_hashing_and_policy(local_auth):
    from dqga import auth
    h = auth.hash_password("Correct-Horse-9")
    assert h.startswith("pbkdf2_sha256$1000$") and auth.verify_password("Correct-Horse-9", h)
    assert not auth.verify_password("wrong", h) and not auth.verify_password("x", "garbage")
    assert auth.password_problem("short1") and auth.password_problem("onlyletterslong")
    assert auth.password_problem("asha.patel2024", email="asha.patel@tcs.com")
    assert auth.password_problem("Tr1cky-Glacier") is None


def test_first_run_setup_creates_admin_once(local_auth):
    c = client()
    cfg = c.get("/api/auth/config").json()
    assert cfg["mode"] == "local" and cfg["needs_setup"] is True
    assert c.get("/api/overview").status_code == 401
    assert c.post("/api/auth/signup", json={**ADMIN, "email": "x@tcs.example"}).status_code == 409
    c = setup_admin()
    me = c.get("/api/auth/me").json()
    assert me["role"] == "admin" and me["email"] == ADMIN["email"]
    assert c.get("/api/overview").status_code == 200
    assert client().post("/api/auth/setup", json={**ADMIN, "email": "two@tcs.example"}).status_code == 409
    assert client().get("/api/auth/config").json()["needs_setup"] is False


def test_csrf_header_required_for_changes(local_auth):
    from dqga.api.main import create_app
    bare = TestClient(create_app(bootstrap=False))
    r = bare.post("/api/auth/login", json={"email": ADMIN["email"], "password": ADMIN["password"]})
    assert r.status_code == 403 and r.json()["code"] == "csrf"


def test_signup_needs_approval_then_works(local_auth):
    admin = setup_admin()
    u = client()
    r = u.post("/api/auth/signup", json={"name": "Ravi", "email": "Ravi@TCS.example", "password": "Meter-Reads-42"})
    assert r.json()["status"] == "pending" and r.json()["user"]["email"] == "ravi@tcs.example"
    r = u.post("/api/auth/login", json={"email": "ravi@tcs.example", "password": "Meter-Reads-42"})
    assert r.status_code == 403 and "approval" in r.json()["detail"]
    assert admin.get("/api/admin/summary").json()["pending"] == 1
    uid = next(x["id"] for x in admin.get("/api/admin/users").json() if x["email"] == "ravi@tcs.example")
    assert admin.patch(f"/api/admin/users/{uid}", json={"status": "active", "role": "viewer"}).json()["role"] == "viewer"
    assert u.post("/api/auth/login", json={"email": "ravi@tcs.example", "password": "Meter-Reads-42"}).status_code == 200
    assert u.get("/api/auth/me").json()["role"] == "viewer"
    assert u.post("/api/auth/signup", json={"name": "R", "email": "ravi@tcs.example", "password": "Meter-Reads-42"}).status_code == 409


def test_admin_sign_in_rejects_non_admins(local_auth):
    admin = setup_admin()
    r = admin.post("/api/admin/users", json={"name": "Sam Steward", "email": "sam@tcs.example", "role": "steward"})
    temp = r.json()["temporary_password"]
    s = client()
    r = s.post("/api/auth/login", json={"email": "sam@tcs.example", "password": temp, "admin": True})
    assert r.status_code == 403 and "isn't an administrator" in r.json()["detail"]
    assert client().post("/api/auth/login", json={**ADMIN, "admin": True}).json()["role"] == "admin"


def test_roles_are_enforced(local_auth):
    admin = setup_admin()
    ids = {}
    for email, role in (("viewer@tcs.example", "viewer"), ("steward@tcs.example", "steward")):
        temp = admin.post("/api/admin/users", json={"name": role, "email": email, "role": role}).json()["temporary_password"]
        c = client()
        c.post("/api/auth/login", json={"email": email, "password": temp})
        assert c.get("/api/overview").json()["code"] == "password_change_required"
        assert c.post("/api/auth/password", json={"current": temp, "new": "Fresh-Glacier-2026"}).status_code == 200
        ids[role] = c
    asset = admin.get("/api/assets").json()[0]["id"]
    v, s = ids["viewer"], ids["steward"]
    assert v.get("/api/overview").status_code == 200
    r = v.post(f"/api/assets/{asset}/run")
    assert r.status_code == 403 and r.json()["code"] == "viewer"
    assert v.post("/api/agent/chat", json={"message": "show open incidents"}).status_code == 200
    assert s.post(f"/api/assets/{asset}/profile").status_code == 200
    assert s.get("/api/admin/users").json()["code"] == "admin_only"
    assert s.post("/api/connections", json={"name": "x", "type": "duckdb", "config": {}}).json()["code"] == "admin_only"
    assert s.get("/api/settings/env").status_code == 403
    audit = admin.get("/api/audit").json()
    assert any(a["action"] == "checks.run" or a["actor"] == "steward@tcs.example" for a in audit)


def test_lockout_after_failed_attempts(local_auth):
    setup_admin()
    c = client()
    for _ in range(3):
        assert c.post("/api/auth/login", json={"email": ADMIN["email"], "password": "nope-nope-1"}).status_code == 401
    r = c.post("/api/auth/login", json={"email": ADMIN["email"], "password": ADMIN["password"]})
    assert r.status_code == 429 and "Too many failed attempts" in r.json()["detail"]
    r = c.post("/api/auth/login", json={"email": "nobody@tcs.example", "password": "whatever-123"})
    assert r.status_code == 401 and r.json()["detail"] == "Incorrect email or password."


def test_reset_password_signs_user_out_and_forces_change(local_auth):
    admin = setup_admin()
    temp = admin.post("/api/admin/users", json={"name": "Priya", "email": "priya@tcs.example"}).json()["temporary_password"]
    p = client()
    p.post("/api/auth/login", json={"email": "priya@tcs.example", "password": temp})
    p.post("/api/auth/password", json={"current": temp, "new": "Own-Glacier-Pass-1"})
    assert p.get("/api/overview").status_code == 200
    uid = next(x["id"] for x in admin.get("/api/admin/users").json() if x["email"] == "priya@tcs.example")
    new_temp = admin.post(f"/api/admin/users/{uid}/reset-password").json()["temporary_password"]
    assert p.get("/api/overview").status_code == 401  # old session revoked
    p2 = client()
    assert p2.post("/api/auth/login", json={"email": "priya@tcs.example", "password": new_temp}).json()["must_change_password"]
    r = p2.post("/api/auth/password", json={"current": new_temp, "new": "short"})
    assert r.status_code == 400
    assert p2.post("/api/auth/password", json={"current": new_temp, "new": "New-Glacier-Pass-2"}).status_code == 200
    assert p2.get("/api/overview").status_code == 200


def test_last_admin_and_self_protection(local_auth):
    admin = setup_admin()
    me = admin.get("/api/auth/me").json()["id"]
    assert admin.patch(f"/api/admin/users/{me}", json={"role": "steward"}).status_code == 400
    assert admin.patch(f"/api/admin/users/{me}", json={"status": "disabled"}).status_code == 400
    assert admin.delete(f"/api/admin/users/{me}").status_code == 400


def test_logout_ends_session(local_auth):
    admin = setup_admin()
    assert admin.post("/api/auth/logout").status_code == 200
    assert admin.get("/api/auth/me").status_code == 401


def test_sso_mode_provisions_users_from_header(local_auth):
    local_auth.data["auth"]["mode"] = "sso"
    c = client()
    assert client().get("/api/overview").json()["code"] == "sso_missing"
    me = c.get("/api/auth/me", headers={"X-Forwarded-Email": "First.User@TCS.example"}).json()
    assert me["role"] == "admin" and me["auth_source"] == "sso" and me["email"] == "first.user@tcs.example"
    other = c.get("/api/auth/me", headers={"X-Forwarded-Email": "second@tcs.example"}).json()
    assert other["role"] == "steward"
    assert c.post("/api/auth/login", json=ADMIN).status_code == 409
    c.patch(f"/api/admin/users/{other['id']}", json={"status": "disabled"}, headers={"X-Forwarded-Email": "first.user@tcs.example"})
    r = c.get("/api/overview", headers={"X-Forwarded-Email": "second@tcs.example"})
    assert r.status_code == 403 and r.json()["code"] == "disabled"


def test_admin_bootstrap_from_environment(local_auth, monkeypatch):
    from dqga import auth
    from dqga.db import session_scope
    monkeypatch.setenv("DQGA_ADMIN_EMAIL", "ops@tcs.example")
    monkeypatch.setenv("DQGA_ADMIN_PASSWORD", "Bootstrap-Pass-77")
    with session_scope() as db:
        assert auth.bootstrap_admin_from_env(db) == "ops@tcs.example"
        assert auth.bootstrap_admin_from_env(db) is None
    r = client().post("/api/auth/login", json={"email": "ops@tcs.example", "password": "Bootstrap-Pass-77", "admin": True})
    assert r.status_code == 200 and r.json()["role"] == "admin"
