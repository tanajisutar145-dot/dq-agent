"""Plain-English rules, AI rule discovery, anomalies, corrections, quarantine, impact, insights."""
from datetime import datetime, timedelta

import pytest
from sqlalchemy import select

from dqga import services as S
from dqga.connectors import get_connector

COLS = [{"name": n, "family": f, "data_type": t} for n, f, t in [
    ("meter_id", "string", "VARCHAR"), ("reading_ts", "temporal", "TIMESTAMP"), ("kwh", "numeric", "DOUBLE"),
    ("voltage", "numeric", "DOUBLE"), ("substation", "string", "VARCHAR"), ("ingested_at", "temporal", "TIMESTAMP"),
    ("discount", "numeric", "DOUBLE"), ("amount", "numeric", "DOUBLE")]]


@pytest.mark.parametrize("text,rtype,check", [
    ("kwh should be greater than 0", "custom_sql", lambda r: r["params"]["expression"] == "kwh > 0"),
    ("kwh cannot be negative", "range", lambda r: r["params"] == {"min": 0}),
    ("kWh must not exceed 500", "range", lambda r: r["params"] == {"max": 500}),
    ("voltage should be less than 260", "custom_sql", lambda r: "voltage < 260" in r["params"]["expression"]),
    ("Voltage must be between 200 and 260 volts", "range", lambda r: r["params"] == {"min": 200, "max": 260}),
    ("meter_id should never be empty", "not_null", lambda r: r["column"] == "meter_id"),
    ("Every reading must have a meter id", "not_null", lambda r: r["column"] == "meter_id"),
    ("reading timestamp must not be in the future", "not_future", lambda r: r["column"] == "reading_ts"),
    ("readings should not be older than 3 hours", "freshness", lambda r: r["params"]["max_age_hours"] == 3),
    ("no duplicate meter_id and reading_ts", "unique", lambda r: r["params"]["columns"] == ["meter_id", "reading_ts"]),
    ("substation must be one of SUB-01, SUB-02 or SUB-07", "accepted_values", lambda r: r["params"]["values"] == ["SUB-01", "SUB-02", "SUB-07"]),
    ("kwh >= 0", "range", lambda r: r["params"] == {"min": 0}),
    ("Ensure kwh is not null", "not_null", lambda r: r["column"] == "kwh"),
    ("meter_id must start with MTR-", "regex", lambda r: r["params"]["pattern"].startswith("MTR")),
    ("reading_ts must be before ingested_at", "custom_sql", lambda r: r["params"]["expression"] == "reading_ts <= ingested_at"),
    ("at least 99% of kwh values must be populated", "not_null", lambda r: r["threshold"] == 0.99),
    ("discount must be less than amount", "custom_sql", lambda r: r["params"]["expression"] == "discount < amount"),
    ("data must be refreshed every 6 hours", "freshness", lambda r: r["column"] == "ingested_at" and r["params"]["max_age_hours"] == 6),
    ("substation must not be 'SUB-99'", "custom_sql", lambda r: r["params"]["expression"] == "substation <> 'SUB-99'"),
    ("meter_id must be 10 characters long", "length", lambda r: r["params"] == {"min": 10, "max": 10}),
    ("table must have at least 1,000 rows", "row_count", lambda r: r["params"] == {"min": 1000}),
    ("kwh should be above zero", "custom_sql", lambda r: r["params"]["expression"] == "kwh > 0"),
])
def test_plain_english_phrasings(text, rtype, check):
    from dqga.dq.nl_rules import parse
    from dqga.dq.rules import validate_rule
    r = parse(text, COLS)
    assert r and r["type"] == rtype, (text, r)
    assert check(r), (text, r)
    assert r["interpretation"]
    validate_rule({k: v for k, v in r.items() if k != "interpretation"}, COLS)


def test_plain_english_failure_explains(seeded):
    from dqga.dq.suggester import nl_to_rule
    with pytest.raises(ValueError) as e:
        nl_to_rule("make kwh nicer please", COLS)
    assert "recognised the column(s) kwh" in str(e.value) and "Try for example" in str(e.value)


def test_nl_rule_api_with_interpretation(db):
    a = S.find_asset(db, "bronze.ami_raw")
    res = S.nl_rule(db, a, "voltage must be between 200 and 260 for at least 99.5% of rows", "tester")
    assert res["interpretation"].startswith("Validity: voltage between 200 and 260")
    assert res["rule"]["threshold"] == 0.995 and res["dry_run"]["status"] == "pass"


# ---------------------------------------------------------------- discovery
def test_semantic_types():
    from dqga.dq.discovery import semantic_type
    assert semantic_type({"name": "latitude", "family": "numeric"}, {})[0] == "latitude"
    assert semantic_type({"name": "total_amount", "family": "numeric"}, {})[0] == "amount"
    assert semantic_type({"name": "customer_email", "family": "string"}, {})[0] == "email"
    assert semantic_type({"name": "discount_pct", "family": "numeric"}, {})[0] == "percentage"
    assert semantic_type({"name": "ingested_at", "family": "temporal"}, {})[0] == "load_time"


def test_discovery_uses_many_sources_and_accept(db):
    from dqga.dq.discovery import accept, discover
    a = S.find_asset(db, "bronze.ami_raw")
    a.description = "Raw meter reads. Voltage must be between 180 and 280."
    res = discover(db, a, use_llm=False)
    cats = {s for c in res["candidates"] for s in c["sources"]}
    assert {"Relationship", "Observability", "History", "Business context"} <= cats, cats
    rel = next(c for c in res["candidates"] if c["category"] == "Relationship")
    assert rel["params"]["expression"] == "reading_ts <= ingested_at" and rel["dry_run"]["status"] == "pass"
    biz = next(c for c in res["candidates"] if "Business context" in c["sources"] and c.get("column") == "voltage")
    assert any("Voltage must be between 180 and 280" in e for e in biz["evidence"])
    assert all(0 < c["confidence"] < 1 and c["evidence"] for c in res["candidates"])
    assert sum(res["coverage"]["after"].values()) > sum(res["coverage"]["before"].values())
    created = accept(db, a, [rel], "tester")
    assert created[0].status == "proposed" and created[0].source == "discovery"
    again = discover(db, a, use_llm=False)
    assert not any(c.get("params", {}).get("expression") == "reading_ts <= ingested_at" for c in again["candidates"])


def test_learned_from_other_datasets(db):
    from dqga.dq.discovery import learned_candidates
    a = S.find_asset(db, "gold.billing_mart")
    out = learned_candidates(db, a, a.columns)
    assert any(c["column"] == "customer_id" and "Teams already apply" in c["evidence"][0] for c in out)


# ---------------------------------------------------------------- anomalies
def test_band_series_and_level_shift():
    from dqga.dq.anomaly_scan import band_series, level_shift
    t0 = datetime(2026, 10, 1)
    pts = [(t0 + timedelta(days=i), 100 + (i % 3)) for i in range(30)] + [(t0 + timedelta(days=30), 160)]
    s = band_series(pts)
    assert s[-1]["anomaly"] and s[-1]["low"] < 101 < s[-1]["high"]
    shifted = [(t0 + timedelta(days=i), 100 + (i % 3) if i < 25 else 140 + (i % 3)) for i in range(31)]
    assert level_shift(shifted)["pct"] > 30


def test_anomaly_scan_finds_planted_anomalies(db):
    from dqga.dq.anomaly_scan import asset_view, monitor_pack, scan
    res = scan(db, 30)
    kinds = {(i["fqn"].split(".", 1)[1], i["metric"], i["kind"]) for i in res["items"]}
    assert ("bronze.ami_raw", "null_rate", "spike") in kinds
    assert any(k[0] == "finance.gl_revenue" and k[2] == "level_shift" for k in kinds)
    a = S.find_asset(db, "bronze.ami_raw")
    v = asset_view(db, a)
    rc = next(s for s in v["series"] if s["metric"] == "row_count")
    assert rc["points"][-1]["low"] is not None
    c = S.find_asset(db, "silver.customers")
    first = monitor_pack(db, c, "tester")
    assert first and all(r.status == "active" for r in first)
    assert monitor_pack(db, c, "tester") == []


# ---------------------------------------------------------------- corrections
def _seg_counts(conn):
    return {r["segment"]: r["n"] for r in conn.query("SELECT segment, COUNT(*) AS n FROM utility.silver.customers GROUP BY 1")}


def test_corrections_preview_apply_undo_and_auto(db, seeded):
    from dqga.config import get_settings
    from dqga.dq.runner import run_asset
    from dqga.incidents import autofix
    from dqga.models import Approval, Rule
    a = S.find_asset(db, "silver.customers")
    conn = get_connector(a.connection)
    rule = db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.type == "accepted_values", Rule.column == "segment")).first()
    fixes = {f["kind"]: f for f in autofix.analyze_rule(db, rule, a)}
    assert fixes["standardize"]["risk"] == "low" and fixes["typo"]["risk"] == "medium"
    assert {"before": "comercial", "after": "commercial"}.items() <= fixes["typo"]["preview"][0].items()
    before = _seg_counts(conn)
    fr = autofix.apply(db, fixes["standardize"]["id"], "tester")
    after = _seg_counts(conn)
    assert "Residential" not in after and after["residential"] > before["residential"]
    autofix.undo(db, fr, "tester")
    assert _seg_counts(conn) == before
    # medium risk runs at once too
    appr = S.run_action(db, "autofix", "typo", {"fix_id": fixes["typo"]["id"]}, "tester")
    assert appr.status == "approved" and "comercial" not in _seg_counts(conn)
    # low-risk corrections run automatically after a failing run when enabled
    rem = get_settings().data["remediation"]
    rem["auto_correct_low_risk"] = True
    try:
        res = run_asset(db, a, trigger="test")
    finally:
        rem["auto_correct_low_risk"] = False
    kinds = {c["title"].split(" ")[0] for c in res["auto_corrections"]}
    assert {"Standardize", "Remove"} <= kinds, res["auto_corrections"]
    assert all(c["recheck"] == "pass" for c in res["auto_corrections"])
    uniq = db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.type == "unique")).first()
    assert uniq.last_status == "pass"
    assert not db.scalars(select(Approval).where(Approval.kind == "autofix", Approval.status == "pending")).first()


# ---------------------------------------------------------------- quarantine
def _range_rule(db, a):
    from dqga.models import Rule
    return next(r for r in db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.type == "range", Rule.column == "kwh"))
                if (r.params or {}).get("max") == 50)


def test_quarantine_modes_release_and_purge(db):
    from dqga.incidents import quarantine as Q
    a = S.find_asset(db, "bronze.ami_raw")
    conn = get_connector(a.connection)
    rule = _range_rule(db, a)
    bad = lambda: conn.query(f"SELECT COUNT(*) AS n FROM {a.fqn} WHERE kwh < 0")[0]["n"]  # noqa: E731
    assert bad() == 1
    with pytest.raises(ValueError):
        Q.quarantine(db, a, rule, "tester", target="bad name; drop table x")
    b1 = Q.quarantine(db, a, rule, "tester", mode="copy")
    assert b1.rows == 1 and bad() == 1 and b1.target_table == "utility.dq_quarantine.ami_raw_quarantine"
    assert Q.release(db, b1, "tester")["note"].startswith("Copy mode")
    b2 = Q.quarantine(db, a, rule, "tester", mode="split", clean_table="utility.bronze.ami_raw_clean")
    assert conn.query("SELECT COUNT(*) AS n FROM utility.bronze.ami_raw_clean WHERE kwh < 0")[0]["n"] == 0
    assert bad() == 1
    b3 = Q.quarantine(db, a, rule, "tester", mode="move", target="utility.dq_quarantine.kwh_negative")
    assert bad() == 0
    rows = Q.rows(db, b3)
    assert rows["rows"][0]["_dq_rule"] == rule.name and rows["rows"][0]["_dq_batch"] == b3.batch_key
    assert Q.release(db, b3, "tester", revalidate=True)["released"] == 0  # still fails the rule
    assert Q.purge(db, b3, "tester")["purged"] == 1 and b3.status == "purged"
    assert Q.summary(db)["batches"] >= 3
    _ = b2


def test_quarantine_masks_personal_data(db):
    from dqga.incidents import quarantine as Q
    from dqga.models import Rule
    c = S.find_asset(db, "silver.customers")
    conn = get_connector(c.connection)
    conn.query("UPDATE utility.silver.customers SET segment = 'retail' WHERE customer_id = 3")
    rule = db.scalars(select(Rule).where(Rule.asset_id == c.id, Rule.type == "accepted_values")).first()
    b = Q.quarantine(db, c, rule, "tester", mode="copy")
    r = Q.rows(db, b)
    assert "email" in r["masked"] and r["rows"][0]["email"] == "••••" and r["rows"][0]["segment"] == "retail"
    assert Q.rows(db, b, unmask=True)["rows"][0]["email"] != "••••"


# ---------------------------------------------------------------- impact
def test_impact_data_issue_and_schema_change(db):
    from dqga.impact import analyze, notify_owners
    a = S.find_asset(db, "bronze.ami_raw")
    rep = analyze(db, a)
    names = {i["fqn"]: i["distance"] for i in rep["impacted"]}
    assert names["utility.gold.meter_readings_daily"] == 1 and "utility.finance.gl_revenue" in names
    assert rep["score"] > 0 and rep["owners"] and rep["level"] in ("low", "medium", "high", "critical")
    bm = S.find_asset(db, "gold.billing_mart")
    drop = analyze(db, bm, ["amount"], "drop")
    assert any(c["breaking"] and "amount" in c["columns"] for c in drop["contracts"])
    assert any(r["asset"] == bm.fqn for r in drop["rules"])
    m = S.find_asset(db, "silver.meters")
    rep2 = analyze(db, m, ["customer_id"], "drop")
    bmi = next(i for i in rep2["impacted"] if i["fqn"].endswith("billing_mart"))
    assert bmi["columns"] == ["customer_id"] and bmi["column_match"] == "same column name"
    assert notify_owners(db, rep2, "tester")["owners"]


# ---------------------------------------------------------------- insights
def test_insights_find_patterns(db):
    from dqga.insights import compute
    res = compute(db, 30)
    ami = next(r for r in res["recurring"] if r["root"].endswith("bronze.ami_raw"))
    assert ami["count"] >= 3 and ami["common_day"] == "Mon"
    assert res["highlights"] and any("Mondays" in h["text"] for h in res["highlights"])
    assert res["learnings"]["feedback"]["true_positive"] >= 2 and res["learnings"]["precision"] is not None
    assert sum(res["by_day"]) == res["totals"]["failures"]


def test_new_endpoints(seeded):
    from fastapi.testclient import TestClient
    from dqga.api.main import create_app
    c = TestClient(create_app(bootstrap=False))
    aid = next(a["id"] for a in c.get("/api/assets").json() if a["fqn"].endswith("gold.meter_readings_daily"))
    assert c.post(f"/api/assets/{aid}/discover?use_llm=false").json()["candidates"] is not None
    assert c.get("/api/anomalies").json()["summary"]["total"] > 0
    assert c.get(f"/api/assets/{aid}/anomalies").json()["series"]
    assert "suggestions" in c.get("/api/fixes").json()
    assert c.get(f"/api/impact?asset_id={aid}&change=data").json()["impacted"]
    assert c.get("/api/insights").json()["highlights"]
    assert c.get("/api/quarantine?status=all").json()["summary"]["batches"] >= 1


def test_agent_routes_new_questions(db):
    from dqga.agent import agent as A
    a = S.find_asset(db, "silver.meters")
    cases = {"show anomalies": "anomalies", "what patterns have you found?": "insights",
             "what is the impact of dropping customer_id in meters?": "impact_analysis",
             "discover rules for meters": "discover_rules", "what's in quarantine?": "quarantine_status"}
    for msg, tool in cases.items():
        r = A.chat(db, "route-test", msg, {"asset_id": a.id} if "meters" in msg else {}, "tester")
        assert any(t["tool"] == tool and t["ok"] for t in r["trace"]), (msg, r["trace"], r["answer"][:200])
    r = A.chat(db, "route-test", "what is the impact of dropping customer_id in meters?", {}, "tester")
    assert "Dropping customer_id" in r["answer"]
