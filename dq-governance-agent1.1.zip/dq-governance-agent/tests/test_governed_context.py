"""Contracts, policies and standards as context for rule generation, with a source tag on each proposal."""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete, select


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


@pytest.fixture
def target(client):
    """A dataset, a column with no active unique rule, and a date column; contract and policy rows made here are removed afterwards."""
    from dqga.db import session_scope
    from dqga.models import Asset, Contract, GlossaryLink, GlossaryTerm, Policy, Rule
    with session_scope() as db:
        for a in db.scalars(select(Asset).order_by(Asset.id)):
            covered = {c for r in db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status == "active", Rule.type == "unique")) for c in (r.params or {}).get("columns", [])}
            free = [c["name"] for c in a.columns if c["name"] not in covered and c.get("family") != "temporal"]
            dates = [c["name"] for c in a.columns if c.get("family") == "temporal"]
            nums = [c["name"] for c in a.columns if c.get("family") == "numeric"]
            if free and dates and nums:
                info = {"id": a.id, "fqn": a.fqn, "free": free[0], "date": dates[0], "num": nums[0]}
                break
    yield info
    with session_scope() as db:
        db.execute(delete(Contract).where(Contract.name == "t-gc-contract"))
        db.execute(delete(Policy).where(Policy.key.like("t-gc-%")))
        ids = [t.id for t in db.scalars(select(GlossaryTerm).where(GlossaryTerm.name == "t-gc-term"))]
        db.execute(delete(GlossaryLink).where(GlossaryLink.term_id.in_(ids)))
        db.execute(delete(GlossaryTerm).where(GlossaryTerm.name == "t-gc-term"))


def add_contract(info):
    from dqga.db import session_scope
    from dqga.models import Contract
    spec = {"apiVersion": "v3.0.0", "kind": "DataContract", "schema": [{"name": "t", "properties": [{"name": info["free"], "unique": True}]}]}
    with session_scope() as db:
        db.add(Contract(asset_id=info["id"], name="t-gc-contract", version="2.1", status="active", spec=spec))


def add_policy(client, **spec):
    r = client.post("/api/policies", json=spec)
    assert r.status_code == 200, r.text


def discover(client, info, context=None):
    body = {"context": context} if context is not None else {}
    r = client.post(f"/api/assets/{info['id']}/discover?use_llm=false", json=body)
    assert r.status_code == 200, r.text
    return r.json()


def test_contract_promises_become_tagged_proposals(client, target):
    add_contract(target)
    res = discover(client, target)
    hit = [c for c in res["candidates"] if "Contract" in c["sources"] and c["type"] == "unique" and c["params"]["columns"] == [target["free"]]]
    assert hit and "contract t-gc-contract v2.1" in hit[0]["ref_docs"] and "Promised in contract t-gc-contract v2.1" in hit[0]["evidence"]
    assert res["context"]["governed"]["contract"] == {"name": "t-gc-contract", "version": "2.1"} and res["context"]["by_source"]["Contract"] >= 1


def test_context_can_be_switched_off(client, target):
    add_contract(target)
    add_policy(client, id="t-gc-ret", type="retention", column=target["date"], max_age_days=30, applies_to={"fqn_pattern": target["fqn"]})
    off = discover(client, target, {"contracts": False, "policies": False})
    assert not any({"Contract", "Policy"} & set(c["sources"]) for c in off["candidates"])
    assert off["context"]["governed"]["contract"] is None and off["context"]["governed"]["policies"] == []
    on = discover(client, target)  # default: contracts and policies on
    assert on["context"]["governed"]["contract"] and "t-gc-ret" in [p["key"] for p in on["context"]["governed"]["policies"]]


def test_retention_policy_sets_the_retention_rule(client, target):
    add_policy(client, id="t-gc-ret", type="retention", column=target["date"], max_age_days=30, applies_to={"fqn_pattern": target["fqn"]})
    res = discover(client, target)
    ret = [c for c in res["candidates"] if c["type"] == "retention" and c["column"] == target["date"]]
    assert ret and ret[0]["params"]["max_age_days"] == 30  # the strictest policy beats the configured default period
    assert "Policy" in ret[0]["sources"] and "policy t-gc-ret" in ret[0]["ref_docs"] and ret[0]["rule_category"] == "governance"


def test_policy_that_does_not_apply_is_ignored(client, target):
    add_policy(client, id="t-gc-other", type="retention", column=target["date"], max_age_days=30, applies_to={"fqn_pattern": "nothing.matches.this"})
    res = discover(client, target)
    assert "t-gc-other" not in [p["key"] for p in res["context"]["governed"]["policies"]]


def test_standards_are_opt_in_and_tag_proposals(client, target):
    assert discover(client, target)["context"]["governed"]["standards"] == []
    res = discover(client, target, {"standards": ["gdpr", "iso_8000", "not_a_standard"]})
    got = {s["key"]: s for s in res["context"]["governed"]["standards"]}
    assert set(got) == {"gdpr", "iso_8000"}
    for c in res["candidates"]:
        if "Standard" in c["sources"]:
            assert any(d.startswith(("GDPR", "ISO 8000")) for d in c["ref_docs"]) and any(e.startswith("Helps ") for e in c["evidence"])


def test_governed_context_endpoint(client, target):
    add_contract(target)
    add_policy(client, id="t-gc-own", type="ownership", require=["owner"], applies_to={"all": True})
    r = client.get(f"/api/assets/{target['id']}/governed-context?standards=sox,bogus").json()
    assert r["contract"]["name"] == "t-gc-contract" and any(p["key"] == "t-gc-own" and p["description"] for p in r["policies"])
    assert [s["key"] for s in r["standards"]] == ["sox"]
    r2 = client.get(f"/api/assets/{target['id']}/governed-context?contracts=false&policies=false&glossary=false").json()
    assert r2 == {"contract": None, "policies": [], "standards": [], "glossary": []}


class StubLLM:
    def __init__(self):
        self.prompts = []

    def complete_json(self, system, prompt):
        self.prompts.append((system, prompt))
        return {"rules": [{"type": "unique", "params": {"columns": [self.col]}, "severity": "high", "category": "core",
                           "reason": getattr(self, "reason", "From policy t-gc-own and contract t-gc-contract")}]}


def test_model_gets_the_context_and_its_citations_are_tagged(client, target, seeded):
    from dqga.db import session_scope
    from dqga.dq.discovery import discover as run
    from dqga.models import Asset
    add_contract(target)
    add_policy(client, id="t-gc-own", type="ownership", require=["owner"], applies_to={"all": True})
    llm = StubLLM()
    llm.col = target["free"]
    with session_scope() as db:
        res = run(db, db.get(Asset, target["id"]), use_llm=True, llm=llm, dry_run=False)
    system, prompt = llm.prompts[0]
    assert "GOVERNANCE CONTEXT" in prompt and "contract t-gc-contract v2.1" in prompt and "policy t-gc-own" in prompt
    assert "Cite 'contract <name>'" in system or "cite 'contract <name>'" in system
    c = next(x for x in res["candidates"] if x["type"] == "unique" and x["params"]["columns"] == [target["free"]])
    assert {"LLM", "Contract", "Policy"} <= set(c["sources"]) and res["context"]["governed"]["llm_chars"] > 0
    off = StubLLM()
    off.col = target["free"]
    with session_scope() as db:
        run(db, db.get(Asset, target["id"]), use_llm=True, llm=off, dry_run=False, context={"contracts": False, "policies": False, "glossary": False})
    assert "GOVERNANCE CONTEXT" not in off.prompts[0][1]


def add_term(info):
    from dqga.db import session_scope
    from dqga.models import GlossaryLink, GlossaryTerm
    with session_scope() as db:
        t = GlossaryTerm(name="t-gc-term", definition=f"{info['num']} must be between 0 and 987654321.", domain=None)
        db.add(t)
        db.flush()
        db.add(GlossaryLink(term_id=t.id, target_type="asset", target_ref=info["fqn"]))


def test_glossary_definitions_become_tagged_proposals(client, target):
    add_term(target)
    res = discover(client, target)
    hit = [c for c in res["candidates"] if "Glossary" in c["sources"] and c["type"] == "range" and c["column"] == target["num"]]
    assert hit and "term t-gc-term" in hit[0]["ref_docs"] and any("t-gc-term" in e for e in hit[0]["evidence"])
    assert hit[0]["params"]["max"] == 987654321
    assert "t-gc-term" in [t["name"] for t in res["context"]["governed"]["glossary"]] and res["context"]["by_source"]["Glossary"] >= 1


def test_glossary_can_be_switched_off(client, target):
    add_term(target)
    off = discover(client, target, {"glossary": False})
    assert off["context"]["governed"]["glossary"] == [] and not any("Glossary" in c["sources"] for c in off["candidates"])
    assert "t-gc-term" not in off["context"]["glossary_terms"]
    assert client.get(f"/api/assets/{target['id']}/governed-context?glossary=false").json()["glossary"] == []
    assert "t-gc-term" in [t["name"] for t in client.get(f"/api/assets/{target['id']}/governed-context").json()["glossary"]]


def test_model_gets_the_glossary_and_term_citations_are_tagged(client, target):
    from dqga.db import session_scope
    from dqga.dq.discovery import discover as run
    from dqga.models import Asset
    add_term(target)
    llm = StubLLM()
    llm.col = target["free"]
    llm.reason = "From the business term t-gc-term"
    with session_scope() as db:
        res = run(db, db.get(Asset, target["id"]), use_llm=True, llm=llm, dry_run=False)
    system, prompt = llm.prompts[0]
    assert "BUSINESS GLOSSARY" in prompt and "t-gc-term" in prompt and "term <name>" in system
    c = next(x for x in res["candidates"] if x["type"] == "unique" and x["params"]["columns"] == [target["free"]])
    assert "Glossary" in c["sources"] and "term t-gc-term" in c["ref_docs"]
