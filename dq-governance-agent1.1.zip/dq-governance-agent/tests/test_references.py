"""Reference library (parsers, matching, API), the three rule sets, governance proposals and rule editing."""
import base64
import io
import zipfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from dqga import reference as REF
from dqga.dq.categories import infer

CMM = Path("C:/tms-code/utility-knowledge-graph-v3/input/data_model")


def facts(name, text, kind=None):
    k, f, summary, _ = REF.extract(name, text.encode() if isinstance(text, str) else text, kind)
    return k, f.items, summary


def has(items, kind, column, value=None, table=None):
    return any(x["kind"] == kind and (x["column"] or "").lower() == column.lower() and (value is None or x["value"] == value)
               and (table is None or (x["table"] or "").lower() == table.lower()) for x in items)


# ---------------------------------------------------------------------------- parsers
def test_sql_ddl_constraints_comments_and_keys():
    ddl = """-- model
    CREATE TABLE IF NOT EXISTS `billing`.`invoice` (
      `invoice_id` BIGINT NOT NULL COMMENT 'Unique id. Primary key of the invoice.',
      `status` VARCHAR(12) NOT NULL COMMENT 'Invoice status. Valid values: draft|issued|paid|void.',
      `amount` DECIMAL(18,2) CHECK (amount >= 0),
      `tags` ARRAY<STRUCT<k: STRING, v: STRING>>,
      `account_no` STRING COMMENT 'Account number referencing the primary key of account. Pattern: ^AC[0-9]{6}$.',
      `kind` STRING,
      CONSTRAINT pk_invoice PRIMARY KEY (invoice_id),
      CHECK (kind IN ('std', 'credit'))
    );
    ALTER TABLE billing.invoice ADD CONSTRAINT fk_acc FOREIGN KEY (account_no) REFERENCES billing.account (account_no);
    """
    kind, items, summary = facts("model.sql", ddl)
    assert kind == "sql_model" and summary["tables"] == 1 and summary["foreign_keys"] == 1
    assert has(items, "not_null", "invoice_id") and has(items, "not_null", "status")
    assert has(items, "values", "status", ["draft", "issued", "paid", "void"])
    assert has(items, "values", "kind", ["std", "credit"])
    assert has(items, "range", "amount", {"min": 0.0})
    assert has(items, "max_length", "status", 12)
    assert has(items, "pattern", "account_no", "^AC[0-9]{6}$")
    assert has(items, "pk", "invoice_id")
    assert not any(x["kind"] == "pk" and x["column"] == "account_no" for x in items)  # "primary key" in a comment is not a key
    assert any(x["kind"] == "datatype" and x["column"] == "tags" and x["value"]["type"].startswith("ARRAY<STRUCT") for x in items)
    fk = next(x for x in items if x["kind"] == "fk")
    assert fk["column"] == "account_no" and fk["value"] == {"ref_table": "billing.account", "ref_column": "account_no"}


def test_turtle_shacl_and_ontology_annotations():
    ttl = """@prefix sh: <http://www.w3.org/ns/shacl#> . @prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
    @prefix owl: <http://www.w3.org/2002/07/owl#> . @prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
    @prefix ex: <http://example.org/m#> .
    # a comment with a [bracket] and a # hash
    ex:Meter a owl:Class ; rdfs:label "Meter"@en ; ex:physicalTable "cat.metering.meter" .
    ex:MeterShape a sh:NodeShape ; sh:targetClass ex:Meter ;
      sh:property [ sh:path ex:Meter.serialNo ; sh:datatype xsd:string ; sh:minCount 1 ; sh:pattern "^[A-Z]{2}[0-9]{6}$" ] ,
                  [ sh:path ex:Meter.phase ; sh:in ( "L1" "L2" "L3" ) ] ,
                  [ sh:path ex:Meter.lat ; sh:datatype xsd:decimal ; sh:minInclusive -90.0 ; sh:maxInclusive 90.0 ] .
    ex:Meter.ownerEmail a owl:DatatypeProperty ; rdfs:domain ex:Meter ; rdfs:range xsd:string ;
      ex:physicalColumn "owner_email" ; ex:nullable false ; ex:validValues "a|b" ; ex:sensitivity "pii_email" ;
      ex:businessTerm "Owner Email Address" .
    ex:physicalColumn a owl:AnnotationProperty ; rdfs:label "physical column"@en .
    """
    kind, items, _ = facts("m.ttl", ttl)
    assert kind == "ontology"
    assert has(items, "not_null", "serialNo", table="cat.metering.meter")
    assert has(items, "pattern", "serialNo", "^[A-Z]{2}[0-9]{6}$")
    assert has(items, "values", "phase", ["L1", "L2", "L3"])
    assert has(items, "range", "lat", {"min": -90.0, "max": 90.0})
    assert has(items, "not_null", "owner_email") and has(items, "classification", "owner_email", "pii_email")
    assert has(items, "business_term", "owner_email")
    assert not any(x["column"] == "physicalColumn" for x in items)  # annotation property declarations are skipped
    assert REF.tkey("cat.metering.meter") == "metering.meter" and REF.ckey("serialNo") == REF.ckey("serial_no")


def test_xsd_xmi_and_plantuml():
    xsd = """<?xml version="1.0"?><xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
      <xs:simpleType name="Phase"><xs:restriction base="xs:string"><xs:enumeration value="L1"/><xs:enumeration value="L2"/></xs:restriction></xs:simpleType>
      <xs:element name="reading" type="ReadingType"/>
      <xs:complexType name="ReadingType"><xs:sequence>
        <xs:element name="meter_id"><xs:simpleType><xs:restriction base="xs:string"><xs:pattern value="M[0-9]+"/><xs:maxLength value="12"/></xs:restriction></xs:simpleType></xs:element>
        <xs:element name="phase" type="Phase" minOccurs="0"/>
        <xs:element name="kwh" type="xs:decimal"/>
      </xs:sequence></xs:complexType></xs:schema>"""
    _, items, _ = facts("r.xsd", xsd)
    assert has(items, "not_null", "meter_id", table="reading") and not has(items, "not_null", "phase")
    assert has(items, "values", "phase", ["L1", "L2"]) and has(items, "pattern", "meter_id", "M[0-9]+") and has(items, "max_length", "meter_id", 12)
    xmi = """<?xml version="1.0"?><xmi:XMI xmlns:xmi="http://www.omg.org/spec/XMI/20131001" xmlns:uml="http://www.omg.org/spec/UML/20131001">
      <uml:Model><packagedElement xmi:type="uml:Enumeration" xmi:id="E1" name="Status"><ownedLiteral name="open"/><ownedLiteral name="closed"/></packagedElement>
      <packagedElement xmi:type="uml:Class" xmi:id="C1" name="WorkOrder">
        <ownedAttribute name="wo_id" isID="true"><lowerValue value="1"/></ownedAttribute>
        <ownedAttribute name="status" type="E1"/></packagedElement></uml:Model></xmi:XMI>"""
    kind, items, _ = facts("wo.xmi", xmi)
    assert kind == "uml" and has(items, "not_null", "wo_id") and has(items, "pk", "wo_id") and has(items, "values", "status", ["open", "closed"])
    puml = """@startuml
    enum Phase { L1
      L2 }
    entity "metering.meter" as M {
      * meter_id : varchar(20) <<PK>>
      --
      phase : Phase
      serial_no : String [1]
      note : text
    }
    @enduml"""
    kind, items, _ = facts("model.puml", puml)
    assert kind == "uml" and has(items, "not_null", "meter_id") and has(items, "pk", "meter_id") and has(items, "max_length", "meter_id", 20)
    assert has(items, "not_null", "serial_no") and not has(items, "not_null", "note") and has(items, "values", "phase", ["L1", "L2"])


def test_glossary_master_json_schema_docx_and_policy():
    gl = ("term,definition,column,classification,business rule,synonyms\n"
          "Customer Email,Email used to contact the customer.,email,PII,Customer email must be a valid email address,Contact Email\n"
          '"Consumption","Energy in kWh. Consumption cannot be negative.",kwh,,"kwh must be between 0 and 10000",\n')
    kind, items, summary = facts("g.csv", gl)
    assert kind == "glossary" and summary["terms"] == 2
    assert has(items, "classification", "email", "pii") and has(items, "business_term", "email")
    assert any(x["kind"] == "rule_text" and "10000" in x["text"] for x in items)
    kind, items, _ = facts("subs.csv", "substation,region\nSUB-01,N\nSUB-02,S\nSUB-03,E\n")
    assert kind == "master_data" and any(x["kind"] == "master_values" and x["column"] == "substation" and x["value"]["values"] == ["SUB-01", "SUB-02", "SUB-03"] for x in items)
    schema = '{"title": "customer", "required": ["id"], "properties": {"id": {"type": "integer"}, "email": {"type": "string", "format": "email"}, "tier": {"enum": ["A", "B"]}}}'
    kind, items, _ = facts("c.json", schema)
    assert has(items, "not_null", "id") and has(items, "values", "tier", ["A", "B"]) and has(items, "classification", "email", "pii_email")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("word/document.xml", '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'
                   "<w:p><w:r><w:t>Invoices must be retained for 7 years.</w:t></w:r></w:p><w:p><w:r><w:t>Hello.</w:t></w:r></w:p></w:body></w:document>")
    kind, items, _ = facts("policy.docx", buf.getvalue(), "policy")
    assert kind == "policy" and any(x["kind"] == "rule_text" and x["value"]["governance"] and "7 years" in x["text"] for x in items)


def test_unsafe_xml_and_unreadable_files():
    with pytest.raises(ValueError, match="entity"):
        REF.extract("x.xml", b"<?xml version='1.0'?><!DOCTYPE x [<!ENTITY a 'b'>]><x>&a;</x>")
    kind, items, summary = facts("diagram.png", b"\x89PNG\r\n")
    assert kind == "uml" and not items and "note" in summary


@pytest.mark.skipif(not (CMM / "ttl/cmm_silver_shapes.shacl.ttl").exists(), reason="CMM model files not on this machine")
def test_real_cmm_shapes_and_ddl():
    _, items, summary = facts("shapes.ttl", (CMM / "ttl/cmm_silver_shapes.shacl.ttl").read_bytes())
    assert summary["facts"] > 10000
    assert has(items, "pattern", "assetTag", "^[A-Z0-9]{8,20}$", table="AssetRegistry")
    _, items, summary = facts("asset.sql", (CMM / "ddl/01_asset_tables.sql").read_bytes())
    assert summary["tables"] == 21 and has(items, "values", "asset_condition_rating", ["excellent", "good", "fair", "poor", "critical"])


# ---------------------------------------------------------------------------- API, matching and discovery
@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


@pytest.fixture(scope="module")
def refs(client):
    def up(name, text, **kw):
        r = client.post("/api/references", json={"name": name, "content_b64": base64.b64encode(text.encode()).decode(), **kw})
        assert r.status_code == 200, r.text
        return r.json()
    docs = [
        up("customer_model.sql", "CREATE TABLE silver.customers (customer_id INTEGER NOT NULL, full_name VARCHAR(120) NOT NULL, "
                                 "email VARCHAR(200), segment VARCHAR(20) COMMENT 'Valid values: residential|commercial|industrial.', "
                                 "created_at TIMESTAMP NOT NULL, extra_col INTEGER, PRIMARY KEY (customer_id));"),
        up("glossary.csv", "term,definition,column,classification,business rule,synonyms\n"
                           "Customer Email,Email used to contact the customer.,email,PII,,Contact Email\n"
                           '"Consumption","Energy in kWh. Consumption cannot be negative.",kwh,,"kwh must be between 0 and 10000",\n'),
        up("privacy.md", "# Policy\n\nPersonal data must not be kept longer than five years.\n", kind="policy"),
        up("other_domain.md", "voltage must be between 1 and 2.", domain="finance"),
    ]
    yield {d["name"]: d for d in docs}
    for d in docs:
        client.delete(f"/api/references/{d['id']}")


def _aid(client, suffix):
    return next(a["id"] for a in client.get("/api/assets").json() if a["fqn"].endswith(suffix))


def test_reference_api_lifecycle(client, refs):
    lst = client.get("/api/references").json()
    assert {"customer_model.sql", "glossary.csv", "privacy.md"} <= {d["name"] for d in lst}
    assert "content" not in lst[0]
    gid = refs["glossary.csv"]["id"]
    d = client.get(f"/api/references/{gid}").json()
    assert d["kind"] == "glossary" and d["facts"] and d["summary"]["terms"] == 2
    dl = client.get(f"/api/references/{gid}/download")
    assert dl.status_code == 200 and dl.content.startswith(b"term,definition") and "attachment" in dl.headers["content-disposition"]
    assert client.patch(f"/api/references/{gid}", json={"kind": "bogus"}).status_code == 400
    m = client.patch(f"/api/references/{gid}", json={"kind": "master_data"}).json()  # changing the kind reads the file again
    assert m["kind"] == "master_data" and m["summary"]["by_kind"].get("master_values")
    m = client.patch(f"/api/references/{gid}", json={"kind": "glossary", "description": "terms"}).json()
    assert m["kind"] == "glossary" and m["description"] == "terms"
    assert client.post(f"/api/references/{gid}/reparse").json()["status"] == "parsed"
    kinds = client.get("/api/references/kinds").json()
    assert "ontology" in kinds["kinds"] and kinds["categories"]["governance"]["label"] == "Data governance"


def test_reference_context_matches_tables_columns_and_domain(client, refs):
    cust = _aid(client, "silver.customers")
    v = client.post(f"/api/assets/{cust}/reference-context", json={}).json()
    used = {f["name"]: f["facts"] for f in v["files"]}
    assert used["customer_model.sql"] > 0 and used["glossary.csv"] > 0 and "other_domain.md" not in used  # finance-only file
    assert "email" in v["columns"] and "Contact Email" in v["context_text"]
    only = client.post(f"/api/assets/{cust}/reference-context", json={"reference_ids": [refs["glossary.csv"]["id"]]}).json()
    assert [f["name"] for f in only["files"]] == ["glossary.csv"]


def test_discovery_proposes_three_sets_from_references(client, refs):
    ami = _aid(client, "bronze.ami_raw")
    r = client.post(f"/api/assets/{ami}/discover?use_llm=false", json={}).json()
    assert set(r["sets"]) == {"core", "business", "governance"} and r["categories"]["business"] == "Business domain"
    assert all(c["rule_category"] in ("core", "business", "governance") for c in r["candidates"])
    kwh = next(c for c in r["candidates"] if c["type"] == "range" and c["column"] == "kwh")
    assert kwh["params"] == {"min": 0, "max": 10000} and kwh["rule_category"] == "business" and "glossary.csv" in kwh["ref_docs"]
    none = client.post(f"/api/assets/{ami}/discover?use_llm=false", json={"use_references": False}).json()
    assert not any("Reference" in c["sources"] for c in none["candidates"]) and not none["context"]["reference"]["files"]
    cust = _aid(client, "silver.customers")
    r = client.post(f"/api/assets/{cust}/discover?use_llm=false", json={}).json()
    ret = next(c for c in r["candidates"] if c["type"] == "retention")
    assert ret["rule_category"] == "governance" and ret["params"]["max_age_days"] == 5 * 365 and "privacy.md" in ret["evidence"][0]
    schema = next(c for c in r["candidates"] if c["type"] == "schema" and (c["params"] or {}).get("model") == "customer_model.sql")
    assert schema["rule_category"] == "core" and any("extra_col" in e for e in schema["evidence"])
    acc = client.post(f"/api/assets/{cust}/discover/accept", json={"rules": [ret], "activate": False}).json()["created"][0]
    assert acc["category"] == "governance" and acc["type"] == "retention"
    client.patch(f"/api/rules/{acc['id']}", json={"status": "disabled"})


def test_plain_english_uses_glossary_terms(client, refs):
    cust = _aid(client, "silver.customers")
    r = client.post("/api/rules/nl", json={"asset_id": cust, "text": "Contact Email must not be empty", "save": True}).json()
    assert r["rule"]["column"] == "email" and r["rule"]["type"] == "not_null" and "contact email" in r["aliases_used"]
    client.patch(f"/api/rules/{r['rule']['id']}", json={"status": "disabled"})
    gov = client.post("/api/rules/nl", json={"asset_id": cust, "text": "email must not be null", "category": "governance", "save": True}).json()
    assert gov["rule"]["category"] == "governance"
    client.patch(f"/api/rules/{gov['rule']['id']}", json={"status": "disabled"})


# ---------------------------------------------------------------------------- categories and rule editing
def test_category_inference():
    assert infer({"type": "not_null"}) == "core" and infer({"type": "accepted_values"}) == "business"
    assert infer({"type": "retention"}) == "governance" and infer({"type": "regex", "params": {"negate": True}}) == "governance"
    assert infer({"type": "range", "source": "nl"}) == "business" and infer({"type": "range", "source": "suggested"}) == "core"
    assert infer({"type": "not_null", "category": "governance"}) == "governance"


def test_edit_rule_severity_set_and_validation(client):
    cust = _aid(client, "silver.customers")
    rule = client.post("/api/rules", json={"asset_id": cust, "type": "not_null", "column": "phone", "category": "governance"}).json()
    assert rule["category"] == "governance" and rule["status"] == "proposed"
    up = client.patch(f"/api/rules/{rule['id']}", json={"severity": "critical", "category": "business", "name": "phone present",
                                                       "threshold": 0.98, "params": {}, "type": "not_null"}).json()
    assert up["severity"] == "critical" and up["category"] == "business" and up["name"] == "phone present" and up["version"] == 2
    for bad in ({"severity": "urgent"}, {"category": "other"}, {"threshold": 2}, {"status": "maybe"}, {"name": " "}):
        assert client.patch(f"/api/rules/{rule['id']}", json=bad).status_code == 400, bad
    changed = client.patch(f"/api/rules/{rule['id']}", json={"type": "regex", "params": {"pattern": "[0-9 +()-]+"}}).json()
    assert changed["type"] == "regex" and changed["dimension"] == "validity"
    assert any(r["id"] == rule["id"] for r in client.get(f"/api/rules?asset_id={cust}&category=business").json())
    client.patch(f"/api/rules/{rule['id']}", json={"status": "disabled"})


def test_negated_regex_and_retention_rules_run_and_export(client):
    cust = _aid(client, "silver.customers")
    neg = client.post("/api/rules/dry-run", json={"asset_id": cust, "type": "regex", "column": "email", "params": {"pattern": ".*@.*", "negate": True}}).json()
    assert neg["status"] == "fail"  # every email contains @, so "must not look like an email" fails
    ok = client.post("/api/rules/dry-run", json={"asset_id": cust, "type": "regex", "column": "email", "params": {"pattern": "[0-9]{3}-[0-9]{2}-[0-9]{4}", "negate": True}}).json()
    assert ok["status"] == "pass"
    old = client.post("/api/rules/dry-run", json={"asset_id": cust, "type": "retention", "column": "created_at", "params": {"max_age_days": 1}}).json()
    new = client.post("/api/rules/dry-run", json={"asset_id": cust, "type": "retention", "column": "created_at", "params": {"max_age_days": 36500}}).json()
    assert new["status"] == "pass" and old["status"] in ("pass", "fail")
    assert client.post("/api/rules/dry-run", json={"asset_id": cust, "type": "retention", "column": "created_at", "params": {}}).status_code == 400
    from types import SimpleNamespace

    from dqga.dq.exporters import export_with_report
    rules = [SimpleNamespace(id=1, name="email not raw ssn", type="regex", column="email", params={"pattern": "[0-9]{9}", "negate": True},
                             threshold=1.0, severity="high", dimension="validity", status="active", description=None,
                             schedule_minutes=None, category="governance"),
             SimpleNamespace(id=2, name="retention", type="retention", column="created_at", params={"max_age_days": 30},
                             threshold=1.0, severity="medium", dimension="timeliness", status="active", description=None,
                             schedule_minutes=None, category="governance")]
    sql = export_with_report(rules, "sql", "cat.s.t")
    assert sql["rules"] == 2 and "INTERVAL 30 DAYS" in sql["code"]
    from dqga.dq.exporters import FORMATS
    for fmt in FORMATS:  # every format can express both, through its SQL-expression check
        rep = export_with_report(rules, fmt, "cat.s.t")
        assert rep["rules"] == 2 and not rep["skipped"], (fmt, rep["skipped"])
    import yaml
    dqx = yaml.safe_load(export_with_report(rules, "dqx", "cat.s.t")["code"])
    assert [c["check"]["function"] for c in dqx] == ["sql_expression", "sql_expression"]
    neg, ret = (c["check"]["arguments"]["expression"] for c in dqx)
    # must-not-match: the row is valid when the value does NOT match; never exported as a positive regex_match
    assert neg == "NOT (`email` IS NOT NULL AND (CAST(`email` AS STRING) RLIKE '^([0-9]{9})$'))"
    assert ret == "NOT (`created_at` < current_timestamp() - INTERVAL 30 DAYS)"


def test_export_preview_reports_proposed_rules_left_out(client):
    cust = _aid(client, "silver.customers")
    rule = client.post("/api/rules", json={"asset_id": cust, "type": "retention", "column": "created_at", "params": {"max_age_days": 365}}).json()
    try:
        without = client.get(f"/api/rules/export?asset_id={cust}&target=dqx").json()
        assert without["proposed_excluded"] >= 1 and "INTERVAL 365 DAYS" not in without["code"]
        withp = client.get(f"/api/rules/export?asset_id={cust}&target=dqx&include_proposed=true").json()
        assert withp["proposed_excluded"] == 0 and "INTERVAL 365 DAYS" in withp["code"]
    finally:
        client.patch(f"/api/rules/{rule['id']}", json={"status": "disabled"})


def test_governance_candidates_for_sensitive_finance_table(db):
    from dqga.dq.governance_rules import governance_candidates
    from dqga.models import Asset
    a = Asset(id=-1, connection="demo", platform="duckdb", fqn="x.finance.payments", domain="finance")
    cols = [{"name": n, "family": f} for n, f in [("payment_id", "numeric"), ("card_no", "string"), ("email", "string"), ("marketing_consent", "boolean"),
                                                  ("is_deleted", "boolean"), ("created_at", "temporal"), ("created_by", "string"),
                                                  ("approved_by", "string"), ("nerc_cip_class", "string")]]
    out = governance_candidates(db, a, cols, {}, None, retention_days=2555)
    names = {c.get("name", "") for c in out}
    assert all(c["rule_category"] == "governance" for c in out)
    assert "card_no not stored in clear text" in names and any(c["params"].get("negate") for c in out if c["type"] == "regex")
    assert any(c["type"] == "custom_sql" and "marketing_consent" in c["params"]["expression"] for c in out)
    assert any(c.get("name", "").startswith("deleted records keep no") for c in out)
    assert any(c["type"] == "retention" and c["params"]["max_age_days"] == 2555 for c in out)
    assert "created_by and approved_by differ" in names
    assert any(c["type"] == "not_null" and c["column"] == "nerc_cip_class" for c in out)


def test_reset_can_keep_reference_files(client, refs):
    from dqga.maintenance import REFERENCE_TABLES
    assert REFERENCE_TABLES == {"reference_docs", "reference_facts"}
    info = client.get("/api/admin/maintenance").json()
    assert info["counts"]["reference_docs"] >= 3 and info["counts"]["reference_facts"] > 0


def test_rules_list_filters_several_statuses(client):
    cust = _aid(client, "silver.customers")
    saved = client.post("/api/rules", json={"asset_id": cust, "type": "not_null", "column": "address", "name": "address present (saved)"}).json()
    try:
        both = client.get(f"/api/rules?asset_id={cust}&status=active,disabled").json()
        assert both and all(r["status"] in ("active", "disabled") for r in both) and saved["id"] not in {r["id"] for r in both}
        proposed = client.get(f"/api/rules?asset_id={cust}&status=proposed").json()
        assert saved["id"] in {r["id"] for r in proposed} and all(r["status"] == "proposed" for r in proposed)
    finally:
        client.patch(f"/api/rules/{saved['id']}", json={"status": "disabled"})
