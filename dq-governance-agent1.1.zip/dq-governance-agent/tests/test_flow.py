"""End-to-end tests on the seeded demo warehouse."""
from sqlalchemy import select

from dqga import services as S
from dqga.agent import agent as A
from dqga.connectors import get_connector
from dqga.dq.exporters import export
from dqga.governance import compliance, contracts, policies
from dqga.incidents import lineage as L
from dqga.incidents.remediation import execute, suggestions_for_incident
from dqga.learning import feedback
from dqga.models import Approval, Asset, Classification, Incident, Rule
from dqga import scheduler


def _asset(db, short):
    return S.find_asset(db, short)


def _inc_for(db, root_short):
    return next(i for i in db.scalars(select(Incident)) if i.root_fqn.endswith(root_short))


def test_planted_issues_become_grouped_incidents(db):
    incs = db.scalars(select(Incident)).all()
    roots = {i.root_fqn.split(".", 1)[1] for i in incs}
    assert {"bronze.ami_raw", "silver.meters", "finance.gl_revenue", "ot.sensor_timeseries"} <= roots
    ami = _inc_for(db, "bronze.ami_raw")
    assert "utility.gold.meter_readings_daily" in ami.assets, "gold failure must be grouped under the bronze root cause"
    assert "utility.gold.billing_mart" in ami.downstream
    # gold has two failing parents; orphan meter keys (integrity) cannot explain missing kWh (completeness)
    assert "utility.gold.meter_readings_daily" not in _inc_for(db, "silver.meters").assets
    # gl_revenue duplicates sit behind a healthy billing_mart: must NOT be blamed on bronze
    assert _inc_for(db, "finance.gl_revenue").root_fqn == "utility.finance.gl_revenue"


def test_find_root_is_deterministic_and_dimension_aware(db):
    from dqga.incidents.manager import find_root
    for _ in range(3):
        root, _chain = find_root(db, "utility.gold.meter_readings_daily", {"completeness"})
        assert root == "utility.bronze.ami_raw"
    root, _ = find_root(db, "utility.gold.meter_readings_daily", {"uniqueness"})
    assert root == "utility.gold.meter_readings_daily"


def test_rca_evidence_and_hypothesis(db):
    ami = _inc_for(db, "bronze.ami_raw")
    rules = {e["rule"] for e in ami.rca["evidence"]}
    assert "kwh populated >= 99%" in rules and "row volume vs baseline" in rules
    assert "volume" in ami.rca["hypothesis"].lower() or "load" in ami.rca["hypothesis"].lower()


def test_sensor_checks_find_planted_faults(db):
    a = _asset(db, "ot.sensor_timeseries")
    status = {r.name: r.last_status for r in db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.type == "timeseries"))}
    assert status["sensor flatline < 6h"] == "fail"
    assert status["sensor data gaps"] == "fail"
    assert status["temperature within physical bounds"] == "fail"


def test_pii_classified_and_masking_policy_violated(db):
    a = _asset(db, "silver.customers")
    labels = {c.column: c.label for c in db.scalars(select(Classification).where(Classification.asset_id == a.id))}
    assert labels.get("email") == "email" and labels.get("phone") == "phone" and labels.get("full_name") == "person_name"
    v = [x for x in policies.evaluate(db) if x["policy"] == "pii-masking" and x["asset_id"] == a.id]
    assert {x["column"] for x in v} >= {"email", "phone"}
    assert all(x["enforceable"] for x in v)


def test_enforce_masking_runs_at_once_and_creates_masked_view(db):
    a = _asset(db, "silver.customers")
    pol = next(p for p in db.scalars(select(policies.Policy)) if p.key == "pii-masking")
    vio = next(x for x in policies.evaluate(db, [pol]) if x["asset_id"] == a.id and x["column"] == "email")
    stmts = policies.enforcement_sql(pol, vio, "duckdb", a)
    appr = S.run_action(db, "enforce_policy", "mask email", {"asset_id": a.id, "column": "email",
                                                             "policy_type": "masking", "statements": stmts}, "tester")
    assert appr.status == "approved", appr.result
    rows = get_connector(a.connection).query(f"SELECT DISTINCT email FROM {a.fqn}_masked")
    assert rows == [{"email": "***REDACTED***"}]
    assert not [x for x in policies.evaluate(db, [pol]) if x["asset_id"] == a.id and x["column"] == "email"]


def test_apply_tags_writes_back_to_platform(db):
    a = _asset(db, "silver.customers")
    c = db.scalars(select(Classification).where(Classification.asset_id == a.id, Classification.column == "phone")).first()
    appr = S.run_action(db, "apply_tags", "tag phone", {"asset_id": a.id, "items": [
        {"column": "phone", "classification_id": c.id, "tags": {"pii": "phone", "sensitivity": "confidential"}}]}, "tester")
    assert appr.status == "approved", appr.result
    tags = get_connector(a.connection).get_tags(a.fqn)
    assert tags["columns"]["phone"]["pii"] == "phone"


def test_compliance_reports(db):
    for fw in compliance.FRAMEWORKS:
        r = compliance.report(db, fw)
        assert r["summary"]["total"] == len(r["controls"]) > 0
        assert all(c["status"] in ("met", "partial", "gap") for c in r["controls"])


def test_contract_round_trip_and_breaking_change(db):
    a = _asset(db, "gold.billing_mart")
    rules = db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status == "active")).all()
    spec = contracts.parse(contracts.dump(contracts.export_contract(a, rules)))
    back = contracts.rules_from_contract(spec, a.columns)
    assert {(r["type"], r.get("column")) for r in back} >= {(r.type, r.column) for r in rules if r.type != "reconciliation"}
    assert contracts.validate_against_schema(spec, a.columns)["ok"]
    broken = [c for c in a.columns if c["name"] != "amount"]
    res = contracts.validate_against_schema(spec, broken)
    assert not res["ok"] and any("amount" in b for b in res["breaking"])


def test_exporters(db):
    a = _asset(db, "finance.gl_revenue")
    rules = db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status == "active")).all()
    assert "is_unique" in export(rules, "dqx", a.fqn)
    assert "IsUnique" in export(rules, "glue_dqdl", a.fqn) or "IsPrimaryKey" in export(rules, "glue_dqdl", a.fqn)
    assert "DUPLICATE_COUNT" in export(rules, "snowflake_dmf", a.fqn)
    assert "CONSTRAINT" in export(rules, "lakeflow", a.fqn)


def test_remediation_guardrails_and_quarantine(db):
    inc = _inc_for(db, "silver.meters")
    sugg = suggestions_for_incident(db, inc)
    q = next(s for s in sugg if s["kind"] == "quarantine")
    res = execute(db, q, "tester", auto=True)  # 15 rows > max_rows_auto=10 -> an automatic run does nothing
    assert res["status"] == "skipped" and any("exceeds" in r for r in res["reasons"])
    done = execute(db, q, "tester", auto=False)
    assert done["status"] == "executed"
    conn = get_connector("demo")
    assert conn.query("SELECT COUNT(*) AS n FROM utility.dq_quarantine.meters_quarantine")[0]["n"] == 15
    from dqga.dq.runner import run_asset
    out = run_asset(db, _asset(db, "silver.meters"), trigger="test")
    assert out["failed"] == 0
    db.refresh(inc)
    assert inc.status == "resolved"


def test_feedback_learning(db):
    a = _asset(db, "bronze.ami_raw")
    rule = db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.type == "anomaly")).first()
    before = rule.params["sensitivity"]
    feedback.record(db, "false_positive", "tester", rule_id=rule.id)
    assert rule.params["sensitivity"] == before + 0.5
    nn = db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.name == "kwh populated >= 99%")).first()
    feedback.record(db, "false_positive", "tester", rule_id=nn.id)
    assert nn.threshold >= 0.99, "a threshold change is suggested, never applied silently"
    assert not db.scalars(select(Approval).where(Approval.kind == "rule_update")).first()
    feedback.record(db, "expected_change", "tester", rule_id=rule.id)
    assert "baseline_from" in rule.params


def test_scheduler_is_change_aware(db):
    plan = scheduler.plan(db)
    # nothing is due right after the seed run (all rules ran < 60 min ago)
    assert all(not p["rules"] or p["skipped"] for p in plan) or plan == []
    for r in db.scalars(select(Rule).where(Rule.status == "active")):
        r.last_run = r.last_run.replace(year=2000) if r.last_run else None
    db.flush()
    plan = scheduler.plan(db)
    unchanged = [p for p in plan if p["skipped"] == "unchanged since last check"]
    assert unchanged, "unchanged tables without time-dependent rules must be skipped"
    ami = next(p for p in plan if p["fqn"].endswith("bronze.ami_raw"))
    assert ami["only_types"] == {"freshness"}, "freshness still runs on unchanged tables"


def test_lineage_ingest_openlineage(db):
    n = L.ingest_openlineage(db, {"inputs": [{"namespace": "s3", "name": "raw/weather"}],
                                  "outputs": [{"namespace": "dbx", "name": "utility.silver.weather"}]})
    assert n == 1
    assert "raw.weather" in L.upstream(db, "utility.silver.weather")


def test_agent_router_answers_without_llm(db):
    r = A.chat(db, "t1", "why is meter_readings_daily failing?", {}, "tester")
    assert "bronze.ami_raw" in r["answer"] and r["provider"]["provider"] == "rules"
    assert any(t["tool"] == "root_cause" for t in r["trace"])
    r = A.chat(db, "t1", "kwh must be between 0 and 40 on ami_raw", {}, "tester")
    assert r["actions"] == [] and "draft" in r["answer"].lower()  # the rule is a draft for the review queue, no approval card
    r = A.chat(db, "t1", "GDPR compliance report", {}, "tester")
    assert "Art. 5(1)(d)" in r["answer"]
    a = _asset(db, "gold.billing_mart")
    r = A.chat(db, "t1", "export dqx", {"asset_id": a.id}, "tester")
    assert "is_" in r["answer"] or "sql_expression" in r["answer"]
