"""Optional GitHub sync of rule files, against a fake GitHub (no network)."""
import json

import httpx
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete

TOKEN = "ghp_test_token_value_123"


class FakeHub:
    """Just enough of the GitHub REST API: repo, branch, ref, commit, tree, create commit/ref, pull request."""

    def __init__(self, same_tree=False, push=True, fail=None):
        self.calls, self.same_tree, self.push, self.fail = [], same_tree, push, fail
        self.tree_sent = None

    def __call__(self, request: httpx.Request) -> httpx.Response:
        path, m = request.url.path, request.method
        body = json.loads(request.content) if request.content else None
        self.calls.append((m, path, body))
        assert request.headers["authorization"] == f"Bearer {TOKEN}"
        if self.fail and self.fail[0] in path:
            return httpx.Response(self.fail[1], json={"message": "boom"})
        r = "/repos/acme/rules"
        if (m, path) == ("GET", r):
            return httpx.Response(200, json={"full_name": "acme/rules", "default_branch": "main", "private": True, "permissions": {"push": self.push}})
        if (m, path) == ("GET", f"{r}/branches/main"):
            return httpx.Response(200, json={"commit": {"sha": "a" * 40}})
        if (m, path) == ("GET", f"{r}/git/ref/heads/main"):
            return httpx.Response(200, json={"object": {"sha": "a" * 40}})
        if (m, path) == ("GET", f"{r}/git/commits/{'a' * 40}"):
            return httpx.Response(200, json={"tree": {"sha": "t" * 40}})
        if (m, path) == ("POST", f"{r}/git/trees"):
            self.tree_sent = body
            return httpx.Response(201, json={"sha": "t" * 40 if self.same_tree else "n" * 40})
        if (m, path) == ("POST", f"{r}/git/commits"):
            return httpx.Response(201, json={"sha": "c" * 40})
        if (m, path) == ("POST", f"{r}/git/refs"):
            return httpx.Response(201, json={"ref": body["ref"]})
        if (m, path) == ("PATCH", f"{r}/git/refs/heads/main"):
            return httpx.Response(200, json={})
        if (m, path) == ("POST", f"{r}/pulls"):
            return httpx.Response(201, json={"html_url": "https://github.com/acme/rules/pull/7", "number": 7})
        return httpx.Response(404, json={"message": "not found"})


@pytest.fixture()
def hub(seeded):
    """The feature on, a repository saved, GitHub faked. Everything is put back afterwards."""
    from dqga import gitsync
    from dqga.config import get_settings
    from dqga.db import session_scope
    from dqga.models import AppSetting
    feats = get_settings().data.setdefault("features", {})
    old = feats.get("git_sync")
    feats["git_sync"] = True
    fake = FakeHub()
    gitsync._transport = httpx.MockTransport(fake)
    with session_scope() as db:
        gitsync.save(db, {"repo": "https://github.com/acme/rules.git", "token": TOKEN}, "tester")
    yield fake
    gitsync._transport = None
    feats["git_sync"] = old
    with session_scope() as db:
        db.execute(delete(AppSetting).where(AppSetting.key == gitsync.KEY))


@pytest.fixture()
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


def test_settings_are_validated_and_the_token_is_never_shown(hub, seeded):
    from dqga import gitsync as G
    from dqga.db import session_scope
    with session_scope() as db:
        v = G.view(db)
        assert v["repo"] == "acme/rules" and v["branch"] == "main" and v["folder"] == "dq-rules" and v["mode"] == "pr" and v["token_set"] is True
        assert TOKEN not in json.dumps(v) and TOKEN not in json.dumps(G.get(db))  # stored encrypted
        for bad in ({"repo": "not a repo"}, {"folder": "../etc"}, {"folder": "/abs path"}, {"mode": "force"}, {"api_url": "http://evil.example"}, {"branch": "a b"}):
            with pytest.raises(G.GitError):
                G.save(db, bad, "tester")
        v2 = G.save(db, {"folder": "rules/dq", "mode": "commit"}, "tester")  # the saved token is kept when none is sent
        assert v2["folder"] == "rules/dq" and v2["mode"] == "commit" and v2["token_set"] is True


def test_connection_test_reports_access(hub, seeded):
    from dqga import gitsync as G
    from dqga.db import session_scope
    with session_scope() as db:
        r = G.test(db, "tester")
        assert r["ok"] and r["can_push"] and "acme/rules" in r["detail"] and r["private"]
        hub.push = False
        assert G.test(db, "tester")["ok"] is False and "read but not write" in G.test(db, "tester")["detail"]
        hub.push, hub.fail = True, ("/branches/", 404)
        with pytest.raises(G.GitError, match="could not find acme/rules or branch main"):
            G.test(db, "tester")
        hub.fail = ("/repos/acme/rules", 401)
        with pytest.raises(G.GitError, match="rejected the token"):
            G.test(db, "tester")


def test_export_opens_a_pull_request_with_the_rule_files(hub, seeded):
    from dqga import gitsync as G, rulefiles as RF
    from dqga.db import session_scope
    with session_scope() as db:
        res = G.export(db, "tester")
        expected = dict(RF.export_files(db))
    assert res["status"] == "committed" and res["mode"] == "pr" and res["url"].endswith("/pull/7") and res["branch"].startswith("datatrustai/rules-")
    sent = {e["path"]: e["content"] for e in hub.tree_sent["tree"]}
    assert sent == {f"dq-rules/{p}": t for p, t in expected.items()}
    assert hub.tree_sent["base_tree"] == "t" * 40 and all(e["mode"] == "100644" for e in hub.tree_sent["tree"])
    methods = [(m, p.split("/repos/acme/rules")[-1]) for m, p, _ in hub.calls]
    assert ("POST", "/git/refs") in methods and ("POST", "/pulls") in methods and ("PATCH", "/git/refs/heads/main") not in methods
    ref = next(b for m, p, b in hub.calls if p.endswith("/git/refs"))
    assert ref["ref"] == "refs/heads/" + res["branch"] and ref["sha"] == "c" * 40
    pr = next(b for m, p, b in hub.calls if p.endswith("/pulls"))
    assert pr["base"] == "main" and pr["head"] == res["branch"] and "nothing goes live without approval" in pr["body"]
    with session_scope() as db:
        assert G.view(db)["last"]["url"].endswith("/pull/7") and G.view(db)["last"]["actor"] == "tester"


def test_export_to_the_branch_directly_never_forces(hub, seeded):
    from dqga import gitsync as G
    from dqga.db import session_scope
    with session_scope() as db:
        G.save(db, {"mode": "commit"}, "tester")
        res = G.export(db, "tester", message="Sync rules")
    assert res["branch"] == "main" and res["mode"] == "commit" and "url" in res
    patch = next(b for m, p, b in hub.calls if m == "PATCH")
    assert patch == {"sha": "c" * 40, "force": False}
    assert not any(p.endswith("/pulls") for _, p, _ in hub.calls)
    assert next(b for m, p, b in hub.calls if p.endswith("/git/commits"))["message"] == "Sync rules"


def test_nothing_is_committed_when_the_repository_is_already_current(hub, seeded):
    from dqga import gitsync as G
    from dqga.db import session_scope
    hub.same_tree = True
    with session_scope() as db:
        res = G.export(db, "tester")
    assert res["status"] == "unchanged" and "already has these rules" in res["detail"]
    assert not any(p.endswith(("/git/commits", "/git/refs", "/pulls")) for _, p, _ in hub.calls if _ == "POST" or True) or \
        not any(m == "POST" and p.endswith(("/git/commits", "/git/refs", "/pulls")) for m, p, _ in hub.calls)


def test_github_errors_become_plain_messages(hub, seeded):
    from dqga import gitsync as G
    from dqga.db import session_scope
    with session_scope() as db:
        for status, text in ((403, "lacks permission"), (422, "could not accept the change"), (500, "GitHub returned 500")):
            hub.fail = ("/git/trees", status)
            with pytest.raises(G.GitError, match=text):
                G.export(db, "tester")


def test_export_needs_rules(hub, seeded):
    from dqga import gitsync as G
    from dqga.db import session_scope
    with session_scope() as db:
        with pytest.raises(G.GitError, match="No rules to export"):
            G.export(db, "tester", asset_ids=[999999])


def test_the_whole_feature_is_off_unless_enabled(client, seeded):
    from dqga.config import get_settings
    feats = get_settings().data.setdefault("features", {})
    old = feats.get("git_sync")
    feats["git_sync"] = False
    try:
        for m, p in (("get", "/api/git"), ("put", "/api/git"), ("delete", "/api/git"), ("post", "/api/git/test"), ("post", "/api/git/export")):
            assert getattr(client, m)(p).status_code == 404, p
        assert client.get("/api/meta").json()["features"]["git_sync"] is False
    finally:
        feats["git_sync"] = old


def test_api_round_trip_and_admin_only_settings(client, hub, seeded):
    from dqga.api.security import is_admin_only
    r = client.get("/api/git").json()
    assert r["configured"] and r["token_set"] and TOKEN not in json.dumps(r)
    assert client.get("/api/meta").json()["features"]["git_sync"] is True
    assert client.post("/api/git/test").json()["ok"] is True
    out = client.post("/api/git/export", json={}).json()
    assert out["status"] == "committed" and out["url"].endswith("/pull/7")
    assert client.put("/api/git", json={"repo": "bad repo"}).status_code == 400
    assert is_admin_only("PUT", "/api/git") and is_admin_only("DELETE", "/api/git") and is_admin_only("POST", "/api/git/test")
    assert not is_admin_only("POST", "/api/git/export") and not is_admin_only("GET", "/api/git")
    assert client.delete("/api/git").json() == {"ok": True}
    assert client.get("/api/git").json()["configured"] is False
