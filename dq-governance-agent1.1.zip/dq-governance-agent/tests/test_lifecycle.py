"""Rule lifecycle (draft -> review -> approved -> active), who may do what, the app-wide LLM setting,
real dry runs on the platform, selected-rule export and configurable dataset grouping."""
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete

H = {"X-Requested-With": "DataTrustAI"}
ADMIN = {"name": "Asha Admin", "email": "admin@tcs.example", "password": "Str0ng-Glacier-Pass"}


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


def _aid(client, suffix):
    return next(a["id"] for a in client.get("/api/assets").json() if a["fqn"].endswith(suffix))


def _draft(client, aid, column="kwh", name=None):
    r = client.post("/api/rules", json={"asset_id": aid, "type": "range", "column": column, "params": {"min": 0}, "severity": "high",
                                        "name": name or f"{column} not negative (lifecycle test)"})
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture()
def cleanup(seeded):
    from dqga.db import session_scope
    from dqga.models import Rule, RuleHistory
    made = []
    yield made
    with session_scope() as db:
        for rid in made:
            db.execute(delete(RuleHistory).where(RuleHistory.rule_id == rid))
            db.execute(delete(Rule).where(Rule.id == rid))


# ---------------------------------------------------------------------------- lifecycle
def test_draft_review_approve_activate_and_the_rules_of_the_road(client, cleanup):
    aid = _aid(client, "bronze.ami_raw")
    r = _draft(client, aid)
    cleanup.append(r["id"])
    assert r["status"] == "proposed"
    # a draft cannot be approved or activated; only sent for approval
    assert client.post("/api/rules/review/decide", json={"rule_ids": [r["id"]], "decision": "approve"}).status_code == 400
    assert client.post("/api/rules/review/decide", json={"rule_ids": [r["id"]], "decision": "activate"}).status_code == 400
    sub = client.post("/api/rules/submit", json={"rule_ids": [r["id"]], "note": "check the floor"}).json()["rules"][0]
    assert sub["status"] == "review" and sub["submitted_by"] and sub["submit_note"] == "check the floor"
    assert client.post("/api/rules/submit", json={"rule_ids": [r["id"]]}).status_code == 400  # already waiting
    q = client.get("/api/rules/review").json()
    assert r["id"] in {x["id"] for x in q["rules"]} and q["counts"]["waiting"] >= 1 and q["rules"][0]["platform"]
    # withdraw, then send again
    assert client.post("/api/rules/withdraw", json={"rule_ids": [r["id"]]}).status_code == 200
    assert client.get("/api/rules?asset_id=%d&status=proposed" % aid).json()
    client.post("/api/rules/submit", json={"rule_ids": [r["id"]]})
    # reject needs a reason and goes back to the author
    assert client.post("/api/rules/review/decide", json={"rule_ids": [r["id"]], "decision": "reject"}).status_code == 400
    rej = client.post("/api/rules/review/decide", json={"rule_ids": [r["id"]], "decision": "reject", "note": "scope it"}).json()["rules"][0]
    assert rej["status"] == "rejected" and rej["decision_note"] == "scope it" and rej["decided_by"]
    assert r["id"] in {x["id"] for x in client.get("/api/rules?status=proposed,rejected").json()}
    # sent again: the earlier decision is cleared; approve, then activate in a second step
    again = client.post("/api/rules/submit", json={"rule_ids": [r["id"]]}).json()["rules"][0]
    assert again["status"] == "review" and again["decision_note"] is None
    ok = client.post("/api/rules/review/decide", json={"rule_ids": [r["id"]], "decision": "approve"}).json()["rules"][0]
    assert ok["status"] == "approved"
    assert client.post("/api/rules/review/decide", json={"rule_ids": [r["id"]], "decision": "approve"}).status_code == 400
    live = client.post("/api/rules/review/decide", json={"rule_ids": [r["id"]], "decision": "activate"}).json()["rules"][0]
    assert live["status"] == "active"
    assert client.get("/api/rules/review?status=bogus").status_code == 400
    hist = client.get(f"/api/rules/{r['id']}/history").json()["versions"]
    assert [h["change"] for h in hist][:2] == ["created (proposed)", "sent for approval"] and hist[-1]["change"] == "activated"


def test_discovery_and_nl_only_ever_make_drafts(client, cleanup):
    aid = _aid(client, "silver.meters")
    acc = client.post(f"/api/assets/{aid}/discover/accept", json={"activate": True, "rules": [
        {"type": "length", "column": "meter_id", "params": {"min": 3, "max": 40}, "severity": "medium", "name": "meter id length (lifecycle test)"}]}).json()["created"]
    cleanup.extend(r["id"] for r in acc)
    assert acc and all(r["status"] == "proposed" for r in acc)  # activate is ignored
    nl = client.post("/api/rules/nl", json={"asset_id": aid, "text": "meter_id must not be null"}).json()
    assert nl["saved"] is False and nl["rule"]["id"] is None and nl["dry_run"]["ran_on"]["queries"] >= 1


def test_dry_run_runs_on_the_platform_and_says_where(client):
    aid = _aid(client, "bronze.ami_raw")
    d = client.post("/api/rules/dry-run", json={"asset_id": aid, "type": "range", "column": "kwh", "params": {"min": 0}}).json()
    ran = d["ran_on"]
    assert d["total"] > 0 and ran["platform"] == "duckdb" and ran["connection"] and ran["queries"] == 1
    assert ran["sql"][0].upper().startswith("SELECT") and "kwh" in ran["sql"][0]
    # nothing was stored
    assert not [r for r in client.get(f"/api/rules?asset_id={aid}").json() if r["name"] == d.get("name")]


def test_dry_run_refuses_platforms_that_cannot_run_sql(client, monkeypatch):
    from dqga import connectors as C
    aid = _aid(client, "bronze.ami_raw")
    conn = C.get_connector("demo")
    monkeypatch.setattr(type(conn), "supports_sql", False, raising=False)
    r = client.post("/api/rules/dry-run", json={"asset_id": aid, "type": "not_null", "column": "kwh"})
    assert r.status_code == 400 and "can't run SQL" in r.json()["detail"]


def test_rules_can_be_filtered_by_platform(client):
    assert client.get("/api/rules?platform=duckdb").json() and client.get("/api/rules?platform=snowflake").json() == []


# ---------------------------------------------------------------------------- roles
@pytest.fixture()
def team(seeded, monkeypatch):
    """Local sign-in with an administrator, a steward and a viewer."""
    from dqga import auth
    from dqga.api.main import create_app
    from dqga.config import get_settings
    from dqga.db import session_scope
    from dqga.models import AuthSession, User

    monkeypatch.setattr(auth, "ITERATIONS", 1000)
    s = get_settings()
    old = dict(s.data.get("auth") or {})
    s.data["auth"] = {**old, "mode": "local", "signup": "approval", "default_role": "steward", "max_failed_logins": 3,
                      "lockout_minutes": 15, "min_password_length": 10, "admins": []}
    with session_scope() as db:
        db.execute(delete(AuthSession))
        db.execute(delete(User))

    def new():
        return TestClient(create_app(bootstrap=False), headers=H)
    admin = new()
    assert admin.post("/api/auth/setup", json=ADMIN).status_code == 200
    out = {"admin": admin}
    for role in ("steward", "viewer"):
        email = f"{role}@tcs.example"
        temp = admin.post("/api/admin/users", json={"name": role, "email": email, "role": role}).json()["temporary_password"]
        c = new()
        c.post("/api/auth/login", json={"email": email, "password": temp})
        assert c.post("/api/auth/password", json={"current": temp, "new": "Fresh-Glacier-2026"}).status_code == 200
        out[role] = c
    yield out
    s.data["auth"] = old


def test_only_administrators_approve_reject_and_activate(team, cleanup):
    admin, steward, viewer = team["admin"], team["steward"], team["viewer"]
    aid = _aid(admin, "bronze.ami_raw")
    r = _draft(steward, aid, name="kwh floor (roles test)")
    cleanup.append(r["id"])
    assert viewer.post("/api/rules/submit", json={"rule_ids": [r["id"]]}).json()["code"] == "viewer"
    # a steward can edit a draft and send it, but cannot make anything live
    assert steward.patch(f"/api/rules/{r['id']}", json={"severity": "critical"}).status_code == 200
    assert steward.post(f"/api/rules/{r['id']}/activate").status_code == 403
    assert steward.patch(f"/api/rules/{r['id']}", json={"status": "active"}).status_code == 403
    assert steward.post("/api/rules", json={"asset_id": aid, "type": "not_null", "column": "kwh", "status": "active"}).status_code == 403
    assert steward.patch(f"/api/rules/{r['id']}", json={"status": "review"}).json()["status"] == "review"  # same as Send for approval
    for decision in ("approve", "reject", "approve_activate", "activate"):
        res = steward.post("/api/rules/review/decide", json={"rule_ids": [r["id"]], "decision": decision, "note": "x"})
        assert res.status_code == 403 and "administrators" in res.json()["detail"]
    # waiting rules are locked for content edits by a steward; the author may withdraw
    assert steward.patch(f"/api/rules/{r['id']}", json={"params": {"min": 5}}).status_code == 403
    assert steward.post("/api/rules/withdraw", json={"rule_ids": [r["id"]]}).status_code == 200
    steward.post("/api/rules/submit", json={"rule_ids": [r["id"]]})
    assert admin.post("/api/rules/review/decide", json={"rule_ids": [r["id"]], "decision": "approve_activate"}).json()["rules"][0]["status"] == "active"
    # a live rule: only an administrator changes it; a steward can still switch it off
    assert steward.patch(f"/api/rules/{r['id']}", json={"severity": "low"}).status_code == 403
    assert admin.patch(f"/api/rules/{r['id']}", json={"severity": "low"}).status_code == 200
    assert steward.patch(f"/api/rules/{r['id']}", json={"status": "disabled"}).json()["status"] == "disabled"
    assert any(a["action"] == "rule.approve_activate" for a in admin.get("/api/audit").json())


def test_steward_monitors_and_contracts_become_drafts_but_the_admins_go_live(team, cleanup):
    admin, steward = team["admin"], team["steward"]
    made = []
    for a in admin.get("/api/assets").json():  # earlier tests may already have monitors on some datasets
        s = steward.post(f"/api/assets/{a['id']}/monitor").json()
        cleanup.extend(r["id"] for r in s["created"])
        made += s["created"]
        assert s["as_drafts"] is True
    assert made and all(r["status"] == "proposed" for r in made)


def test_there_is_no_approvals_inbox(team, seeded):
    assert team["admin"].get("/api/approvals").status_code in (404, 405)
    assert team["admin"].post("/api/approvals/1/decide", json={"approve": True}).status_code in (404, 405)


# ---------------------------------------------------------------------------- LLM settings
class _FakeLLM(BaseHTTPRequestHandler):
    seen = []

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get("content-length", 0))) or b"{}")
        _FakeLLM.seen.append({"auth": self.headers.get("Authorization"), "model": body.get("model")})
        if self.headers.get("Authorization") == "Bearer bad-key":
            self.send_response(401)
            self.end_headers()
            self.wfile.write(b'{"error":"invalid key"}')
            return
        text = json.dumps(body).lower()
        content = ('{"rules": [{"type": "range", "column": "kwh", "params": {"min": 0, "max": 9000}, "severity": "high", '
                   '"reason": "fake model says so", "category": "business"}]}') if "table" in text and "columns" in text else "OK"
        out = json.dumps({"choices": [{"message": {"content": content}}]}).encode()
        self.send_response(200)
        self.send_header("content-length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)

    def log_message(self, *a):
        pass


@pytest.fixture()
def fake_llm():
    srv = HTTPServer(("127.0.0.1", 0), _FakeLLM)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    _FakeLLM.seen.clear()
    yield f"http://127.0.0.1:{srv.server_port}/v1"
    srv.shutdown()


@pytest.fixture()
def llm_reset(client):
    yield
    client.delete("/api/llm")


def test_llm_settings_are_validated_tested_saved_and_used_everywhere(client, fake_llm, llm_reset, seeded):
    from dqga import services as S
    from dqga.db import session_scope
    from dqga.models import AppSetting
    v = client.get("/api/llm").json()
    assert v["current"]["provider"] == "rules" and v["source"] == "config" and set(v["providers"]) >= {"anthropic", "openai_compatible", "ollama", "databricks"}
    assert client.put("/api/llm", json={"provider": "nope"}).status_code == 400
    assert client.put("/api/llm", json={"provider": "openai_compatible", "base_url": fake_llm}).status_code == 400  # no model
    assert "No API key" in client.post("/api/llm/test", json={"provider": "openai_compatible", "base_url": fake_llm, "model": "m", "api_key_env": "NOPE_X"}).json()["error"]
    bad = client.post("/api/llm/test", json={"provider": "openai_compatible", "base_url": fake_llm, "model": "m", "api_key": "bad-key"}).json()
    assert bad["ok"] is False and "401" in bad["error"] and "rejected" in bad["error"]
    gone = client.post("/api/llm/test", json={"provider": "ollama", "base_url": "http://127.0.0.1:9", "model": "m"}).json()
    assert gone["ok"] is False and "Could not connect" in gone["error"]
    good = client.post("/api/llm/test", json={"provider": "openai_compatible", "base_url": fake_llm, "model": "fake-model", "api_key": "test-key-0001"}).json()
    assert good["ok"] and good["reply"] == "OK" and good["latency_s"] >= 0
    assert S.get_llm() is None  # testing saves nothing

    saved = client.put("/api/llm", json={"provider": "openai_compatible", "base_url": fake_llm, "model": "fake-model", "api_key": "test-key-0001"}).json()
    assert saved["source"] == "app" and saved["active"]["provider"] == "openai_compatible" and saved["key"] == {
        "needed": True, "set": True, "source": "saved", "hint": "…0001"}
    assert "test-key-0001" not in json.dumps(saved) and "test-key-0001" not in json.dumps(client.get("/api/llm").json())
    with session_scope() as db:  # encrypted at rest
        raw = json.dumps(db.get(AppSetting, "llm").value)
    assert "test-key-0001" not in raw and "api_key_enc" in raw
    # one model for the whole app
    assert S.get_llm().model == "fake-model" and client.get("/api/meta").json()["llm"]["model"] == "fake-model"
    aid = _aid(client, "bronze.ami_raw")
    d = client.post(f"/api/assets/{aid}/discover?use_llm=true", json={}).json()
    assert d["context"]["llm"] is True and any("LLM" in c["sources"] for c in d["candidates"])
    assert _FakeLLM.seen[-1]["auth"] == "Bearer test-key-0001"
    # saving without a key keeps the stored one; clearing removes it
    kept = client.put("/api/llm", json={"provider": "openai_compatible", "base_url": fake_llm, "model": "fake-model-2", "profile_id": saved["active_id"]}).json()
    assert kept["key"]["set"] and kept["key"]["source"] == "saved" and S.get_llm().model == "fake-model-2"
    cleared = client.put("/api/llm", json={"provider": "openai_compatible", "base_url": fake_llm, "model": "fake-model-2", "clear_key": True, "profile_id": saved["active_id"]}).json()
    assert cleared["key"]["set"] is False
    assert len(cleared["profiles"]) == 1 and cleared["profiles"][0]["active"] and cleared["profiles"][0]["name"].endswith("fake-model-2")
    second = client.put("/api/llm", json={"provider": "ollama", "base_url": "http://127.0.0.1:9", "model": "m2", "name": "Local"}).json()
    assert [p["name"] for p in second["profiles"]][0] == "Local" and len(second["profiles"]) == 2 and second["active"]["model"] == "m2"
    assert client.put("/api/llm", json={"provider": "ollama", "model": "m3", "name": "Local"}).status_code == 400  # name already used
    back_to = client.post(f"/api/llm/profiles/{saved['active_id']}/activate").json()
    assert back_to["active"]["model"] == "fake-model-2" and S.get_llm().model == "fake-model-2"
    assert client.post("/api/llm/profiles/nope/activate").status_code == 404
    gone = client.delete(f"/api/llm/profiles/{saved['active_id']}").json()  # deleting the one in use falls back to config
    assert gone["source"] == "config" and len(gone["profiles"]) == 1 and S.get_llm() is None
    back = client.delete("/api/llm").json()
    assert back["source"] == "config" and S.get_llm() is None


def test_ai_discovery_is_an_error_without_a_working_model(client, llm_reset):
    aid = _aid(client, "bronze.ami_raw")
    r = client.post(f"/api/assets/{aid}/discover?use_llm=true", json={})
    assert r.status_code == 400 and "Settings > LLM" in r.json()["detail"]
    off = client.post(f"/api/assets/{aid}/discover?use_llm=false", json={}).json()
    dr = off["context"]["dry_runs"]
    assert off["candidates"] and dr["ran"] == len(off["candidates"]) and dr["platform"] == "duckdb" and dr["unavailable"] is None
    assert all(c.get("dry_run") for c in off["candidates"])  # every candidate was run on the platform
    client.put("/api/llm", json={"provider": "ollama", "base_url": "http://127.0.0.1:9", "model": "m"})
    down = client.post(f"/api/assets/{aid}/discover?use_llm=true", json={})
    assert down.status_code == 502 and "could not be reached" in down.json()["detail"]


def test_llm_settings_are_for_administrators(team, llm_reset):
    s = team["steward"]
    assert s.get("/api/llm").status_code == 200
    for call in (lambda: s.put("/api/llm", json={"provider": "rules"}), lambda: s.post("/api/llm/test", json={"provider": "rules"}), lambda: s.delete("/api/llm")):
        assert call().json()["code"] == "admin_only"
    assert team["admin"].put("/api/llm", json={"provider": "rules"}).status_code == 200


def test_secretbox_round_trip_and_unreadable_keys(seeded, monkeypatch):
    from dqga import secretbox
    monkeypatch.setenv("DQGA_SECRET_KEY", "one")
    token = secretbox.encrypt("sk-test-abcdef123456")
    assert "abcdef" not in token and secretbox.decrypt(token) == "sk-test-abcdef123456" and secretbox.hint("sk-test-abcdef123456") == "…3456"
    monkeypatch.setenv("DQGA_SECRET_KEY", "two")  # another installation's key can't open it
    assert secretbox.decrypt(token) is None


# ---------------------------------------------------------------------------- export of selected rules
def test_export_only_the_selected_rules(client, cleanup):
    a1, a2 = _aid(client, "bronze.ami_raw"), _aid(client, "silver.meters")
    r1 = _draft(client, a1, name="selected-one (export test)")
    r2 = client.post("/api/rules", json={"asset_id": a2, "type": "not_null", "column": "meter_id", "name": "selected-two (export test)"}).json()
    cleanup.extend([r1["id"], r2["id"]])
    one = client.get(f"/api/rules/export?rule_ids={r1['id']}&target=sql").json()
    assert one["rules"] == 1 and one["selected"] == 1 and "selected-one" in one["code"] and "selected-two" not in one["code"]  # drafts export when picked
    many = client.get(f"/api/rules/export?rule_ids={r1['id']},{r2['id']}&target=sql").json()
    assert many["multi"] is True and many["datasets"] == 2 and many["rules"] == 2
    z = client.get(f"/api/rules/export?rule_ids={r1['id']},{r2['id']}&target=sql&download=true")
    assert z.headers["content-type"] == "application/zip" and z.content[:2] == b"PK"
    bundle = client.get(f"/api/rules/export/bundle?rule_ids={r1['id']}&formats=sql,dqx")
    assert bundle.content[:2] == b"PK"
    assert client.get("/api/rules/export?rule_ids=abc&target=sql").status_code == 400
    assert client.get("/api/rules/export?target=sql").status_code == 400


# ---------------------------------------------------------------------------- grouping
def test_grouping_sources_and_locking(client, seeded, monkeypatch):
    from dqga import grouping as G
    from dqga.config import get_settings
    from dqga.db import session_scope
    from dqga.models import Asset
    s = get_settings()
    old = dict(s.data.get("grouping") or {})
    try:
        for src, expect in (("catalog", "utility"), ("schema", "silver"), ("connection", "demo"), ("owner", "grid-ops@x.com"), ("tag", "ops-tag")):
            s.data["grouping"] = {**old, "source": src, "tag": "domain"}
            assert G.derive("utility.silver.meters", "demo", "grid-ops@x.com", {"Domain": "ops-tag"}) == expect, src
        s.data["grouping"] = {**old, "source": "tag", "tag": "unit"}
        assert G.derive("a.b.c", "demo", None, {"domain": "no", "unit": "Retail"}) == "Retail" and G.derive("a.b.c", "demo", None, {}) is None
        assert G.derive("a.b.c", "demo", None, {}, reported="Ops") == "Ops"  # what a connector reports wins
        s.data["grouping"] = {**old, "label": "Business unit", "critical": ["Risk"], "financial": ["Treasury"], "hints": {"Retail": "refunds are not negative"}}
        assert G.public()["label"] == "Business unit" and G.is_critical("risk") and G.is_financial("TREASURY") and not G.is_critical("finance")
        assert G.hint_for("retail") == "refunds are not negative" and client.get("/api/meta").json()["grouping"]["label"] == "Business unit"
    finally:
        s.data["grouping"] = old

    # a typed value is locked; clearing hands the dataset back to the configured source
    aid = _aid(client, "silver.meters")
    with session_scope() as db:  # the demo's groups, restored at the end so other tests see them
        saved = {a.id: (a.domain, a.domain_locked) for a in db.query(Asset)}
        before = db.get(Asset, aid).domain
    assert client.patch(f"/api/assets/{aid}", json={"domain": "Custom group"}).json()["domain"] == "Custom group"
    with session_scope() as db:  # what a sync does to a dataset (no real sync: it would register tables other tests created)
        a = db.get(Asset, aid)
        G.apply_on_sync(a, None)
        assert a.domain == "Custom group" and a.domain_locked is True
        fresh = Asset(connection="demo", fqn="x.y.z", tags={"domain": "From tag"})  # new dataset: follows the configured source
        G.apply_on_sync(fresh, None)
        assert fresh.domain == "From tag" and fresh.domain_locked is False
        legacy = Asset(connection="demo", fqn="x.y.legacy", domain="Old value", tags={"domain": "Other"})  # from before locking existed
        G.apply_on_sync(legacy, None)
        assert legacy.domain == "Old value" and legacy.domain_locked is True
        db.rollback()
    s.data["grouping"] = {**old, "source": "schema"}
    try:
        assert client.patch(f"/api/assets/{aid}", json={"domain": " "}).json()["domain"] == "silver"
        res = client.post("/api/grouping/reapply").json()
        assert res["datasets"] >= 7 and client.get(f"/api/assets/{aid}").json()["domain"] == "silver"
        assert client.get("/api/grouping").json()["source"] == "schema"
    finally:
        s.data["grouping"] = old
        with session_scope() as db:
            for a in db.query(Asset):
                a.domain, a.domain_locked = saved[a.id]


def test_nothing_assumes_a_group_name_when_the_lists_are_empty(seeded):
    from dqga import grouping as G
    from dqga.config import get_settings
    s = get_settings()
    old = dict(s.data.get("grouping") or {})
    s.data["grouping"] = {"label": "Domain"}
    try:
        assert not G.is_critical("finance") and not G.is_financial("billing") and G.hint_for("metering") is None
    finally:
        s.data["grouping"] = old


# ---------------------------------------------------------------------------- allowed values keep no SQL-style quotes
def test_quoted_allowed_values_are_cleaned_for_checks_and_exports(client):
    from dqga.dq.exporters import FORMATS, export_with_report
    from dqga.dq.rules import fail_condition, validate_rule
    from dqga.connectors.base import SparkDialect
    cols = [{"name": "city", "type": "string", "family": "string"}]
    v = validate_rule({"type": "accepted_values", "column": "city", "params": {"values": ["'Austin'", '"Chicago"', "Seattle"]}}, cols)
    assert v["params"]["values"] == ["Austin", "Chicago", "Seattle"] and v["name"] == "city in ['Austin', 'Chicago', 'Seattle']"
    assert validate_rule({"type": "accepted_values", "column": "city", "params": {"values": "'A', 'B'"}}, cols)["params"]["values"] == ["A", "B"]

    class R:  # a rule saved before cleaning existed
        type, column, name, severity, threshold, dimension = "accepted_values", "city", "city in list", "medium", 1.0, "validity"
        params = {"values": ["'Austin'", "'Chicago'"]}
    assert "''Austin''" not in fail_condition(R, SparkDialect()) and "'Austin'" in fail_condition(R, SparkDialect())
    rep = export_with_report([R], "dqx", "cat.sch.customers", None)
    assert "allowed:\n    - Austin\n    - Chicago" in rep["code"].replace("      ", "    ") or "- Austin" in rep["code"]
    assert "\"'Austin'\"" not in rep["code"] and set(FORMATS) >= {"dqx"}


# ---------------------------------------------------------------------------- platform filter on Monitor pages
def test_insights_and_anomalies_follow_the_platform(client):
    full, duck, none = (client.get(f"/api/insights?days=30{q}").json() for q in ("", "&platform=duckdb", "&platform=snowflake"))
    assert duck["totals"] == full["totals"] and duck["totals"]["checks"] > 0
    assert none["totals"] == {"failures": 0, "checks": 0, "incidents": 0} and none["recurring"] == [] and none["hotspots"] == []
    a_full, a_duck, a_none = (client.get(f"/api/anomalies?days=30{q}").json() for q in ("", "&platform=duckdb", "&platform=snowflake"))
    assert a_duck["summary"]["datasets"] == a_full["summary"]["datasets"] > 0
    assert a_none["summary"]["datasets"] == 0 and a_none["items"] == [] and a_none["unmonitored"] == []
    assert client.get("/api/incidents?status=all&platform=snowflake").json() == []


def test_load_demo_button_refuses_a_second_load(client):
    assert client.get("/api/admin/maintenance").json()["demo_loaded"] is True
    r = client.post("/api/admin/demo/load")
    assert r.status_code == 409 and "already loaded" in r.json()["detail"]


def test_list_style_model_replies_are_read(client, fake_llm, llm_reset):
    """Reasoning models return the reply as a list of blocks; the connection test must not crash on that."""
    from dqga.llm import content_text
    assert content_text([{"type": "reasoning", "text": "thinking"}, {"type": "text", "text": "OK"}]) == "OK"
    assert content_text(None) == "" and content_text("plain") == "plain"


# ---------------------------------------------------------------------------- fixes and quarantine are switched off by default
def test_fixes_and_quarantine_can_be_switched_off(client, monkeypatch):
    from dqga.config import get_settings
    s = get_settings()
    old = dict(s.data.get("features") or {})
    s.data["features"] = {"fixes_and_quarantine": False}
    try:
        assert client.get("/api/meta").json()["features"] == {"fixes_and_quarantine": False, "git_sync": False}
        for path in ("/api/fixes", "/api/quarantine", "/api/quarantine/plan", "/api/incidents/1/fixes"):
            r = client.get(path) if path != "/api/quarantine/plan" else client.post(path, json={})
            assert r.status_code == 404 and r.json()["code"] == "feature_off", path
        assert client.post("/api/fixes/apply", json={"fix_id": "x:1"}).status_code == 404
        # nothing offers it: the agent has no tools or answers for it, incidents suggest no quarantine, nothing auto-corrects
        from dqga.agent import agent as A
        assert A.HIDDEN_TOOLS() == {"suggest_corrections", "quarantine_status"}
        from dqga.db import get_session
        from dqga.incidents import autofix
        from dqga.incidents.remediation import suggestions_for_incident
        from dqga.models import Asset, Incident
        db = get_session()
        try:
            assert autofix.auto_correct(db, db.query(Asset).first(), [1], []) == []
            for inc in db.query(Incident).all():
                assert all(x.get("kind") != "quarantine" for x in suggestions_for_incident(db, inc))
            r = A.chat(db, "no-fixes", "what is in quarantine?", {}, "tester")
            assert "Fixes and quarantine" not in r["answer"] and not any(t["tool"] == "quarantine_status" for t in r["trace"])
        finally:
            db.close()
        from dqga import ai_insights as AI
        db = get_session()
        try:
            kinds = {f["type"] for f in AI.build_facts(db)}
            assert not kinds & {"corrections", "quarantine"}
        finally:
            db.close()
    finally:
        s.data["features"] = old
    assert client.get("/api/fixes").status_code == 200  # on again, as the shared tests have it
