"""Unit tests that need no warehouse."""
from datetime import datetime, timedelta

import pytest

from dqga.connectors.base import DuckDBDialect, SnowflakeDialect, SparkDialect, UnsafeSQLError, lit, safe_expression, type_family
from dqga.dq import anomaly, timeseries
from dqga.dq.rules import fail_condition, validate_rule
from dqga.dq.suggester import parse_nl_rule
from dqga.governance.classification import classify_column, luhn_ok

COLS = [{"name": "kwh", "data_type": "DOUBLE", "family": "numeric"},
        {"name": "meter_id", "data_type": "VARCHAR", "family": "string"},
        {"name": "reading_ts", "data_type": "TIMESTAMP", "family": "temporal"},
        {"name": "customer_id", "data_type": "INTEGER", "family": "numeric"},
        {"name": "email", "data_type": "VARCHAR", "family": "string"},
        {"name": "status", "data_type": "VARCHAR", "family": "string"}]


class R:
    def __init__(self, **kw):
        self.__dict__.update({"column": None, "params": {}, **kw})


def test_literal_and_identifier_safety():
    assert lit("O'Brien") == "'O''Brien'"
    assert lit(3) == "3" and lit(None) == "NULL"
    with pytest.raises(UnsafeSQLError):
        DuckDBDialect().q("kwh; DROP TABLE x")
    with pytest.raises(UnsafeSQLError):
        safe_expression("1=1; delete from t")
    with pytest.raises(UnsafeSQLError):
        safe_expression("amount > 0 -- comment")
    assert safe_expression("end_ts >= start_ts") == "end_ts >= start_ts"


def test_type_family():
    assert type_family("DECIMAL(10,2)") == "numeric"
    assert type_family("timestamp_ntz") == "temporal"
    assert type_family("array<string>") == "complex"
    assert type_family("STRING") == "string"


def test_validate_rule_normalizes_and_rejects():
    r = validate_rule({"type": "not_null", "column": "KWH"}, COLS)
    assert r["column"] == "kwh" and r["dimension"] == "completeness" and r["threshold"] == 1.0
    with pytest.raises(ValueError):
        validate_rule({"type": "not_null", "column": "nope"}, COLS)
    with pytest.raises(ValueError):
        validate_rule({"type": "range", "column": "kwh"}, COLS)
    with pytest.raises(ValueError):
        validate_rule({"type": "custom_sql", "params": {"expression": "1=1; drop table t"}}, COLS)


def test_fail_conditions_per_dialect():
    rule = R(type="regex", column="meter_id", params={"pattern": "MTR-[0-9]{6}"})
    assert "regexp_full_match" in fail_condition(rule, DuckDBDialect())
    assert "RLIKE" in fail_condition(rule, SparkDialect()) and "`meter_id`" in fail_condition(rule, SparkDialect())
    assert "REGEXP_LIKE" in fail_condition(rule, SnowflakeDialect())
    rng = R(type="range", column="kwh", params={"min": 0, "max": 50})
    assert fail_condition(rng, DuckDBDialect()) == '"kwh" IS NOT NULL AND ("kwh" < 0 OR "kwh" > 50)'


@pytest.mark.parametrize("text,expected", [
    ("kwh must be between 0 and 500", ("range", "kwh")),
    ("meter_id must be unique", ("unique", None)),
    ("kwh cannot be null", ("not_null", "kwh")),
    ("reading_ts must not be in the future", ("not_future", "reading_ts")),
    ("status must be one of active, inactive", ("accepted_values", "status")),
    ("email must be a valid email", ("regex", "email")),
    ("customer_id must exist in utility.silver.customers.customer_id", ("referential", "customer_id")),
    ("table must be refreshed every 6 hours", ("freshness", "reading_ts")),
    ("kwh must be positive", ("custom_sql", None)),
])
def test_nl_patterns(text, expected):
    r = parse_nl_rule(text, COLS)
    assert r is not None, text
    assert r["type"] == expected[0]
    if expected[1]:
        assert r["column"] == expected[1]
    validate_rule(r, COLS)


def test_anomaly_detects_drop_with_weekly_seasonality():
    now = datetime(2026, 11, 16, 8)
    hist = [(now - timedelta(days=d), 1000 * (1.05 if (now - timedelta(days=d)).weekday() < 5 else 0.9)) for d in range(28, 0, -1)]
    assert anomaly.detect(hist, 1040, now)["is_anomaly"] is False
    res = anomaly.detect(hist, 830, now)
    assert res["is_anomaly"] is True and res["mode"] == "weekly"
    assert anomaly.detect(hist[:3], 830, now)["status"] == "insufficient"


def test_psi():
    assert anomaly.psi({"a": 50, "b": 50}, {"a": 50, "b": 50}) == pytest.approx(0)
    assert anomaly.psi({"a": 90, "b": 10}, {"a": 10, "b": 90}) > 0.2


def test_timeseries_checks():
    t0 = datetime(2026, 1, 1)
    pts = [(t0 + timedelta(minutes=5 * i), 50 + (i % 7) * 0.3) for i in range(300)]
    assert timeseries.gaps(pts)["failed"] == 0
    gappy = pts[:100] + pts[140:]
    assert timeseries.gaps(gappy, expected_interval_s=300)["failed"] == 1
    flat = pts[:100] + [(t0 + timedelta(minutes=5 * i), 71.4) for i in range(100, 200)]
    assert timeseries.flatline(flat, flatline_s=6 * 3600)["failed"] == 1
    spiky = list(pts)
    spiky[150] = (spiky[150][0], 640.0)
    assert timeseries.spikes(spiky, spike_z=8)["failed"] >= 1
    assert timeseries.bounds(spiky, min=-40, max=150)["failed"] == 1
    assert timeseries.monotonic(pts + [pts[10]])["failed"] == 1


def test_classification():
    assert luhn_ok("4111 1111 1111 1111") and not luhn_ok("4111 1111 1111 1112")
    assert classify_column("contact", "string", ["a.b@x.com", "c@d.org", "e@f.net"])["label"] == "email"
    assert classify_column("email_address", "string", ["a.b@x.com"] * 10)["method"] == "name+value"
    assert classify_column("card", "string", ["4111111111111111", "5500005555555559"])["label"] == "credit_card"
    assert classify_column("meter_id", "string", ["MTR-000001", "MTR-000002"]) is None
    assert classify_column("account_ref", "string", ["123456789012"] * 5) is None or \
        classify_column("account_ref", "string", ["123456789012"] * 5)["label"] != "phone"
