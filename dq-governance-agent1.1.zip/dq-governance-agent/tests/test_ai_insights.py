"""AI-written Patterns and Insights: facts are computed in code, the model only writes them up, and its answer is checked."""
import json

import pytest
from fastapi.testclient import TestClient

from dqga import ai_insights as AI
from dqga import services as S


@pytest.fixture(scope="module")
def client(seeded):
    from dqga.api.main import create_app
    return TestClient(create_app(bootstrap=False))


class Stub:
    """A model stand-in: writes one good insight per recurring source, plus items the checker must drop."""
    calls = 0

    def __init__(self, bad=True):
        self.bad = bad

    def describe(self):
        return {"provider": "stub", "model": "stub-1"}

    def complete_json(self, system, prompt):
        Stub.calls += 1
        facts = json.loads(prompt)["facts"]
        period = facts[0]
        rec = [f for f in facts if f["type"] == "recurring_incidents"]
        d = rec[0]["data"] if rec else {"dataset": "x", "incidents": 0}
        out = {"insights": [{"text": f"{d['dataset']} had {d['incidents']} incidents in {period['data']['days']} days.", "facts": [rec[0]["id"] if rec else period["id"]], "severity": "high"}],
               "learnings": [], "recommendations": []}
        if rec:
            out["recommendations"].append({"text": f"Add a freshness check on {d['dataset']}.", "facts": [rec[0]["id"]],
                                           "action": {"type": "dataset", "dataset": d["dataset"]}})
        if self.bad:
            out["insights"] += [{"text": "Failures doubled to 999 this week.", "facts": [period["id"]], "severity": "high"},   # invented number
                                {"text": "Something is wrong somewhere.", "facts": [], "severity": "low"},                          # cites nothing
                                {"text": "Cites a fact that does not exist.", "facts": ["F999"], "severity": "low"}]
            out["recommendations"].append({"text": "Look at the nowhere table.", "facts": [period["id"]], "action": {"type": "dataset", "dataset": "no.such.table"}})
        return out


@pytest.fixture()
def model(db):
    from dqga.models import AppSetting
    Stub.calls = 0
    S._llm = Stub()
    db.query(AppSetting).filter(AppSetting.key.like(AI.KEY_PREFIX + "%")).delete(synchronize_session=False)
    db.commit()
    yield
    S.reset_llm()
    db.rollback()
    db.query(AppSetting).filter(AppSetting.key.like(AI.KEY_PREFIX + "%")).delete(synchronize_session=False)
    db.commit()


def test_facts_are_numbered_stable_and_scoped(db):
    a, b = AI.build_facts(db), AI.build_facts(db)
    assert a == b and a[0]["type"] == "period" and [f["id"] for f in a] == [f"F{i}" for i in range(1, len(a) + 1)]
    assert any(f["type"] == "recurring_incidents" for f in a)
    text = json.dumps(a)
    assert "@" not in text.replace("example", "")  # no personal data: names, counts and causes only
    assert AI.fingerprint(a, "all") == AI.fingerprint(b, "all") and AI.fingerprint(a, "all") != AI.fingerprint(a, "duckdb")
    assert AI.build_facts(db, platform="snowflake")[0]["data"]["checks"] == 0


def test_validation_drops_what_cannot_be_checked(db):
    facts = AI.build_facts(db)
    rec = next(f for f in facts if f["type"] == "recurring_incidents")["data"]
    p = facts[0]
    good = {"text": f"{rec['dataset']} had {rec['incidents']} incidents.", "facts": [facts[1]["id"]]}
    answer = {"insights": [good, {"text": "Made up 12345.", "facts": [p["id"]]}, {"text": "No citation.", "facts": []}, {"text": "x" * 400, "facts": [p["id"]]}],
              "recommendations": [{"text": "Open it.", "facts": [p["id"]], "action": {"type": "dataset", "dataset": "not.a.dataset"}},
                                  {"text": "Review rules.", "facts": [p["id"]], "action": {"type": "bogus"}}],
              "learnings": "not a list"}
    clean, dropped = AI.validate(answer, facts)
    assert [i["text"] for i in clean["insights"]] == [good["text"]] and dropped == 3
    assert [r["action"] for r in clean["recommendations"]] == [{"type": "none", "dataset": None}] * 2  # an unknown dataset or action never links anywhere
    assert clean["learnings"] == [] and AI.validate("garbage", facts)[0]["insights"] == []
    many = {"insights": [{"text": f"Note {chr(97 + i)}.", "facts": [p["id"]]} for i in range(20)]}
    assert len(AI.validate(many, facts)[0]["insights"]) == AI.LIMITS["insights"]


def test_same_facts_reuse_the_saved_text_and_changed_facts_do_not(db, model, monkeypatch):
    first = AI.generate(db, S.get_llm(), "tester")
    assert Stub.calls == 1 and first["reused"] is False and first["model"] == "stub-1" and first["dropped"] == 3 and first["insights"][0]["severity"] == "high"
    again = AI.generate(db, S.get_llm(), "tester")
    assert Stub.calls == 1 and again["reused"] is True and again["insights"] == first["insights"]
    S._llm = Stub(bad=False)  # a different model, same facts: the page text does not change
    assert AI.generate(db, S.get_llm(), "tester")["insights"] == first["insights"] and Stub.calls == 1
    assert AI.generate(db, S.get_llm(), "tester", force=True)["reused"] is False and Stub.calls == 2
    assert AI.state(db)["fresh"] is True
    real = AI.build_facts
    monkeypatch.setattr(AI, "build_facts", lambda *a, **k: real(*a, **k) + [{"id": "F99", "type": "period", "data": {"days": 30}}])
    assert AI.state(db)["fresh"] is False  # new facts: the page says so


def test_no_model_is_an_error_not_a_guess(db):
    S.reset_llm()
    with pytest.raises(AI.AIInsightsError, match="Settings > LLM"):
        AI.generate(db, None, "tester")


def test_endpoints(client, model):
    st = client.get("/api/ai-insights").json()
    assert st["report"] is None and st["fresh"] is False and st["configured"] and st["model"]["model"] == "stub-1"
    r = client.post("/api/ai-insights/generate", json={}).json()
    assert r["insights"] and r["reused"] is False
    link = next(x for x in r["recommendations"] if x["action"]["type"] == "dataset")["href"]
    assert link.startswith("#/asset/") and all(x["href"] is None for x in r["recommendations"] if x["action"]["type"] == "none")
    after = client.get("/api/ai-insights").json()
    assert after["fresh"] is True and after["report"]["generated_by"] and Stub.calls == 1
    assert client.post("/api/ai-insights/generate", json={}).json()["reused"] is True and Stub.calls == 1
    # a platform view has its own saved text
    assert client.get("/api/ai-insights?platform=duckdb").json()["report"] is None
    S.reset_llm()
    none = client.post("/api/ai-insights/generate", json={"platform": "duckdb"})
    assert none.status_code == 400 and "Settings > LLM" in none.json()["detail"]
    assert client.get("/api/ai-insights").json()["configured"] is False
