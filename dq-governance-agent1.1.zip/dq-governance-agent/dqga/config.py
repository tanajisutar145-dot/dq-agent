"""Settings: config.yaml merged over defaults, with environment overrides.

Where values come from (highest wins):
  1. Real environment variables (e.g. set by Databricks Apps from app.yaml)
  2. A `.env` file (never overrides 1). Looked up at $DQGA_ENV_FILE, ./.env, the
     project root, then next to the config file. DQGA_ENV_FILE=none disables it.
  3. config.yaml, where any string can reference variables: ${VAR} or ${VAR:-default}
  4. Built-in defaults

Also:
- `foo_env: SOME_VAR` on any key: `resolve_env(cfg, "foo")` reads that variable (secrets).
- `DQGA__SECTION__KEY=value` overrides any setting, e.g. DQGA__SCHEDULER__ENABLED=false.
- Shortcuts: DQGA_CONFIG, DQGA_DATABASE_URL, DQGA_LLM_PROVIDER, DQGA_LLM_MODEL, DQGA_LLM_BASE_URL.
"""
from __future__ import annotations

import copy
import json
import os
import re
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parent.parent
APP_NAME = "TCS DataTrustAI"

_dotenv_state: dict[str, Any] = {"files": [], "keys": []}
_VAR_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")
_KEY_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def parse_dotenv(text: str) -> dict[str, str]:
    """Parse KEY=VALUE lines: comments, `export` prefix, single/double quotes, inline ` #` comments."""
    out: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, val = line.split("=", 1)
        key, val = key.strip(), val.strip()
        if not _KEY_RE.fullmatch(key):
            continue
        if val[:1] in ("'", '"'):
            q = val[0]
            end = val.find(q, 1)
            val = val[1:end] if end != -1 else val[1:]
            if q == '"':
                val = val.replace("\\n", "\n")
        elif " #" in val:
            val = val.split(" #", 1)[0].rstrip()
        out[key] = val
    return out


def load_dotenv(path: str | Path, override: bool = False) -> dict[str, str]:
    """Load a .env file into os.environ. Existing variables win unless override=True; empty values are skipped."""
    p = Path(path)
    if not p.is_file():
        return {}
    loaded = {}
    for k, v in parse_dotenv(p.read_text(encoding="utf-8-sig")).items():
        if v == "":
            continue
        if override or k not in os.environ:
            os.environ[k] = v
            loaded[k] = v
    if str(p) not in _dotenv_state["files"]:
        _dotenv_state["files"].append(str(p))
    _dotenv_state["keys"] = sorted(set(_dotenv_state["keys"]) | set(loaded))
    return loaded


def dotenv_info() -> dict:
    return {"files": list(_dotenv_state["files"]), "keys": list(_dotenv_state["keys"])}


def _coerce(v: str) -> Any:
    s = v.strip()
    if s.lower() in ("true", "false"):
        return s.lower() == "true"
    if re.fullmatch(r"-?\d+", s):
        return int(s)
    if re.fullmatch(r"-?\d+\.\d*", s):
        return float(s)
    if s[:1] in "[{":
        try:
            return json.loads(s)
        except ValueError:
            return v
    return v


def interpolate(obj: Any) -> Any:
    """Replace ${VAR} / ${VAR:-default} in strings. A value that is only a reference is type-coerced."""
    if isinstance(obj, str):
        sub = _VAR_RE.sub(lambda m: os.environ.get(m.group(1)) or (m.group(2) or ""), obj)
        return _coerce(sub) if _VAR_RE.fullmatch(obj.strip()) else sub
    if isinstance(obj, dict):
        return {k: interpolate(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [interpolate(v) for v in obj]
    return obj


def apply_env_overrides(data: dict) -> dict:
    """DQGA__SECTION__KEY=value -> data[section][key] = value (type-coerced)."""
    for k, v in sorted(os.environ.items()):
        if not k.startswith("DQGA__"):
            continue
        path = [p.lower() for p in k[6:].split("__") if p]
        if not path:
            continue
        cur = data
        for p in path[:-1]:
            if not isinstance(cur.get(p), dict):
                cur[p] = {}
            cur = cur[p]
        cur[path[-1]] = _coerce(v)
    return data


def _load_env_files(config_path: Path | None, env_file: str | Path | None) -> None:
    choice = env_file or os.environ.get("DQGA_ENV_FILE")
    if str(choice).lower() == "none":
        return
    if choice:
        load_dotenv(choice)
        return
    for c in (Path.cwd() / ".env", ROOT / ".env", (config_path.parent / ".env") if config_path else None):
        if c and c.is_file():
            load_dotenv(c)

DEFAULTS: dict[str, Any] = {
    "app": {
        "name": APP_NAME,
        "database_url": "sqlite:///data/dqga.db",
        "quarantine_schema": "dq_quarantine",
        "actor": "steward",
    },
    "llm": {
        "provider": "rules",  # rules | ollama | anthropic | anthropic_bedrock | openai_compatible
        "model": "qwen2.5:7b",
        "base_url": "http://localhost:11434",
        "api_key_env": None,
        "max_steps": 8,
        "timeout_s": 120,
    },
    "features": {  # parts of the product that are switched off for now
        "fixes_and_quarantine": False,  # corrections, auto-correct and quarantine of bad rows
        "git_sync": False,  # export rule files to a GitHub repository (Settings > Git)
    },
    "grouping": {  # how datasets are grouped; see dqga/grouping.py
        "label": "Domain",
        "source": "tag",
        "tag": "domain",
        "critical": [],
        "financial": [],
        "hints": {},
    },
    "connections": [],
    "scheduler": {
        "enabled": False,
        "tick_seconds": 300,
        "daily_budget_seconds": 3600,
        "change_aware": True,
        "default_interval_minutes": 60,
    },
    "notifications": {
        "min_severity": "high",
        "slack_webhook_env": "DQ_SLACK_WEBHOOK",
        "teams_webhook_env": "DQ_TEAMS_WEBHOOK",
        "smtp": None,
    },
    "ticketing": {"provider": "none"},
    "remediation": {
        "auto_enabled": False,
        "allowed_auto_actions": ["quarantine"],
        "max_rows_auto": 10000,
        "auto_correct_low_risk": False,   # apply low-risk corrections automatically after a failed check
        "auto_correct_max_rows": 1000,
        "quarantine_retention_days": 30,
    },
    "governance": {"policies_file": "policies.yaml", "neo4j": None},
    "auth": {
        "mode": "local",            # local | sso | none
        "signup": "approval",       # approval | open | disabled
        "default_role": "steward",  # role for new sign-ups and SSO users
        "session_hours": 12,
        "max_failed_logins": 5,
        "lockout_minutes": 15,
        "min_password_length": 10,
        "admins": [],               # sso mode: emails that become administrators
    },
    "profiling": {"sample_rows": 500, "max_top_value_columns": 15, "column_batch": 20},
    "timeseries": {"max_rows": 200000},
}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def resolve_env(cfg: dict, key: str, default: Any = None) -> Any:
    """Return cfg[key], or the value of the env var named by cfg[key + '_env']."""
    if cfg is None:
        return default
    val = cfg.get(key)
    if val not in (None, ""):
        return val
    env_name = cfg.get(f"{key}_env")
    if env_name:
        return os.environ.get(env_name, default)
    return default


def feature_on(name: str) -> bool:
    """Whether an optional part of the product is switched on (config.yaml `features:`)."""
    try:
        return bool((get_settings().section("features") or {}).get(name))
    except Exception:
        return False


class Settings:
    def __init__(self, data: dict, path: Path | None):
        self.data = data
        self.path = path
        self.root = path.parent if path else ROOT

    def __getitem__(self, key: str) -> Any:
        return self.data[key]

    def section(self, key: str) -> dict:
        return self.data.get(key) or {}

    def abspath(self, p: str | Path) -> Path:
        p = Path(p)
        return p if p.is_absolute() else (self.root / p)


def load_settings(path: str | Path | None = None, env_file: str | Path | None = None) -> Settings:
    _load_env_files(None, env_file)  # first, so DQGA_CONFIG may come from .env
    path = Path(path or os.environ.get("DQGA_CONFIG") or ROOT / "config.yaml")
    if not env_file and str(os.environ.get("DQGA_ENV_FILE", "")).lower() != "none":
        load_dotenv(path.parent / ".env")
    raw: dict = {}
    if path.exists():
        raw = interpolate(yaml.safe_load(path.read_text(encoding="utf-8")) or {})
    data = apply_env_overrides(_merge(DEFAULTS, raw))
    env_map = {
        "DQGA_DATABASE_URL": ("app", "database_url"),
        "DQGA_LLM_PROVIDER": ("llm", "provider"),
        "DQGA_LLM_MODEL": ("llm", "model"),
        "DQGA_LLM_BASE_URL": ("llm", "base_url"),
    }
    for env, (sec, key) in env_map.items():
        if os.environ.get(env):
            data[sec][key] = os.environ[env]
    return Settings(data, path if path.exists() else None)


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = load_settings()
    return _settings


def set_settings(s: Settings) -> None:
    global _settings
    _settings = s
