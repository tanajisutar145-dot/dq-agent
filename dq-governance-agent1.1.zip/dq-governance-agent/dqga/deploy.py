"""Deployment targets and app packaging.

Targets live in `dqga/deploy_targets.yaml`; the Deploy page is generated from it,
so new platforms are added there without code changes. Every target with
`package: true` offers the same app package: code, configs, Dockerfile and docs,
never `.env`, local data, the venv or tests.
"""
from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path

import yaml

from .config import ROOT

TARGETS_FILE = Path(__file__).resolve().parent / "deploy_targets.yaml"
PACKAGE_DIRS = ["dqga", "docs", "deploy"]
PACKAGE_FILES = ["app.yaml", "databricks.yml", "config.databricks.yaml", "config.yaml", "policies.yaml",
                 "requirements.txt", "README.md", "pyproject.toml", ".env.example", "Dockerfile", ".dockerignore"]
EXCLUDE_PARTS = {"__pycache__", ".pytest_cache", ".venv", "data", "tests", "dist"}
EXCLUDE_NAMES = {".env"}
REQUIRED = ("id", "label", "group", "summary", "steps")


def package_files(root: Path = ROOT) -> list[Path]:
    files = []
    for d in PACKAGE_DIRS:
        for p in sorted((root / d).rglob("*")):
            if p.is_file() and not (set(p.relative_to(root).parts) & EXCLUDE_PARTS) and p.name not in EXCLUDE_NAMES \
                    and p.suffix not in (".pyc", ".pyo"):
                files.append(p)
    files += [root / f for f in PACKAGE_FILES if (root / f).is_file()]
    return files


def build_app_package(root: Path = ROOT, folder: str = "tcs-datatrustai") -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in package_files(root):
            z.write(p, f"{folder}/{p.relative_to(root).as_posix()}")
    return buf.getvalue()


def load_targets(path: Path = TARGETS_FILE) -> list[dict]:
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    targets, seen = [], set()
    for t in data.get("targets", []):
        missing = [k for k in REQUIRED if not t.get(k)]
        if missing:
            raise ValueError(f"Deploy target {t.get('id', '?')} is missing {missing}")
        if not re.fullmatch(r"[a-z0-9_]+", t["id"]) or t["id"] in seen:
            raise ValueError(f"Deploy target id {t['id']!r} must be unique, lowercase letters, digits or _")
        seen.add(t["id"])
        targets.append(t)
    return targets


def targets_view(runtime: dict, root: Path = ROOT) -> dict:
    """Targets with file previews and a `current` flag for the runtime this instance runs on."""
    out = []
    n_files = len(package_files(root))
    for t in load_targets():
        files = []
        for name in t.get("files", []) or []:
            p = root / name
            if p.is_file():
                files.append({"name": name, "content": p.read_text(encoding="utf-8")})
        out.append({**t, "files": files, "current": t.get("runtime") == runtime.get("platform"),
                    "package_files": n_files if t.get("package") else 0})
    default = next((t["id"] for t in out if t["current"] and t.get("runtime") != "local"), None) \
        or next((t["id"] for t in out if t.get("default")), out[0]["id"] if out else None)
    return {"targets": out, "default": default, "runtime": runtime}
