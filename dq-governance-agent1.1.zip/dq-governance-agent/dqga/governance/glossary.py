"""Business glossary graph: term -> asset / column / rule, plus owners and lineage.

Stored relationally; optionally mirrored to Neo4j for graph exploration
alongside an existing knowledge graph.
"""
from __future__ import annotations

from sqlalchemy import select

from ..config import get_settings, resolve_env
from ..models import Asset, GlossaryLink, GlossaryTerm, LineageEdge, Rule


def find_terms(db, text: str) -> list[GlossaryTerm]:
    t = (text or "").lower()
    out = []
    for term in db.scalars(select(GlossaryTerm)):
        names = [term.name.lower()] + [s.lower() for s in term.synonyms or []]
        if any(n in t or t in n for n in names if n):
            out.append(term)
    return out


def term_detail(db, term: GlossaryTerm) -> dict:
    links = db.scalars(select(GlossaryLink).where(GlossaryLink.term_id == term.id)).all()
    return {**term.to_dict(), "links": [{"type": l.target_type, "ref": l.target_ref} for l in links]}


def graph(db) -> dict:
    nodes, edges = {}, []
    for t in db.scalars(select(GlossaryTerm)):
        nodes[f"term:{t.id}"] = {"id": f"term:{t.id}", "label": t.name, "type": "term"}
    for l in db.scalars(select(GlossaryLink)):
        tgt = f"{l.target_type}:{l.target_ref}"
        nodes.setdefault(tgt, {"id": tgt, "label": l.target_ref.split(".")[-1], "type": l.target_type})
        edges.append({"source": f"term:{l.term_id}", "target": tgt, "type": "describes"})
    for a in db.scalars(select(Asset)):
        key = f"asset:{a.fqn}"
        if key in nodes and a.owner:
            okey = f"owner:{a.owner}"
            nodes.setdefault(okey, {"id": okey, "label": a.owner, "type": "owner"})
            edges.append({"source": okey, "target": key, "type": "owns"})
    return {"nodes": list(nodes.values()), "edges": edges}


def sync_neo4j(db) -> dict:
    cfg = get_settings().section("governance").get("neo4j") or {}
    uri = resolve_env(cfg, "uri")
    if not uri:
        return {"status": "skipped", "note": "Set governance.neo4j.uri (or uri_env) in config.yaml"}
    from neo4j import GraphDatabase

    driver = GraphDatabase.driver(uri, auth=(resolve_env(cfg, "user") or "neo4j", resolve_env(cfg, "password")))
    database = cfg.get("database")
    counts = {"terms": 0, "assets": 0, "rules": 0, "lineage": 0}
    with driver.session(database=database) as s:
        for a in db.scalars(select(Asset)):
            s.run("MERGE (a:DataAsset {fqn:$fqn}) SET a.platform=$p, a.domain=$d, a.score=$s, a.owner=$o, a.certified=$c",
                  fqn=a.fqn, p=a.platform, d=a.domain, s=a.score, o=a.owner, c=a.certified)
            if a.owner:
                s.run("MERGE (o:Person {name:$o}) WITH o MATCH (a:DataAsset {fqn:$fqn}) MERGE (o)-[:OWNS]->(a)", o=a.owner, fqn=a.fqn)
            counts["assets"] += 1
        for r in db.scalars(select(Rule).where(Rule.status == "active")):
            a = db.get(Asset, r.asset_id)
            s.run("MERGE (r:DQRule {id:$id}) SET r.name=$n, r.type=$t, r.dimension=$dim, r.status=$st "
                  "WITH r MATCH (a:DataAsset {fqn:$fqn}) MERGE (r)-[:CHECKS]->(a)",
                  id=r.id, n=r.name, t=r.type, dim=r.dimension, st=r.last_status, fqn=a.fqn)
            counts["rules"] += 1
        for e in db.scalars(select(LineageEdge).where(LineageEdge.source_column == "")):
            s.run("MERGE (x:DataAsset {fqn:$a}) MERGE (y:DataAsset {fqn:$b}) MERGE (x)-[:FEEDS]->(y)", a=e.source, b=e.target)
            counts["lineage"] += 1
        for t in db.scalars(select(GlossaryTerm)):
            s.run("MERGE (t:BusinessTerm {name:$n}) SET t.definition=$d, t.domain=$dom", n=t.name, d=t.definition, dom=t.domain)
            for l in db.scalars(select(GlossaryLink).where(GlossaryLink.term_id == t.id, GlossaryLink.target_type == "asset")):
                s.run("MATCH (t:BusinessTerm {name:$n}) MERGE (a:DataAsset {fqn:$fqn}) MERGE (t)-[:DESCRIBES]->(a)",
                      n=t.name, fqn=l.target_ref)
            counts["terms"] += 1
    driver.close()
    return {"status": "synced", **counts}
