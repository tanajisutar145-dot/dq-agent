"""Policy scans: evaluate every enabled policy, keep the result, and track what is new or resolved between scans.

A scan reads what the app already knows (metadata, scores, rules, contracts, sensitive-column detection); it does not
query your data. It is a real step with a saved result, so violations have a "last scanned" time, a history and a trend,
and can run on a schedule.
"""
from __future__ import annotations

import time
from collections import Counter
from datetime import datetime

from sqlalchemy import delete, select

from ..dq import schedules as SCH
from ..models import Asset, AppSetting, Policy, PolicyScan, RuleSchedule, audit, utcnow
from . import policies as P

KEEP_SCANS = 100
MAX_STORED = 3000
SCHEDULE_KEY = "policy_scan_schedule"


def latest(db) -> PolicyScan | None:
    return db.scalars(select(PolicyScan).order_by(PolicyScan.ts.desc(), PolicyScan.id.desc()).limit(1)).first()


def _key(v: dict) -> str:
    return f"{v['policy']}|{v['asset_id']}|{v.get('column') or ''}|{v['message']}"


def run_scan(db, actor: str, trigger: str = "manual") -> PolicyScan:
    t0 = time.perf_counter()
    prev = latest(db)
    assets = {a.id: a for a in db.scalars(select(Asset))}
    items = []
    for v in P.evaluate(db):
        a = assets.get(v["asset_id"])
        items.append({**v, "platform": a.platform if a else None, "key": _key(v)})
    prev_keys = {x["key"] for x in (prev.violations or [])} if prev else set()
    cur = {x["key"] for x in items}
    for x in items:
        x["new"] = bool(prev) and x["key"] not in prev_keys  # the first scan has nothing to compare with
    sev = Counter(x["severity"] for x in items)
    pol = Counter(x["policy"] for x in items)
    row = PolicyScan(ts=utcnow(), trigger=trigger, actor=actor, duration_s=round(time.perf_counter() - t0, 3), total=len(items),
                     new_count=sum(1 for x in items if x["new"]), resolved_count=len(prev_keys - cur) if prev else 0,
                     policies=len(db.scalars(select(Policy.id).where(Policy.enabled.is_(True))).all()), datasets=len(assets),
                     by_severity=dict(sev), by_policy=dict(pol), violations=items[:MAX_STORED])
    db.add(row)
    db.flush()
    old = db.scalars(select(PolicyScan.id).order_by(PolicyScan.ts.desc(), PolicyScan.id.desc()).offset(KEEP_SCANS)).all()
    if old:
        db.execute(delete(PolicyScan).where(PolicyScan.id.in_(old)))
    audit(db, actor, "policy.scanned", trigger, total=row.total, new=row.new_count, resolved=row.resolved_count)
    db.flush()
    return row


def view(row: PolicyScan | None, with_violations: bool = True) -> dict | None:
    if row is None:
        return None
    d = {k: getattr(row, k) for k in ("id", "trigger", "actor", "duration_s", "total", "new_count", "resolved_count", "policies", "datasets", "by_severity", "by_policy")}
    d["ts"] = row.ts.isoformat(timespec="seconds")
    if with_violations:
        d["violations"] = row.violations or []
    return d


def history(db, limit: int = 30) -> list[dict]:
    rows = db.scalars(select(PolicyScan).order_by(PolicyScan.ts.desc(), PolicyScan.id.desc()).limit(max(1, min(limit, KEEP_SCANS)))).all()
    return [view(r, False) for r in rows]


# ------------------------------------------------------------------ schedule
def _sched_obj(cfg: dict) -> RuleSchedule:
    return RuleSchedule(name="Policy scan", cadence=cfg.get("cadence", "interval"), every_minutes=cfg.get("every_minutes"), at_time=cfg.get("at_time"),
                        weekdays=cfg.get("weekdays") or [], enabled=bool(cfg.get("enabled")))


def get_schedule(db, key: str = SCHEDULE_KEY) -> dict:
    row = db.get(AppSetting, key)
    cfg = dict(row.value) if row and row.value else {"enabled": False, "cadence": "daily", "at_time": "06:00", "weekdays": []}
    cfg["text"] = SCH.cadence_text(_sched_obj(cfg)) if cfg.get("cadence") and (cfg.get("every_minutes") or cfg.get("at_time")) else None
    return cfg


def set_schedule(db, body: dict, actor: str, key: str = SCHEDULE_KEY, label: str = "Policy scan", extra: dict | None = None) -> dict:
    """Validate and save a scan schedule. `extra` carries settings that belong to one kind of scan (for example scan after a catalog sync)."""
    v = SCH.validate({"name": label, "cadence": body.get("cadence") or "daily", "every_minutes": body.get("every_minutes"),
                      "at_time": body.get("at_time"), "weekdays": body.get("weekdays") or [], "enabled": bool(body.get("enabled")), "scope": {}})
    cfg = {"enabled": v["enabled"], "cadence": v["cadence"], "every_minutes": v["every_minutes"], "at_time": v["at_time"], "weekdays": v["weekdays"],
           "last_run": (get_schedule(db, key) or {}).get("last_run"), **(extra or {})}
    cfg["next_run"] = SCH.next_after(_sched_obj(cfg), utcnow()).isoformat(timespec="seconds") if cfg["enabled"] else None
    row = db.get(AppSetting, key)
    if row:
        row.value, row.updated, row.updated_by = cfg, utcnow(), actor
    else:
        db.add(AppSetting(key=key, value=cfg, updated=utcnow(), updated_by=actor))
    audit(db, actor, "policy.scan_schedule" if key == SCHEDULE_KEY else key.replace("_schedule", "") + ".schedule", None, enabled=cfg["enabled"], cadence=SCH.cadence_text(_sched_obj(cfg)))
    db.flush()
    return get_schedule(db, key)


def run_if_due(db, key: str = SCHEDULE_KEY, runner=None) -> dict | None:
    """Called by the scheduler tick. `runner(db)` returns a dict describing what it did; the policy scan is the default."""
    row = db.get(AppSetting, key)
    cfg = dict(row.value) if row and row.value else None
    if not cfg or not cfg.get("enabled"):
        return None
    now = utcnow()
    nxt = cfg.get("next_run")
    if nxt and datetime.fromisoformat(nxt) > now:
        return None
    if runner is None:
        def runner(d):
            scan = run_scan(d, "schedule", "schedule")
            return {"scan_id": scan.id, "total": scan.total, "new": scan.new_count}
    res = runner(db)
    cfg["last_run"] = now.isoformat(timespec="seconds")
    cfg["next_run"] = SCH.next_after(_sched_obj(cfg), now).isoformat(timespec="seconds")
    row.value, row.updated = cfg, now
    db.flush()
    return res
