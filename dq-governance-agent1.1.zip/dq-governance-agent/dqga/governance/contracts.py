"""Data contracts using the Open Data Contract Standard (ODCS v3, Bitol / Linux Foundation).

- export: asset + active rules + owners -> ODCS YAML (rules also kept losslessly
  under customProperties so a round trip recreates them exactly).
- import: ODCS -> rules (status active, source contract), owners, SLA freshness.
- validate: contract vs live schema -> breaking changes. `python -m dqga
  contract-check` exits non-zero on breaking changes, for CI gates.
"""
from __future__ import annotations

import uuid
from typing import Any

import yaml

from ..connectors.base import type_family
from ..dq.rules import validate_rule

ODCS_VERSION = "v3.0.2"

LOGICAL = {"numeric": "number", "string": "string", "temporal": "date", "boolean": "boolean", "complex": "object"}


def export_contract(asset, rules: list, version: str = "1.0.0") -> dict:
    table = asset.fqn.split(".")[-1]
    rule_by_col: dict[str, list] = {}
    table_rules = []
    for r in rules:
        (rule_by_col.setdefault(r.column, []) if r.column else table_rules).append(r)
    props = []
    for c in asset.columns or []:
        crules = rule_by_col.get(c["name"], [])
        prop: dict[str, Any] = {
            "name": c["name"], "logicalType": LOGICAL.get(c.get("family"), "string"), "physicalType": c.get("data_type"),
            "required": any(r.type == "not_null" and r.threshold >= 1 for r in crules),
            "unique": any(r.type == "unique" and r.params.get("columns") == [c["name"]] for r in rules),
        }
        tag = ((asset.tags or {}).get("columns") or {}).get(c["name"], {})
        if tag.get("pii"):
            prop["classification"] = tag.get("sensitivity", "confidential")
            prop["tags"] = [f"pii:{tag['pii']}"]
        q = [_quality_item(r) for r in crules]
        if q:
            prop["quality"] = q
        props.append(prop)
    freshness = next((r for r in rules if r.type == "freshness"), None)
    spec = {
        "apiVersion": ODCS_VERSION, "kind": "DataContract",
        "id": str(uuid.uuid5(uuid.NAMESPACE_URL, asset.fqn)), "name": table, "version": version, "status": "active",
        "domain": asset.domain, "description": {"purpose": asset.description or f"Contract for {asset.fqn}"},
        "schema": [{"name": table, "physicalName": asset.fqn, "logicalType": "object",
                    "physicalType": asset.kind, "properties": props,
                    "quality": [_quality_item(r) for r in table_rules]}],
        "team": [m for m in ([{"username": asset.owner, "role": "owner"}] if asset.owner else []) +
                 ([{"username": asset.steward, "role": "data steward"}] if asset.steward else [])],
        "slaProperties": ([{"property": "latency", "value": freshness.params.get("max_age_hours"), "unit": "h",
                            "element": f"{table}.{freshness.column}"}] if freshness else []),
        "customProperties": [{"property": "dqga_platform", "value": asset.platform}],
    }
    return spec


def _quality_item(r) -> dict:
    item: dict[str, Any] = {"name": r.name, "description": r.description or r.name, "dimension": r.dimension,
                            "severity": r.severity,
                            "customProperties": [{"property": "dqga_rule", "value": {
                                "type": r.type, "column": r.column, "params": r.params, "threshold": r.threshold}}]}
    if r.type == "row_count":
        item.update({"type": "library", "rule": "rowCount"})
        if r.params.get("min") is not None:
            item["mustBeGreaterOrEqualTo"] = r.params["min"]
    elif r.type == "unique":
        item.update({"type": "library", "rule": "duplicateCount", "mustBe": 0})
    elif r.type == "not_null":
        item.update({"type": "library", "rule": "nullCheck", "mustBeLessOrEqualTo": round(1 - r.threshold, 6), "unit": "percent"})
    else:
        item.update({"type": "custom", "engine": "dqga"})
    return item


def dump(spec: dict) -> str:
    return yaml.safe_dump(spec, sort_keys=False, allow_unicode=True)


def parse(text: str) -> dict:
    spec = yaml.safe_load(text)
    if not isinstance(spec, dict) or spec.get("kind") != "DataContract":
        raise ValueError("Not an ODCS DataContract (kind: DataContract expected)")
    if not spec.get("schema"):
        raise ValueError("Contract has no schema")
    return spec


def rules_from_contract(spec: dict, columns: list[dict]) -> list[dict]:
    out = []
    for obj in spec.get("schema", []):
        items = [(None, q) for q in obj.get("quality", []) or []]
        for prop in obj.get("properties", []) or []:
            items += [(prop["name"], q) for q in prop.get("quality", []) or []]
            if prop.get("required") and not any(_native(q) and _native(q).get("type") == "not_null"
                                                for q in prop.get("quality", []) or []):
                items.append((prop["name"], {"_synth": {"type": "not_null", "column": prop["name"]}}))
            if prop.get("unique") and not any(_native(q) and _native(q).get("type") == "unique"
                                              for q in prop.get("quality", []) or []):
                items.append((prop["name"], {"_synth": {"type": "unique", "params": {"columns": [prop["name"]]}}}))
        for col, q in items:
            raw = q.get("_synth") or _native(q) or _from_library(col, q)
            if not raw:
                continue
            raw = dict(raw)
            raw.setdefault("name", q.get("name"))
            raw.setdefault("severity", q.get("severity", "high"))
            raw.setdefault("description", q.get("description"))
            try:
                v = validate_rule(raw, columns)
                v["source"] = "contract"
                out.append(v)
            except Exception:
                continue
    for sla in spec.get("slaProperties", []) or []:
        if sla.get("property") in ("latency", "freshness") and sla.get("element"):
            col = sla["element"].split(".")[-1]
            hours = float(sla["value"]) * {"d": 24, "day": 24, "days": 24, "m": 1 / 60, "min": 1 / 60}.get(sla.get("unit", "h"), 1)
            try:
                v = validate_rule({"type": "freshness", "column": col, "params": {"max_age_hours": hours},
                                   "severity": "high"}, columns)
                v["source"] = "contract"
                if not any(o["type"] == "freshness" for o in out):
                    out.append(v)
            except Exception:
                pass
    return out


def _native(q: dict) -> dict | None:
    for cp in q.get("customProperties", []) or []:
        if cp.get("property") == "dqga_rule":
            return {k: v for k, v in cp["value"].items() if v is not None}
    return None


def _from_library(col, q):
    rule = q.get("rule") or q.get("metric")
    if rule in ("duplicateCount", "duplicateValues") and col:
        return {"type": "unique", "params": {"columns": [col]}}
    if rule in ("nullCheck", "nullValues", "missingValues") and col:
        thr = 1 - float(q.get("mustBeLessOrEqualTo", q.get("mustBeLessThan", 0)) or 0)
        return {"type": "not_null", "column": col, "threshold": thr}
    if rule == "rowCount":
        return {"type": "row_count", "params": {"min": q.get("mustBeGreaterOrEqualTo", q.get("mustBeGreaterThan", 0))}}
    if q.get("type") == "sql" and q.get("query"):
        return None
    return None


def validate_against_schema(spec: dict, live_columns: list[dict]) -> dict:
    live = {c["name"].lower(): c for c in live_columns}
    breaking, warnings = [], []
    for obj in spec.get("schema", []):
        declared = {p["name"].lower() for p in obj.get("properties", []) or []}
        for prop in obj.get("properties", []) or []:
            got = live.get(prop["name"].lower())
            if not got:
                breaking.append(f"Column {prop['name']} missing")
                continue
            want = prop.get("physicalType") or prop.get("logicalType")
            if want and type_family(want) != type_family(got["data_type"]) and \
                    not (prop.get("logicalType") and LOGICAL.get(type_family(got["data_type"])) == prop["logicalType"]):
                breaking.append(f"Column {prop['name']} type {got['data_type']} (contract: {want})")
            if prop.get("required") and got.get("nullable") is True:
                warnings.append(f"Column {prop['name']} is required but nullable in the platform")
        for k, c in live.items():
            if k not in declared:
                warnings.append(f"Column {c['name']} not in contract (additive change)")
    return {"ok": not breaking, "breaking": breaking, "warnings": warnings}
