"""Creating policies: validation, plain-English drafting, and suggestions from signals, standards and uploaded documents.

Everything a person or a model proposes passes through `validate`, and is checked against your real datasets (domains,
columns, name patterns). A proposal also says how many violations it would raise today, before anyone saves it.
The model, when used, gets fixed guidance and only names and counts, never data values.
"""
from __future__ import annotations

import json
import re

from sqlalchemy import select

from ..config import get_settings
from ..models import Asset, Classification, Policy, ReferenceDoc
from . import compliance
from . import policies as P
from .classification import SENSITIVITY

TYPES = tuple(P.SEVERITY)
LABELS = tuple(SENSITIVITY)
SEVERITIES = ("critical", "high", "medium", "low")
APPLIES_KEYS = {"all", "domain", "fqn_pattern", "certified", "platform", "classification"}
SLUG = re.compile(r"^[a-z0-9][a-z0-9_-]{1,59}$")
GUIDANCE_VERSION = 1

# what each standard asks of a catalog: the policy types that cover it (see compliance.FRAMEWORKS for the controls)
STANDARD_POLICIES = {
    "gdpr": ("masking", "retention", "classification_required", "ownership"),
    "sox": ("ownership", "quality_gate", "certification", "contract_required"),
    "nerc_cip": ("ownership", "classification_required", "masking"),
    "iso_8000": ("quality_gate", "classification_required", "ownership"),
    "dama": ("ownership", "classification_required", "contract_required"),
}


# ---------------------------------------------------------------------------- validation
def validate(spec: dict) -> dict:
    """Normalise a policy and raise ValueError, in plain words, if it can't work."""
    if not isinstance(spec, dict):
        raise ValueError("A policy is an object with an id, a type and the datasets it applies to")
    s = dict(spec)
    key = str(s.get("id") or "").strip().lower()
    if not SLUG.match(key):
        raise ValueError("Give the policy an id of 2-60 lowercase letters, digits, dashes or underscores, for example pii-masking")
    t = s.get("type")
    if t not in TYPES:
        raise ValueError(f"Unknown policy type {t!r}. Choose one of: {', '.join(TYPES)}")
    sev = s.get("severity") or P.SEVERITY[t]
    if sev not in SEVERITIES:
        raise ValueError(f"Severity must be one of {', '.join(SEVERITIES)}")
    ap = s.get("applies_to")
    if not isinstance(ap, dict) or not ap:
        raise ValueError("Say which datasets it applies to: all datasets, a domain, a name pattern, certified datasets, a platform, or datasets holding certain sensitive data")
    bad = set(ap) - APPLIES_KEYS
    if bad:
        raise ValueError(f"'applies_to' has unknown keys {sorted(bad)}. Use: {', '.join(sorted(APPLIES_KEYS))}")
    applies = {}
    if ap.get("all"):
        applies["all"] = True
    if ap.get("domain"):
        applies["domain"] = [str(x) for x in (ap["domain"] if isinstance(ap["domain"], list) else [ap["domain"]])]
    if ap.get("fqn_pattern"):
        applies["fqn_pattern"] = str(ap["fqn_pattern"])
    if "certified" in ap:
        applies["certified"] = bool(ap["certified"])
    if ap.get("platform"):
        applies["platform"] = str(ap["platform"])
    if ap.get("classification"):
        labels = [str(x) for x in (ap["classification"] if isinstance(ap["classification"], list) else [ap["classification"]])]
        unknown = [x for x in labels if x not in LABELS]
        if unknown:
            raise ValueError(f"Unknown sensitive-data labels {unknown}. Use: {', '.join(LABELS)}")
        applies["classification"] = labels
    if not applies:
        raise ValueError("'applies_to' is empty. Say which datasets it covers")
    out = {"id": key, "type": t, "severity": sev, "applies_to": applies, "enabled": bool(s.get("enabled", True))}
    if s.get("description"):
        out["description"] = str(s["description"])[:300]
    if t == "masking":
        labels = s.get("labels") or applies.get("classification") or []
        labels = [str(x) for x in (labels if isinstance(labels, list) else [labels])]
        if not labels:
            raise ValueError("Masking needs the sensitive-data labels to mask, for example [email, phone]")
        unknown = [x for x in labels if x not in LABELS]
        if unknown:
            raise ValueError(f"Unknown sensitive-data labels {unknown}. Use: {', '.join(LABELS)}")
        out["labels"] = labels
        out["except_group"] = str(s.get("except_group") or "pii_readers")
    elif t == "retention":
        if not s.get("column"):
            raise ValueError("Retention needs the date or timestamp column the age is measured on")
        try:
            days = int(s.get("max_age_days"))
        except (TypeError, ValueError):
            raise ValueError("Retention needs max_age_days, a whole number of days") from None
        if not 1 <= days <= 36500:
            raise ValueError("max_age_days must be between 1 and 36500")
        out["column"], out["max_age_days"] = str(s["column"]), days
    elif t == "ownership":
        req = s.get("require") or ["owner"]
        req = [str(x) for x in (req if isinstance(req, list) else [req])]
        if not req or set(req) - {"owner", "steward"}:
            raise ValueError("'require' may contain owner and steward")
        out["require"] = req
    elif t == "quality_gate":
        try:
            ms = float(s.get("min_score"))
        except (TypeError, ValueError):
            raise ValueError("A quality gate needs min_score, a number from 0 to 100") from None
        if not 0 <= ms <= 100:
            raise ValueError("min_score must be between 0 and 100")
        out["min_score"] = ms
    elif t == "certification":
        try:
            n = int(s.get("min_rules", 3))
        except (TypeError, ValueError):
            raise ValueError("min_rules must be a whole number") from None
        if not 1 <= n <= 100:
            raise ValueError("min_rules must be between 1 and 100")
        out["min_rules"] = n
    return out


def describe(spec: dict) -> str:
    ap = spec.get("applies_to") or {}
    who = ("all datasets" if ap.get("all") else " and ".join(filter(None, [
        ("datasets in " + ", ".join(ap["domain"])) if ap.get("domain") else None,
        f"datasets named {ap['fqn_pattern']}" if ap.get("fqn_pattern") else None,
        ("certified datasets" if ap.get("certified") else "uncertified datasets") if "certified" in ap else None,
        f"{ap['platform']} datasets" if ap.get("platform") else None,
        ("datasets holding " + ", ".join(ap["classification"])) if ap.get("classification") else None]))) or "datasets"
    t = spec.get("type")
    what = {"masking": lambda: f"Columns holding {', '.join(spec.get('labels') or [])} must be masked (except for {spec.get('except_group', 'pii_readers')})",
            "retention": lambda: f"Rows older than {spec.get('max_age_days')} days (by {spec.get('column')}) must be purged",
            "ownership": lambda: f"Each needs {' and '.join(spec.get('require') or ['owner'])}",
            "quality_gate": lambda: f"Each must keep a DQ score of at least {spec.get('min_score')}",
            "classification_required": lambda: "Each must be scanned for sensitive data",
            "certification": lambda: f"Each must have an owner, a data contract and at least {spec.get('min_rules', 3)} active rules",
            "contract_required": lambda: "Each must have a data contract"}.get(t, lambda: "")()
    return f"{what} on {who}." if t in ("masking", "retention") else f"For {who}: {what[0].lower() + what[1:] if what else ''}."


def would_flag(db, spec: dict) -> dict:
    """How many violations this policy would raise right now, without saving it."""
    pol = Policy(key=spec["id"], type=spec["type"], spec=spec, enabled=True)
    v = P.evaluate(db, [pol])
    return {"count": len(v), "examples": [{"asset": x["asset"], "column": x["column"], "message": x["message"]} for x in v[:3]]}


# ---------------------------------------------------------------------------- context from the real catalog
def _context(db) -> dict:
    assets = db.scalars(select(Asset)).all()
    return {"domains": sorted({a.domain for a in assets if a.domain}), "platforms": sorted({a.platform for a in assets if a.platform}),
            "datasets": sorted(a.fqn for a in assets)[:60], "columns": sorted({c["name"] for a in assets for c in (a.columns or [])})[:300],
            "labels": list(LABELS), "types": list(TYPES)}


def check_against_catalog(db, spec: dict) -> None:
    """A proposal may only name domains, columns and name patterns that exist."""
    import fnmatch
    ctx = _context(db)
    ap = spec["applies_to"]
    for d in ap.get("domain", []):
        if d not in ctx["domains"]:
            raise ValueError(f"No dataset is in the domain {d!r}. Domains in use: {', '.join(ctx['domains']) or 'none'}")
    if ap.get("fqn_pattern") and not any(fnmatch.fnmatch(f, ap["fqn_pattern"]) for f in ctx["datasets"]):
        raise ValueError(f"No dataset matches the name pattern {ap['fqn_pattern']!r}")
    if spec["type"] == "retention" and spec["column"] not in ctx["columns"]:
        raise ValueError(f"No dataset has a column called {spec['column']!r}")


def _unique_id(db, base: str) -> str:
    taken = {p.key for p in db.scalars(select(Policy))}
    base = re.sub(r"[^a-z0-9_-]+", "-", base.lower()).strip("-")[:50] or "policy"
    key, n = base, 2
    while key in taken:
        key, n = f"{base}-{n}", n + 1
    return key


# ---------------------------------------------------------------------------- plain English
LABEL_WORDS = {"email": ("email", "e-mail"), "phone": ("phone", "telephone", "mobile"), "ssn": ("ssn", "social security"), "credit_card": ("credit card", "card number", "card"),
               "person_name": ("person name", "full name", "customer name", "names"), "address": ("address",), "iban": ("iban", "bank account"),
               "date_of_birth": ("date of birth", "birth date", "dob"), "passport": ("passport",), "national_id": ("national id",),
               "ip_address": ("ip address",), "geo_location": ("geo location", "gps", "coordinates")}
EXAMPLES = ["customer emails and phone numbers must be masked", "every dataset needs an owner and a steward",
            "certified datasets must keep a DQ score of at least 95", "finance datasets need a data contract",
            "certified datasets need at least 3 active rules", "delete rows older than 7 years using reading_ts on ami_raw",
            "all datasets must be scanned for sensitive data"]
POLICY_GUIDANCE = (
    "You turn one requirement, written in plain English, into ONE data governance policy for a data catalog. Return ONE JSON object and nothing else:\n"
    '{"id": str, "type": "masking"|"retention"|"ownership"|"quality_gate"|"classification_required"|"certification"|"contract_required", '
    '"severity": "critical"|"high"|"medium"|"low", "description": str, "applies_to": {"all": true} or {"domain": [..]} or {"fqn_pattern": str} or '
    '{"certified": bool} or {"platform": str} or {"classification": [..]}, plus the fields of the type:\n'
    "masking: labels (sensitive-data labels to mask), except_group; retention: column, max_age_days; ownership: require (owner and/or steward); "
    "quality_gate: min_score (0-100); certification: min_rules; classification_required and contract_required: nothing more.\n"
    "Rules: use ONLY the domains, columns, platforms and labels listed in the context. Never invent a name. If the requirement cannot be expressed with "
    'these types, return {"error": "<why, in one sentence>"}. The id is lowercase words joined by dashes. No prose.'
)


def _scope_from(low: str, ctx: dict) -> dict:
    doms = [d for d in ctx["domains"] if re.search(rf"\b{re.escape(d.lower())}\b", low)]
    if doms:
        return {"domain": doms}
    m = re.search(r"\bcertified\b", low)
    if m:
        return {"certified": True}
    for f in ctx["datasets"]:
        short = f.split(".")[-1].lower()
        if len(short) > 3 and re.search(rf"\b{re.escape(short)}\b", low):
            return {"fqn_pattern": f"*.{f.split('.')[-1]}"}
    return {"all": True}


def parse(db, text: str) -> dict | None:
    """Built-in reader for common policy sentences. Returns {spec, interpretation} or None when it doesn't recognise one."""
    low = " ".join(text.lower().split())
    ctx = _context(db)
    sev = next((s for s in SEVERITIES if re.search(rf"\b{s}\b", low)), None)
    spec: dict | None = None
    if re.search(r"\b(mask|masked|redact|hide|protect)\w*\b", low):
        labels = [k for k, words in LABEL_WORDS.items() if any(re.search(rf"\b{re.escape(w)}s?\b", low) for w in words)]
        if re.search(r"\b(pii|personal data|sensitive data|personal information)\b", low) and not labels:
            labels = ["email", "phone", "ssn", "credit_card", "person_name", "address", "iban"]
        if labels:
            grp = re.search(r"except (?:for )?(?:the )?([a-z0-9_]+)(?: group| role)?", low)
            spec = {"type": "masking", "labels": labels, "applies_to": _scope_from(low, ctx) if not re.search(r"\b(customer|customers)\b", low) else {"classification": labels},
                    "except_group": grp.group(1) if grp else "pii_readers", "id": "mask-" + "-".join(labels[:3])}
    if spec is None and re.search(r"\b(retain|retention|older than|delete|purge|keep)\b", low):
        m = re.search(r"(\d+)\s*(day|week|month|year)s?", low)
        col = next((c for c in ctx["columns"] if re.search(rf"\b{re.escape(c.lower())}\b", low)), None)
        if m and col:
            days = int(m.group(1)) * {"day": 1, "week": 7, "month": 30, "year": 365}[m.group(2)]
            spec = {"type": "retention", "column": col, "max_age_days": days, "applies_to": _scope_from(low, ctx), "id": f"retention-{col}-{days}d"}
        elif m:
            raise ValueError("Which column holds the date? Name it, for example: delete rows older than 7 years using reading_ts")
    if spec is None and re.search(r"\b(owner|steward)\b", low) and re.search(r"\b(need|needs|must|require|requires|have)\b", low):
        req = [w for w in ("owner", "steward") if w in low]
        spec = {"type": "ownership", "require": req, "applies_to": _scope_from(low, ctx), "id": "ownership-" + "-and-".join(req)}
    if spec is None and re.search(r"\b(score|quality)\b", low) and re.search(r"\d", low):
        m = re.search(r"(?:at least|above|over|minimum of|min|>=|no lower than)\s*(\d+(?:\.\d+)?)", low) or re.search(r"(\d+(?:\.\d+)?)", low)
        if m:
            spec = {"type": "quality_gate", "min_score": float(m.group(1)), "applies_to": _scope_from(low, ctx), "id": f"quality-gate-{int(float(m.group(1)))}"}
    if spec is None and re.search(r"\brules?\b", low) and re.search(r"\bcertified\b", low):
        m = re.search(r"at least (\d+)", low)
        if m:
            spec = {"type": "certification", "min_rules": int(m.group(1)), "applies_to": {"certified": True}, "id": "certified-requirements"}
    if spec is None and re.search(r"\bcontracts?\b", low):
        spec = {"type": "contract_required", "applies_to": _scope_from(low, ctx), "id": "contract-required"}
    if spec is None and re.search(r"\b(classified|classify|scanned|scan)\b", low):
        spec = {"type": "classification_required", "applies_to": _scope_from(low, ctx), "id": "classify-datasets"}
    if spec is None:
        return None
    if sev:
        spec["severity"] = sev
    spec["description"] = text.strip()[:300]
    spec["id"] = _unique_id(db, spec["id"])
    return {"spec": spec}


def llm_policy(db, llm, text: str) -> dict:
    ctx = _context(db)
    try:
        answer = llm.complete_json(POLICY_GUIDANCE, json.dumps({"requirement": text, "context": ctx}, sort_keys=True))
    except Exception as e:
        raise ValueError(f"The model could not be reached ({type(e).__name__}: {str(e)[:160]}). Check it in Settings > LLM.") from e
    if not isinstance(answer, dict):
        raise ValueError("The model did not return a policy")
    if answer.get("error"):
        raise ValueError(str(answer["error"])[:300])
    answer["id"] = _unique_id(db, str(answer.get("id") or "policy"))
    return answer


def draft(db, text: str, llm=None) -> dict:
    """A policy from plain English: the built-in reader first, then the model. Validated, checked against the catalog, with a dry count."""
    text = (text or "").strip()
    if not text:
        raise ValueError("Write the requirement first, for example: " + EXAMPLES[0])
    found, parser = parse(db, text), "built-in"
    raw = found["spec"] if found else None
    if raw is None:
        if llm is None:
            raise ValueError("I couldn't read that as a policy. Try a sentence such as: " + "; ".join(f'"{e}"' for e in EXAMPLES[:3])
                             + ". With a model set in Settings > LLM, free-form requirements are understood too.")
        raw, parser = llm_policy(db, llm, text), "llm"
    spec = validate(raw)
    check_against_catalog(db, spec)
    return {"spec": spec, "interpretation": describe(spec), "parser": parser, "would_flag": would_flag(db, spec)}


# ---------------------------------------------------------------------------- suggestions
def _existing_keys(db) -> set[tuple]:
    out = set()
    for p in db.scalars(select(Policy)):
        s = p.spec or {}
        out.add((p.type, json.dumps(s.get("applies_to", {}), sort_keys=True), json.dumps(sorted(s.get("labels", []))), s.get("column")))
    return out


def _sig(spec: dict) -> tuple:
    return (spec["type"], json.dumps(spec["applies_to"], sort_keys=True), json.dumps(sorted(spec.get("labels", []))), spec.get("column"))


def _signals(db) -> list[dict]:
    assets = db.scalars(select(Asset)).all()
    out = []
    labels = sorted({c.label for c in db.scalars(select(Classification).where(Classification.status != "rejected"))} & set(LABELS))
    if labels:
        out.append(({"type": "masking", "labels": labels, "applies_to": {"classification": labels}, "id": "pii-masking", "severity": "high"},
                    f"Sensitive columns were detected ({', '.join(labels)}), so each should be masked for everyone except an approved group."))
    if any(not a.owner for a in assets) or any(not a.steward for a in assets):
        out.append(({"type": "ownership", "require": ["owner", "steward"], "applies_to": {"all": True}, "id": "owner-and-steward"},
                    f"{sum(1 for a in assets if not a.owner or not a.steward)} dataset(s) lack an owner or a steward."))
    if any(a.certified for a in assets):
        out.append(({"type": "quality_gate", "min_score": 95, "applies_to": {"certified": True}, "id": "certified-quality-gate", "severity": "high"},
                    "Certified datasets should keep a high DQ score."))
        out.append(({"type": "certification", "min_rules": 3, "applies_to": {"certified": True}, "id": "certified-requirements"},
                    "Certified datasets should have an owner, a contract and enough active rules."))
    fin = [d for d in (get_settings().section("grouping") or {}).get("financial", []) if any((a.domain or "").lower() == str(d).lower() for a in assets)]
    if fin:
        doms = sorted({a.domain for a in assets if (a.domain or "").lower() in {str(x).lower() for x in fin}})
        out.append(({"type": "contract_required", "applies_to": {"domain": doms}, "id": "financial-contracts"},
                    f"Datasets in {', '.join(doms)} are configured as financial data, which normally needs a data contract."))
    if any(not a.last_profiled for a in assets):
        out.append(({"type": "classification_required", "applies_to": {"all": True}, "id": "classify-everything"},
                    f"{sum(1 for a in assets if not a.last_profiled)} dataset(s) were never scanned for sensitive data."))
    return out


def _retention_signal(db) -> list[tuple[dict, str]]:
    pii_assets = {c.asset_id for c in db.scalars(select(Classification).where(Classification.status != "rejected"))}
    for a in db.scalars(select(Asset).where(Asset.id.in_(pii_assets or {0}))):
        col = next((c["name"] for c in a.columns or [] if c.get("family") == "temporal" and re.search(r"creat|insert|record|event|posting|_at$|_ts$|date", c["name"].lower())), None)
        if col:
            return [({"type": "retention", "column": col, "max_age_days": 1095, "applies_to": {"fqn_pattern": f"*.{a.fqn.split('.')[-1]}"}, "id": f"retention-{a.fqn.split('.')[-1]}", "severity": "medium"},
                     f"{a.fqn.split('.')[-1]} holds personal data. Storage limitation says keep it no longer than needed: 1095 days (3 years) is a placeholder, so set your own period.")]
    return []


def suggest(db, standards: list[str] | None = None, use_uploads: bool = True, llm=None) -> dict:
    standards = [s for s in (standards or []) if s in STANDARD_POLICIES]
    wanted = {t for s in standards for t in STANDARD_POLICIES[s]} if standards else set(TYPES)
    have = _existing_keys(db)
    cand = _signals(db) + (_retention_signal(db) if (not standards or "gdpr" in standards) else [])
    out, seen = [], set()
    for raw, why in cand:
        if raw["type"] not in wanted:
            continue
        try:
            spec = validate({**raw})
            check_against_catalog(db, spec)
        except ValueError:
            continue
        if _sig(spec) in have or _sig(spec) in seen:
            continue
        seen.add(_sig(spec))
        spec["id"] = _unique_id(db, spec["id"])
        by = [s for s in standards if spec["type"] in STANDARD_POLICIES[s]]
        ctl = []
        for s in by:
            for cid, title, _ in compliance.FRAMEWORKS[s]["controls"]:
                if any(w in title.lower() for w in {"masking": ("masked", "sensitive", "protection"), "retention": ("retention", "storage"), "ownership": ("owner", "accountab", "responsib", "governance"),
                                                    "quality_gate": ("accura", "quality", "complete"), "classification_required": ("classif", "identified", "inventory", "sensitive"),
                                                    "certification": ("certif", "assur", "change"), "contract_required": ("contract", "agreement", "supplier", "definition")}.get(spec["type"], ())):
                    ctl.append(f"{compliance.FRAMEWORKS[s]['title'].split(' (')[0]} {cid}")
                    break
        out.append({"spec": spec, "reason": why, "source": "standard" if by else "signals", "standards": by, "controls": ctl,
                    "interpretation": describe(spec), "would_flag": would_flag(db, spec)})
    notes, llm_used = [], False
    docs = db.scalars(select(ReferenceDoc).where(ReferenceDoc.kind == "policy", ReferenceDoc.status != "error")).all() if use_uploads else []
    if docs and llm is None:
        notes.append(f"{len(docs)} uploaded standard document(s) are read when a model is configured: add one in Settings > LLM.")
    elif docs and llm is not None:
        text = "\n\n".join(f"## {d.name}\n{(d.text or '')[:3500]}" for d in docs[:4])[:9000]
        try:
            ans = llm.complete_json(POLICY_GUIDANCE.replace("ONE data governance policy", "a LIST of data governance policies") +
                                    '\nReturn {"policies": [ ... up to 6 ... ], "error": null} and base each on a requirement stated in the document; put its quote-free reason in "description".',
                                    json.dumps({"document": text, "context": _context(db)}, sort_keys=True))
            llm_used = True
            for raw in (ans.get("policies") if isinstance(ans, dict) else None) or []:
                try:
                    spec = validate({**raw, "id": _unique_id(db, str(raw.get("id") or "policy"))})
                    check_against_catalog(db, spec)
                except ValueError:
                    continue
                if _sig(spec) in have or _sig(spec) in seen:
                    continue
                seen.add(_sig(spec))
                out.append({"spec": spec, "reason": spec.get("description") or "Stated in an uploaded standard.", "source": "upload", "standards": [], "controls": [],
                            "interpretation": describe(spec), "would_flag": would_flag(db, spec)})
        except Exception as e:
            notes.append(f"The model could not read the uploaded documents ({type(e).__name__}).")
    return {"suggestions": out, "notes": notes, "llm_used": llm_used, "standards": standards}
