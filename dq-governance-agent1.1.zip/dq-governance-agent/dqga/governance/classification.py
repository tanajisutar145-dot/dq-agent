"""Sensitive-data classification.

Combines column-name hints with value pattern matches on a small local
sample (validated with checksums where one exists, e.g. Luhn for cards).
Sample values stay in process memory; only the label is stored.
"""
from __future__ import annotations

import re

SENSITIVITY = {
    "ssn": "restricted", "credit_card": "restricted", "iban": "restricted", "passport": "restricted",
    "email": "confidential", "phone": "confidential", "person_name": "confidential", "address": "confidential",
    "date_of_birth": "confidential", "national_id": "restricted",
    "ip_address": "internal", "geo_location": "internal", "customer_ref": "internal",
}

VALUE_PATTERNS = {
    "email": re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$"),
    "phone": re.compile(r"^\+?[0-9][0-9 ()\-.]{7,17}[0-9]$"),
    "ssn": re.compile(r"^(?!000|666|9\d\d)\d{3}-(?!00)\d{2}-(?!0000)\d{4}$"),
    "credit_card": re.compile(r"^(?:\d[ -]?){13,19}$"),
    "iban": re.compile(r"^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$"),
    "ip_address": re.compile(r"^(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)$"),
}

NAME_HINTS = {
    "email": [r"e?mail"],
    "phone": [r"phone", r"mobile", r"\bcell", r"\btel"],
    "ssn": [r"\bssn\b", r"social_?sec"],
    "credit_card": [r"card_?(no|num)", r"\bpan\b", r"credit_?card", r"\bcc_?num"],
    "iban": [r"\biban\b", r"bank_?acc"],
    "passport": [r"passport"],
    "national_id": [r"national_?id", r"\bnino\b", r"aadhaar", r"tax_?id", r"\btin\b"],
    "person_name": [r"first_?name", r"last_?name", r"full_?name", r"surname", r"^name$", r"customer_?name", r"contact_?name"],
    "address": [r"address", r"street", r"\bzip", r"postcode", r"postal"],
    "date_of_birth": [r"\bdob\b", r"birth"],
    "ip_address": [r"\bip(_?addr(ess)?)?\b"],
    "geo_location": [r"\blat(itude)?\b", r"\blon(g|gitude)?\b", r"geo"],
    "customer_ref": [r"customer_?id", r"account_?(no|num|id)"],
}


def luhn_ok(s: str) -> bool:
    digits = [int(c) for c in s if c.isdigit()]
    if not 13 <= len(digits) <= 19:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def classify_column(name: str, family: str, samples: list[str]) -> dict | None:
    lname = name.lower()
    best, best_score, method = None, 0.0, ""
    for label, hints in NAME_HINTS.items():
        if any(re.search(h, lname) for h in hints):
            score = 0.6
            if score > best_score:
                best, best_score, method = label, score, "name"
    vals = [v.strip() for v in samples if v and v.strip()][:500]
    if vals:
        for label, pat in VALUE_PATTERNS.items():
            hits = [v for v in vals if pat.match(v)]
            if label == "credit_card":
                hits = [v for v in hits if luhn_ok(v)]
            if label == "phone":
                # pure digit strings are usually account/meter ids, not phone numbers
                hits = [v for v in hits if v.startswith("+") or (sum(ch.isdigit() for ch in v) >= 9 and not v.isdigit())]
            ratio = len(hits) / len(vals)
            if ratio >= 0.6:
                score = 0.5 + 0.5 * ratio
                if best == label:
                    score = min(0.99, score + 0.1)
                    method = "name+value"
                elif score > best_score:
                    method = "value"
                if score > best_score or best == label:
                    best, best_score = label, score
    if best and best_score >= 0.55:
        return {"label": best, "sensitivity": SENSITIVITY.get(best, "internal"),
                "confidence": round(best_score, 2), "method": method}
    return None


def classify_asset(columns: list[dict], samples: dict[str, list[str]]) -> list[dict]:
    out = []
    for c in columns:
        res = classify_column(c["name"], c.get("family", "string"), samples.get(c["name"], []))
        if res:
            out.append({"column": c["name"], **res})
    return out
