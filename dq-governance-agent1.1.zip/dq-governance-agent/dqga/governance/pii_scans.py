"""Sensitive-data scans: look for personal or sensitive columns across datasets, keep the result, and run on a schedule.

A scan profiles each dataset (a small local sample, kept in memory only) and stores the label, sensitivity and confidence of
every column it recognises. Columns someone dismissed ("Not PII") stay dismissed. Raw values are never stored or sent to a model.
"""
from __future__ import annotations

import time
from collections import Counter

from sqlalchemy import select

from .. import connectors as C
from .. import services as S
from ..models import Asset, AppSetting, Classification, audit, utcnow
from . import scans

STATE_KEY = "pii_scan"
SCHEDULE_KEY = "pii_scan_schedule"
MAX_ERRORS = 20


def _assets(db, platform: str | None, asset_ids: list[int] | None, only_unscanned: bool) -> list[Asset]:
    out = []
    for a in db.scalars(select(Asset).order_by(Asset.fqn)):
        if asset_ids is not None and a.id not in asset_ids:
            continue
        if platform and a.platform != platform:
            continue
        if only_unscanned and a.last_profiled:
            continue
        out.append(a)
    return out


def run_scan(db, actor: str, trigger: str = "manual", platform: str | None = None, asset_ids: list[int] | None = None, only_unscanned: bool = False) -> dict:
    t0 = time.perf_counter()
    assets = _assets(db, platform, asset_ids, only_unscanned)
    scanned, new, errors, skipped = 0, 0, [], 0
    for a in assets:
        try:
            C.get_connector(a.connection)  # a disabled or removed connection is skipped, not an error
        except Exception:
            skipped += 1
            continue
        try:
            with db.begin_nested():
                res = S.profile_asset(db, a)
            scanned += 1
            new += len(res["new_classifications"])
        except Exception as e:
            if len(errors) < MAX_ERRORS:
                errors.append({"asset": a.fqn, "error": f"{type(e).__name__}: {e}"[:200]})
    db.flush()
    st = {"ts": utcnow().isoformat(timespec="seconds"), "trigger": trigger, "actor": actor, "scanned": scanned, "skipped": skipped, "new": new,
          "errors": errors, "error_count": len(errors), "platform": platform, "only_unscanned": only_unscanned, "duration_s": round(time.perf_counter() - t0, 2)}
    row = db.get(AppSetting, STATE_KEY)
    if row:
        row.value, row.updated, row.updated_by = st, utcnow(), actor
    else:
        db.add(AppSetting(key=STATE_KEY, value=st, updated=utcnow(), updated_by=actor))
    audit(db, actor, "pii.scanned", trigger, scanned=scanned, new=new, errors=len(errors))
    db.flush()
    return st


def status(db) -> dict:
    row = db.get(AppSetting, STATE_KEY)
    assets = db.scalars(select(Asset)).all()
    cls = db.scalars(select(Classification).where(Classification.status != "rejected")).all()
    sev = Counter(c.sensitivity for c in cls)
    sched = scans.get_schedule(db, SCHEDULE_KEY)
    return {"last": dict(row.value) if row and row.value else None, "datasets": len(assets), "never_scanned": sum(1 for a in assets if not a.last_profiled),
            "unscanned": [{"id": a.id, "fqn": a.fqn} for a in assets if not a.last_profiled][:50],
            "columns": len(cls), "to_review": sum(1 for c in cls if c.status == "suggested" and not c.applied), "tagged": sum(1 for c in cls if c.applied),
            "by_sensitivity": dict(sev), "schedule": sched}


def get_schedule(db) -> dict:
    return scans.get_schedule(db, SCHEDULE_KEY)


def set_schedule(db, body: dict, actor: str) -> dict:
    return scans.set_schedule(db, body, actor, SCHEDULE_KEY, "Sensitive-data scan", {"after_sync": bool(body.get("after_sync"))})


def run_if_due(db) -> dict | None:
    return scans.run_if_due(db, SCHEDULE_KEY, lambda d: run_scan(d, "schedule", "schedule"))


def after_sync(db) -> dict | None:
    """Called after a catalog sync: scan datasets that were never scanned, when the schedule says to."""
    cfg = db.get(AppSetting, SCHEDULE_KEY)
    if not cfg or not (cfg.value or {}).get("after_sync"):
        return None
    return run_scan(db, "catalog sync", "sync", only_unscanned=True)
