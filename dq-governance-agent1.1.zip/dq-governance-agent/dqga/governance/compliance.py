"""Compliance mapping: frameworks -> controls -> measurable evidence.

This is mapping guidance to organize evidence for auditors, not legal advice.
Each control is scored from facts the platform already tracks (ownership,
classification, masking, retention, rule coverage, lineage, contracts,
incident response, audit trail).
"""
from __future__ import annotations

from sqlalchemy import func, select

from ..grouping import is_critical
from ..models import Asset, AuditLog, Classification, Contract, Incident, LineageEdge, Policy, Rule
from .policies import evaluate


def facts(db) -> dict:
    assets = db.scalars(select(Asset)).all()
    n = len(assets) or 1
    rules_by = {}
    for r in db.scalars(select(Rule).where(Rule.status == "active")):
        rules_by.setdefault(r.asset_id, []).append(r)
    critical = [a for a in assets if a.certified or is_critical(a.domain)]
    lineage_nodes = {e.target for e in db.scalars(select(LineageEdge))} | {e.source for e in db.scalars(select(LineageEdge))}
    pii_assets = {c.asset_id for c in db.scalars(select(Classification).where(Classification.status != "rejected"))}
    viol = evaluate(db)
    from ..incidents.manager import mttr_hours
    return {
        "assets": len(assets),
        "ownership_coverage": sum(1 for a in assets if a.owner) / n,
        "steward_coverage": sum(1 for a in assets if a.steward) / n,
        "profiled_coverage": sum(1 for a in assets if a.last_profiled) / n,
        "rule_coverage": sum(1 for a in assets if rules_by.get(a.id)) / n,
        "critical_rule_coverage": (sum(1 for a in critical if len(rules_by.get(a.id, [])) >= 3) / len(critical)) if critical else 1.0,
        "lineage_coverage": sum(1 for a in assets if a.fqn in lineage_nodes) / n,
        "contract_coverage": len({c.asset_id for c in db.scalars(select(Contract))}) / n,
        "pii_assets": len(pii_assets),
        "masking_violations": sum(1 for v in viol if v["type"] == "masking"),
        "retention_violations": sum(1 for v in viol if v["type"] == "retention"),
        "retention_policies": db.scalar(select(func.count()).select_from(Policy)
                                        .where(Policy.type == "retention", Policy.enabled.is_(True))) or 0,
        "accuracy_rules": sum(1 for rs in rules_by.values() for r in rs if r.dimension in ("validity", "accuracy", "consistency")),
        "open_incidents": db.scalar(select(func.count()).select_from(Incident).where(Incident.status.in_(["open", "ack"]))) or 0,
        "mttr_hours": mttr_hours(db),
        "audit_events": db.scalar(select(func.count()).select_from(AuditLog)) or 0,
        "violations": len(viol),
    }


def _st(ok: bool, partial: bool = False) -> str:
    return "met" if ok else ("partial" if partial else "gap")


def _cov(x: float, full=0.95, part=0.5) -> str:
    return _st(x >= full, x >= part)


FRAMEWORKS = {
    "gdpr": {
        "title": "GDPR (EU 2016/679)",
        "controls": [
            ("Art. 5(1)(d)", "Accuracy: personal data kept accurate and up to date",
             lambda f: (_st(f["accuracy_rules"] > 0 and f["rule_coverage"] >= 0.8, f["accuracy_rules"] > 0),
                        f"{f['accuracy_rules']} validity/accuracy rules; rule coverage {f['rule_coverage']:.0%}")),
            ("Art. 5(1)(e)", "Storage limitation: retention enforced",
             lambda f: (_st(f["retention_policies"] > 0 and f["retention_violations"] == 0, f["retention_policies"] > 0),
                        f"{f['retention_policies']} retention policies; {f['retention_violations']} open violations")),
            ("Art. 25", "Data protection by design: sensitive data identified and masked",
             lambda f: (_st(f["profiled_coverage"] >= 0.9 and f["masking_violations"] == 0, f["profiled_coverage"] > 0.3),
                        f"{f['profiled_coverage']:.0%} assets classified; {f['pii_assets']} with PII; "
                        f"{f['masking_violations']} unmasked PII columns")),
            ("Art. 30", "Records of processing: owners and lineage documented",
             lambda f: (_st(f["ownership_coverage"] >= 0.95 and f["lineage_coverage"] >= 0.8,
                            f["ownership_coverage"] >= 0.5), f"Ownership {f['ownership_coverage']:.0%}; lineage {f['lineage_coverage']:.0%}")),
            ("Art. 32", "Security of processing: access controls and audit trail",
             lambda f: (_st(f["masking_violations"] == 0 and f["audit_events"] > 0, f["audit_events"] > 0),
                        f"{f['audit_events']} audit events; {f['masking_violations']} masking gaps")),
        ],
    },
    "sox": {
        "title": "SOX ITGC (financial reporting data)",
        "controls": [
            ("ITGC-DI-1", "Completeness and accuracy checks on financial data",
             lambda f: (_cov(f["critical_rule_coverage"]), f"{f['critical_rule_coverage']:.0%} of critical/finance assets have >= 3 rules")),
            ("ITGC-CM-1", "Change management: schema changes governed by contracts",
             lambda f: (_cov(f["contract_coverage"], 0.8, 0.2), f"Contract coverage {f['contract_coverage']:.0%}")),
            ("ITGC-AC-1", "Accountability: every financial dataset has an owner",
             lambda f: (_cov(f["ownership_coverage"]), f"Ownership {f['ownership_coverage']:.0%}")),
            ("ITGC-MON-1", "Exceptions tracked and resolved with audit trail",
             lambda f: (_st(f["audit_events"] > 0 and (f["mttr_hours"] or 0) <= 72, f["audit_events"] > 0),
                        f"MTTR {f['mttr_hours']}h; {f['open_incidents']} open incidents")),
        ],
    },
    "nerc_cip": {
        "title": "NERC CIP (bulk electric system)",
        "controls": [
            ("CIP-011-3 R1", "Identify and protect BES Cyber System Information",
             lambda f: (_st(f["profiled_coverage"] >= 0.9 and f["masking_violations"] == 0, f["profiled_coverage"] > 0.3),
                        f"Classification {f['profiled_coverage']:.0%}; {f['masking_violations']} unprotected sensitive columns")),
            ("CIP-004-7 R4", "Access management for information repositories",
             lambda f: (_st(f["masking_violations"] == 0, False), f"{f['masking_violations']} masking gaps; review platform grants")),
            ("CIP-010-4 R1", "Configuration change management (schemas, pipelines)",
             lambda f: (_cov(f["contract_coverage"], 0.8, 0.2), f"Contract coverage {f['contract_coverage']:.0%}")),
            ("CIP-007-6 R4", "Security event monitoring and logging",
             lambda f: (_st(f["audit_events"] > 0), f"{f['audit_events']} audit events retained")),
        ],
    },
    "iso_8000": {
        "title": "ISO 8000 (data quality)",
        "controls": [
            ("8000-8", "Syntactic and semantic quality measured",
             lambda f: (_cov(f["rule_coverage"], 0.9, 0.4), f"Rule coverage {f['rule_coverage']:.0%}")),
            ("8000-61", "Data quality management process (measure, analyze, improve)",
             lambda f: (_st(f["rule_coverage"] > 0.5 and f["mttr_hours"] is not None, f["rule_coverage"] > 0),
                        f"Incidents managed; MTTR {f['mttr_hours']}h")),
            ("8000-120", "Provenance captured",
             lambda f: (_cov(f["lineage_coverage"], 0.9, 0.4), f"Lineage coverage {f['lineage_coverage']:.0%}")),
            ("8000-150", "Roles and responsibilities (owner, steward)",
             lambda f: (_st(f["ownership_coverage"] >= 0.95 and f["steward_coverage"] >= 0.8, f["ownership_coverage"] >= 0.5),
                        f"Owners {f['ownership_coverage']:.0%}; stewards {f['steward_coverage']:.0%}")),
        ],
    },
    "dama": {
        "title": "DAMA-DMBOK data quality dimensions",
        "controls": [
            ("DQ-Completeness", "Completeness measured on key assets", lambda f: (_cov(f["rule_coverage"], 0.9, 0.4), f"Rule coverage {f['rule_coverage']:.0%}")),
            ("DQ-Governance", "Stewardship and metadata management", lambda f: (_cov(f["steward_coverage"], 0.9, 0.4), f"Stewards {f['steward_coverage']:.0%}")),
            ("DQ-Lineage", "Data lineage documented", lambda f: (_cov(f["lineage_coverage"], 0.9, 0.4), f"Lineage {f['lineage_coverage']:.0%}")),
        ],
    },
}


def report(db, framework: str) -> dict:
    if framework not in FRAMEWORKS:
        raise ValueError(f"Unknown framework {framework}; choose from {list(FRAMEWORKS)}")
    f = facts(db)
    fw = FRAMEWORKS[framework]
    controls = []
    for cid, title, fn in fw["controls"]:
        status, evidence = fn(f)
        controls.append({"id": cid, "title": title, "status": status, "evidence": evidence})
    met = sum(1 for c in controls if c["status"] == "met")
    return {"framework": framework, "title": fw["title"], "controls": controls,
            "summary": {"met": met, "partial": sum(1 for c in controls if c["status"] == "partial"),
                        "gap": sum(1 for c in controls if c["status"] == "gap"), "total": len(controls)},
            "facts": f, "disclaimer": "Mapping guidance to organize evidence; not legal advice."}
