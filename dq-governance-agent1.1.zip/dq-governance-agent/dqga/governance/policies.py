"""Policy as code.

Policies are YAML (policies.yaml, stored in the DB) with a type, a selector
(`applies_to`) and type-specific settings. `evaluate` returns violations;
`enforcement_sql` renders platform-native statements (Unity Catalog column
masks, Snowflake masking policies, retention deletes) which only run after
approval.

Policy types: masking, retention, ownership, quality_gate,
classification_required, certification, contract_required.
"""
from __future__ import annotations

import fnmatch
from datetime import timedelta

from sqlalchemy import select

from ..models import Asset, Classification, Contract, Policy, Rule, utcnow

SEVERITY = {"masking": "high", "retention": "medium", "ownership": "medium", "quality_gate": "high",
            "classification_required": "medium", "certification": "high", "contract_required": "medium"}


def selects(sel: dict, asset: Asset, column_labels: set[str] | None = None) -> bool:
    sel = sel or {}
    if sel.get("all"):
        return True
    if sel.get("domain") and (asset.domain or "") not in (sel["domain"] if isinstance(sel["domain"], list) else [sel["domain"]]):
        return False
    if sel.get("fqn_pattern") and not fnmatch.fnmatch(asset.fqn, sel["fqn_pattern"]):
        return False
    if "certified" in sel and bool(asset.certified) != bool(sel["certified"]):
        return False
    if sel.get("platform") and asset.platform != sel["platform"]:
        return False
    if sel.get("classification") and not (column_labels or set()) & set(sel["classification"]):
        return False
    return True


def evaluate(db, policies: list[Policy] | None = None) -> list[dict]:
    policies = policies if policies is not None else db.scalars(select(Policy).where(Policy.enabled.is_(True))).all()
    assets = db.scalars(select(Asset)).all()
    cls = {}
    for c in db.scalars(select(Classification).where(Classification.status != "rejected")):
        cls.setdefault(c.asset_id, []).append(c)
    contracts = {c.asset_id for c in db.scalars(select(Contract))}
    rules_by_asset = {}
    for r in db.scalars(select(Rule).where(Rule.status == "active")):
        rules_by_asset.setdefault(r.asset_id, []).append(r)
    out = []
    for p in policies:
        s = p.spec
        for a in assets:
            labels = {c.label for c in cls.get(a.id, [])}
            if not selects(s.get("applies_to", {}), a, labels):
                continue

            def v(msg, column=None, enforceable=False):
                out.append({"policy": p.key, "type": p.type, "asset_id": a.id, "asset": a.fqn, "column": column,
                            "message": msg, "severity": s.get("severity", SEVERITY.get(p.type, "medium")),
                            "enforceable": enforceable})
            if p.type == "masking":
                wanted = set(s.get("labels") or s.get("applies_to", {}).get("classification") or [])
                col_tags = (a.tags or {}).get("columns", {})
                for c in cls.get(a.id, []):
                    if c.label in wanted and not col_tags.get(c.column, {}).get("masked"):
                        v(f"{c.column} ({c.label}) has no masking policy", c.column, enforceable=True)
            elif p.type == "retention":
                col = s.get("column")
                if not col or not any(x["name"] == col for x in a.columns or []):
                    v(f"Retention column {col!r} not found; retention cannot be enforced")
                elif not (a.tags or {}).get("retention_enforced"):
                    v(f"Rows older than {s.get('max_age_days')} days must be purged via {col}", col, enforceable=True)
            elif p.type == "ownership":
                for field in s.get("require", ["owner"]):
                    if not getattr(a, field, None):
                        v(f"Missing {field}")
            elif p.type == "quality_gate":
                if a.score is None:
                    v("No DQ checks have run")
                elif a.score < float(s.get("min_score", 90)):
                    v(f"DQ score {a.score} below gate {s.get('min_score', 90)}")
            elif p.type == "classification_required":
                if not a.last_profiled:
                    v("Not profiled or classified yet")
            elif p.type == "certification":
                if a.certified:
                    if not a.owner:
                        v("Certified asset without owner")
                    if a.id not in contracts:
                        v("Certified asset without a data contract")
                    if len(rules_by_asset.get(a.id, [])) < int(s.get("min_rules", 3)):
                        v(f"Certified asset with fewer than {s.get('min_rules', 3)} active rules")
            elif p.type == "contract_required":
                if a.id not in contracts:
                    v("No data contract")
    return out


def enforcement_sql(policy: Policy, violation: dict, dialect_name: str, asset: Asset) -> list[str]:
    s = policy.spec
    col = violation.get("column")
    if policy.type == "masking" and col:
        group = s.get("except_group", "pii_readers")
        label = violation["message"].split("(")[-1].split(")")[0] if "(" in violation["message"] else "pii"
        if dialect_name == "spark":
            cat, sch, _ = asset.fqn.split(".")
            fn = f"{cat}.{sch}.dq_mask_{label}"
            return [f"CREATE FUNCTION IF NOT EXISTS {fn}(v STRING) RETURNS STRING "
                    f"RETURN CASE WHEN is_account_group_member('{group}') THEN v ELSE '***REDACTED***' END",
                    f"ALTER TABLE {asset.fqn} ALTER COLUMN `{col}` SET MASK {fn}"]
        if dialect_name == "snowflake":
            db, sch, _ = asset.fqn.split(".")
            pol = f"{db}.{sch}.DQ_MASK_{label.upper()}"
            return [f"CREATE MASKING POLICY IF NOT EXISTS {pol} AS (v STRING) RETURNS STRING -> "
                    f"CASE WHEN IS_ROLE_IN_SESSION('{group.upper()}') THEN v ELSE '***REDACTED***' END",
                    f"ALTER TABLE {asset.fqn} MODIFY COLUMN \"{col}\" SET MASKING POLICY {pol}"]
        if dialect_name == "duckdb":
            cols = ", ".join(f"'***REDACTED***' AS \"{c['name']}\"" if c["name"] == col else f"\"{c['name']}\""
                             for c in asset.columns)
            return [f"CREATE OR REPLACE VIEW {asset.fqn}_masked AS SELECT {cols} FROM {asset.fqn}"]
    if policy.type == "retention" and col:
        days = int(s.get("max_age_days", 365))
        cutoff = (utcnow() - timedelta(days=days)).isoformat(sep=" ", timespec="seconds")
        q = {"spark": f"`{col}`", "snowflake": f'"{col}"'}.get(dialect_name, f'"{col}"')
        return [f"DELETE FROM {asset.fqn} WHERE {q} < TIMESTAMP '{cutoff}'"]
    return []


def seed_policies(db, specs: list[dict]) -> int:
    n = 0
    for s in specs:
        if db.scalars(select(Policy).where(Policy.key == s["id"])).first():
            continue
        db.add(Policy(key=s["id"], type=s["type"], spec=s, enabled=s.get("enabled", True)))
        n += 1
    db.flush()
    return n
