"""Impact analysis: what is affected if this dataset (or these columns) breaks or changes.

Two modes:
  data     a quality problem in the dataset: who consumes it downstream, how critical they are
  drop / retype   a planned schema change: which rules, contracts, policies, downstream
                  columns and owners would break

Column-level lineage is used when the platform provides it; otherwise downstream
columns with the same name are reported as "likely affected".
"""
from __future__ import annotations

import re

from sqlalchemy import select

from .grouping import is_critical
from .incidents import lineage as L
from .incidents.notify import send
from .models import Asset, Contract, Incident, LineageEdge, Policy, Rule, audit

def _rule_uses(r: Rule, cols: set[str]) -> bool:
    p = r.params or {}
    if (r.column or "").lower() in cols:
        return True
    if any(c.lower() in cols for c in p.get("columns", []) or []):
        return True
    expr = " ".join(str(p.get(k, "")) for k in ("expression", "ref_expression", "where"))
    return any(re.search(rf"\b{re.escape(c)}\b", expr, re.I) for c in cols)


def analyze(db, asset: Asset, columns: list[str] | None = None, change: str = "data", depth: int = 6) -> dict:
    cols = {c.lower() for c in (columns or [])}
    dist = L.downstream(db, asset.fqn, depth)
    by_fqn = {a.fqn: a for a in db.scalars(select(Asset))}
    open_inc = {}
    for i in db.scalars(select(Incident).where(Incident.status.in_(["open", "ack"]))):
        for f in set(i.assets) | {i.root_fqn}:
            open_inc[f] = open_inc.get(f, 0) + 1
    col_edges = db.scalars(select(LineageEdge).where(LineageEdge.source == asset.fqn, LineageEdge.source_column != "")).all()
    exact_cols = {}
    for e in col_edges:
        if not cols or e.source_column.lower() in cols:
            exact_cols.setdefault(e.target, set()).add(e.target_column)

    impacted, score = [], 0.0
    for fqn, d in sorted(dist.items(), key=lambda kv: (kv[1], kv[0])):
        a = by_fqn.get(fqn)
        w = (3 if a and a.certified else 1) * (2 if a and is_critical(a.domain) else 1)
        score += w / d
        affected_cols, how = [], None
        if cols and a:
            if fqn in exact_cols:
                affected_cols, how = sorted(exact_cols[fqn]), "column lineage"
            else:
                affected_cols = sorted(c["name"] for c in a.columns or [] if c["name"].lower() in cols)
                how = "same column name" if affected_cols else None
        impacted.append({"fqn": fqn, "asset_id": a.id if a else None, "distance": d, "platform": a.platform if a else fqn.split(":")[0],
                         "domain": a.domain if a else None, "owner": a.owner if a else None, "steward": a.steward if a else None,
                         "certified": bool(a and a.certified), "score": a.score if a else None, "open_incidents": open_inc.get(fqn, 0),
                         "columns": affected_cols, "column_match": how, "weight": round(w / d, 2)})

    # rules that would break or that already guard the affected data
    rules = []
    for r in db.scalars(select(Rule).where(Rule.status == "active")):
        a = db.get(Asset, r.asset_id)
        if not a:
            continue
        on_self = a.id == asset.id and (not cols or _rule_uses(r, cols))
        refs_self = r.type in ("referential", "reconciliation") and (r.params or {}).get("ref_table") == asset.fqn and \
            (not cols or (r.params or {}).get("ref_column", "").lower() in cols or r.type == "reconciliation")
        downstream_same = a.fqn in dist and cols and _rule_uses(r, cols)
        if on_self or refs_self or downstream_same:
            rules.append({"id": r.id, "name": r.name, "type": r.type, "asset": a.fqn, "asset_id": a.id, "severity": r.severity,
                          "why": "on this dataset" if on_self else "references this dataset" if refs_self else "downstream, same column"})
    # contracts
    contracts = []
    for c in db.scalars(select(Contract)):
        a = db.get(Asset, c.asset_id) if c.asset_id else None
        if not a or (a.id != asset.id and a.fqn not in dist):
            continue
        props = [p["name"] for s in c.spec.get("schema", []) for p in s.get("properties", []) or []]
        hit = [p for p in props if p.lower() in cols] if cols else []
        if a.id == asset.id and (hit or change == "data"):
            contracts.append({"asset": a.fqn, "asset_id": a.id, "version": c.version, "columns": hit,
                              "breaking": change in ("drop", "retype") and bool(hit)})
        elif a.fqn in dist and hit:
            contracts.append({"asset": a.fqn, "asset_id": a.id, "version": c.version, "columns": hit, "breaking": change in ("drop", "retype")})
    # policies tied to these columns
    policies = []
    for p in db.scalars(select(Policy).where(Policy.enabled.is_(True))):
        spec = p.spec or {}
        if cols and (spec.get("column", "").lower() in cols):
            policies.append({"policy": p.key, "type": p.type, "column": spec.get("column")})
    if cols:
        for col, tags in ((asset.tags or {}).get("columns") or {}).items():
            if col.lower() in cols and tags.get("masked"):
                policies.append({"policy": "column mask", "type": "masking", "column": col})

    score += 0.5 * len(rules) + 3 * sum(1 for c in contracts if c["breaking"]) + (2 if asset.certified else 0)
    if change in ("drop", "retype") and cols:
        score += 2 * sum(len(i["columns"]) for i in impacted)
    pct = min(100, round(score * 8))
    level = "critical" if pct >= 75 else "high" if pct >= 45 else "medium" if pct >= 20 else "low"
    owners = {}
    for x in [{"owner": asset.owner, "steward": asset.steward, "fqn": asset.fqn}] + impacted:
        for role in ("owner", "steward"):
            if x.get(role):
                owners.setdefault(x[role], set()).add(x["fqn"])
    what = {"data": "A data quality problem in", "drop": "Dropping", "retype": "Changing the type of"}[change]
    subject = f"{', '.join(sorted(cols))} in {asset.fqn}" if cols and change != "data" else asset.fqn
    summary = (f"{what} {subject} reaches {len(impacted)} downstream dataset(s)"
               f"{' (' + str(sum(1 for i in impacted if i['certified'])) + ' certified)' if impacted else ''}, "
               f"touches {len(rules)} active rule(s) and {len(contracts)} contract(s)"
               f"{', ' + str(sum(1 for c in contracts if c['breaking'])) + ' of them breaking' if change != 'data' else ''}. "
               f"Impact is {level}.")
    return {"asset": asset.fqn, "asset_id": asset.id, "change": change, "columns": sorted(cols), "score": pct, "level": level,
            "summary": summary, "impacted": impacted, "rules": rules, "contracts": contracts, "policies": policies,
            "owners": [{"name": k, "datasets": sorted(v)} for k, v in sorted(owners.items())],
            "column_lineage": bool(col_edges)}


def notify_owners(db, report: dict, actor: str, note: str | None = None) -> dict:
    who = ", ".join(o["name"] for o in report["owners"]) or "no owners on record"
    text = report["summary"] + (f"\n\nNote from {actor}: {note}" if note else "") + f"\n\nOwners: {who}"
    title = f"[Impact {report['level']}] {report['asset']}" + (f" ({report['change']} {', '.join(report['columns'])})" if report["columns"] else "")
    res = send(db, title, text, severity="high" if report["level"] in ("high", "critical") else "medium")
    audit(db, actor, "impact.notified", report["asset"], level=report["level"], owners=[o["name"] for o in report["owners"]],
          change=report["change"], columns=report["columns"])
    return {"sent": res, "owners": report["owners"]}
