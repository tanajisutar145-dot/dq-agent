"""Alerts to Slack (incoming webhook), Microsoft Teams (Workflows webhook with an
Adaptive Card), and email (SMTP). Unconfigured channels are recorded as skipped."""
from __future__ import annotations

import smtplib
from email.message import EmailMessage

import httpx

from ..config import get_settings, resolve_env
from ..models import Notification

SEV_RANK = {"low": 0, "medium": 1, "high": 2, "critical": 3}


def _send_webhook(url: str, payload: dict) -> str:
    r = httpx.post(url, json=payload, timeout=15)
    return f"sent ({r.status_code})" if r.status_code < 300 else f"failed ({r.status_code})"


def send(db, title: str, text: str, link: str | None = None, severity: str = "high") -> list[dict]:
    cfg = get_settings().section("notifications")
    out = []
    slack = resolve_env(cfg, "slack_webhook")
    teams = resolve_env(cfg, "teams_webhook")
    channels = []
    if slack:
        channels.append(("slack", slack, {"text": f"*{title}*\n{text}" + (f"\n<{link}|Open in TCS DataTrustAI>" if link else "")}))
    if teams:
        card = {"type": "AdaptiveCard", "version": "1.4", "body": [
            {"type": "TextBlock", "text": title, "weight": "Bolder", "wrap": True},
            {"type": "TextBlock", "text": text, "wrap": True}],
            "actions": [{"type": "Action.OpenUrl", "title": "Open", "url": link}] if link else []}
        channels.append(("teams", teams, {"type": "message", "attachments": [
            {"contentType": "application/vnd.microsoft.card.adaptive", "content": card}]}))
    for name, url, payload in channels:
        try:
            status = _send_webhook(url, payload)
        except Exception as e:
            status = f"failed ({type(e).__name__})"
        db.add(Notification(channel=name, title=title, payload=payload, status=status))
        out.append({"channel": name, "status": status})
    smtp = cfg.get("smtp")
    if smtp and smtp.get("to"):
        try:
            msg = EmailMessage()
            msg["Subject"], msg["From"], msg["To"] = title, smtp.get("from", "dq-agent@localhost"), ", ".join(smtp["to"])
            msg.set_content(text + (f"\n\n{link}" if link else ""))
            with smtplib.SMTP(smtp["host"], int(smtp.get("port", 587)), timeout=15) as s:
                if smtp.get("starttls", True):
                    s.starttls()
                user = resolve_env(smtp, "user")
                if user:
                    s.login(user, resolve_env(smtp, "password"))
                s.send_message(msg)
            status = "sent"
        except Exception as e:
            status = f"failed ({type(e).__name__})"
        db.add(Notification(channel="email", title=title, payload={"to": smtp["to"]}, status=status))
        out.append({"channel": "email", "status": status})
    if not out:
        db.add(Notification(channel="none", title=title, payload={"text": text}, status="skipped (no channel configured)"))
        out.append({"channel": "none", "status": "skipped"})
    return out


def notify_incident(db, inc) -> list[dict]:
    cfg = get_settings().section("notifications")
    if SEV_RANK.get(inc.severity, 0) < SEV_RANK.get(cfg.get("min_severity", "high"), 2):
        return []
    base = cfg.get("base_url", "http://localhost:8000")
    return send(db, f"[{inc.severity.upper()}] {inc.title}", inc.summary or "", f"{base}/#/incident/{inc.id}", inc.severity)
