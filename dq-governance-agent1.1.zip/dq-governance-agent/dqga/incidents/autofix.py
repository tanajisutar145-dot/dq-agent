"""Intelligent corrections for failing checks, scored by risk, previewed, reversible.

Corrections (only when the intended value is clear):
  standardize   'Active', ' active ' -> 'active' when it matches an allowed value ignoring case and spaces   (low)
  typo          'comercial' -> 'commercial' when exactly one allowed value is a close spelling            (medium)
  trim          values that pass the pattern once surrounding spaces are removed                          (low)
  dedupe_exact  remove rows that are complete duplicates of another row                                   (low)

Risk rises with the share of rows touched, the absolute row count, and certification.
Low-risk corrections can run automatically (remediation.auto_correct_low_risk). Everything
takes a snapshot first (Delta: the table version; elsewhere: a copy), so it can be undone.
"""
from __future__ import annotations

import difflib
import uuid

from sqlalchemy import select

from ..config import get_settings
from ..connectors import get_connector
from ..connectors.base import lit
from ..dq.rules import fail_condition
from ..models import Asset, FixRun, Rule, audit, utcnow

RISKS = ["low", "medium", "high"]


def _escalate(risk: str, steps: int) -> str:
    return RISKS[min(RISKS.index(risk) + steps, 2)]


def _score(base: str, rows: int, total: int, asset: Asset) -> tuple[str, list[str]]:
    reasons, steps = [], 0
    share = rows / total if total else 0
    max_rows = int(get_settings().section("remediation").get("auto_correct_max_rows", 1000))
    if share > 0.05:
        steps += 1
        reasons.append(f"touches {share:.1%} of rows")
    if rows > max_rows:
        steps += 1
        reasons.append(f"more than {max_rows:,} rows")
    if asset.certified:
        steps += 1
        reasons.append("certified dataset")
    return _escalate(base, steps), reasons


def _total(conn, fqn) -> int:
    return int(conn.query(f"SELECT COUNT(*) AS n FROM {conn.dialect.table(fqn)}")[0]["n"])


def analyze_rule(db, rule: Rule, asset: Asset | None = None) -> list[dict]:
    asset = asset or db.get(Asset, rule.asset_id)
    conn = get_connector(asset.connection)
    if not conn.supports_sql:
        return []
    d, t = conn.dialect, conn.dialect.table(asset.fqn)
    out = []
    total = None
    if rule.type == "accepted_values":
        c = d.q(rule.column)
        allowed = [str(v) for v in rule.params["values"]]
        norm = {a.strip().lower(): a for a in allowed}
        bad = conn.query(f"SELECT {c} AS v, COUNT(*) AS n FROM {t} WHERE {fail_condition(rule, d)} GROUP BY {c} ORDER BY n DESC {d.limit(200)}")
        std, typo = {}, {}
        for r in bad:
            v = str(r["v"])
            key = v.strip().lower()
            if key in norm:
                std[v] = (norm[key], int(r["n"]))
            else:
                m = difflib.get_close_matches(key, list(norm), n=2, cutoff=0.8)
                if len(m) == 1:
                    typo[v] = (norm[m[0]], int(r["n"]))
        total = _total(conn, asset.fqn)
        for kind, mapping, base, label in (("standardize", std, "low", "Standardize case and spacing"),
                                           ("typo", typo, "medium", "Correct likely misspellings")):
            if not mapping:
                continue
            rows = sum(n for _, n in mapping.values())
            case = " ".join(f"WHEN {lit(k)} THEN {lit(v)}" for k, (v, _) in mapping.items())
            stmt = f"UPDATE {t} SET {c} = CASE {c} {case} ELSE {c} END WHERE {c} IN ({', '.join(lit(k) for k in mapping)})"
            risk, why = _score(base, rows, total, asset)
            out.append({"kind": kind, "title": f"{label} in {rule.column} ({rows:,} rows)", "rule_id": rule.id, "asset_id": asset.id,
                        "column": rule.column, "rows": rows, "risk": risk, "risk_reasons": why or [f"{base} risk: the intended value is unambiguous"
                                                                                                   if kind == "standardize" else "close spelling of an allowed value"],
                        "preview": [{"before": k, "after": v, "rows": n} for k, (v, n) in mapping.items()][:20], "statements": [stmt]})
    elif rule.type == "regex" and not (rule.params or {}).get("negate"):
        c = d.q(rule.column)
        cond = f"{fail_condition(rule, d)} AND {d.regex(f'TRIM({c})', rule.params['pattern'])}"
        sample = conn.query(f"SELECT {c} AS v, COUNT(*) AS n FROM {t} WHERE {cond} GROUP BY {c} ORDER BY n DESC {d.limit(10)}")
        rows = sum(int(r["n"]) for r in sample) and int(conn.query(f"SELECT COUNT(*) AS n FROM {t} WHERE {cond}")[0]["n"])
        if rows:
            total = _total(conn, asset.fqn)
            risk, why = _score("low", rows, total, asset)
            out.append({"kind": "trim", "title": f"Trim spaces in {rule.column} ({rows:,} rows)", "rule_id": rule.id, "asset_id": asset.id,
                        "column": rule.column, "rows": rows, "risk": risk,
                        "risk_reasons": why or ["only surrounding spaces change; values then match the pattern"],
                        "preview": [{"before": repr(str(r["v"])), "after": repr(str(r["v"]).strip()), "rows": int(r["n"])} for r in sample],
                        "statements": [f"UPDATE {t} SET {c} = TRIM({c}) WHERE {cond}"]})
    elif rule.type == "unique":
        total = _total(conn, asset.fqn)
        distinct = int(conn.query(f"SELECT COUNT(*) AS n FROM (SELECT DISTINCT * FROM {t}) x")[0]["n"])
        extra = total - distinct
        if extra > 0:
            risk, why = _score("low", extra, total, asset)
            out.append({"kind": "dedupe_exact", "title": f"Remove {extra:,} exact duplicate rows", "rule_id": rule.id, "asset_id": asset.id,
                        "column": None, "rows": extra, "risk": risk,
                        "risk_reasons": why or ["removed rows are identical copies; no information is lost"],
                        "preview": [{"before": f"{total:,} rows", "after": f"{distinct:,} rows", "rows": extra}],
                        "statements": [f"CREATE OR REPLACE TABLE {t} AS SELECT DISTINCT * FROM {t}"]})
    for f in out:
        f["id"] = f"{f['kind']}:{rule.id}"
        f["reversible"] = True
        f["auto_eligible"] = f["risk"] == "low"
    return out


def analyze_asset(db, asset: Asset) -> list[dict]:
    out = []
    for r in db.scalars(select(Rule).where(Rule.asset_id == asset.id, Rule.status == "active", Rule.last_status == "fail")):
        try:
            out += analyze_rule(db, r, asset)
        except Exception:
            continue
    return out


def analyze_incident(db, inc) -> list[dict]:
    out = []
    for rid in inc.rule_ids:
        r = db.get(Rule, rid)
        if r and r.status == "active":
            try:
                out += analyze_rule(db, r)
            except Exception:
                continue
    return out


def _snapshot(conn, fqn: str, key: str) -> str:
    d = conn.dialect
    if d.name == "spark":
        v = conn.query(f"DESCRIBE HISTORY {d.table(fqn)} LIMIT 1")
        if v:
            return f"delta_version:{v[0]['version']}"
    qs = get_settings().section("app").get("quarantine_schema", "dq_quarantine")
    parts = fqn.split(".")
    schema = ".".join(parts[:-2] + [qs]) if len(parts) >= 3 else qs
    snap = f"{schema}.{parts[-1]}_snap_{key}"
    conn.execute([f"CREATE SCHEMA IF NOT EXISTS {schema}", f"CREATE TABLE {snap} AS SELECT * FROM {d.table(fqn)}"])
    return snap


def apply(db, fix_id: str, actor: str, auto: bool = False, incident_id: int | None = None) -> FixRun:
    kind, _, rid = fix_id.partition(":")
    rule = db.get(Rule, int(rid))
    if not rule:
        raise ValueError("Rule not found")
    asset = db.get(Asset, rule.asset_id)
    fix = next((f for f in analyze_rule(db, rule, asset) if f["kind"] == kind), None)
    if not fix:
        raise ValueError("This correction no longer applies (the data changed). Refresh the suggestions.")
    if auto and fix["risk"] != "low":
        raise ValueError("Only low-risk corrections run automatically")
    conn = get_connector(asset.connection)
    key = uuid.uuid4().hex[:8]
    snap = _snapshot(conn, asset.fqn, key)
    conn.execute(fix["statements"])
    try:
        marker = conn.change_marker(asset.fqn)
    except Exception:
        marker = None
    fr = FixRun(asset_id=asset.id, rule_id=rule.id, incident_id=incident_id, kind=kind, title=fix["title"], risk=fix["risk"],
                rows=fix["rows"], statements=fix["statements"], snapshot=snap, marker_after=marker, auto=auto, actor=actor,
                detail={"preview": fix["preview"], "risk_reasons": fix["risk_reasons"]})
    db.add(fr)
    db.flush()
    audit(db, actor, "fix.applied" if not auto else "fix.auto_applied", asset.fqn, fix_run=fr.id, kind=kind, rows=fix["rows"], risk=fix["risk"])
    if incident_id:
        from ..models import Incident
        from .manager import add_event
        inc = db.get(Incident, incident_id)
        if inc:
            add_event(db, inc, "auto_corrected" if auto else "corrected", f"{fix['title']} (risk {fix['risk']}); undo is available", actor)
    return fr


def undo(db, fr: FixRun, actor: str, force: bool = False) -> FixRun:
    if fr.status != "applied":
        raise ValueError(f"This correction is {fr.status}")
    asset = db.get(Asset, fr.asset_id)
    conn = get_connector(asset.connection)
    try:
        now_marker = conn.change_marker(asset.fqn)
    except Exception:
        now_marker = None
    if not force and fr.marker_after and now_marker and now_marker != fr.marker_after:
        raise ValueError("The table changed after this correction. Undo would discard those later changes; confirm to undo anyway.")
    d = conn.dialect
    if fr.snapshot and fr.snapshot.startswith("delta_version:"):
        conn.execute([f"RESTORE TABLE {d.table(asset.fqn)} TO VERSION AS OF {int(fr.snapshot.split(':')[1])}"])
    elif fr.snapshot:
        conn.execute([f"CREATE OR REPLACE TABLE {d.table(asset.fqn)} AS SELECT * FROM {d.table(fr.snapshot)}"])
    fr.status, fr.undone_ts = "undone", utcnow()
    audit(db, actor, "fix.undone", asset.fqn, fix_run=fr.id, forced=force)
    return fr


def auto_correct(db, asset: Asset, failing_rule_ids: list[int], incident_ids: list[int]) -> list[FixRun]:
    from ..config import feature_on
    if not feature_on("fixes_and_quarantine"):
        return []
    rem = get_settings().section("remediation")
    if not rem.get("auto_correct_low_risk"):
        return []
    applied = []
    for rid in failing_rule_ids:
        rule = db.get(Rule, rid)
        if not rule:
            continue
        for f in analyze_rule(db, rule, asset):
            if f["risk"] == "low":
                try:
                    applied.append(apply(db, f["id"], "auto-correct", auto=True, incident_id=incident_ids[0] if incident_ids else None))
                except Exception:
                    continue
    return applied
