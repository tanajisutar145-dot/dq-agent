"""Ticket creation in Jira or ServiceNow. With no provider configured, returns a
dry-run preview of the payload instead of failing."""
from __future__ import annotations

import httpx

from ..config import get_settings, resolve_env

URGENCY = {"critical": "1", "high": "2", "medium": "3", "low": "3"}


def build_ticket(inc) -> dict:
    ev = "\n".join(f"- {e['at']} {e['asset']}: {e['rule']} - {e['message']}" for e in (inc.rca or {}).get("evidence", [])[:15])
    return {
        "summary": f"[DataTrustAI][{inc.severity}] {inc.title}"[:250],
        "description": f"{inc.summary or ''}\n\nAffected assets: {', '.join(inc.assets)}\n"
                       f"Downstream at risk: {', '.join(inc.downstream[:20]) or 'none'}\n\nEvidence:\n{ev}",
        "severity": inc.severity,
    }


def create_ticket(inc) -> dict:
    cfg = get_settings().section("ticketing")
    provider = cfg.get("provider", "none")
    t = build_ticket(inc)
    if provider == "jira":
        base = resolve_env(cfg, "base_url").rstrip("/")
        r = httpx.post(f"{base}/rest/api/2/issue", timeout=30,
                       auth=(resolve_env(cfg, "user"), resolve_env(cfg, "api_token")),
                       json={"fields": {"project": {"key": cfg["project_key"]}, "summary": t["summary"],
                                        "description": t["description"],
                                        "issuetype": {"name": cfg.get("issue_type", "Bug")},
                                        "labels": ["data-quality", f"dq-{inc.severity}"]}})
        r.raise_for_status()
        key = r.json()["key"]
        return {"provider": "jira", "key": key, "url": f"{base}/browse/{key}", "status": "created"}
    if provider == "servicenow":
        inst = resolve_env(cfg, "instance_url").rstrip("/")
        r = httpx.post(f"{inst}/api/now/table/incident", timeout=30,
                       auth=(resolve_env(cfg, "user"), resolve_env(cfg, "password")),
                       headers={"Accept": "application/json"},
                       json={"short_description": t["summary"], "description": t["description"],
                             "urgency": URGENCY.get(inc.severity, "3"),
                             "assignment_group": cfg.get("assignment_group")})
        r.raise_for_status()
        res = r.json()["result"]
        return {"provider": "servicenow", "key": res["number"], "url": f"{inst}/nav_to.do?uri=incident.do?sys_id={res['sys_id']}",
                "status": "created"}
    return {"provider": "none", "status": "dry_run", "preview": t,
            "note": "Set ticketing.provider to jira or servicenow in config.yaml to create real tickets"}
