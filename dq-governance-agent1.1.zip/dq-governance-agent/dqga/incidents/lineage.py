"""Lineage graph: sync from platforms, ingest OpenLineage / dbt, and traverse
for root-cause (upstream) and blast-radius (downstream) analysis."""
from __future__ import annotations

from collections import deque

from sqlalchemy import select

from ..models import Asset, Incident, LineageEdge, utcnow


def upsert_edge(db, source: str, target: str, origin: str, source_column: str = "", target_column: str = "") -> bool:
    if not source or not target or source == target:
        return False
    e = db.scalars(select(LineageEdge).where(LineageEdge.source == source, LineageEdge.target == target,
                                             LineageEdge.source_column == (source_column or ""),
                                             LineageEdge.target_column == (target_column or ""))).first()
    if e:
        e.updated = utcnow()
        return False
    db.add(LineageEdge(source=source, target=target, origin=origin, source_column=source_column or "",
                       target_column=target_column or ""))
    return True


def sync_from_connectors(db, connectors: dict) -> dict:
    added, errors = 0, {}
    for name, conn in connectors.items():
        if not conn.supports_lineage:
            continue
        try:
            for e in conn.get_lineage():
                added += upsert_edge(db, e["source"], e["target"], f"{conn.type}:{name}",
                                     e.get("source_column", ""), e.get("target_column", ""))
        except Exception as ex:
            errors[name] = f"{type(ex).__name__}: {ex}"[:300]
    db.flush()
    return {"added": added, "errors": errors}


def ingest_openlineage(db, event: dict) -> int:
    """OpenLineage RunEvent: inputs[] -> outputs[] (Spark listener, Airflow, dbt-ol)."""
    def name(ds):
        return ds.get("name", "").replace("/", ".")
    added = 0
    for i in event.get("inputs", []):
        for o in event.get("outputs", []):
            added += upsert_edge(db, name(i), name(o), "openlineage")
            cl = ((o.get("facets") or {}).get("columnLineage") or {}).get("fields", {})
            for tcol, spec in cl.items():
                for f in spec.get("inputFields", []):
                    added += upsert_edge(db, name(f), name(o), "openlineage", f.get("field", ""), tcol)
    db.flush()
    return added


def ingest_dbt_manifest(db, manifest: dict) -> int:
    nodes = {**manifest.get("nodes", {}), **manifest.get("sources", {})}

    def rel(uid):
        n = nodes.get(uid) or {}
        parts = [n.get("database"), n.get("schema"), n.get("alias") or n.get("identifier") or n.get("name")]
        return ".".join(p for p in parts if p)
    added = 0
    for child, parents in manifest.get("parent_map", {}).items():
        if not child.startswith(("model.", "snapshot.", "seed.")):
            continue
        for p in parents:
            if p.startswith(("model.", "source.", "seed.", "snapshot.")):
                added += upsert_edge(db, rel(p), rel(child), "dbt")
    db.flush()
    return added


def _adjacency(db):
    up, down = {}, {}
    for e in db.scalars(select(LineageEdge).where(LineageEdge.source_column == "")):
        down.setdefault(e.source, set()).add(e.target)
        up.setdefault(e.target, set()).add(e.source)
    return up, down


def traverse(db, fqn: str, direction: str = "both", depth: int = 5) -> dict[str, int]:
    """Return {fqn: signed distance}; negative = upstream, positive = downstream."""
    up, down = _adjacency(db)
    out = {fqn: 0}
    for adj, sign in ((up, -1), (down, 1)):
        if direction == "upstream" and sign == 1 or direction == "downstream" and sign == -1:
            continue
        q, seen = deque([(fqn, 0)]), {fqn}
        while q:
            node, dist = q.popleft()
            if dist >= depth:
                continue
            for nxt in adj.get(node, ()):
                if nxt not in seen:
                    seen.add(nxt)
                    out.setdefault(nxt, sign * (dist + 1))
                    q.append((nxt, dist + 1))
    return out


def upstream(db, fqn, depth=10):
    return {k: -v for k, v in traverse(db, fqn, "upstream", depth).items() if v < 0}


def downstream(db, fqn, depth=10):
    return {k: v for k, v in traverse(db, fqn, "downstream", depth).items() if v > 0}


def graph(db, fqn: str | None = None, depth: int = 3) -> dict:
    assets = {a.fqn: a for a in db.scalars(select(Asset))}
    open_inc = {}
    for inc in db.scalars(select(Incident).where(Incident.status.in_(["open", "ack"]))):
        for f in inc.assets:
            open_inc[f] = max(open_inc.get(f, 0), {"critical": 4, "high": 3, "medium": 2, "low": 1}.get(inc.severity, 1))
        open_inc[inc.root_fqn] = max(open_inc.get(inc.root_fqn, 0), 5)
    if fqn:
        dist = traverse(db, fqn, "both", depth)
        names = set(dist)
    else:
        dist = {}
        names = set(assets)
        for e in db.scalars(select(LineageEdge).where(LineageEdge.source_column == "")):
            names |= {e.source, e.target}
    edges = [{"source": e.source, "target": e.target, "origin": e.origin}
             for e in db.scalars(select(LineageEdge).where(LineageEdge.source_column == ""))
             if e.source in names and e.target in names]
    nodes = []
    for n in sorted(names):
        a = assets.get(n)
        health = "unknown"
        if a and a.score is not None:
            health = "healthy" if a.score >= 95 else "warning" if a.score >= 80 else "failing"
        if open_inc.get(n, 0) >= 5:
            health = "root_cause"
        elif open_inc.get(n):
            health = "failing" if health != "unknown" else "impacted"
        nodes.append({"id": n, "asset_id": a.id if a else None, "platform": a.platform if a else n.split(":")[0],
                      "score": a.score if a else None, "health": health, "distance": dist.get(n)})
    return {"nodes": nodes, "edges": edges, "focus": fqn}
