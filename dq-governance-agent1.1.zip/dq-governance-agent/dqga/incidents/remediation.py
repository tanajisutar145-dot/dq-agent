"""Fix suggestions and guarded execution.

Suggestions are concrete (SQL in the platform dialect, a job to re-run, an
extractor to restart). Execution always:
  1. counts affected rows first (dry run),
  2. refuses automatic execution unless the action type is allow-listed,
     the row count is under the limit, and the asset is not certified,
  3. writes an audit record.
Anything outside the guardrails is skipped (and logged); a person can run it from the incident.
"""
from __future__ import annotations

from sqlalchemy import select

from ..config import get_settings
from ..connectors import get_connector
from ..dq.rules import RULE_TYPES, fail_condition
from ..models import Asset, Rule, audit


def quarantine_condition(rule: Rule, d) -> str | None:
    """Row predicate selecting the bad rows, for row-level rules and orphan keys."""
    if RULE_TYPES[rule.type]["row_level"]:
        return fail_condition(rule, d)
    if rule.type == "referential":
        c, p = d.q(rule.column), rule.params
        return (f"{c} IS NOT NULL AND {c} NOT IN (SELECT {d.q(p['ref_column'])} FROM {d.table(p['ref_table'])} "
                f"WHERE {d.q(p['ref_column'])} IS NOT NULL)")
    return None


def suggestions_for_rule(rule: Rule, asset: Asset) -> list[dict]:
    try:
        conn = get_connector(asset.connection)
    except KeyError:
        return []
    d = conn.dialect
    qschema = get_settings().section("app").get("quarantine_schema", "dq_quarantine")
    out = []
    table = asset.fqn
    short = table.split(".")[-1]
    prefix = ".".join(table.split(".")[:-2] + [qschema]) if table.count(".") >= 2 else qschema
    cond = quarantine_condition(rule, d) if conn.supports_sql else None
    if cond:
        q = f"{prefix}.{short}_quarantine"
        out.append({
            "kind": "quarantine", "rule_id": rule.id, "asset": table,
            "title": f"Move rows failing '{rule.name}' to {q}",
            "count_sql": f"SELECT COUNT(*) AS n FROM {table} WHERE {cond}",
            "statements": [f"CREATE SCHEMA IF NOT EXISTS {prefix}",
                           f"CREATE TABLE IF NOT EXISTS {q} AS SELECT * FROM {table} WHERE 1 = 0",
                           f"INSERT INTO {q} SELECT * FROM {table} WHERE {cond}",
                           f"DELETE FROM {table} WHERE {cond}"],
            "reversible": d.name == "spark",
            "risk": "medium",
            "note": "Reversible with Delta time travel (RESTORE TABLE)" if d.name == "spark" else
                    "Rows are copied to the quarantine table before deletion",
        })
    if conn.supports_sql and rule.type == "unique":
        keys = ", ".join(d.q(c) for c in rule.params["columns"])
        try:
            star = d.star_except("_dq_rn")
            out.append({
                "kind": "dedupe", "rule_id": rule.id, "asset": table,
                "title": f"Remove duplicates on ({', '.join(rule.params['columns'])}), keep first",
                "count_sql": f"SELECT COALESCE(SUM(c - 1), 0) AS n FROM (SELECT COUNT(*) AS c FROM {table} GROUP BY {keys} HAVING COUNT(*) > 1) x",
                "statements": [f"CREATE OR REPLACE TABLE {table} AS SELECT {star} FROM (SELECT *, ROW_NUMBER() OVER "
                               f"(PARTITION BY {keys} ORDER BY {keys}) AS _dq_rn FROM {table}) t WHERE _dq_rn = 1"],
                "reversible": d.name == "spark", "risk": "high",
                "note": "Rewrites the table; take a snapshot first if the platform has no time travel",
            })
        except NotImplementedError:
            pass
    job = (asset.tags or {}).get("pipeline_job_id")
    if job and rule.type in ("freshness", "anomaly", "row_count", "not_null", "referential"):
        out.append({"kind": "rerun_job", "rule_id": rule.id, "asset": table, "job": job,
                    "title": f"Re-run pipeline job {job} to backfill {short}", "reversible": True, "risk": "low"})
    if rule.type == "timeseries" or asset.platform == "cognite":
        out.append({"kind": "notify_owner", "rule_id": rule.id, "asset": table,
                    "title": "Ask the OT / source-system owner to check the sensor or extractor",
                    "reversible": True, "risk": "low"})
    if rule.type == "schema":
        out.append({"kind": "notify_owner", "rule_id": rule.id, "asset": table,
                    "title": "Raise a contract breach with the upstream producer", "reversible": True, "risk": "low"})
    return out


def suggestions_for_incident(db, inc) -> list[dict]:
    from ..config import feature_on
    out = _suggestions_for_incident(db, inc)
    return out if feature_on("fixes_and_quarantine") else [s for s in out if s.get("kind") != "quarantine"]


def _suggestions_for_incident(db, inc) -> list[dict]:
    out, seen = [], set()
    for rid in inc.rule_ids:
        rule = db.get(Rule, rid)
        if not rule:
            continue
        asset = db.get(Asset, rule.asset_id)
        for s in suggestions_for_rule(rule, asset):
            key = (s["kind"], s["asset"], s.get("rule_id"))
            if key not in seen:
                seen.add(key)
                s["incident_id"] = inc.id
                out.append(s)
    root_rules = [s for s in out if s["asset"] == inc.root_fqn]
    return root_rules + [s for s in out if s["asset"] != inc.root_fqn]


def dry_run(action: dict) -> int | None:
    if not action.get("count_sql"):
        return None
    asset_conn = action.get("connection")
    conn = get_connector(asset_conn)
    return int(conn.query(action["count_sql"])[0]["n"])


def execute(db, action: dict, actor: str, auto: bool = False) -> dict:
    asset = db.scalars(select(Asset).where(Asset.fqn == action["asset"])).first()
    if not asset:
        raise ValueError(f"Unknown asset {action['asset']}")
    action = {**action, "connection": asset.connection}
    conn = get_connector(asset.connection)
    rem = get_settings().section("remediation")
    rows = dry_run(action)
    if auto:
        reasons = []
        if not rem.get("auto_enabled"):
            reasons.append("auto-remediation disabled")
        if action["kind"] not in rem.get("allowed_auto_actions", []):
            reasons.append(f"{action['kind']} not allow-listed")
        if rows is not None and rows > int(rem.get("max_rows_auto", 10000)):
            reasons.append(f"{rows} rows exceeds limit {rem.get('max_rows_auto')}")
        if asset.certified:
            reasons.append("asset is certified")
        if reasons:  # an automatic run outside its guardrails does nothing; a person can run it from the incident
            audit(db, "auto-remediation", "remediation.skipped", asset.fqn, reasons=reasons, title=action["title"])
            return {"status": "skipped", "reasons": reasons, "rows": rows}
    result: dict = {"rows_affected_estimate": rows}
    if action["kind"] == "quarantine":
        from .quarantine import quarantine as quarantine_rows
        rule = db.get(Rule, action["rule_id"])
        b = quarantine_rows(db, asset, rule, actor, mode=action.get("mode", "move"), target=action.get("target"),
                            clean_table=action.get("clean_table"), incident_id=action.get("incident_id"))
        result.update({"batch": b.batch_key, "quarantine_table": b.target_table, "mode": b.mode, "rows": b.rows,
                       "clean_table": b.clean_table})
    elif action["kind"] == "dedupe":
        result["executed"] = conn.execute(action["statements"])
    elif action["kind"] == "rerun_job":
        result["job_run"] = conn.run_job(action["job"])
    elif action["kind"] == "notify_owner":
        from .notify import send
        result["notified"] = send(db, f"Action needed on {asset.fqn}", action["title"], severity="medium")
    else:
        raise ValueError(f"Unknown remediation kind {action['kind']}")
    audit(db, actor, f"remediation.{action['kind']}", asset.fqn, rows=rows, auto=auto, title=action["title"])
    db.flush()
    return {"status": "executed", **{k: v for k, v in result.items() if k != "executed"},
            "statements": action.get("statements", [])}
