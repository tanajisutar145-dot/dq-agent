"""Incident management: grouping, severity, root-cause analysis, lifecycle.

Failures that share a root cause become ONE incident: when a failing asset
has failing assets upstream (via lineage, within the last 24h), the most
upstream failing asset is the root, and the incident key is root + day.
"""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import select

from ..config import get_settings
from ..models import Asset, CheckResult, Incident, IncidentEvent, Rule, audit, utcnow
from . import lineage as L

SEV_ORDER = ["low", "medium", "high", "critical"]


def _sev_max(*sevs):
    return max(sevs, key=lambda s: SEV_ORDER.index(s) if s in SEV_ORDER else 0)


def compute_severity(rule_sevs: list[str], downstream_count: int, certified: bool) -> str:
    base = _sev_max(*rule_sevs) if rule_sevs else "low"
    idx = SEV_ORDER.index(base)
    if downstream_count >= 10:
        idx += 1
    if certified:
        idx += 1
    return SEV_ORDER[min(idx, 3)]


# Which upstream failure dimensions can explain a downstream failure in a given dimension.
CAUSES = {
    "completeness": {"completeness", "volume", "timeliness", "schema", "plausibility"},
    "volume": {"volume", "timeliness", "completeness", "schema"},
    "timeliness": {"timeliness", "volume"},
    "validity": {"validity", "schema", "plausibility"},
    "consistency": {"completeness", "volume", "timeliness", "validity", "consistency", "uniqueness"},
    "uniqueness": {"uniqueness"},
    "integrity": {"integrity", "completeness", "volume", "timeliness"},
    "accuracy": {"accuracy", "validity", "plausibility"},
    "schema": {"schema"},
    "plausibility": {"plausibility"},
}


def _failing_dims_recent(db, hours=24) -> dict[str, set[str]]:
    """fqn -> dimensions of checks that failed in the window and are still failing."""
    since = utcnow() - timedelta(hours=hours)
    out: dict[str, set[str]] = {}
    for r in db.scalars(select(CheckResult).where(CheckResult.ts >= since, CheckResult.status == "fail")):
        rule = db.get(Rule, r.rule_id)
        a = db.get(Asset, r.asset_id)
        if rule and a and rule.last_status == "fail":
            out.setdefault(a.fqn, set()).add(rule.dimension)
    return out


def find_root(db, fqn: str, dims: set[str] | None = None) -> tuple[str, list[str]]:
    """Walk upstream only through failing assets whose failure can explain the symptom
    (see CAUSES); the farthest such asset is the root. A failing table behind a healthy
    one, or failing for an unrelated reason (e.g. orphan keys vs missing values), is not blamed."""
    failing = _failing_dims_recent(db)
    up, _ = L._adjacency(db)
    dims = set(dims or failing.get(fqn, set()))
    frontier, dist, chain = [(fqn, dims)], {fqn: 0}, []
    while frontier:
        nxt = []
        for node, node_dims in frontier:
            explainable = set().union(*(CAUSES.get(d, {d}) for d in node_dims)) if node_dims else set()
            for parent in sorted(up.get(node, ())):
                pdims = failing.get(parent)
                if pdims and parent not in dist and pdims & explainable:
                    dist[parent] = dist[node] + 1
                    chain.append(parent)
                    nxt.append((parent, pdims))
        frontier = nxt
    if chain:
        root = sorted(chain, key=lambda f: (-dist[f], f))[0]
        return root, sorted(chain, key=lambda f: (-dist[f], f))
    return fqn, []


def add_event(db, inc: Incident, kind: str, text: str, actor: str = "system") -> None:
    db.add(IncidentEvent(incident_id=inc.id, kind=kind, text=text, actor=actor))
    inc.updated = utcnow()


def process_results(db, asset: Asset, results: list[CheckResult]) -> list[int]:
    failing = [r for r in results if r.status == "fail"]
    touched = []
    # auto-resolve incidents where every rule for this asset now passes
    passing_rules = {r.rule_id for r in results if r.status == "pass"}
    for inc in db.scalars(select(Incident).where(Incident.status.in_(["open", "ack"]))):
        mine = [rid for rid in inc.rule_ids if db.get(Rule, rid) and db.get(Rule, rid).asset_id == asset.id]
        if mine and all(rid in passing_rules for rid in mine):
            others = [rid for rid in inc.rule_ids if rid not in mine]
            still_failing = [rid for rid in others if (db.get(Rule, rid) and db.get(Rule, rid).last_status == "fail")]
            if not still_failing:
                inc.status, inc.resolved_at = "resolved", utcnow()
                add_event(db, inc, "auto_resolved", "All checks passing again")
                touched.append(inc.id)
    if not failing:
        db.flush()
        return touched

    rules = [db.get(Rule, r.rule_id) for r in failing]
    root, chain = find_root(db, asset.fqn, {r.dimension for r in rules})
    key = f"{root}|{utcnow().date().isoformat()}"
    inc = db.scalars(select(Incident).where(Incident.key == key, Incident.status.in_(["open", "ack", "muted"]))).first()
    down = sorted(L.downstream(db, root).keys())
    root_asset = db.scalars(select(Asset).where(Asset.fqn == root)).first()
    certified = bool((root_asset and root_asset.certified) or asset.certified)
    sev = compute_severity([r.severity for r in rules], len(down), certified)
    msgs = "; ".join(f"{r.name}: {c.message}" for r, c in zip(rules, failing))[:1500]
    if inc is None:
        title = (f"{asset.fqn}: {rules[0].name}" if len(rules) == 1 else f"{asset.fqn}: {len(rules)} checks failing")
        if root != asset.fqn:
            title = f"Upstream issue in {root} affecting {asset.fqn}"
        inc = Incident(key=key, title=title[:500], severity=sev, root_fqn=root, assets=[asset.fqn],
                       rule_ids=[r.id for r in rules], downstream=down,
                       assignee=(root_asset.owner if root_asset else None) or asset.owner)
        db.add(inc)
        db.flush()
        add_event(db, inc, "opened", msgs)
        audit(db, "system", "incident.opened", asset.fqn, incident_id=inc.id, severity=sev)
        new = True
    else:
        if asset.fqn not in inc.assets:
            inc.assets = inc.assets + [asset.fqn]
            add_event(db, inc, "grouped", f"{asset.fqn} grouped under root cause {root}")
        new_rules = [r.id for r in rules if r.id not in inc.rule_ids]
        if new_rules:
            inc.rule_ids = inc.rule_ids + new_rules
            add_event(db, inc, "new_failures", msgs)
        inc.severity = _sev_max(inc.severity, sev)
        inc.downstream = sorted(set(inc.downstream) | set(down))
        if inc.status == "resolved":
            inc.status = "open"
        new = False
    inc.rca = analyze(db, inc)
    inc.summary = inc.rca.get("narrative")
    touched.append(inc.id)
    db.flush()
    if new and inc.status != "muted":
        from .notify import notify_incident
        notify_incident(db, inc)
    return touched


def analyze(db, inc: Incident) -> dict:
    """Deterministic RCA: evidence from checks, metrics, lineage. The agent can narrate on top."""
    evidence = []
    since = utcnow() - timedelta(hours=24)
    involved = set(inc.assets) | {inc.root_fqn} | set(L.upstream(db, inc.root_fqn).keys())
    for fqn in involved:
        a = db.scalars(select(Asset).where(Asset.fqn == fqn)).first()
        if not a:
            continue
        for cr in db.scalars(select(CheckResult).where(CheckResult.asset_id == a.id, CheckResult.ts >= since,
                                                      CheckResult.status == "fail").order_by(CheckResult.ts)):
            rule = db.get(Rule, cr.rule_id)
            evidence.append({"asset": fqn, "rule": rule.name if rule else cr.rule_id, "type": rule.type if rule else None,
                             "dimension": rule.dimension if rule else None, "message": cr.message,
                             "at": cr.ts.isoformat(timespec="seconds"), "is_root": fqn == inc.root_fqn})
    evidence.sort(key=lambda e: e["at"])
    first = evidence[0] if evidence else None
    kinds = {e["type"] for e in evidence if e["is_root"]}
    hypothesis = "Data defect in the root asset"
    if kinds & {"freshness"}:
        hypothesis = "Late or failed load upstream (freshness breach at the root)"
    elif kinds & {"anomaly", "row_count"}:
        hypothesis = "Partial load or dropped partition upstream (volume anomaly at the root)"
    elif kinds & {"schema"}:
        hypothesis = "Upstream schema change"
    elif kinds & {"timeseries"}:
        hypothesis = "Sensor / extractor problem in the source system"
    elif kinds & {"referential"}:
        hypothesis = "Reference data out of sync (orphan keys)"
    elif kinds & {"unique"}:
        hypothesis = "Duplicate load or broken merge key"
    narrative = (f"Root cause candidate: {inc.root_fqn}. Hypothesis: {hypothesis}. "
                 + (f"First failure: {first['rule']} on {first['asset']} at {first['at']} ({first['message']}). " if first else "")
                 + f"{len(inc.assets)} asset(s) affected; {len(inc.downstream)} downstream asset(s) at risk.")
    return {"root": inc.root_fqn, "hypothesis": hypothesis, "evidence": evidence[:40],
            "downstream": inc.downstream, "narrative": narrative}


def act(db, inc: Incident, action: str, actor: str, assignee: str | None = None, note: str | None = None) -> Incident:
    if action == "ack":
        inc.status = "ack"
    elif action == "assign":
        inc.assignee = assignee
    elif action == "resolve":
        inc.status, inc.resolved_at = "resolved", utcnow()
    elif action == "mute":
        inc.status = "muted"
    elif action == "reopen":
        inc.status, inc.resolved_at = "open", None
    elif action != "comment":
        raise ValueError(f"Unknown action {action}")
    add_event(db, inc, action, note or (f"Assigned to {assignee}" if action == "assign" else action), actor)
    audit(db, actor, f"incident.{action}", inc.root_fqn, incident_id=inc.id, note=note)
    db.flush()
    return inc


def mttr_hours(db) -> float | None:
    rs = [i for i in db.scalars(select(Incident).where(Incident.status == "resolved", Incident.resolved_at.is_not(None)))]
    if not rs:
        return None
    return round(sum((i.resolved_at - i.created).total_seconds() for i in rs) / len(rs) / 3600, 2)


__all__ = ["process_results", "analyze", "act", "find_root", "compute_severity", "mttr_hours", "get_settings"]
