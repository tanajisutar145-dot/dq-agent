"""Quarantine management for bad rows.

Modes:
  move   copy failing rows to the quarantine table, then delete them from the source (default)
  copy   copy failing rows to the quarantine table; the source is untouched (inspect first)
  split  source untouched; good rows are written to a separate clean table and bad rows
         to the quarantine table, so consumers can switch to the clean table

Every batch adds _dq_batch, _dq_rule, _dq_reason and _dq_quarantined_at columns, so
rows can be traced, released back (after re-checking them against the rule) or purged.
"""
from __future__ import annotations

import re
import uuid
from datetime import timedelta

from sqlalchemy import select

from ..config import get_settings
from ..connectors import get_connector
from ..connectors.base import FQN_RE, lit
from ..dq.rules import RULE_TYPES
from ..models import Asset, Classification, QuarantineBatch, Rule, audit, utcnow
from .remediation import quarantine_condition

META_COLS = ["_dq_batch", "_dq_rule", "_dq_reason", "_dq_quarantined_at"]
MODES = ("move", "copy", "split")


def default_target(asset: Asset) -> str:
    qs = get_settings().section("app").get("quarantine_schema", "dq_quarantine")
    parts = asset.fqn.split(".")
    prefix = ".".join(parts[:-2] + [qs]) if len(parts) >= 3 else qs
    return f"{prefix}.{parts[-1]}_quarantine"


def default_clean(asset: Asset) -> str:
    return f"{asset.fqn}_clean"


def _check_table(name: str) -> str:
    if not name or not FQN_RE.match(name) or name.count(".") > 2 or not re.match(r"^[A-Za-z_]", name.split(".")[-1]):
        raise ValueError(f"Invalid table name {name!r}. Use catalog.schema.table.")
    return name


def can_quarantine(rule: Rule) -> bool:
    return RULE_TYPES[rule.type]["row_level"] or rule.type == "referential"


def plan(db, asset: Asset, rule: Rule, mode: str = "move", target: str | None = None, clean_table: str | None = None) -> dict:
    if mode not in MODES:
        raise ValueError(f"Mode must be one of {', '.join(MODES)}")
    if not can_quarantine(rule):
        raise ValueError(f"Rows can't be quarantined for a {rule.type} rule")
    conn = get_connector(asset.connection)
    d = conn.dialect
    cond = quarantine_condition(rule, d)
    target = _check_table(target or default_target(asset))
    clean = _check_table(clean_table or default_clean(asset)) if mode == "split" else None
    if target == asset.fqn or clean == asset.fqn:
        raise ValueError("The quarantine and clean tables must differ from the source table")
    rows = int(conn.query(f"SELECT COUNT(*) AS n FROM {d.table(asset.fqn)} WHERE COALESCE(({cond}), FALSE)")[0]["n"])
    return {"rows": rows, "condition": cond, "target": target, "clean_table": clean, "mode": mode}


def quarantine(db, asset: Asset, rule: Rule, actor: str, mode: str = "move", target: str | None = None,
               clean_table: str | None = None, incident_id: int | None = None, note: str | None = None) -> QuarantineBatch:
    p = plan(db, asset, rule, mode, target, clean_table)
    if p["rows"] == 0:
        raise ValueError("No rows currently fail this rule, so there is nothing to quarantine.")
    conn = get_connector(asset.connection)
    d = conn.dialect
    src, tgt, cond = d.table(asset.fqn), p["target"], p["condition"]
    key = uuid.uuid4().hex[:12]
    reason = (note or rule.name)[:300]
    st = d.string_type
    schema = ".".join(tgt.split(".")[:-1])
    stmts = []
    if schema:
        stmts.append(f"CREATE SCHEMA IF NOT EXISTS {schema}")
    stmts.append(f"CREATE TABLE IF NOT EXISTS {tgt} AS SELECT s.*, CAST(NULL AS {st}) AS _dq_batch, CAST(NULL AS {st}) AS _dq_rule, "
                 f"CAST(NULL AS {st}) AS _dq_reason, CAST(NULL AS TIMESTAMP) AS _dq_quarantined_at FROM {src} s WHERE 1 = 0")
    stmts.append(f"INSERT INTO {tgt} SELECT s.*, {lit(key)}, {lit(rule.name[:200])}, {lit(reason)}, {d.now()} "
                 f"FROM {src} s WHERE COALESCE(({cond}), FALSE)")
    if p["mode"] == "move":
        stmts.append(f"DELETE FROM {src} WHERE COALESCE(({cond}), FALSE)")
    elif p["mode"] == "split":
        stmts.append(f"CREATE OR REPLACE TABLE {p['clean_table']} AS SELECT * FROM {src} WHERE NOT COALESCE(({cond}), FALSE)")
    conn.execute(stmts)
    days = int(get_settings().section("remediation").get("quarantine_retention_days", 30))
    b = QuarantineBatch(batch_key=key, asset_id=asset.id, rule_id=rule.id, incident_id=incident_id, mode=p["mode"],
                        target_table=tgt, clean_table=p["clean_table"], condition=cond, rows=p["rows"], reason=reason, actor=actor,
                        expires=utcnow() + timedelta(days=days) if days > 0 else None,
                        history=[{"at": utcnow().isoformat(timespec="seconds"), "actor": actor, "action": "quarantined", "rows": p["rows"]}])
    db.add(b)
    db.flush()
    audit(db, actor, "quarantine.created", asset.fqn, batch=key, rows=p["rows"], mode=p["mode"], quarantine_table=tgt, rule=rule.name)
    if incident_id:
        from ..models import Incident
        from .manager import add_event
        inc = db.get(Incident, incident_id)
        if inc:
            add_event(db, inc, "quarantine", f"{p['rows']:,} rows quarantined ({p['mode']}) to {tgt}, batch {key}", actor)
    return b


def _pii_columns(db, asset_id: int) -> set[str]:
    return {c.column for c in db.scalars(select(Classification).where(Classification.asset_id == asset_id,
                                                                     Classification.status != "rejected"))}


def rows(db, b: QuarantineBatch, limit: int = 50, unmask: bool = False) -> dict:
    asset = db.get(Asset, b.asset_id)
    conn = get_connector(asset.connection)
    data = conn.query(f"SELECT * FROM {conn.dialect.table(b.target_table)} WHERE _dq_batch = {lit(b.batch_key)} {conn.dialect.limit(limit)}") \
        if b.status != "purged" else []
    pii = set() if unmask else _pii_columns(db, b.asset_id)
    out = [{k: ("••••" if k in pii and v is not None else (v.isoformat(sep=' ') if hasattr(v, "isoformat") else v)) for k, v in r.items()}
           for r in data]
    return {"columns": list(out[0].keys()) if out else [c["name"] for c in asset.columns] + META_COLS, "rows": out,
            "masked": sorted(pii)}


def remaining(db, b: QuarantineBatch) -> int:
    asset = db.get(Asset, b.asset_id)
    conn = get_connector(asset.connection)
    return int(conn.query(f"SELECT COUNT(*) AS n FROM {conn.dialect.table(b.target_table)} WHERE _dq_batch = {lit(b.batch_key)}")[0]["n"])


def release(db, b: QuarantineBatch, actor: str, revalidate: bool = True) -> dict:
    """Put rows back. With revalidate, only rows that now pass the rule go back; the rest stay quarantined."""
    if b.status in ("released", "purged"):
        raise ValueError(f"Batch is already {b.status}")
    asset, rule = db.get(Asset, b.asset_id), db.get(Rule, b.rule_id) if b.rule_id else None
    conn = get_connector(asset.connection)
    d = conn.dialect
    cols = ", ".join(d.q(c["name"]) for c in asset.columns or [])
    cond = quarantine_condition(rule, d) if (revalidate and rule) else None
    where = f"_dq_batch = {lit(b.batch_key)}" + (f" AND NOT COALESCE(({cond}), FALSE)" if cond else "")
    n = int(conn.query(f"SELECT COUNT(*) AS n FROM {d.table(b.target_table)} WHERE {where}")[0]["n"])
    stmts = []
    if n:
        if b.mode == "move":
            stmts.append(f"INSERT INTO {d.table(asset.fqn)} ({cols}) SELECT {cols} FROM {d.table(b.target_table)} WHERE {where}")
        elif b.mode == "split" and b.clean_table:
            stmts.append(f"INSERT INTO {d.table(b.clean_table)} ({cols}) SELECT {cols} FROM {d.table(b.target_table)} WHERE {where}")
        stmts.append(f"DELETE FROM {d.table(b.target_table)} WHERE {where}")
        conn.execute(stmts)
    left = remaining(db, b)
    b.released = (b.released or 0) + n
    b.status = "released" if left == 0 else ("partially_released" if b.released else b.status)
    b.history = (b.history or []) + [{"at": utcnow().isoformat(timespec="seconds"), "actor": actor,
                                      "action": "released" if revalidate else "force_released", "rows": n, "remaining": left}]
    audit(db, actor, "quarantine.released", asset.fqn, batch=b.batch_key, rows=n, remaining=left, revalidated=revalidate)
    note = ("Copy mode: the source was never changed, so these rows were only removed from quarantine."
            if b.mode == "copy" else None)
    return {"released": n, "remaining": left, "status": b.status, "note": note}


def purge(db, b: QuarantineBatch, actor: str) -> dict:
    if b.status == "purged":
        raise ValueError("Batch is already purged")
    asset = db.get(Asset, b.asset_id)
    conn = get_connector(asset.connection)
    left = remaining(db, b)
    conn.execute([f"DELETE FROM {conn.dialect.table(b.target_table)} WHERE _dq_batch = {lit(b.batch_key)}"])
    b.status = "purged"
    b.history = (b.history or []) + [{"at": utcnow().isoformat(timespec="seconds"), "actor": actor, "action": "purged", "rows": left}]
    audit(db, actor, "quarantine.purged", asset.fqn, batch=b.batch_key, rows=left)
    return {"purged": left}


def expire(db) -> int:
    n = 0
    for b in db.scalars(select(QuarantineBatch).where(QuarantineBatch.status.in_(["quarantined", "partially_released"]),
                                                      QuarantineBatch.expires.is_not(None), QuarantineBatch.expires < utcnow())):
        try:
            purge(db, b, "retention")
            n += 1
        except Exception:
            pass
    return n


def summary(db) -> dict:
    bs = db.scalars(select(QuarantineBatch)).all()
    live = [b for b in bs if b.status in ("quarantined", "partially_released")]
    return {"batches": len(bs), "open_batches": len(live), "rows_held": sum(b.rows - (b.released or 0) for b in live),
            "released_rows": sum(b.released or 0 for b in bs), "purged_batches": sum(1 for b in bs if b.status == "purged"),
            "datasets": len({b.asset_id for b in live})}
