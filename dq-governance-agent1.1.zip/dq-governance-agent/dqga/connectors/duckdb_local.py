"""Local DuckDB connector: runs the whole product offline against a demo warehouse.

It emulates the platform metadata Databricks exposes (lineage system table,
tags) inside a `dq_meta` schema so every flow can be exercised locally.
"""
from __future__ import annotations

import threading
from datetime import date, datetime
from decimal import Decimal

from .base import AssetInfo, ColumnInfo, Connector, DuckDBDialect, lit


def _clean(v):
    if isinstance(v, Decimal):
        return float(v)
    return v


class DuckDBConnector(Connector):
    type = "duckdb"
    dialect = DuckDBDialect()
    supports_tags = True
    supports_lineage = True
    supports_timeseries = True

    def __init__(self, name: str, config: dict):
        super().__init__(name, config)
        import duckdb

        self.path = config["path"]
        self._con = duckdb.connect(self.path)
        self._lock = threading.Lock()
        self._con.execute("CREATE SCHEMA IF NOT EXISTS dq_meta")
        self._con.execute("CREATE TABLE IF NOT EXISTS dq_meta.tags (fqn VARCHAR, column_name VARCHAR, key VARCHAR, value VARCHAR)")
        self._con.execute("CREATE TABLE IF NOT EXISTS dq_meta.lineage (source VARCHAR, target VARCHAR)")

    def close(self):
        with self._lock:
            self._con.close()

    def query(self, sql: str) -> list[dict]:
        with self._lock:
            cur = self._con.cursor()
            try:
                cur.execute(sql)
                if cur.description is None:
                    return []
                cols = [d[0] for d in cur.description]
                return [{c: _clean(v) for c, v in zip(cols, row)} for row in cur.fetchall()]
            finally:
                cur.close()

    def test(self) -> dict:
        self.query("SELECT 1")
        return {"ok": True, "detail": f"DuckDB file {self.path}"}

    def _catalog_filter(self) -> str:
        cats = self.config.get("catalogs")
        return f" AND table_catalog IN ({', '.join(lit(c) for c in cats)})" if cats else ""

    def list_assets(self) -> list[AssetInfo]:
        tables = self.query(
            "SELECT table_catalog, table_schema, table_name, table_type FROM information_schema.tables "
            "WHERE table_schema NOT IN ('information_schema', 'pg_catalog', 'dq_meta')" + self._catalog_filter()
        )
        cols = self.query(
            "SELECT table_catalog, table_schema, table_name, column_name, data_type, is_nullable "
            "FROM information_schema.columns WHERE table_schema NOT IN ('information_schema', 'pg_catalog', 'dq_meta')"
            + self._catalog_filter() + " ORDER BY ordinal_position"
        )
        by_table: dict[str, list[ColumnInfo]] = {}
        for c in cols:
            fqn = f"{c['table_catalog']}.{c['table_schema']}.{c['table_name']}"
            by_table.setdefault(fqn, []).append(ColumnInfo(c["column_name"], c["data_type"], c["is_nullable"] == "YES"))
        out = []
        for t in tables:
            fqn = f"{t['table_catalog']}.{t['table_schema']}.{t['table_name']}"
            out.append(AssetInfo(fqn=fqn, kind="view" if "VIEW" in t["table_type"] else "table",
                                 columns=by_table.get(fqn, []), tags=self.get_tags(fqn),
                                 change_marker=self.change_marker(fqn)))
        return out

    def get_columns(self, fqn: str) -> list[ColumnInfo]:
        cat, sch, tbl = fqn.split(".")
        rows = self.query(
            "SELECT column_name, data_type, is_nullable FROM information_schema.columns "
            f"WHERE table_catalog={lit(cat)} AND table_schema={lit(sch)} AND table_name={lit(tbl)} ORDER BY ordinal_position"
        )
        return [ColumnInfo(r["column_name"], r["data_type"], r["is_nullable"] == "YES") for r in rows]

    def get_lineage(self) -> list[dict]:
        return [{"source": r["source"], "target": r["target"]} for r in self.query("SELECT source, target FROM dq_meta.lineage")]

    def get_tags(self, fqn: str) -> dict:
        rows = self.query(f"SELECT column_name, key, value FROM dq_meta.tags WHERE fqn = {lit(fqn)}")
        tags: dict = {}
        for r in rows:
            if r["column_name"]:
                tags.setdefault("columns", {}).setdefault(r["column_name"], {})[r["key"]] = r["value"]
            else:
                tags[r["key"]] = r["value"]
        return tags

    def set_tags(self, fqn: str, tags: dict, column: str | None = None) -> list[str]:
        stmts = []
        for k, v in tags.items():
            col_pred = f"column_name = {lit(column)}" if column else "column_name IS NULL"
            stmts.append(f"DELETE FROM dq_meta.tags WHERE fqn = {lit(fqn)} AND {col_pred} AND key = {lit(k)}")
            stmts.append(f"INSERT INTO dq_meta.tags VALUES ({lit(fqn)}, {lit(column)}, {lit(k)}, {lit(str(v))})")
        for st in stmts:
            self.query(st)
        return stmts

    def change_marker(self, fqn: str) -> str | None:
        cat, sch, tbl = fqn.split(".")
        rows = self.query(
            "SELECT estimated_size, column_count FROM duckdb_tables() "
            f"WHERE database_name={lit(cat)} AND schema_name={lit(sch)} AND table_name={lit(tbl)}"
        )
        if not rows:
            return None
        cnt = self.query(f"SELECT COUNT(*) AS n FROM {fqn}")[0]["n"]
        return f"{rows[0]['column_count']}:{cnt}"

    def timeseries(self, fqn, start=None, end=None, limit=100000):
        ts_col = self.config.get("ts_column", "ts")
        val_col = self.config.get("value_column", "value")
        where = []
        if start:
            where.append(f"{ts_col} >= {lit(start.isoformat(sep=' '))}")
        if end:
            where.append(f"{ts_col} <= {lit(end.isoformat(sep=' '))}")
        sql = f"SELECT {ts_col} AS ts, {val_col} AS value FROM {fqn}"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += f" ORDER BY 1 LIMIT {int(limit)}"
        return [(r["ts"] if isinstance(r["ts"], datetime) else datetime.combine(r["ts"], datetime.min.time())
                 if isinstance(r["ts"], date) else r["ts"], r["value"]) for r in self.query(sql)]
