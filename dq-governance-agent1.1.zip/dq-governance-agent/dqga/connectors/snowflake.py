"""Snowflake connector.

Execution:  snowflake-connector-python (password, key-pair, or externalbrowser/OAuth).
Metadata:   <db>.INFORMATION_SCHEMA (tables incl. ROW_COUNT and LAST_ALTERED, columns).
Lineage:    SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY (base_objects_accessed -> objects_modified).
Tags:       Object tagging (CREATE TAG / ALTER TABLE ... SET TAG), TAG_REFERENCES.
Native DQ:  Data Metric Functions. `apply_dmf` attaches system DMFs and
            `dmf_results` reads SNOWFLAKE.LOCAL.DATA_QUALITY_MONITORING_RESULTS
            so native results flow into the same scorecards.
"""
from __future__ import annotations

import threading
from decimal import Decimal

from ..config import resolve_env
from .base import AssetInfo, ColumnInfo, Connector, SnowflakeDialect, lit


def _clean(v):
    return float(v) if isinstance(v, Decimal) else v


class SnowflakeConnector(Connector):
    type = "snowflake"
    dialect = SnowflakeDialect()
    supports_tags = True
    supports_lineage = True

    def __init__(self, name: str, config: dict):
        super().__init__(name, config)
        self._conn = None
        self._lock = threading.Lock()

    def _connect(self):
        if self._conn is not None:
            return self._conn
        import snowflake.connector

        kwargs = {
            "account": resolve_env(self.config, "account"),
            "user": resolve_env(self.config, "user"),
            "warehouse": resolve_env(self.config, "warehouse"),
            "role": resolve_env(self.config, "role"),
            "database": (self.config.get("databases") or [None])[0],
            "application": "tcs-datatrustai",
            "client_session_keep_alive": True,
        }
        password = resolve_env(self.config, "password")
        key_path = resolve_env(self.config, "private_key_file")
        if key_path:
            kwargs["private_key_file"] = key_path
            pwd = resolve_env(self.config, "private_key_password")
            if pwd:
                kwargs["private_key_file_pwd"] = pwd
        elif password:
            kwargs["password"] = password
        else:
            kwargs["authenticator"] = self.config.get("authenticator", "externalbrowser")
        self._conn = snowflake.connector.connect(**{k: v for k, v in kwargs.items() if v})
        return self._conn

    def query(self, sql: str) -> list[dict]:
        with self._lock:
            cur = self._connect().cursor()
            try:
                cur.execute(sql)
                if not cur.description:
                    return []
                cols = [d[0].lower() for d in cur.description]
                return [{c: _clean(v) for c, v in zip(cols, row)} for row in cur.fetchall()]
            finally:
                cur.close()

    def test(self) -> dict:
        r = self.query("SELECT CURRENT_USER() AS u, CURRENT_ROLE() AS r, CURRENT_WAREHOUSE() AS w")[0]
        return {"ok": True, "detail": f"Connected as {r['u']} role {r['r']} on {r['w']}"}

    def _databases(self) -> list[str]:
        return self.config.get("databases") or [r["name"] for r in self.query("SHOW DATABASES")]

    def list_assets(self) -> list[AssetInfo]:
        out = []
        schemas = self.config.get("schemas")
        sch_filter = f" AND table_schema IN ({', '.join(lit(s.upper()) for s in schemas)})" if schemas else ""
        for db in self._databases():
            tables = self.query(
                f"SELECT table_schema, table_name, table_type, comment, row_count, last_altered "
                f"FROM {db}.INFORMATION_SCHEMA.TABLES WHERE table_schema <> 'INFORMATION_SCHEMA'{sch_filter}")
            cols = self.query(
                f"SELECT table_schema, table_name, column_name, data_type, is_nullable, comment "
                f"FROM {db}.INFORMATION_SCHEMA.COLUMNS WHERE table_schema <> 'INFORMATION_SCHEMA'{sch_filter} "
                "ORDER BY ordinal_position")
            by_table: dict[str, list[ColumnInfo]] = {}
            for c in cols:
                by_table.setdefault(f"{db}.{c['table_schema']}.{c['table_name']}", []).append(
                    ColumnInfo(c["column_name"], c["data_type"], c["is_nullable"] == "YES", c.get("comment")))
            for t in tables:
                fqn = f"{db}.{t['table_schema']}.{t['table_name']}"
                out.append(AssetInfo(fqn=fqn, kind="view" if "VIEW" in t["table_type"] else "table",
                                     columns=by_table.get(fqn, []), description=t.get("comment"),
                                     row_count=t.get("row_count"), change_marker=str(t.get("last_altered"))))
        return out

    def change_marker(self, fqn: str) -> str | None:
        db, sch, tbl = fqn.split(".")
        rows = self.query(f"SELECT last_altered FROM {db}.INFORMATION_SCHEMA.TABLES "
                          f"WHERE table_schema = {lit(sch)} AND table_name = {lit(tbl)}")
        return str(rows[0]["last_altered"]) if rows else None

    def get_lineage(self) -> list[dict]:
        days = int(self.config.get("lineage_days", 30))
        rows = self.query(
            "SELECT DISTINCT src.value:\"objectName\"::string AS source, tgt.value:\"objectName\"::string AS target "
            "FROM SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY ah, "
            "LATERAL FLATTEN(input => ah.base_objects_accessed) src, "
            "LATERAL FLATTEN(input => ah.objects_modified) tgt "
            f"WHERE ah.query_start_time > DATEADD('day', -{days}, CURRENT_TIMESTAMP()) "
            "AND src.value:\"objectDomain\"::string = 'Table' AND tgt.value:\"objectDomain\"::string = 'Table'")
        return [{"source": r["source"], "target": r["target"]} for r in rows if r["source"] != r["target"]]

    def get_tags(self, fqn: str) -> dict:
        db = fqn.split(".")[0]
        rows = self.query(f"SELECT tag_name, tag_value, column_name FROM TABLE({db}.INFORMATION_SCHEMA.TAG_REFERENCES_ALL_COLUMNS({lit(fqn)}, 'table'))")
        tags: dict = {}
        for r in rows:
            if r.get("column_name"):
                tags.setdefault("columns", {}).setdefault(r["column_name"], {})[r["tag_name"]] = r["tag_value"]
            else:
                tags[r["tag_name"]] = r["tag_value"]
        return tags

    def set_tags(self, fqn: str, tags: dict, column: str | None = None) -> list[str]:
        db, sch, _ = fqn.split(".")
        tag_schema = self.config.get("tag_schema", f"{db}.{sch}")
        stmts = []
        for k, v in tags.items():
            tag = f"{tag_schema}.{k.upper()}"
            stmts.append(f"CREATE TAG IF NOT EXISTS {tag}")
            if column:
                stmts.append(f"ALTER TABLE {fqn} MODIFY COLUMN {self.dialect.q(column)} SET TAG {tag} = {lit(str(v))}")
            else:
                stmts.append(f"ALTER TABLE {fqn} SET TAG {tag} = {lit(str(v))}")
        for st in stmts:
            self.query(st)
        return stmts

    # -- native Data Metric Functions --------------------------------------
    def apply_dmf(self, fqn: str, dmf: str, column: str | None = None, schedule: str = "60 MINUTE") -> list[str]:
        on = f"({self.dialect.q(column)})" if column else "()"
        stmts = [f"ALTER TABLE {fqn} SET DATA_METRIC_SCHEDULE = {lit(schedule)}",
                 f"ALTER TABLE {fqn} ADD DATA METRIC FUNCTION SNOWFLAKE.CORE.{dmf.upper()} ON {on}"]
        for st in stmts:
            self.query(st)
        return stmts

    def dmf_results(self, fqn: str, limit: int = 500) -> list[dict]:
        db, sch, tbl = fqn.split(".")
        return self.query(
            "SELECT measurement_time, metric_name, argument_names, value "
            "FROM SNOWFLAKE.LOCAL.DATA_QUALITY_MONITORING_RESULTS "
            f"WHERE table_database = {lit(db)} AND table_schema = {lit(sch)} AND table_name = {lit(tbl)} "
            f"ORDER BY measurement_time DESC LIMIT {int(limit)}")
