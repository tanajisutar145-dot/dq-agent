"""Connector registry. Platform SDKs are imported lazily so only what you use must be installed."""
from __future__ import annotations

import importlib
import threading

from .base import AssetInfo, ColumnInfo, Connector, Dialect, UnsafeSQLError, lit, safe_expression, type_family

CONNECTOR_TYPES = {
    "duckdb": ("dqga.connectors.duckdb_local", "DuckDBConnector"),
    "databricks": ("dqga.connectors.databricks", "DatabricksConnector"),
    "snowflake": ("dqga.connectors.snowflake", "SnowflakeConnector"),
    "spark": ("dqga.connectors.spark", "SparkConnector"),
    "cognite": ("dqga.connectors.cognite", "CogniteConnector"),
    "aws_glue": ("dqga.connectors.aws_glue", "GlueConnector"),
    "azure_purview": ("dqga.connectors.azure_purview", "PurviewConnector"),
}

_registry: dict[str, Connector] = {}
_disabled: set[str] = set()
_lock = threading.Lock()


def build_connector(name: str, type_: str, config: dict) -> Connector:
    if type_ not in CONNECTOR_TYPES:
        raise ValueError(f"Unknown connector type {type_!r}. Known: {sorted(CONNECTOR_TYPES)}")
    mod, cls = CONNECTOR_TYPES[type_]
    return getattr(importlib.import_module(mod), cls)(name, config)


def register(conn: Connector) -> None:
    with _lock:
        old = _registry.get(conn.name)
        if old is not None and hasattr(old, "close"):
            try:
                old.close()
            except Exception:
                pass
        _registry[conn.name] = conn
        _disabled.discard(conn.name)


def unregister(name: str, disabled: bool = False) -> None:
    """Drop a connector (closing its session). With disabled=True, later lookups say it is disabled."""
    with _lock:
        old = _registry.pop(name, None)
        if disabled:
            _disabled.add(name)
        else:
            _disabled.discard(name)
    if old is not None and hasattr(old, "close"):
        try:
            old.close()
        except Exception:
            pass


def mark_disabled(name: str) -> None:
    with _lock:
        _disabled.add(name)


def is_disabled(name: str) -> bool:
    return name in _disabled


def get_connector(name: str) -> Connector:
    if name not in _registry:
        if name in _disabled:
            raise KeyError(f"Connection {name!r} is disabled. Enable it in Settings > Connections.")
        raise KeyError(f"Connection {name!r} is not registered")
    return _registry[name]


def all_connectors() -> dict[str, Connector]:
    return dict(_registry)


def clear() -> None:
    with _lock:
        for c in _registry.values():
            if hasattr(c, "close"):
                try:
                    c.close()
                except Exception:
                    pass
        _registry.clear()
        _disabled.clear()


__all__ = ["AssetInfo", "ColumnInfo", "Connector", "Dialect", "UnsafeSQLError", "lit", "safe_expression",
           "type_family", "build_connector", "register", "unregister", "mark_disabled", "is_disabled",
           "get_connector", "all_connectors", "clear", "CONNECTOR_TYPES"]
