"""Connector contract and SQL dialects.

Every platform implements the same small surface so the DQ engine, governance
modules and agent never care where data lives:

    query / execute / list_assets / get_columns / get_lineage /
    get_tags / set_tags / change_marker / timeseries

Checks are compiled to SQL in the platform's dialect and pushed down, so only
aggregates come back.
"""
from __future__ import annotations

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_\- ]*$")
FQN_RE = re.compile(r"^[A-Za-z0-9_\-`\".:]+$")
FORBIDDEN_SQL = re.compile(
    r"(;|--|/\*|\b(insert|update|delete|drop|alter|create|grant|revoke|merge|truncate|call|exec|execute|copy|put|attach|detach|install|load|pragma|set)\b)",
    re.IGNORECASE,
)


class UnsafeSQLError(ValueError):
    pass


def safe_expression(expr: str) -> str:
    """Allow a user-written boolean expression only if it is read-only."""
    if not expr or FORBIDDEN_SQL.search(expr):
        raise UnsafeSQLError(f"Expression rejected (read-only boolean expressions only): {expr!r}")
    return expr


def lit(v: Any) -> str:
    """Render a Python value as a SQL literal."""
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return repr(float(v)) if isinstance(v, float) else str(int(v))
    s = str(v).replace("'", "''")
    return f"'{s}'"


def type_family(data_type: str | None) -> str:
    t = (data_type or "").lower()
    if any(k in t for k in ("array", "map", "struct", "variant", "object", "binary", "blob", "geography", "geometry")):
        return "complex"
    if "bool" in t:
        return "boolean"
    if any(k in t for k in ("timestamp", "datetime", "date", "time")):
        return "temporal"
    if any(k in t for k in ("int", "decimal", "numeric", "float", "double", "real", "number", "long", "short", "byte", "hugeint")):
        return "numeric"
    return "string"


@dataclass
class ColumnInfo:
    name: str
    data_type: str
    nullable: bool = True
    comment: str | None = None

    def to_dict(self) -> dict:
        return {"name": self.name, "data_type": self.data_type, "nullable": self.nullable,
                "comment": self.comment, "family": type_family(self.data_type)}


@dataclass
class AssetInfo:
    fqn: str
    kind: str = "table"
    columns: list[ColumnInfo] = field(default_factory=list)
    description: str | None = None
    row_count: int | None = None
    change_marker: str | None = None
    tags: dict = field(default_factory=dict)
    domain: str | None = None


class Dialect:
    name = "ansi"
    quote_char = '"'
    string_type = "VARCHAR"

    def q(self, ident: str) -> str:
        if not IDENT_RE.match(ident or ""):
            raise UnsafeSQLError(f"Invalid identifier: {ident!r}")
        return f"{self.quote_char}{ident}{self.quote_char}"

    def table(self, fqn: str) -> str:
        if not FQN_RE.match(fqn or ""):
            raise UnsafeSQLError(f"Invalid table name: {fqn!r}")
        return fqn

    def regex(self, col: str, pattern: str) -> str:
        return f"REGEXP_LIKE({col}, {lit(pattern)})"

    def quantile(self, col: str, q: float) -> str:
        return f"APPROX_PERCENTILE({col}, {q})"

    def stddev(self, col: str) -> str:
        return f"STDDEV_SAMP({col})"

    def length(self, col: str) -> str:
        return f"LENGTH(CAST({col} AS VARCHAR))"

    def as_double(self, col: str) -> str:
        return f"CAST({col} AS DOUBLE)"

    def now(self) -> str:
        return "CURRENT_TIMESTAMP"

    def days_ago(self, days: int) -> str:
        return f"CURRENT_TIMESTAMP - INTERVAL '{int(days)}' DAY"

    def star_except(self, col: str) -> str:
        return f"* EXCLUDE ({col})"

    def limit(self, n: int) -> str:
        return f"LIMIT {int(n)}"

    def hours_since(self, expr: str) -> str:
        return f"EXTRACT(EPOCH FROM ({self.now()} - {expr})) / 3600.0"


class DuckDBDialect(Dialect):
    """DuckDB's CURRENT_TIMESTAMP is local-time TIMESTAMPTZ; demo data is naive UTC,
    so "now" is rendered as a UTC literal to keep comparisons exact."""
    name = "duckdb"

    def regex(self, col, pattern):
        return f"regexp_full_match(CAST({col} AS VARCHAR), {lit(pattern)})"

    def quantile(self, col, q):
        return f"approx_quantile({col}, {q})"

    def now(self):
        from datetime import datetime, timezone
        return f"TIMESTAMP '{datetime.now(timezone.utc).replace(tzinfo=None).isoformat(sep=' ', timespec='seconds')}'"

    def days_ago(self, days):
        from datetime import datetime, timedelta, timezone
        t = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=int(days))
        return f"TIMESTAMP '{t.isoformat(sep=' ', timespec='seconds')}'"

    def hours_since(self, expr):
        return f"date_diff('second', {expr}, {self.now()}) / 3600.0"


class SparkDialect(Dialect):
    """Databricks SQL and Spark SQL."""
    name = "spark"
    quote_char = "`"
    string_type = "STRING"

    def regex(self, col, pattern):
        p = pattern if pattern.startswith("^") else "^(" + pattern + ")$"
        return f"CAST({col} AS STRING) RLIKE {lit(p)}"

    def quantile(self, col, q):
        return f"percentile_approx({col}, {q})"

    def length(self, col):
        return f"LENGTH(CAST({col} AS STRING))"

    def now(self):
        return "current_timestamp()"

    def days_ago(self, days):
        return f"current_timestamp() - INTERVAL {int(days)} DAYS"

    def star_except(self, col):
        return f"* EXCEPT ({col})"

    def hours_since(self, expr):
        return f"(unix_timestamp(current_timestamp()) - unix_timestamp({expr})) / 3600.0"


class SnowflakeDialect(Dialect):
    name = "snowflake"

    def regex(self, col, pattern):
        return f"REGEXP_LIKE(TO_VARCHAR({col}), {lit(pattern)})"

    def length(self, col):
        return f"LENGTH(TO_VARCHAR({col}))"

    def days_ago(self, days):
        return f"DATEADD('day', -{int(days)}, CURRENT_TIMESTAMP())"

    def hours_since(self, expr):
        return f"DATEDIFF('second', {expr}, CURRENT_TIMESTAMP()) / 3600.0"


class TrinoDialect(Dialect):
    """Athena / Trino."""
    name = "trino"

    def regex(self, col, pattern):
        p = pattern if pattern.startswith("^") else "^(" + pattern + ")$"
        return f"regexp_like(CAST({col} AS VARCHAR), {lit(p)})"

    def star_except(self, col):
        raise NotImplementedError("Trino has no SELECT * EXCEPT; list columns explicitly")

    def hours_since(self, expr):
        return f"date_diff('second', {expr}, current_timestamp) / 3600.0"


class Connector(ABC):
    type = "base"
    dialect: Dialect = Dialect()
    supports_sql = True
    supports_tags = False
    supports_lineage = False
    supports_timeseries = False

    def __init__(self, name: str, config: dict):
        self.name = name
        self.config = config or {}

    # -- required ---------------------------------------------------------
    @abstractmethod
    def test(self) -> dict: ...

    @abstractmethod
    def list_assets(self) -> list[AssetInfo]: ...

    # -- SQL --------------------------------------------------------------
    def query(self, sql: str) -> list[dict]:
        raise NotImplementedError(f"{self.type} does not support SQL queries")

    def execute(self, statements: list[str]) -> list[dict]:
        """Run write statements. Only called after approval or within auto-remediation guardrails."""
        out = []
        for st in statements:
            out.append({"statement": st, "rows": self.query(st)})
        return out

    def get_columns(self, fqn: str) -> list[ColumnInfo]:
        for a in self.list_assets():
            if a.fqn == fqn:
                return a.columns
        return []

    # -- metadata ---------------------------------------------------------
    def get_lineage(self) -> list[dict]:
        """Return [{source, target, source_column?, target_column?}]."""
        return []

    def get_tags(self, fqn: str) -> dict:
        return {}

    def set_tags(self, fqn: str, tags: dict, column: str | None = None) -> list[str]:
        raise NotImplementedError(f"{self.type} does not support tag write-back")

    def change_marker(self, fqn: str) -> str | None:
        return None

    # -- time series ------------------------------------------------------
    def timeseries(self, fqn: str, start: datetime | None = None, end: datetime | None = None,
                   limit: int = 100000) -> list[tuple[datetime, float]]:
        raise NotImplementedError(f"{self.type} does not expose time series")

    # -- platform-native extras (remediation hooks) -------------------------
    def run_job(self, job_ref: str) -> dict:
        raise NotImplementedError(f"{self.type} cannot trigger jobs")

    def describe(self) -> dict:
        return {"name": self.name, "type": self.type, "dialect": self.dialect.name,
                "sql": self.supports_sql, "tags": self.supports_tags,
                "lineage": self.supports_lineage, "timeseries": self.supports_timeseries}
