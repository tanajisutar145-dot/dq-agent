"""AWS connector: Glue Data Catalog + Athena execution + Glue Data Quality + Lake Formation tags.

- Assets come from the Glue Data Catalog (fqn `glue:<database>.<table>`).
- Checks run through Athena (Trino dialect).
- `push_glue_ruleset` exports rules as DQDL and starts a native Glue DQ
  evaluation run, so customers keep using Glue DQ where they already do.
- Tags are written as Lake Formation LF-tags (LF-TBAC).
"""
from __future__ import annotations

import time

from ..config import resolve_env
from .base import AssetInfo, ColumnInfo, Connector, TrinoDialect


class GlueConnector(Connector):
    type = "aws_glue"
    dialect = TrinoDialect()
    supports_tags = True

    def __init__(self, name: str, config: dict):
        super().__init__(name, config)
        self._session = None

    def _boto(self, svc: str):
        if self._session is None:
            import boto3
            self._session = boto3.Session(profile_name=self.config.get("profile"),
                                          region_name=resolve_env(self.config, "region"))
        return self._session.client(svc)

    def _native(self, fqn: str) -> tuple[str, str]:
        db, tbl = fqn.removeprefix("glue:").split(".", 1)
        return db, tbl

    def test(self) -> dict:
        ident = self._boto("sts").get_caller_identity()
        return {"ok": True, "detail": f"AWS account {ident['Account']} as {ident['Arn']}"}

    def list_assets(self) -> list[AssetInfo]:
        glue = self._boto("glue")
        dbs = self.config.get("databases") or [d["Name"] for d in glue.get_databases()["DatabaseList"]]
        out = []
        for db in dbs:
            for page in glue.get_paginator("get_tables").paginate(DatabaseName=db):
                for t in page["TableList"]:
                    cols = [ColumnInfo(c["Name"], c.get("Type", "string"), True, c.get("Comment"))
                            for c in t.get("StorageDescriptor", {}).get("Columns", []) + t.get("PartitionKeys", [])]
                    out.append(AssetInfo(fqn=f"glue:{db}.{t['Name']}", kind="table", columns=cols,
                                         description=t.get("Description"),
                                         change_marker=str(t.get("UpdateTime"))))
        return out

    def query(self, sql: str) -> list[dict]:
        sql = sql.replace("glue:", "")
        athena = self._boto("athena")
        qid = athena.start_query_execution(
            QueryString=sql,
            WorkGroup=self.config.get("workgroup", "primary"),
            ResultConfiguration={"OutputLocation": resolve_env(self.config, "athena_output")},
        )["QueryExecutionId"]
        while True:
            st = athena.get_query_execution(QueryExecutionId=qid)["QueryExecution"]["Status"]
            if st["State"] in ("SUCCEEDED", "FAILED", "CANCELLED"):
                break
            time.sleep(1)
        if st["State"] != "SUCCEEDED":
            raise RuntimeError(f"Athena query {st['State']}: {st.get('StateChangeReason')}")
        rows, header = [], None
        for page in athena.get_paginator("get_query_results").paginate(QueryExecutionId=qid):
            for r in page["ResultSet"]["Rows"]:
                vals = [d.get("VarCharValue") for d in r["Data"]]
                if header is None:
                    header = vals
                    continue
                rows.append({h: _num(v) for h, v in zip(header, vals)})
        return rows

    def set_tags(self, fqn: str, tags: dict, column: str | None = None) -> list[str]:
        db, tbl = self._native(fqn)
        lf = self._boto("lakeformation")
        resource = ({"TableWithColumns": {"DatabaseName": db, "Name": tbl, "ColumnNames": [column]}}
                    if column else {"Table": {"DatabaseName": db, "Name": tbl}})
        lf.add_lf_tags_to_resource(Resource=resource,
                                   LFTags=[{"TagKey": k, "TagValues": [str(v)]} for k, v in tags.items()])
        return [f"lakeformation.add_lf_tags_to_resource {fqn} {column or ''} {tags}"]

    def push_glue_ruleset(self, fqn: str, dqdl: str, role_arn: str | None = None) -> dict:
        db, tbl = self._native(fqn)
        glue = self._boto("glue")
        name = f"dqga_{db}_{tbl}"[:255]
        try:
            glue.create_data_quality_ruleset(Name=name, Ruleset=dqdl,
                                             TargetTable={"DatabaseName": db, "TableName": tbl})
        except glue.exceptions.AlreadyExistsException:
            glue.update_data_quality_ruleset(Name=name, Ruleset=dqdl)
        run = glue.start_data_quality_ruleset_evaluation_run(
            DataSource={"GlueTable": {"DatabaseName": db, "TableName": tbl}},
            Role=role_arn or resolve_env(self.config, "glue_role_arn"),
            RulesetNames=[name])
        return {"ruleset": name, "run_id": run["RunId"]}


def _num(v):
    if v is None:
        return None
    try:
        return int(v)
    except ValueError:
        try:
            return float(v)
        except ValueError:
            return v
