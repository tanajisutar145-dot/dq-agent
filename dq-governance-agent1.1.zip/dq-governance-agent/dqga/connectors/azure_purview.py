"""Microsoft Purview connector (Azure governance plane).

Purview is a catalog, not a query engine: this connector syncs assets and
lineage from the Purview Data Map, and writes classifications back.
Pair it with a SQL connector (Databricks, Synapse/Fabric via Spark,
Snowflake) for running checks.

API: Purview Data Map REST (`/datamap/api/...`, api-version 2023-09-01).
Auth: azure-identity (client secret or DefaultAzureCredential / managed identity).
Check the API version against your Purview account before production use.
"""
from __future__ import annotations

import httpx

from ..config import resolve_env
from .base import AssetInfo, ColumnInfo, Connector

API_VERSION = "2023-09-01"
LABEL_TO_PURVIEW = {
    "email": "MICROSOFT.PERSONAL.EMAIL",
    "phone": "MICROSOFT.PERSONAL.PHONE_NUMBER",
    "ssn": "MICROSOFT.GOVERNMENT.US.SOCIAL_SECURITY_NUMBER",
    "credit_card": "MICROSOFT.FINANCIAL.CREDIT_CARD_NUMBER",
    "iban": "MICROSOFT.FINANCIAL.INTERNATIONAL_BANKING_ACCOUNT_NUMBER",
    "ip_address": "MICROSOFT.PERSONAL.IPADDRESS",
    "person_name": "MICROSOFT.PERSONAL.NAME",
    "address": "MICROSOFT.PERSONAL.PHYSICAL_ADDRESS",
}


class PurviewConnector(Connector):
    type = "azure_purview"
    supports_sql = False
    supports_tags = True
    supports_lineage = True

    def __init__(self, name: str, config: dict):
        super().__init__(name, config)
        self._cred = None
        self._guid_by_fqn: dict[str, str] = {}

    @property
    def endpoint(self) -> str:
        return f"https://{resolve_env(self.config, 'account')}.purview.azure.com"

    def _headers(self) -> dict:
        if self._cred is None:
            from azure.identity import ClientSecretCredential, DefaultAzureCredential

            secret = resolve_env(self.config, "client_secret")
            self._cred = (ClientSecretCredential(resolve_env(self.config, "tenant_id"),
                                                 resolve_env(self.config, "client_id"), secret)
                          if secret else DefaultAzureCredential())
        token = self._cred.get_token("https://purview.azure.net/.default").token
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    def _req(self, method: str, path: str, **kw) -> dict:
        sep = "&" if "?" in path else "?"
        r = httpx.request(method, f"{self.endpoint}{path}{sep}api-version={API_VERSION}",
                          headers=self._headers(), timeout=60, **kw)
        r.raise_for_status()
        return r.json() if r.content else {}

    def test(self) -> dict:
        self._req("POST", "/datamap/api/search/query", json={"keywords": "*", "limit": 1})
        return {"ok": True, "detail": f"Purview {self.endpoint}"}

    def list_assets(self) -> list[AssetInfo]:
        limit = int(self.config.get("limit", 500))
        body = {"keywords": self.config.get("keywords", "*"), "limit": limit,
                "filter": {"or": [{"entityType": t} for t in self.config.get("entity_types",
                           ["azure_sql_table", "databricks_table", "snowflake_table", "azure_datalake_gen2_resource_set"])]}}
        res = self._req("POST", "/datamap/api/search/query", json=body)
        out = []
        for v in res.get("value", []):
            fqn = v.get("qualifiedName") or v.get("name")
            self._guid_by_fqn[fqn] = v.get("id")
            cols = []
            out.append(AssetInfo(fqn=fqn, kind="table", columns=cols, description=v.get("description"),
                                 tags={"purview_guid": v.get("id"), "classifications": v.get("classification", [])}))
        return out

    def get_columns(self, fqn: str) -> list[ColumnInfo]:
        guid = self._guid_by_fqn.get(fqn)
        if not guid:
            return []
        ent = self._req("GET", f"/datamap/api/atlas/v2/entity/guid/{guid}")
        cols = []
        for ref in (ent.get("referredEntities") or {}).values():
            if ref.get("typeName", "").endswith("column"):
                a = ref.get("attributes", {})
                cols.append(ColumnInfo(a.get("name"), a.get("data_type") or a.get("type") or "string"))
        return cols

    def get_lineage(self) -> list[dict]:
        edges = []
        for fqn, guid in list(self._guid_by_fqn.items())[: int(self.config.get("lineage_limit", 100))]:
            lin = self._req("GET", f"/datamap/api/atlas/v2/lineage/{guid}?direction=BOTH&depth=1")
            names = {g: (e.get("attributes") or {}).get("qualifiedName", g) for g, e in lin.get("guidEntityMap", {}).items()}
            for rel in lin.get("relations", []):
                edges.append({"source": names.get(rel["fromEntityId"]), "target": names.get(rel["toEntityId"])})
        return [e for e in edges if e["source"] and e["target"]]

    def set_tags(self, fqn: str, tags: dict, column: str | None = None) -> list[str]:
        guid = self._guid_by_fqn.get(fqn)
        if not guid:
            raise ValueError(f"Unknown Purview asset {fqn}; sync first")
        label = tags.get("pii")
        type_name = LABEL_TO_PURVIEW.get(label)
        if not type_name:
            return []
        self._req("POST", f"/datamap/api/atlas/v2/entity/guid/{guid}/classifications", json=[{"typeName": type_name}])
        return [f"purview classification {type_name} -> {fqn}"]
