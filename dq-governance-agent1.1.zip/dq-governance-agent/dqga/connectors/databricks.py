"""Databricks connector (primary platform).

Execution:  Databricks SQL warehouse via databricks-sql-connector.
Auth:       PAT (token) or OAuth via databricks-sdk unified auth. Inside a
            Databricks App the service principal env vars are injected, so
            Config() picks them up with no extra settings.
Metadata:   Unity Catalog information_schema (tables, columns, tags).
Lineage:    system.access.table_lineage and system.access.column_lineage.
Write-back: UC tags (ALTER TABLE ... SET TAGS), column masks (policies module).
Jobs:       databricks-sdk WorkspaceClient().jobs.run_now for backfill remediation.
"""
from __future__ import annotations

import threading
from decimal import Decimal

from ..config import resolve_env
from .base import AssetInfo, ColumnInfo, Connector, SparkDialect, lit


def _clean(v):
    return float(v) if isinstance(v, Decimal) else v


# databricks-sql-connector errors that mean "the SQL itself failed" (never retried).
# Anything else (closed session, network, auth refresh) triggers one reconnect.
_SQL_ERRORS = {"ServerOperationError", "ProgrammingError", "UnsafeSQLError"}


class DatabricksConnector(Connector):
    type = "databricks"
    dialect = SparkDialect()
    supports_tags = True
    supports_lineage = True

    def __init__(self, name: str, config: dict):
        super().__init__(name, config)
        self._conn = None
        self._lock = threading.Lock()

    # -- connection -------------------------------------------------------
    def _host(self) -> str:
        host = resolve_env(self.config, "host")
        if not host:
            from databricks.sdk.core import Config
            host = Config().host
        return host.replace("https://", "").rstrip("/")

    def _http_path(self) -> str:
        http_path = resolve_env(self.config, "http_path")
        if http_path:
            return http_path
        wid = resolve_env(self.config, "warehouse_id")
        if not wid:
            raise ValueError("Databricks connection needs http_path or warehouse_id")
        return f"/sql/1.0/warehouses/{wid}"

    def _connect(self):
        if self._conn is not None:
            return self._conn
        from databricks import sql as dbsql

        token = resolve_env(self.config, "token")
        if token:
            self._conn = dbsql.connect(server_hostname=self._host(), http_path=self._http_path(), access_token=token)
        else:
            from databricks.sdk.core import Config

            cfg = Config(host=resolve_env(self.config, "host"), profile=self.config.get("profile"))
            self._conn = dbsql.connect(server_hostname=cfg.host.replace("https://", ""),
                                       http_path=self._http_path(),
                                       credentials_provider=lambda: cfg.authenticate)
        return self._conn

    def _reset(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
        self._conn = None

    def close(self) -> None:
        with self._lock:
            self._reset()

    def query(self, sql: str) -> list[dict]:
        """Run SQL; on a dropped or expired session, reconnect once and retry.
        SQL errors (bad syntax, missing table, no permission) are raised immediately."""
        with self._lock:
            for attempt in (1, 2):
                try:
                    with self._connect().cursor() as cur:
                        cur.execute(sql)
                        if not cur.description:
                            return []
                        cols = [d[0] for d in cur.description]
                        return [{c: _clean(v) for c, v in zip(cols, row)} for row in cur.fetchall()]
                except Exception as e:
                    if attempt == 2 or type(e).__name__ in _SQL_ERRORS:
                        raise
                    self._reset()
        return []

    def test(self) -> dict:
        row = self.query("SELECT current_user() AS user, current_catalog() AS catalog")[0]
        return {"ok": True, "detail": f"Connected as {row['user']} (catalog {row['catalog']})"}

    # -- catalog ----------------------------------------------------------
    def _catalogs(self) -> list[str]:
        cats = self.config.get("catalogs")
        if cats:
            return cats
        return [r["catalog_name"] for r in self.query("SELECT catalog_name FROM system.information_schema.catalogs "
                                                      "WHERE catalog_name NOT IN ('system', 'samples', '__databricks_internal')")]

    def _schema_filter(self, col: str = "table_schema") -> str:
        schemas = self.config.get("schemas")
        base = f" AND {col} <> 'information_schema'"
        return base + (f" AND {col} IN ({', '.join(lit(s) for s in schemas)})" if schemas else "")

    def list_assets(self) -> list[AssetInfo]:
        out: list[AssetInfo] = []
        for cat in self._catalogs():
            c = self.dialect.q(cat)
            tables = self.query(
                f"SELECT table_schema, table_name, table_type, comment, last_altered FROM {c}.information_schema.tables "
                f"WHERE 1=1{self._schema_filter()}"
            )
            cols = self.query(
                f"SELECT table_schema, table_name, column_name, full_data_type, is_nullable, comment "
                f"FROM {c}.information_schema.columns WHERE 1=1{self._schema_filter()} ORDER BY ordinal_position"
            )
            tag_rows = self.query(
                f"SELECT schema_name, table_name, tag_name, tag_value FROM {c}.information_schema.table_tags "
                f"WHERE 1=1{self._schema_filter('schema_name')}"
            )
            by_table: dict[str, list[ColumnInfo]] = {}
            for r in cols:
                key = f"{cat}.{r['table_schema']}.{r['table_name']}"
                by_table.setdefault(key, []).append(
                    ColumnInfo(r["column_name"], r["full_data_type"], r["is_nullable"] == "YES", r.get("comment")))
            tags: dict[str, dict] = {}
            for r in tag_rows:
                tags.setdefault(f"{cat}.{r['schema_name']}.{r['table_name']}", {})[r["tag_name"]] = r["tag_value"]
            for t in tables:
                fqn = f"{cat}.{t['table_schema']}.{t['table_name']}"
                kind = "view" if "VIEW" in (t["table_type"] or "") else "table"
                out.append(AssetInfo(fqn=fqn, kind=kind, columns=by_table.get(fqn, []), description=t.get("comment"),
                                     change_marker=str(t.get("last_altered")), tags=tags.get(fqn, {})))
        return out

    def get_columns(self, fqn: str) -> list[ColumnInfo]:
        cat, sch, tbl = fqn.split(".")
        rows = self.query(
            f"SELECT column_name, full_data_type, is_nullable, comment FROM {self.dialect.q(cat)}.information_schema.columns "
            f"WHERE table_schema = {lit(sch)} AND table_name = {lit(tbl)} ORDER BY ordinal_position"
        )
        return [ColumnInfo(r["column_name"], r["full_data_type"], r["is_nullable"] == "YES", r.get("comment")) for r in rows]

    def change_marker(self, fqn: str) -> str | None:
        cat, sch, tbl = fqn.split(".")
        rows = self.query(
            f"SELECT last_altered FROM {self.dialect.q(cat)}.information_schema.tables "
            f"WHERE table_schema = {lit(sch)} AND table_name = {lit(tbl)}"
        )
        return str(rows[0]["last_altered"]) if rows else None

    # -- lineage ----------------------------------------------------------
    def get_lineage(self) -> list[dict]:
        days = int(self.config.get("lineage_days", 30))
        edges = [
            {"source": r["source"], "target": r["target"]}
            for r in self.query(
                "SELECT source_table_full_name AS source, target_table_full_name AS target "
                "FROM system.access.table_lineage "
                f"WHERE event_date >= current_date() - INTERVAL {days} DAYS "
                "AND source_table_full_name IS NOT NULL AND target_table_full_name IS NOT NULL "
                "GROUP BY 1, 2"
            )
        ]
        if self.config.get("column_lineage", False):
            edges += [
                {"source": r["source"], "target": r["target"], "source_column": r["sc"], "target_column": r["tc"]}
                for r in self.query(
                    "SELECT source_table_full_name AS source, target_table_full_name AS target, "
                    "source_column_name AS sc, target_column_name AS tc FROM system.access.column_lineage "
                    f"WHERE event_date >= current_date() - INTERVAL {days} DAYS "
                    "AND source_table_full_name IS NOT NULL AND target_table_full_name IS NOT NULL GROUP BY 1, 2, 3, 4"
                )
            ]
        return edges

    # -- tags -------------------------------------------------------------
    def get_tags(self, fqn: str) -> dict:
        cat, sch, tbl = fqn.split(".")
        c = self.dialect.q(cat)
        tags = {r["tag_name"]: r["tag_value"] for r in self.query(
            f"SELECT tag_name, tag_value FROM {c}.information_schema.table_tags "
            f"WHERE schema_name = {lit(sch)} AND table_name = {lit(tbl)}")}
        for r in self.query(
                f"SELECT column_name, tag_name, tag_value FROM {c}.information_schema.column_tags "
                f"WHERE schema_name = {lit(sch)} AND table_name = {lit(tbl)}"):
            tags.setdefault("columns", {}).setdefault(r["column_name"], {})[r["tag_name"]] = r["tag_value"]
        return tags

    def set_tags(self, fqn: str, tags: dict, column: str | None = None) -> list[str]:
        pairs = ", ".join(f"{lit(k)} = {lit(str(v))}" for k, v in tags.items())
        if column:
            st = f"ALTER TABLE {self.dialect.table(fqn)} ALTER COLUMN {self.dialect.q(column)} SET TAGS ({pairs})"
        else:
            st = f"ALTER TABLE {self.dialect.table(fqn)} SET TAGS ({pairs})"
        self.query(st)
        return [st]

    # -- jobs -------------------------------------------------------------
    def run_job(self, job_ref: str) -> dict:
        from databricks.sdk import WorkspaceClient

        w = WorkspaceClient()
        run = w.jobs.run_now(job_id=int(job_ref))
        return {"run_id": run.run_id, "job_id": int(job_ref)}
