"""Cognite Data Fusion connector (industrial / OT data).

Assets in DQ terms are CDF time series (fqn `cdf:<project>:ts:<external_id>`).
Checks run in Python on retrieved datapoints (gaps, flatlines, spikes, bounds,
monotonic timestamps, sampling drift), using bounds from time series metadata
when present. Extraction pipeline run status feeds freshness; DQ findings are
written back as CDF events so engineers see them in Charts / InField.

Auth: OAuth client credentials (Entra ID or other IdP).
"""
from __future__ import annotations

from datetime import datetime, timezone

from ..config import resolve_env
from .base import AssetInfo, ColumnInfo, Connector


class CogniteConnector(Connector):
    type = "cognite"
    supports_sql = False
    supports_timeseries = True
    supports_tags = True

    def __init__(self, name: str, config: dict):
        super().__init__(name, config)
        self._client = None

    def _c(self):
        if self._client is None:
            from cognite.client import ClientConfig, CogniteClient
            from cognite.client.credentials import OAuthClientCredentials

            base_url = resolve_env(self.config, "base_url") or "https://api.cognitedata.com"
            tenant = resolve_env(self.config, "tenant_id")
            token_url = resolve_env(self.config, "token_url") or f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
            creds = OAuthClientCredentials(
                token_url=token_url,
                client_id=resolve_env(self.config, "client_id"),
                client_secret=resolve_env(self.config, "client_secret"),
                scopes=[f"{base_url}/.default"],
            )
            cfg = ClientConfig(client_name="tcs-datatrustai", project=resolve_env(self.config, "project"),
                               base_url=base_url, credentials=creds)
            self._client = CogniteClient(cfg)
        return self._client

    @property
    def project(self) -> str:
        return resolve_env(self.config, "project") or "cdf"

    def _fqn(self, xid: str) -> str:
        return f"cdf:{self.project}:ts:{xid}"

    def _xid(self, fqn: str) -> str:
        return fqn.split(":ts:", 1)[1]

    def test(self) -> dict:
        status = self._c().iam.token.inspect()
        return {"ok": True, "detail": f"CDF project {self.project}, subject {status.subject}"}

    def list_assets(self) -> list[AssetInfo]:
        limit = int(self.config.get("timeseries_limit", 1000))
        kwargs = {}
        if self.config.get("data_set_external_ids"):
            kwargs["data_set_external_ids"] = self.config["data_set_external_ids"]
        out = []
        for ts in self._c().time_series.list(limit=limit, **kwargs):
            if not ts.external_id:
                continue
            meta = dict(ts.metadata or {})
            tags = {"unit": ts.unit or meta.get("unit"), "asset_id": ts.asset_id, "is_step": ts.is_step}
            for k in ("min", "max", "expected_interval_s"):
                if k in meta:
                    tags[k] = meta[k]
            out.append(AssetInfo(fqn=self._fqn(ts.external_id), kind="timeseries",
                                 columns=[ColumnInfo("timestamp", "timestamp", False), ColumnInfo("value", "double")],
                                 description=ts.description or ts.name, tags=tags,
                                 domain=self.config.get("domain")))
        return out

    def timeseries(self, fqn, start=None, end=None, limit=100000):
        dps = self._c().time_series.data.retrieve(external_id=self._xid(fqn), start=start or "7d-ago",
                                                  end=end or "now", limit=limit)
        return [(datetime.fromtimestamp(t / 1000, tz=timezone.utc).replace(tzinfo=None), v)
                for t, v in zip(dps.timestamp, dps.value)]

    def change_marker(self, fqn: str) -> str | None:
        latest = self._c().time_series.data.retrieve_latest(external_id=self._xid(fqn))
        return str(latest.timestamp[0]) if latest and latest.timestamp else None

    # -- industrial governance checks -----------------------------------------
    def extraction_runs(self) -> list[dict]:
        out = []
        for ep in self._c().extraction_pipelines.list(limit=-1):
            runs = self._c().extraction_pipelines.runs.list(external_id=ep.external_id, limit=1)
            last = runs[0] if len(runs) else None
            out.append({"pipeline": ep.external_id, "name": ep.name,
                        "status": getattr(last, "status", None),
                        "last_run": datetime.fromtimestamp(last.created_time / 1000, tz=timezone.utc).isoformat() if last else None,
                        "message": getattr(last, "message", None)})
        return out

    def hierarchy_report(self, limit: int = 10000) -> dict:
        ts = self._c().time_series.list(limit=limit)
        orphan = [t.external_id for t in ts if not t.asset_id]
        no_unit = [t.external_id for t in ts if not t.unit]
        return {"timeseries": len(ts), "orphan_timeseries": len(orphan), "orphan_examples": orphan[:20],
                "missing_unit": len(no_unit), "missing_unit_examples": no_unit[:20]}

    def set_tags(self, fqn: str, tags: dict, column: str | None = None) -> list[str]:
        from cognite.client.data_classes import TimeSeriesUpdate

        upd = TimeSeriesUpdate(external_id=self._xid(fqn)).metadata.add({f"dq_{k}": str(v) for k, v in tags.items()})
        self._c().time_series.update(upd)
        return [f"timeseries.metadata.add {self._xid(fqn)} {tags}"]

    def write_flag(self, fqn: str, rule: str, start: datetime, end: datetime, description: str, meta: dict) -> str:
        from cognite.client.data_classes import Event

        xid = f"dq:{self._xid(fqn)}:{rule}:{int(start.timestamp())}"
        self._c().events.create(Event(external_id=xid, type="data_quality", subtype=rule,
                                      start_time=int(start.replace(tzinfo=timezone.utc).timestamp() * 1000),
                                      end_time=int(end.replace(tzinfo=timezone.utc).timestamp() * 1000),
                                      description=description[:500],
                                      metadata={k: str(v)[:500] for k, v in meta.items()}))
        return xid
