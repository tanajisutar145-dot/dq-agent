"""Generic Spark connector (EMR, Synapse, Fabric, open-source Spark, Databricks Connect).

Runs checks with spark.sql(). Lineage for Spark jobs arrives through the
OpenLineage endpoint (POST /api/lineage/openlineage) from the OpenLineage
Spark listener, so this connector does not query lineage itself.
"""
from __future__ import annotations

from .base import AssetInfo, ColumnInfo, Connector, SparkDialect


class SparkConnector(Connector):
    type = "spark"
    dialect = SparkDialect()

    def __init__(self, name: str, config: dict):
        super().__init__(name, config)
        self._spark = None

    def _session(self):
        if self._spark is None:
            if self.config.get("databricks_connect"):
                from databricks.connect import DatabricksSession
                self._spark = DatabricksSession.builder.getOrCreate()
            else:
                from pyspark.sql import SparkSession
                b = SparkSession.builder.appName("tcs-datatrustai")
                if self.config.get("master"):
                    b = b.master(self.config["master"])
                for k, v in (self.config.get("spark_conf") or {}).items():
                    b = b.config(k, v)
                self._spark = b.getOrCreate()
        return self._spark

    def query(self, sql: str) -> list[dict]:
        return [r.asDict() for r in self._session().sql(sql).collect()]

    def test(self) -> dict:
        return {"ok": True, "detail": f"Spark {self._session().version}"}

    def list_assets(self) -> list[AssetInfo]:
        spark = self._session()
        dbs = self.config.get("databases") or [d.name for d in spark.catalog.listDatabases()]
        out = []
        for db in dbs:
            for t in spark.catalog.listTables(db):
                fqn = f"{db}.{t.name}"
                cols = [ColumnInfo(c.name, c.dataType, c.nullable, c.description)
                        for c in spark.catalog.listColumns(t.name, db)]
                out.append(AssetInfo(fqn=fqn, kind="view" if t.tableType == "VIEW" else "table",
                                     columns=cols, description=t.description))
        return out
