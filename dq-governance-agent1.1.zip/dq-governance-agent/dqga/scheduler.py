"""Cost-aware, change-aware scheduler.

Each tick:
  1. find due rules (last_run + interval <= now),
  2. skip assets whose platform change marker has not moved since the last
     check (except time-dependent checks: freshness, anomaly on freshness),
  3. rank assets by value / cost:
         priority = severity weight x (1 + downstream assets) x (2 if certified) / est. seconds
  4. run in priority order until the daily compute budget is spent.
Row-level rules on a table are batched into one scan by the runner.
"""
from __future__ import annotations

import threading
import time
from datetime import timedelta

from sqlalchemy import func, select

from .config import get_settings
from .connectors import get_connector, is_disabled
from .db import session_scope
from .dq.rules import SEVERITY_WEIGHT
from .dq.runner import run_asset
from .dq.schedules import covered_rule_ids, due as due_schedules, preview, run_schedule
from .incidents.lineage import downstream
from .models import Asset, Rule, Run, utcnow

TIME_DEPENDENT = {"freshness"}

_state = {"last_tick": None, "last_summary": None, "running": False}


def budget_used_today(db) -> float:
    start = utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    return float(db.scalar(select(func.coalesce(func.sum(Run.duration_s), 0.0))
                           .where(Run.ts >= start, Run.trigger == "schedule")) or 0.0)


def plan(db) -> list[dict]:
    cfg = get_settings().section("scheduler")
    default_iv = int(cfg.get("default_interval_minutes", 60))
    now = utcnow()
    due: dict[int, list[Rule]] = {}
    covered = covered_rule_ids(db)  # rules in an enabled rule schedule follow that schedule instead
    for r in db.scalars(select(Rule).where(Rule.status == "active")):
        if r.id in covered:
            continue
        iv = r.schedule_minutes or default_iv
        if r.last_run is None or r.last_run + timedelta(minutes=iv) <= now:
            due.setdefault(r.asset_id, []).append(r)
    items = []
    for aid, rules in due.items():
        a = db.get(Asset, aid)
        if not a:
            continue
        only = None
        skipped_reason = None
        if is_disabled(a.connection):
            items.append({"asset_id": aid, "fqn": a.fqn, "rules": [], "only_types": None, "est_cost_s": 0,
                          "priority": 0, "downstream": 0, "skipped": f"connection {a.connection} is disabled"})
            continue
        if cfg.get("change_aware", True):
            try:
                marker = get_connector(a.connection).change_marker(a.fqn)
            except Exception:
                marker = None
            a.change_marker = marker
            if marker is not None and marker == a.last_checked_marker:
                td = [r for r in rules if r.type in TIME_DEPENDENT or
                      (r.type == "anomaly" and (r.params or {}).get("metric") == "freshness_hours")]
                if not td:
                    skipped_reason = "unchanged since last check"
                rules = td
                only = {r.type for r in td}
        cost = sum(r.est_cost_s or 1.0 for r in rules) or 0.1
        weight = max((SEVERITY_WEIGHT.get(r.severity, 2) for r in rules), default=1)
        blast = len(downstream(db, a.fqn))
        prio = weight * (1 + blast) * (2 if a.certified else 1) / max(cost, 0.1)
        items.append({"asset_id": aid, "fqn": a.fqn, "rules": [r.id for r in rules], "only_types": only,
                      "est_cost_s": round(cost, 3), "priority": round(prio, 3), "downstream": blast,
                      "skipped": skipped_reason})
    return sorted(items, key=lambda x: -x["priority"])


def tick(db) -> dict:
    cfg = get_settings().section("scheduler")
    budget = float(cfg.get("daily_budget_seconds", 3600))
    used = budget_used_today(db)
    ran, skipped, deferred, schedules = [], [], [], []
    for s in due_schedules(db):
        est = preview(db, s.scope)["est_seconds"]
        if used + est > budget:
            deferred.append({"fqn": f"schedule {s.name}", "reason": "daily budget reached", "est_cost_s": est})
            continue
        try:
            res = run_schedule(db, s)
            used += res["duration_s"]
            schedules.append({"schedule": s.name, "datasets": res["datasets"], "checks": res["checks"],
                              "failed": res["failed"], "errors": res["errors"], "status": res["status"]})
        except Exception as e:
            schedules.append({"schedule": s.name, "error": f"{type(e).__name__}: {e}"[:300]})
    for item in plan(db):
        if item["skipped"] or not item["rules"]:
            skipped.append({"fqn": item["fqn"], "reason": item["skipped"] or "nothing due"})
            continue
        if used + item["est_cost_s"] > budget:
            deferred.append({"fqn": item["fqn"], "reason": "daily budget reached", "est_cost_s": item["est_cost_s"]})
            continue
        a = db.get(Asset, item["asset_id"])
        try:
            res = run_asset(db, a, trigger="schedule", rule_ids=item["rules"])
            used += res["duration_s"]
            ran.append({"fqn": a.fqn, "checks": res["checks"], "failed": res["failed"], "duration_s": res["duration_s"]})
        except Exception as e:
            ran.append({"fqn": a.fqn, "error": f"{type(e).__name__}: {e}"[:300]})
    from .incidents.quarantine import expire
    purged = expire(db)
    from .dq.custom_metrics import evaluate_all
    metrics = evaluate_all(db, include_sql=True)
    try:
        from .governance import scans
        policy_scan = scans.run_if_due(db)
    except Exception as e:
        policy_scan = {"error": f"{type(e).__name__}: {e}"[:200]}
    try:
        from .governance import pii_scans
        pii_scan = pii_scans.run_if_due(db)
    except Exception as e:
        pii_scan = {"error": f"{type(e).__name__}: {e}"[:200]}
    summary = {"at": utcnow().isoformat(timespec="seconds"), "policy_scan": policy_scan, "pii_scan": pii_scan, "ran": ran, "schedules": schedules, "skipped": skipped, "deferred": deferred,
               "budget_used_s": round(used, 2), "budget_s": budget, "quarantine_batches_expired": purged,
               "custom_metrics": {"evaluated": metrics["evaluated"], "errors": metrics["errors"]}}
    _state["last_tick"], _state["last_summary"] = summary["at"], summary
    return summary


def reset_state() -> None:
    _state["last_tick"], _state["last_summary"] = None, None


def status() -> dict:
    cfg = get_settings().section("scheduler")
    return {"enabled": bool(cfg.get("enabled")), "tick_seconds": cfg.get("tick_seconds"),
            "daily_budget_seconds": cfg.get("daily_budget_seconds"), "change_aware": cfg.get("change_aware"),
            "running": _state["running"], "last_tick": _state["last_tick"], "last_summary": _state["last_summary"]}


def start_background() -> threading.Thread | None:
    cfg = get_settings().section("scheduler")
    if not cfg.get("enabled"):
        return None

    def loop():
        _state["running"] = True
        while _state["running"]:
            try:
                with session_scope() as db:
                    tick(db)
            except Exception as e:  # keep the loop alive
                _state["last_summary"] = {"error": f"{type(e).__name__}: {e}"}
            time.sleep(int(cfg.get("tick_seconds", 300)))

    t = threading.Thread(target=loop, name="dq-scheduler", daemon=True)
    t.start()
    return t


def stop_background() -> None:
    _state["running"] = False
