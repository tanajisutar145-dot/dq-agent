/* TCS DataTrustAI - single-page UI (no build step, no external deps; runs locally and on Databricks Apps). */
"use strict";

const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const jsq = (s) => esc(JSON.stringify(s));

async function api(path, opts = {}) {
  const init = { ...opts, headers: { "Content-Type": "application/json", "X-Requested-With": "DataTrustAI", ...(opts.headers || {}) } };
  if (init.body && typeof init.body !== "string") init.body = JSON.stringify(init.body);
  const r = await fetch("/api" + path, init);
  const ct = r.headers.get("content-type") || "";
  const data = ct.includes("json") ? await r.json() : await r.text();
  if (!r.ok) {
    if (r.status === 401 && !path.startsWith("/auth/")) Auth.expired();
    if (r.status === 403 && data && data.code === "password_change_required") Auth.show("change");
    throw new Error((data && data.detail) || r.statusText);
  }
  return data;
}
const post = (p, b) => api(p, { method: "POST", body: b || {} });
const patch = (p, b) => api(p, { method: "PATCH", body: b || {} });

/* Messages stack at the bottom. Errors stay until dismissed; others fade, but pause while the pointer is on them. */
function toast(msg, ms = 4000, kind = "info") {
  let host = $("#toasts");
  if (!host) {
    host = document.createElement("div");
    host.id = "toasts";
    document.body.appendChild(host);
  }
  const t = document.createElement("div");
  t.className = "toast " + kind;
  t.setAttribute("role", kind === "error" ? "alert" : "status");
  t.innerHTML = '<span class="toast-msg"></span><button class="toast-x" aria-label="Dismiss" title="Dismiss">&times;</button>';
  t.querySelector(".toast-msg").textContent = msg;
  const close = () => t.remove();
  t.querySelector(".toast-x").onclick = close;
  host.appendChild(t);
  while (host.children.length > 5) host.firstElementChild.remove();
  if (ms > 0) {
    let timer = setTimeout(close, ms);
    t.onmouseenter = () => clearTimeout(timer);
    t.onmouseleave = () => { timer = setTimeout(close, 2500); };
  }
  return t;
}
const toastError = (msg) => toast(msg, 0, "error");
const toastWarn = (msg) => toast(msg, 15000, "warn");
const toastOk = (msg) => toast(msg, 4000, "ok");

/* Small modal on the native <dialog> element (Esc closes it). Modal.open(html) returns the dialog. */
const Modal = {
  open(html, opts = {}) {
    Modal.close();
    const d = document.createElement("dialog");
    d.className = "modal" + (opts.wide ? " wide" : "") + (opts.size === "xl" ? " xl" : "");
    d.innerHTML = html;
    d.addEventListener("close", () => d.remove());
    d.addEventListener("click", (e) => { if (e.target === d) d.close(); });
    document.body.appendChild(d);
    d.showModal();
    const first = d.querySelector("[autofocus], input, select, textarea");
    if (first) first.focus();
    return d;
  },
  close() {  // remove at once, so a later dialog never finds a stale field with the same id
    document.querySelectorAll("dialog.modal").forEach((d) => { if (d.open) d.close(); d.remove(); });
  },
  head(title, sub) {
    return `<div class="modal-head"><div><h2>${esc(title)}</h2>${sub ? `<div class="sub">${sub}</div>` : ""}</div>
      <button class="toast-x modal-x" aria-label="Close" onclick="Modal.close()">&times;</button></div>`;
  },
};
function scoreCls(s) { return s == null ? "" : s >= 95 ? "hi" : s >= 80 ? "mid" : "lo"; }
function score(s) { return s == null ? '<span class="muted">n/a</span>' : `<span class="score ${scoreCls(s)}">${Number(s).toFixed(1)}</span>`; }
function pill(s, label) { return `<span class="pill ${esc(s)}">${esc(label ?? s)}</span>`; }
const PLATFORMS = { databricks: "Databricks", snowflake: "Snowflake", azure_purview: "Azure Purview", aws_glue: "AWS Glue",
  spark: "Apache Spark", cognite: "Cognite", cdf: "Cognite", duckdb: "DuckDB" };
const GL = () => (State.meta && State.meta.grouping && State.meta.grouping.label) || "Domain";  // what this installation calls the grouping
const GLl = () => GL().toLowerCase();
function platKey(p) { return p === "cdf" ? "cognite" : (PLATFORMS[p] ? p : "other"); }
function plat(p, label) { return `<span class="plat ${esc(platKey(p))}">${esc(label || PLATFORMS[p] || p || "other")}</span>`; }
/* Platform types of the enabled connections: what has actually been connected, not every platform the app supports. */
/* One platform choice for all Operate pages and the Catalog: only platforms with an enabled connection, and every page then shows just those datasets. */
async function platformPicker() {
  const plats = await connectedPlatforms();
  if (State.platform && !plats.includes(State.platform)) State.platform = "";
  return plats.length ? `<select aria-label="Platform" title="Platform" onchange="State.platform=this.value; Ov.f = null; render(true)"><option value="">${plats.length > 1 ? "All connected platforms" : "Connected platform"}</option>${plats.map((p) =>
    `<option value="${esc(p)}" ${State.platform === p ? "selected" : ""}>${esc(PLATFORMS[p] || p)}</option>`).join("")}</select>` : "";
}
const platQ = (extra = "") => (State.platform ? `${extra}${extra ? "&" : ""}platform=${encodeURIComponent(State.platform)}` : extra);
async function connectedPlatforms() {
  const conns = await api("/connections").catch(() => []);
  return [...new Set(conns.filter((c) => c.enabled !== false).map((c) => c.type))].sort();
}
function initials(s) {
  const base = String(s || "?").split("@")[0].split(/[._\s-]+/).filter(Boolean);
  return ((base[0] || "?")[0] + (base[1] ? base[1][0] : "")).toUpperCase();
}
function kpiTone(kind, v) {
  if (kind === "score") return v == null ? "" : v >= 95 ? "ok" : v >= 80 ? "warn" : "bad";
  if (kind === "count") return v > 0 ? "bad" : "ok";
  if (kind === "soft") return v > 0 ? "warn" : "ok";
  return "info";
}
function ts(iso) {
  if (!iso) return "";
  const d = new Date(iso.endsWith("Z") || iso.includes("+") ? iso : iso + "Z");
  return d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
function short(fqn) { return String(fqn || "").split(/[.:]/).pop(); }
function pct(x) { return x == null ? "" : (x * 100).toFixed(x < 0.01 && x > 0 ? 2 : 1) + "%"; }
function fmtVal(v) {
  if (v == null) return '<span class="muted">-</span>';
  if (typeof v === "number") return Number.isInteger(v) ? v.toLocaleString() : v.toLocaleString(undefined, { maximumFractionDigits: 3 });
  return esc(String(v).length > 28 ? String(v).slice(0, 28) + "…" : v);
}

async function act(btn, fn, okMsg) {
  if (btn) btn.disabled = true;
  try {
    const res = await fn();
    if (okMsg) toast(typeof okMsg === "function" ? okMsg(res) : okMsg);
    await render(true);
    return res;
  } catch (e) {
    toastError(e.message);
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* ------------------------------------------------------------------ charts */
function lineChart(points, opts = {}) {
  const W = opts.width || 560, H = opts.height || 140, P = 28;
  if (!points || points.length < 2) return '<div class="empty">Not enough history yet</div>';
  const vals = points.map((p) => p.value);
  let lo = Math.min(...vals), hi = Math.max(...vals);
  if (lo === hi) { lo -= 1; hi += 1; }
  const x = (i) => P + (i / (points.length - 1)) * (W - P * 2);
  const y = (v) => H - 32 - ((v - lo) / (hi - lo)) * (H - 56);
  const d = points.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(" ");
  const last = points[points.length - 1];
  const f = opts.fmt || ((v) => Number(v).toLocaleString(undefined, { maximumFractionDigits: 2 }));
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="${esc(opts.label || "trend")}">
    <line x1="${P}" x2="${W - P}" y1="${y(lo)}" y2="${y(lo)}" style="stroke:var(--border)"/>
    <line x1="${P}" x2="${W - P}" y1="${y(hi)}" y2="${y(hi)}" style="stroke:var(--border)" stroke-dasharray="3 3"/>
    <path d="${d}" fill="none" style="stroke:var(--accent)" stroke-width="2"/>
    <circle cx="${x(points.length - 1)}" cy="${y(last.value)}" r="3.5" style="fill:var(--accent)"/>
    <text x="${P}" y="${y(hi) - 5}" font-size="11" style="fill:var(--text-3)">${esc(f(hi))}</text>
    <text x="${P}" y="${y(lo) + 13}" font-size="11" style="fill:var(--text-3)">${esc(f(lo))}</text>
    <text x="${W - P}" y="${y(last.value) - 8}" font-size="11" text-anchor="end">${esc(f(last.value))}</text>
    <text x="${P}" y="${H - 2}" font-size="10.5" style="fill:var(--text-3)">${esc(ts(points[0].ts || points[0].date))}</text>
    <text x="${W - P}" y="${H - 2}" font-size="10.5" text-anchor="end" style="fill:var(--text-3)">${esc(ts(last.ts || last.date))}</text>
  </svg>`;
}

const HEALTH = {
  root_cause: ["var(--bad-bg)", "var(--bad)"], failing: ["var(--bad-bg)", "var(--bad)"],
  warning: ["var(--warn-bg)", "var(--warn)"], impacted: ["var(--warn-bg)", "var(--warn)"],
  healthy: ["var(--ok-bg)", "var(--ok)"], unknown: ["var(--surface-2)", "var(--border-strong)"],
};
function lineageSvg(g) {
  if (!g || !g.nodes.length) return '<div class="empty">No lineage recorded yet. Sync from the platform, post OpenLineage events, or upload a dbt manifest.</div>';
  const level = {};
  const hasDist = g.nodes.some((n) => n.distance != null);
  if (hasDist) g.nodes.forEach((n) => (level[n.id] = n.distance ?? 0));
  else {
    g.nodes.forEach((n) => (level[n.id] = 0));
    for (let k = 0; k < g.nodes.length; k++) {
      let changed = false;
      g.edges.forEach((e) => { if (level[e.target] < level[e.source] + 1) { level[e.target] = level[e.source] + 1; changed = true; } });
      if (!changed) break;
    }
  }
  const levels = [...new Set(Object.values(level))].sort((a, b) => a - b);
  const cols = {};
  g.nodes.forEach((n) => (cols[level[n.id]] = cols[level[n.id]] || []).push(n));
  const NW = 190, NH = 46, CG = 70, RG = 16;
  const pos = {};
  let maxRows = 0;
  levels.forEach((lv, ci) => {
    cols[lv].sort((a, b) => a.id.localeCompare(b.id));
    cols[lv].forEach((n, ri) => (pos[n.id] = { x: 10 + ci * (NW + CG), y: 10 + ri * (NH + RG) }));
    maxRows = Math.max(maxRows, cols[lv].length);
  });
  const W = 20 + levels.length * (NW + CG) - CG, H = 20 + maxRows * (NH + RG) - RG;
  const edges = g.edges.filter((e) => pos[e.source] && pos[e.target]).map((e) => {
    const a = pos[e.source], b = pos[e.target];
    const x1 = a.x + NW, y1 = a.y + NH / 2, x2 = b.x, y2 = b.y + NH / 2, mx = (x1 + x2) / 2;
    return `<path d="M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2 - 6},${y2}" fill="none" style="stroke:var(--border-strong)" stroke-width="1.5" marker-end="url(#arr)"/>`;
  }).join("");
  const nodes = g.nodes.map((n) => {
    const p = pos[n.id], [bg, br] = HEALTH[n.health] || HEALTH.unknown;
    const focus = g.focus === n.id ? ' stroke-width="2.5"' : ' stroke-width="1"';
    const click = n.asset_id ? ` onclick="location.hash='#/asset/${n.asset_id}'" style="cursor:pointer"` : "";
    const label = short(n.id).length > 24 ? short(n.id).slice(0, 23) + "…" : short(n.id);
    return `<g${click}><title>${esc(n.id)}</title>
      <rect x="${p.x}" y="${p.y}" width="${NW}" height="${NH}" rx="7" style="fill:${bg};stroke:${br}"${focus}/>
      <rect x="${p.x + 1.5}" y="${p.y + 1.5}" width="5" height="${NH - 3}" rx="2.5" style="fill:var(--p-${platKey(n.platform)})"/>
      <text x="${p.x + 15}" y="${p.y + 19}" font-size="12.5" font-weight="600">${esc(label)}</text>
      <text x="${p.x + 15}" y="${p.y + 35}" font-size="11" style="fill:var(--text-2)">${esc(PLATFORMS[n.platform] || n.platform || "")}${n.score != null ? " · " + n.score : ""}${n.health === "root_cause" ? " · root cause" : ""}</text></g>`;
  }).join("");
  return `<div class="wrap"><svg width="${Math.max(W, 300)}" height="${H}" viewBox="0 0 ${Math.max(W, 300)} ${H}" role="img" aria-label="Lineage graph">
    <defs><marker id="arr" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
    <path d="M0,0 L10,5 L0,10 z" style="fill:var(--border-strong)"/></marker></defs>${edges}${nodes}</svg></div>
    <div class="row sub" style="margin-top:6px">${pill("root_cause", "root cause")} ${pill("failing")} ${pill("warning")} ${pill("healthy")} ${pill("unknown", "not monitored")}</div>`;
}

/* Top-bar Help opens the guide section for the current page (anchors in docs/ui-guide.md). */
const HELP_FOR = { overview: "ui-guide/overview", runs: "ui-guide/runs", violations: "ui-guide/violations", explore: "ui-guide/explore", asset: "ui-guide/dataset-page",
  incident: "ui-guide/incident-page", rules: "ui-guide/ai-rule-studio", lineage: "ui-guide/lineage",
  governance: "ui-guide/governance", settings: "ui-guide/settings", deploy: "ui-guide/deploy",
  guide: "getting-started", admin: "ui-guide/admin-console", account: "ui-guide/your-account",
  insights: "ui-guide/insights", anomalies: "ui-guide/anomalies", impact: "ui-guide/impact-analysis", fixes: "ui-guide/fixes-and-quarantine",
  references: "ui-guide/reference-files" };

/* ------------------------------------------------------------------ state + router */
const State = { meta: null, ctx: {}, q: "", platform: "", incStatus: "open", framework: "gdpr", studioAsset: null, govAsset: "" };

async function render(keepScroll) {
  if (!State.user) return;
  const am = $("#acct-menu");
  if (am) am.hidden = true;
  const main = $("#main");
  const y = main.scrollTop;
  const parts = (location.hash.replace(/^#\/?/, "") || "overview").split("/");
  const REDIRECT = { catalog: "explore/datasets", incidents: "explore/incidents", insights: "explore/patterns", anomalies: "explore/datasets", violations: "explore/violations" };
  if (REDIRECT[parts[0]]) { location.replace("#/" + REDIRECT[parts[0]]); return; }
  if (parts[0] === "overview" && parts[1]) { location.replace("#/overview"); return; }  // the old Summary, Rules and Incidents tabs
  if (parts[0] === "rules" && parts[1] === "runs") { location.replace("#/runs"); return; }  // moved to Operate > Runs
  const [route, a1, a2] = parts;
  const fixesOn = !!(State.meta && State.meta.features && State.meta.features.fixes_and_quarantine);
  document.querySelectorAll('.nav a[data-r="fixes"]').forEach((a) => { a.style.display = fixesOn ? "" : "none"; });
  if (route === "fixes" && !fixesOn) { location.replace("#/overview"); return; }  // not offered in this version
  State.prevRoute = State.route;  // pages can tell a fresh visit from a re-render (Overview filters reset on a visit)
  State.route = route;
  document.querySelectorAll(".nav a").forEach((a) => a.classList.toggle("active", a.dataset.r === route || (["asset", "incident", "impact", "lineage"].includes(route) && a.dataset.r === "explore")));
  const CRUMB = { overview: "Overview", runs: "Runs", explore: "Explore" + (a1 ? " / " + (a1 === "patterns" ? "Patterns and Insights" : a1[0].toUpperCase() + a1.slice(1)) : ""), asset: "Explore / Dataset", incident: "Explore / Incident #" + (a1 || ""),
    rules: "AI Rule Studio", lineage: "Lineage", governance: "Intelligent Governance", settings: "Settings", deploy: "Deploy",
    guide: "Guide and docs", admin: "Admin console", account: "Your account", insights: "Insights", anomalies: "Anomalies",
    impact: "Impact analysis", fixes: "Fixes and quarantine", references: "Reference files" };
  const crumb = CRUMB[route] || "Overview";
  $("#crumb").innerHTML = crumb.split(" / ").map((c, i, arr) => i === arr.length - 1 ? `<strong>${esc(c)}</strong>` : esc(c) + " / ").join("");
  $("#help-link").href = "#/guide/" + (HELP_FOR[route] || "getting-started");
  State.ctx = {};
  try {
    const page = Pages[route] || Pages.overview;
    main.innerHTML = await page(a1, a2);
  } catch (e) {
    main.innerHTML = `<div class="callout bad">${esc(e.message)}</div>`;
  }
  if (keepScroll) main.scrollTop = y; else main.scrollTop = 0;
  Agent.updateCtx();
  refreshCounts();
}
window.addEventListener("hashchange", () => render(false));

async function refreshCounts() {
  try {
    const inc = await api("/incidents?status=open");
    const ni = $("#nav-inc");
    ni.hidden = !inc.length; ni.textContent = inc.length;
    State.openIncCount = inc.length;
    if (State.user && State.user.role === "admin") {
      const s = await api("/admin/summary"), np = $("#nav-pending");
      np.hidden = !s.pending; np.textContent = s.pending;
    }
  } catch (e) { /* ignore */ }
}

/* ------------------------------------------------------------------ pages */
const Pages = {};

/* Custom DQ metrics: user-defined tiles on the Overview, with a target, a warning level and a trend. */
function sparkline(points, target) {
  if (!points || points.length < 2) return "";
  const W = 220, H = 34, P = 2, vals = points.map((p) => p.value);
  let lo = Math.min(...vals, target ?? Infinity), hi = Math.max(...vals, target ?? -Infinity);
  if (lo === hi) { lo -= 1; hi += 1; }
  const x = (i) => P + (i / (points.length - 1)) * (W - 2 * P);
  const y = (v) => H - P - ((v - lo) / (hi - lo)) * (H - 2 * P);
  const d = points.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(" ");
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" preserveAspectRatio="none" role="img" aria-label="Trend of the last ${points.length} values">
    ${target != null ? `<line x1="0" x2="${W}" y1="${y(target).toFixed(1)}" y2="${y(target).toFixed(1)}" style="stroke:var(--text-3)" stroke-dasharray="3 3" vector-effect="non-scaling-stroke"/>` : ""}
    <path d="${d}" fill="none" style="stroke:var(--accent)" stroke-width="1.8" vector-effect="non-scaling-stroke"/></svg>`;
}
const Metrics = {
  canEdit: () => !State.user || State.user.role !== "viewer",
  fmt(m) {
    if (m.last_value == null) return '<span class="muted">-</span>';
    const v = Number(m.last_value);
    const num = Number.isInteger(v) ? v.toLocaleString() : v.toLocaleString(undefined, { maximumFractionDigits: 1 });
    const unit = m.unit && !["score", "count"].includes(m.unit) ? m.unit : "";
    return esc(num) + (unit ? `<span class="unit">${esc(unit)}</span>` : "");
  },
  targetText(m) {
    if (m.target == null) return "No target set";
    const op = m.direction === "lower" ? "≤" : "≥", u = m.unit === "%" ? "%" : "";
    return `Target ${op} ${m.target}${u}` + (m.warn_at != null ? ` · warn ${op} ${m.warn_at}${u}` : "");
  },
  tile(m) {
    const tone = { ok: "ok", warn: "warn", bad: "bad", info: "info" }[m.status] || "";
    const menu = Metrics.canEdit() ? `<div class="tile-menu"><button onclick="Metrics.edit(${m.id})" aria-label="Edit ${esc(m.name)}">Edit</button>
      <button onclick="Metrics.askDelete(${m.id}, ${jsq(m.name)})" aria-label="Delete ${esc(m.name)}">Delete</button></div>` : "";
    return `<div class="card kpi metric-tile ${tone}" title="${esc(m.description || m.measure_label)}">${menu}
      <div class="label">${esc(m.name)}</div><div class="value">${Metrics.fmt(m)}</div>
      <div class="hint">${esc(Metrics.targetText(m))}</div><div class="scope">${esc(m.measure_label)} · ${esc(m.scope)}${m.last_evaluated ? " · " + esc(ts(m.last_evaluated)) : ""}</div>
      ${m.last_error ? `<div class="err">${esc(m.last_error)}</div>` : ""}${sparkline(m.trend, m.target)}</div>`;
  },
  section(ms) {
    State.metrics = ms;
    const edit = Metrics.canEdit();
    const add = edit ? `<button class="metric-new" onclick="Metrics.edit()">+ New custom metric</button>` : "";
    return `<div class="card"><div class="row"><h2 style="margin:0">Custom DQ metrics</h2>
      <span class="sub">${ms.length ? "Your own KPIs, measured against your targets" : "Track the numbers your team cares about, such as completeness of a domain, failed checks this week, or a SQL measure on a platform"}</span>
      <span style="flex:1"></span>${ms.length && edit ? '<button class="btn sm" onclick="Metrics.refresh(this)">Refresh values</button>' : ""}
      ${edit && ms.length ? '<button class="btn sm primary" onclick="Metrics.edit()">New metric</button>' : ""}</div>
      ${ms.length ? `<div class="metric-grid">${ms.map(Metrics.tile).join("")}</div>`
        : add ? `<div class="grid" style="margin-top:12px">${add}</div>` : '<div class="empty">No custom metrics yet.</div>'}</div>`;
  },
  async refresh(btn) {
    btn.disabled = true;
    try {
      const r = await post("/custom-metrics/evaluate");
      const errs = Object.entries(r.errors || {});
      if (errs.length) toastError(errs.map(([n, e]) => `${n}: ${e}`).join("\n"));
      else toastOk(`Refreshed ${r.evaluated} metrics`);
      await render(true);
    } catch (e) { toastError(e.message); btn.disabled = false; }
  },
  async edit(id) {
    const [opt, all] = await Promise.all([api("/custom-metrics/options"), id ? api("/custom-metrics") : Promise.resolve([])]);
    const m = id ? all.find((x) => x.id === id) : null;
    if (id && !m) return toastError("That metric no longer exists");
    Metrics.opt = opt;
    Metrics.cur = m ? { ...m, params: { ...(m.params || {}) } } : { measure: "pass_rate", params: { window_days: 7 }, direction: null, unit: null };
    const ms = opt.measures;
    const group = (sql) => Object.entries(ms).filter(([k]) => (k === "sql") === sql)
      .map(([k, v]) => `<option value="${k}" ${k === Metrics.cur.measure ? "selected" : ""}>${esc(v.label)}</option>`).join("");
    Modal.open(`${Modal.head(m ? "Edit custom metric" : "New custom metric", "Pick what to measure, narrow it down, and set a target.")}
      <div class="modal-body">
        <label class="f">Name<input id="cm-name" value="${esc(m ? m.name : "")}" placeholder="e.g. Billing completeness" autofocus></label>
        <label class="f" style="margin-top:8px">Measure<select id="cm-measure" onchange="Metrics.measureChanged()">
          <optgroup label="From TCS DataTrustAI data">${group(false)}</optgroup><optgroup label="From a platform">${group(true)}</optgroup></select></label>
        <div class="sub" id="cm-help" style="margin-top:3px"></div>
        <div id="cm-filters" class="grid" style="grid-template-columns:1fr 1fr;gap:8px;margin-top:8px"></div>
        <div class="grid" style="grid-template-columns:1fr 1fr 1fr 1fr;gap:8px;margin-top:8px">
          <label class="f">Better when<select id="cm-direction"><option value="higher">Higher</option><option value="lower">Lower</option></select></label>
          <label class="f">Target<input id="cm-target" type="number" step="any" value="${m && m.target != null ? m.target : ""}" placeholder="optional"></label>
          <label class="f">Warn at<input id="cm-warn" type="number" step="any" value="${m && m.warn_at != null ? m.warn_at : ""}" placeholder="optional"></label>
          <label class="f">Unit<input id="cm-unit" list="cm-units"><datalist id="cm-units">${opt.units.filter(Boolean).map((u) => `<option value="${esc(u)}">`).join("")}</datalist></label></div>
        <label class="f" style="margin-top:8px">Description<input id="cm-desc" value="${esc(m && m.description ? m.description : "")}" placeholder="optional: what it means and who owns it"></label>
        <div class="row" style="margin-top:12px;gap:8px"><button class="btn sm" onclick="Metrics.preview(this)">Preview value</button><div id="cm-preview" class="preview-box" style="flex:1">Preview shows the current value before you save.</div></div>
      </div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button>
        <button class="btn primary" onclick="Metrics.save(this)">${m ? "Save changes" : "Create metric"}</button></div>`, { wide: true });
    Metrics.measureChanged(true);
  },
  measureChanged(initial) {
    const opt = Metrics.opt, cur = Metrics.cur;
    const key = $("#cm-measure").value, spec = opt.measures[key];
    if (!initial) {  // keep filters the new measure shares with the old one (domain, connection...)
      const keep = {};
      document.querySelectorAll("#cm-filters [data-p]").forEach((el) => { if (el.value !== "") keep[el.dataset.p] = el.value; });
      cur.params = keep; cur.direction = null; cur.unit = null;
    }
    cur.measure = key;
    $("#cm-help").textContent = spec.help;
    $("#cm-direction").value = cur.direction || spec.direction;
    $("#cm-unit").value = cur.unit != null ? cur.unit : spec.unit;
    const req = new Set(spec.required || []), p = cur.params;
    const sel = (k, label, items, anyLabel) => `<label class="f">${label}<select data-p="${k}">${req.has(k) ? "" : `<option value="">${anyLabel}</option>`}
      ${items.map((i) => { const v = typeof i === "string" ? i : i.value; const l = typeof i === "string" ? i : i.label; return `<option value="${esc(v)}" ${String(p[k] ?? "") === v ? "selected" : ""}>${esc(l)}</option>`; }).join("")}</select></label>`;
    const html = spec.filters.map((k) => {
      if (k === "dimension") return sel(k, "Dimension", opt.dimensions, "Any dimension");
      if (k === "severity") return sel(k, "Rule severity", opt.severities, "Any severity");
      if (k === "domain") return sel(k, GL(), opt.domains, "All " + GLl() + "s");
      if (k === "platform") return sel(k, "Platform", opt.platforms.map((x) => ({ value: x, label: PLATFORMS[x] || x })), "All platforms");
      if (k === "connection") return sel(k, "Connection", opt.connections.filter((c) => c.enabled || c.name === p[k]).map((c) => ({ value: c.name, label: `${c.name} (${PLATFORMS[c.type] || c.type})` })), "All connections");
      if (k === "window_days") return `<label class="f">Time window (days)<input type="number" min="1" max="365" data-p="${k}" value="${esc(p[k] ?? 7)}"></label>`;
      if (k === "threshold") return `<label class="f">Score threshold<input type="number" min="0" max="100" step="any" data-p="${k}" value="${esc(p[k] ?? 80)}"></label>`;
      if (k === "sql") return `<label class="f" style="grid-column:1/-1">SQL (one read-only SELECT; the first column of the first row is the value)
        <textarea data-p="sql" class="mono" rows="5" placeholder="SELECT 100.0 * avg(CASE WHEN email IS NOT NULL THEN 1 ELSE 0 END) FROM main.crm.customers">${esc(p.sql || "")}</textarea></label>`;
      return "";
    }).join("");
    $("#cm-filters").innerHTML = html || '<div class="sub">No filters for this measure: it covers all datasets.</div>';
  },
  collect() {
    const params = {};
    document.querySelectorAll("#cm-filters [data-p]").forEach((el) => { if (el.value !== "") params[el.dataset.p] = el.value; });
    return { name: $("#cm-name").value, measure: $("#cm-measure").value, params, direction: $("#cm-direction").value,
      target: $("#cm-target").value, warn_at: $("#cm-warn").value, unit: $("#cm-unit").value, description: $("#cm-desc").value };
  },
  async preview(btn) {
    const box = $("#cm-preview");
    btn.disabled = true;
    box.textContent = "Calculating…";
    try {
      const body = Metrics.collect();
      if (!body.name.trim()) body.name = "preview";
      const r = await post("/custom-metrics/preview", body);
      if (!r.ok) { box.innerHTML = `<span style="color:var(--bad)">${esc(r.error)}</span>`; return; }
      const label = { ok: ["ok", "meets target"], warn: ["warn", "warning"], bad: ["bad", "misses target"], info: ["info", "no target"], nodata: ["muted", "no data yet"] }[r.status];
      box.innerHTML = `Current value: <strong>${Metrics.fmt({ last_value: r.value, unit: body.unit })}</strong> ${pill(label[0], label[1])}`;
    } catch (e) { box.innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span>`; }
    finally { btn.disabled = false; }
  },
  async save(btn) {
    btn.disabled = true;
    try {
      const body = Metrics.collect(), id = Metrics.cur && Metrics.cur.id;
      const m = id ? await patch(`/custom-metrics/${id}`, body) : await post("/custom-metrics", body);
      Modal.close();
      if (m.last_error) toastError(`${m.name} was saved, but it could not be calculated:\n${m.last_error}`);
      else toastOk(id ? "Metric updated" : "Metric created");
      await render(true);
    } catch (e) { toastError(e.message); btn.disabled = false; }
  },
  askDelete(id, name) {
    Modal.open(`${Modal.head("Delete metric " + name)}<div class="modal-body"><p>The metric and its history are removed. Datasets and rules are not affected.</p></div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button>
        <button class="btn danger" onclick="Metrics.doDelete(this, ${id})">Delete metric</button></div>`);
  },
  async doDelete(btn, id) {
    btn.disabled = true;
    try { await api(`/custom-metrics/${id}`, { method: "DELETE" }); Modal.close(); toastOk("Metric deleted"); await render(true); }
    catch (e) { toastError(e.message); btn.disabled = false; }
  },
};

/* ------------------------------------------------------------------ charts (no external libraries)
   Thin bars with a rounded data-end, 2px surface gaps between stacked segments, 2px lines, hairline grid,
   one tooltip on hover and keyboard focus (values via textContent), a legend for 2+ series, a table view. */
const Viz = {
  store: {}, tableOn: {},
  num(v, unit = "") {
    if (v == null) return "-";
    const n = Number(v);
    return (Number.isInteger(n) ? n.toLocaleString() : n.toLocaleString(undefined, { maximumFractionDigits: 1 })) + unit;
  },
  trunc(s, n) { s = String(s ?? ""); return s.length > n ? s.slice(0, n - 1) + "…" : s; },
  barPath(x, y, w, h) {
    const r = Math.min(4, w, h / 2);
    return `M${x},${y}H${x + w - r}A${r},${r} 0 0 1 ${x + w},${y + r}V${y + h - r}A${r},${r} 0 0 1 ${x + w - r},${y + h}H${x}Z`;
  },
  tipAttr(lines) { return `data-tip="${esc(JSON.stringify(lines))}"`; },
  click(fn, ...args) { return fn ? `onclick="${fn}(${args.map((a) => esc(JSON.stringify(a))).join(",")})"` : ""; },
  legend(series, line) {
    return `<div class="vz-legend">${series.map((s) => `<span><span class="${line ? "ln" : "sw"}" style="background:${s.color}"></span>${esc(s.label)}</span>`).join("")}</div>`;
  },
  /* rows: [{key, label, value, color?, note?}] */
  hbars(rows, o = {}) {
    if (!rows.length) return `<div class="empty">${esc(o.empty || "Nothing to show")}</div>`;
    const W = 560, LW = o.labelW || 180, rowH = 30, barH = 16, top = 4, x0 = LW + 10, avail = W - x0 - 64;
    const max = o.max != null ? o.max : Math.max(...rows.map((r) => r.value), 1);
    const H = top * 2 + rows.length * rowH;
    const body = rows.map((r, i) => {
      const y = top + i * rowH, by = y + (rowH - barH) / 2, w = max ? Math.max(0, (r.value / max) * avail) : 0;
      const val = Viz.num(r.value, o.unit || "");
      const clickable = o.click && r.key != null;
      return `<g class="vz-hit" tabindex="0" role="img" aria-label="${esc(r.label)}: ${esc(val)}" ${Viz.tipAttr([val, r.label + (r.note ? " · " + r.note : "")])} ${clickable ? Viz.click(o.click, r.key) : ""}>
        <rect class="hit" x="0" y="${y}" width="${W}" height="${rowH}" rx="4" fill="transparent"/>
        <text x="${LW}" y="${y + rowH / 2}" text-anchor="end" dominant-baseline="central">${esc(Viz.trunc(r.label, o.chars || 26))}</text>
        ${w > 0.5 ? `<path d="${Viz.barPath(x0, by, w, barH)}" style="fill:${r.color || o.color || "var(--viz-1)"}"/>` : ""}
        <text class="vz-val" x="${x0 + w + 6}" y="${y + rowH / 2}" dominant-baseline="central">${esc(val)}</text></g>`;
    }).join("");
    return `<svg class="vz" viewBox="0 0 ${W} ${H}" width="100%" role="group" aria-label="${esc(o.label || "bar chart")}">
      <line class="vz-base" x1="${x0}" x2="${x0}" y1="${top}" y2="${H - top}"/>${body}</svg>`;
  },
  /* rows: [{key, label, values: {seriesKey: n}}], series: [{key, label, color}] */
  hstack(rows, series, o = {}) {
    if (!rows.length || !rows.some((r) => series.some((s) => r.values[s.key]))) return `<div class="empty">${esc(o.empty || "Nothing to show")}</div>`;
    const W = 560, LW = o.labelW || 150, rowH = 32, barH = 16, top = 4, x0 = LW + 10, avail = W - x0 - 56, gap = 2;
    const total = (r) => series.reduce((t, s) => t + (r.values[s.key] || 0), 0);
    const max = Math.max(...rows.map(total), 1);
    const H = top * 2 + rows.length * rowH;
    const body = rows.map((r, i) => {
      const y = top + i * rowH, by = y + (rowH - barH) / 2, t = total(r);
      const segs = series.filter((s) => r.values[s.key] > 0);
      let x = x0;
      const marks = segs.map((s, j) => {
        const v = r.values[s.key], full = (v / max) * avail, last = j === segs.length - 1, w = Math.max(1, full - (last ? 0 : gap));
        const shape = last ? `<path d="${Viz.barPath(x, by, w, barH)}" style="fill:${s.color}"/>` : `<rect class="seg" x="${x}" y="${by}" width="${w}" height="${barH}" style="fill:${s.color}"/>`;
        const g = `<g class="vz-hit" tabindex="0" role="img" aria-label="${esc(r.label)}, ${esc(s.label)}: ${v}" ${Viz.tipAttr([Viz.num(v), `${s.label} · ${r.label}`])} ${o.click ? Viz.click(o.click, r.key, s.key) : ""}>
          <rect class="hit" x="${x}" y="${y}" width="${Math.max(full, 6)}" height="${rowH}" fill="transparent"/>${shape}</g>`;
        x += full;
        return g;
      }).join("");
      return `<text x="${LW}" y="${y + rowH / 2}" text-anchor="end" dominant-baseline="central">${esc(Viz.trunc(r.label, o.chars || 22))}</text>${marks}
        <text class="vz-val" x="${x + 6}" y="${y + rowH / 2}" dominant-baseline="central">${esc(Viz.num(t))}</text>`;
    }).join("");
    return Viz.legend(series) + `<svg class="vz" viewBox="0 0 ${W} ${H}" width="100%" role="group" aria-label="${esc(o.label || "stacked bar chart")}">
      <line class="vz-base" x1="${x0}" x2="${x0}" y1="${top}" y2="${H - top}"/>${body}</svg>`;
  },
  niceMax(v) {
    if (v <= 0) return 1;
    const p = Math.pow(10, Math.floor(Math.log10(v))), f = v / p;
    return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p;
  },
  /* points: [{date, <seriesKey>: n}], series: [{key, label, color}] */
  lines(id, points, series, o = {}) {
    if (!points.length) return `<div class="empty">${esc(o.empty || "Nothing to show")}</div>`;
    const W = 560, H = 190, pl = 40, pr = series.length > 1 ? 104 : 56, pt = 10, pb = 24, pw = W - pl - pr, ph = H - pt - pb, n = points.length;
    const ymax = Viz.niceMax(Math.max(...points.flatMap((p) => series.map((s) => p[s.key] || 0)), 0));
    const counts = points.every((p) => series.every((s) => Number.isInteger(p[s.key] || 0)));
    const ticks = counts && !Number.isInteger(ymax / 2) ? [0, ymax] : [0, ymax / 2, ymax];  // no "2.5 incidents" tick
    const X = (i) => pl + (n === 1 ? pw / 2 : (i / (n - 1)) * pw), Y = (v) => pt + ph - (v / ymax) * ph;
    const day = (d) => new Date(d + "T00:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" });
    Viz.store[id] = { points, series, W, pl, pw, n, X, Y, day, unit: o.unit || "" };
    const grid = ticks.map((t) => `<line class="${t ? "vz-grid" : "vz-base"}" x1="${pl}" x2="${pl + pw}" y1="${Y(t)}" y2="${Y(t)}"/>
      <text class="vz-axis" x="${pl - 6}" y="${Y(t)}" text-anchor="end" dominant-baseline="central">${esc(Viz.num(t))}</text>`).join("");
    const xl = [0, Math.floor((n - 1) / 2), n - 1].filter((v, i, a) => a.indexOf(v) === i)
      .map((i) => `<text class="vz-axis" x="${X(i)}" y="${H - 6}" text-anchor="${n === 1 ? "middle" : i === 0 ? "start" : i === n - 1 ? "end" : "middle"}">${esc(day(points[i].date))}</text>`).join("");
    const ends = series.map((s) => ({ s, y: Y(points[n - 1][s.key] || 0), v: points[n - 1][s.key] || 0 }));
    const collide = ends.length > 1 && Math.abs(ends[0].y - ends[1].y) < 13;
    const paths = n < 2 ? "" : series.map((s) => `<path d="${points.map((p, i) => `${i ? "L" : "M"}${X(i).toFixed(1)},${Y(p[s.key] || 0).toFixed(1)}`).join("")}" fill="none"
      style="stroke:${s.color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`).join("");
    const dots = ends.map((e) => `<circle cx="${X(n - 1)}" cy="${e.y}" r="4" style="fill:${e.s.color};stroke:var(--surface)" stroke-width="2"/>
      ${collide ? "" : `<text x="${X(n - 1) + 8}" y="${e.y}" dominant-baseline="central">${series.length > 1 ? esc(e.s.label) + " " : ""}<tspan class="vz-val">${esc(Viz.num(e.v, o.unit || ""))}</tspan></text>`}`).join("");
    return (series.length > 1 ? Viz.legend(series, true) : "") + `<svg class="vz" id="vzl-${id}" viewBox="0 0 ${W} ${H}" width="100%" role="group" aria-label="${esc(o.label || "line chart")}">
      ${grid}${xl}${paths}${dots}<line class="vz-cross" id="vzx-${id}" x1="0" x2="0" y1="${pt}" y2="${pt + ph}" visibility="hidden"/>
      <rect x="${pl}" y="${pt}" width="${pw}" height="${ph}" fill="transparent" tabindex="0" aria-label="${esc(o.label || "line chart")}: use the arrow keys to read values"
        onpointermove="Viz.cross(event, '${id}')" onpointerleave="Viz.uncross('${id}')" onblur="Viz.uncross('${id}')" onkeydown="Viz.crossKey(event, '${id}')"/></svg>`;
  },
  crossAt(id, i, cx, cy) {
    const st = Viz.store[id];
    if (!st) return;
    i = Math.max(0, Math.min(st.n - 1, i));
    st.i = i;
    const ln = document.getElementById("vzx-" + id);
    if (ln) { ln.setAttribute("x1", st.X(i)); ln.setAttribute("x2", st.X(i)); ln.setAttribute("visibility", "visible"); }
    const p = st.points[i];
    VizTip.show([st.day(p.date), ...st.series.map((s) => ({ color: s.color, label: s.label, value: Viz.num(p[s.key] || 0, st.unit) }))], cx, cy);
  },
  cross(e, id) {
    const st = Viz.store[id], svg = document.getElementById("vzl-" + id);
    if (!st || !svg) return;
    const r = svg.getBoundingClientRect(), x = (e.clientX - r.left) * (st.W / r.width);
    Viz.crossAt(id, Math.round(((x - st.pl) / st.pw) * (st.n - 1)), e.clientX, e.clientY);
  },
  crossKey(e, id) {
    const st = Viz.store[id];
    if (!st || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key)) return;
    e.preventDefault();
    const i = e.key === "Home" ? 0 : e.key === "End" ? st.n - 1 : (st.i ?? st.n - 1) + (e.key === "ArrowLeft" ? -1 : 1);
    const r = e.target.getBoundingClientRect();
    Viz.crossAt(id, i, r.left + r.width / 2, r.top);
  },
  uncross(id) { const ln = document.getElementById("vzx-" + id); if (ln) ln.setAttribute("visibility", "hidden"); VizTip.hide(); },
  table(head, rows) {
    return `<div class="wrap"><table class="t"><tr>${head.map((h, i) => `<th${i ? ' class="num"' : ""}>${esc(h)}</th>`).join("")}</tr>
      ${rows.map((r) => `<tr>${r.map((c, i) => `<td${i ? ' class="num"' : ""}>${esc(i ? Viz.num(c) : c)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${head.length}" class="empty">No data</td></tr>`}</table></div>`;
  },
  /* a chart card with an optional sort, a Chart/Table toggle and a table twin */
  card({ id, title, sub, chart, table, sort, sortValue, extra }) {
    const on = !!Viz.tableOn[id];
    return `<div class="card vz-card"><div class="row vz-head"><h2>${esc(title)}</h2>${sub ? `<span class="sub">${esc(sub)}</span>` : ""}<span style="flex:1"></span>
      ${extra || ""}${sort ? `<select class="sel-sm" aria-label="Sort ${esc(title)}" onchange="Ov.sortBy('${id}', this.value)">${sort.map(([v, l]) => `<option value="${v}" ${v === sortValue ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>` : ""}
      <button class="btn sm" onclick="Viz.toggle('${id}', this)" aria-pressed="${on}">${on ? "Chart" : "Table"}</button></div>
      <div id="vb-${id}" ${on ? "hidden" : ""}>${chart}</div><div id="vt-${id}" ${on ? "" : "hidden"}>${table}</div></div>`;
  },
  toggle(id, btn) {
    Viz.tableOn[id] = !Viz.tableOn[id];
    $("#vb-" + id).hidden = Viz.tableOn[id];
    $("#vt-" + id).hidden = !Viz.tableOn[id];
    btn.textContent = Viz.tableOn[id] ? "Chart" : "Table";
    btn.setAttribute("aria-pressed", String(Viz.tableOn[id]));
  },
};

/* One tooltip for every chart: the value leads, the label follows; built with textContent */
const VizTip = {
  el() {
    let t = document.getElementById("vz-tip");
    if (!t) { t = document.createElement("div"); t.id = "vz-tip"; t.setAttribute("role", "tooltip"); t.hidden = true; document.body.appendChild(t); }
    return t;
  },
  show(lines, x, y) {
    const t = VizTip.el();
    t.replaceChildren();
    lines.forEach((ln, i) => {
      if (ln && typeof ln === "object") {
        const row = document.createElement("div"), key = document.createElement("span"), name = document.createElement("span"), val = document.createElement("b");
        row.className = "row2";
        key.style.cssText = `display:inline-block;width:12px;height:2px;border-radius:1px;background:${ln.color}`;
        name.textContent = ln.label;
        val.textContent = ln.value;
        row.append(key, name, val);
        t.appendChild(row);
      } else {
        const el = document.createElement(i === 0 ? "strong" : "div");
        el.textContent = ln;
        if (i) el.className = "sub";
        t.appendChild(el);
      }
    });
    t.hidden = false;
    VizTip.move(x, y);
  },
  move(x, y) {
    const t = VizTip.el();
    if (t.hidden) return;
    const w = t.offsetWidth, h = t.offsetHeight;
    t.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, x + 14)) + "px";
    t.style.top = Math.max(8, y - h - 12) + "px";
  },
  hide() { const t = document.getElementById("vz-tip"); if (t) t.hidden = true; },
};
document.addEventListener("pointerover", (e) => {
  const t = e.target.closest && e.target.closest("[data-tip]");
  if (t) { try { VizTip.show(JSON.parse(t.getAttribute("data-tip")), e.clientX, e.clientY); } catch (err) { /* ignore */ } }
});
document.addEventListener("pointermove", (e) => { if (e.target.closest && e.target.closest("[data-tip]")) VizTip.move(e.clientX, e.clientY); });
document.addEventListener("pointerout", (e) => { if (e.target.closest && e.target.closest("[data-tip]")) VizTip.hide(); });
document.addEventListener("focusin", (e) => {
  const t = e.target.closest && e.target.closest("[data-tip]");
  if (t) { const r = t.getBoundingClientRect(); try { VizTip.show(JSON.parse(t.getAttribute("data-tip")), r.left + r.width / 2, r.top); } catch (err) { /* ignore */ } }
});
document.addEventListener("focusout", (e) => { if (e.target.closest && e.target.closest("[data-tip]")) VizTip.hide(); });
document.addEventListener("keydown", (e) => {
  const t = e.target.closest && e.target.closest(".vz-hit[onclick]");
  if (t && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); t.dispatchEvent(new MouseEvent("click", { bubbles: true })); }
});

/* ------------------------------------------------------------------ Overview: Summary | Rules | Incidents, one filter bar */
const OV_TABS = [["summary", "Summary"], ["rules", "Rules"], ["incidents", "Incidents"]];
const SEV_SERIES = [["critical", "Critical"], ["high", "High"], ["medium", "Medium"], ["low", "Low"]].map(([key, label]) => ({ key, label, color: `var(--viz-sev-${key})` }));
const STATUS_SERIES = [{ key: "active", label: "Active", color: "var(--viz-1)" }, { key: "proposed", label: "Saved drafts", color: "var(--viz-2)" },
  { key: "review", label: "In review", color: "var(--viz-4, #8a6bd1)" }, { key: "disabled", label: "Disabled", color: "var(--viz-3)" }];
const SORT_VALUE = [["value-desc", "Highest first"], ["value-asc", "Lowest first"], ["name", "Name A-Z"]];
const Ov = {
  f: null, sort: {}, cache: null, opts: null, incGroup: "dataset",
  defaults() { return { days: 30, platform: State.platform || "", domain: "", asset_id: "", severity: "", category: "" }; },
  qs() {
    const q = new URLSearchParams();
    Object.entries(Ov.f).forEach(([k, v]) => { if (v !== "" && v != null) q.set(k, v); });
    return q.toString();
  },
  set(k, v) {
    Ov.f[k] = k === "days" ? Number(v) : v;
    if (k === "platform") State.platform = v;
    const ds = ((Ov.opts && Ov.opts.datasets) || []).find((d) => String(d.id) === String(Ov.f.asset_id));
    if (ds && ((Ov.f.platform && ds.platform !== Ov.f.platform) || (Ov.f.domain && (ds.domain || "unassigned") !== Ov.f.domain))) Ov.f.asset_id = "";
    render(true);
  },
  clear() { State.platform = ""; Ov.f = Ov.defaults(); render(true); },
  active() { return Object.entries(Ov.f).some(([k, v]) => k !== "days" && v !== "" && v != null); },
  filterBar(tab) {
    const o = Ov.opts, f = Ov.f;
    const sel = (k, label, items, any) => `<label class="f">${label}<select onchange="Ov.set('${k}', this.value)">${any != null ? `<option value="">${esc(any)}</option>` : ""}
      ${items.map(([v, l]) => `<option value="${esc(v)}" ${String(f[k]) === String(v) ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label>`;
    const ds = o.datasets.filter((d) => (!f.platform || d.platform === f.platform) && (!f.domain || (d.domain || "unassigned") === f.domain));
    return `<div class="ov-filters" role="group" aria-label="Overview filters">
      ${sel("days", "Time window", o.windows.map((d) => [d, `Last ${d} days`]))}
      ${sel("platform", "Platform", o.platforms.map((p) => [p, PLATFORMS[p] || p]), "All platforms")}
      ${o.domains.some((d) => d !== "unassigned") ? sel("domain", GL(), o.domains.map((d) => [d, d]), "All " + GLl() + "s") : ""}
      ${sel("asset_id", "Dataset", ds.map((d) => [d.id, d.fqn]), "All datasets")}
      ${sel("severity", "Severity", o.severities.map((s) => [s, s]), "All severities")}
      ${sel("category", "Rule set", Object.entries(o.categories), "All sets")}
      ${Ov.active() ? '<button class="btn sm" onclick="Ov.clear()">Clear filters</button>' : ""}</div>
      <p class="ov-note">Filters apply to all three tabs and reset each time you open the Overview.
        ${tab === "summary" ? "Severity and rule set narrow rules, checks and incidents; DQ scores and custom metrics always cover everything; the platform also narrows the patterns." : "Click a bar to open the matching list."}</p>`;
  },
  sortRows(id, rows, def = "value-desc", total = (r) => r.value) {
    const mode = Ov.sort[id] || def, out = [...rows];
    const byName = (a, b) => String(a.label).localeCompare(String(b.label));
    if (mode === "value-desc") out.sort((a, b) => total(b) - total(a) || byName(a, b));
    else if (mode === "value-asc") out.sort((a, b) => total(a) - total(b) || byName(a, b));
    else if (mode === "name") out.sort(byName);
    return out;
  },
  sortBy(id, v) { Ov.sort[id] = v; Ov.redraw(); },
  redraw() {
    const b = $("#ov-body");
    if (b && Ov.cache) b.innerHTML = Ov.cache.tab === "rules" ? Ov.rulesHtml(Ov.cache.data) : Ov.incidentsHtml(Ov.cache.data);
  },
  tile(cls, label, value, hint, href) {
    return `<div class="card kpi ${cls}"><div class="label">${esc(label)}</div><div class="value">${href ? `<a href="${href}">${esc(value)}</a>` : esc(value)}</div><div class="hint">${esc(hint)}</div></div>`;
  },
  rulesHtml(d) {
    const t = d.tiles, sum = (r) => Object.values(r.values).reduce((a, b) => a + b, 0);
    const setSev = Ov.sortRows("setsev", d.set_severity, "natural", sum);
    const fail = Ov.sortRows("faildata", d.failing_by_dataset);
    const dims = Ov.sortRows("dims", d.pass_rate_by_dimension.map((r) => ({ ...r, note: `${r.checks.toLocaleString()} checks` })), "value-asc");
    const src = Ov.sortRows("source", d.source_status, "value-desc", sum);
    const win = `last ${d.filters.days} days`;
    return `<div class="grid g3">
      ${Ov.tile("info", "Total rules", Viz.num(t.total), "every status")}
      ${Ov.tile("ok", "Active", Viz.num(t.active), "running on schedule")}
      ${Ov.tile(t.saved ? "warn" : "ok", "Saved drafts", Viz.num(t.saved), "not sent for approval yet", "#/rules/saved")}
      ${Ov.tile(t.in_review ? "warn" : "ok", "In review", Viz.num(t.in_review), "waiting for an administrator", "#/rules/review")}
      ${Ov.tile("info", "Disabled", Viz.num(t.disabled), "switched off")}
      ${Ov.tile(t.failing ? "bad" : "ok", "Failing now", Viz.num(t.failing), "active rules whose latest check failed")}</div><div class="sp"></div>
    <div class="grid g2">
      ${Viz.card({ id: "setsev", title: "Rules by set and severity", sub: "active and saved rules", sort: [["natural", "Set order"], ...SORT_VALUE], sortValue: Ov.sort.setsev || "natural",
        chart: Viz.hstack(setSev, SEV_SERIES, { label: "Rules by set and severity", click: "Ov.clickSetSev", empty: "No rules match the filters" }),
        table: Viz.table(["Set", "Critical", "High", "Medium", "Low", "Total"], setSev.map((r) => [r.label, ...SEV_SERIES.map((s) => r.values[s.key] || 0), sum(r)])) })}
      ${Viz.card({ id: "faildata", title: "Failing checks by dataset", sub: `${win}${fail.length > 10 ? " · top 10" : ""}`, sort: SORT_VALUE, sortValue: Ov.sort.faildata || "value-desc",
        chart: Viz.hbars(fail.slice(0, 10), { label: "Failing checks by dataset", click: "Ov.clickDataset", empty: `No failed checks in the ${win}` }),
        table: Viz.table(["Dataset", "Failed checks"], fail.map((r) => [r.label, r.value])) })}
      ${Viz.card({ id: "dims", title: "Pass rate by dimension", sub: win, sort: [["value-asc", "Lowest first"], ["value-desc", "Highest first"], ["name", "Name A-Z"]], sortValue: Ov.sort.dims || "value-asc",
        chart: Viz.hbars(dims, { label: "Pass rate by dimension", unit: "%", max: 100, click: "Ov.clickDim", labelW: 120, empty: `No checks ran in the ${win}` }),
        table: Viz.table(["Dimension", "Pass rate %", "Checks"], dims.map((r) => [r.label, r.value, r.checks])) })}
      ${Viz.card({ id: "source", title: "Rules by source and status", sort: SORT_VALUE, sortValue: Ov.sort.source || "value-desc",
        chart: Viz.hstack(src, STATUS_SERIES, { label: "Rules by source and status", click: "Ov.clickSrc", labelW: 170, chars: 24, empty: "No rules match the filters" }),
        table: Viz.table(["Source", "Active", "Saved drafts", "In review", "Disabled", "Total"], src.map((r) => [r.label, r.values.active, r.values.proposed, r.values.review, r.values.disabled, sum(r)])) })}
    </div>`;
  },
  incidentsHtml(d) {
    const t = d.tiles, win = `last ${d.filters.days} days`;
    const hours = (h) => (h == null ? "-" : h >= 48 ? Viz.num(Math.round((h / 24) * 10) / 10) + " days" : Viz.num(h) + "h");
    const sev = Ov.sortRows("opensev", d.open_by_severity.map((r) => ({ ...r, label: r.label[0].toUpperCase() + r.label.slice(1), color: `var(--viz-sev-${r.key})` })), "natural");
    const groupRows = Ov.incGroup === "domain" ? d.by_domain : d.by_dataset;
    const grp = Ov.sortRows("incgroup", groupRows);
    const age = Ov.sortRows("age", d.age_buckets, "natural");
    const groupSel = `<select class="sel-sm" aria-label="Group incidents by" onchange="Ov.incGroup=this.value; Ov.redraw()">
      <option value="dataset" ${Ov.incGroup === "dataset" ? "selected" : ""}>By dataset</option><option value="domain" ${Ov.incGroup === "domain" ? "selected" : ""}>By ${esc(GLl())}</option></select>`;
    return `<div class="grid g3">
      ${Ov.tile(t.open ? "bad" : "ok", "Open incidents", Viz.num(t.open), "open or acknowledged", "#/incidents")}
      ${Ov.tile("info", "Opened", Viz.num(t.opened), win)}
      ${Ov.tile("ok", "Resolved", Viz.num(t.resolved), win)}
      ${Ov.tile("info", "Mean time to resolve", hours(t.mttr_hours), `incidents resolved in the ${win}`)}
      ${Ov.tile(t.oldest_open_hours > 72 ? "warn" : "info", "Oldest open incident", hours(t.oldest_open_hours), "time since it was opened")}</div><div class="sp"></div>
    <div class="grid g2">
      ${Viz.card({ id: "opensev", title: "Open incidents by severity", sort: [["natural", "Severity order"], ...SORT_VALUE], sortValue: Ov.sort.opensev || "natural",
        chart: Viz.hbars(sev, { label: "Open incidents by severity", click: "Ov.clickSev", labelW: 90 }),
        table: Viz.table(["Severity", "Open incidents"], sev.map((r) => [r.label, r.value])) })}
      ${Viz.card({ id: "ovr", title: "Opened vs resolved", sub: `per day, ${win}`,
        chart: Viz.lines("ovr", d.opened_vs_resolved, [{ key: "opened", label: "Opened", color: "var(--viz-1)" }, { key: "resolved", label: "Resolved", color: "var(--viz-2)" }], { label: "Incidents opened and resolved per day" }),
        table: Viz.table(["Day", "Opened", "Resolved"], d.opened_vs_resolved.filter((p) => p.opened || p.resolved).map((p) => [p.date, p.opened, p.resolved])) })}
      ${Viz.card({ id: "incgroup", title: "Incidents by " + Ov.incGroup, sub: `opened in the ${win}, or still open${grp.length > 10 ? " · top 10" : ""}`, extra: groupSel, sort: SORT_VALUE, sortValue: Ov.sort.incgroup || "value-desc",
        chart: Viz.hbars(grp.slice(0, 10), { label: "Incidents by " + Ov.incGroup, click: Ov.incGroup === "domain" ? "Ov.clickIncDom" : "Ov.clickIncDs", empty: "No incidents" }),
        table: Viz.table([Ov.incGroup === "domain" ? GL() : "Dataset", "Incidents"], grp.map((r) => [r.label, r.value])) })}
      ${Viz.card({ id: "age", title: "Age of open incidents", sort: [["natural", "Age order"], ...SORT_VALUE], sortValue: Ov.sort.age || "natural",
        chart: Viz.hbars(age, { label: "Age of open incidents", click: "Ov.clickAge", labelW: 90, empty: "No open incidents" }),
        table: Viz.table(["Open for", "Incidents"], age.map((r) => [r.label, r.value])) })}
      ${Viz.card({ id: "ttr", title: "Time to resolve", sub: `mean hours per week, ${win}`,
        chart: Viz.lines("ttr", d.ttr_by_week, [{ key: "value", label: "Mean hours to resolve", color: "var(--viz-1)" }], { label: "Mean hours to resolve per week", unit: "h", empty: `No incidents resolved in the ${win}` }),
        table: Viz.table(["Week of", "Mean hours", "Resolved"], d.ttr_by_week.map((p) => [p.date, p.value, p.count])) })}
    </div>`;
  },
  /* drill-down: open the matching list, carrying the Overview filters */
  toIncidents(extra) {
    const { status, ...rest } = extra;
    State.incStatus = status || "open";
    State.incF = { platform: Ov.f.platform, domain: Ov.f.domain, asset_id: Ov.f.asset_id, severity: Ov.f.severity, ...rest };
    location.hash = "#/incidents";
  },
  toCatalog(extra) {
    Catalog.st = { scope: Ov.f.asset_id ? "asset" : "all", set: Ov.f.category || "", status: "all", severity: Ov.f.severity || "", dimension: "", ...extra };
    if (Ov.f.asset_id) State.studioAsset = Number(Ov.f.asset_id);
    location.hash = "#/rules/catalog";
  },
  clickSetSev(set, severity) { Ov.toCatalog({ set, severity }); },
  clickDataset(id) { location.hash = `#/asset/${id}/rules`; },
  clickDim(dimension) { Ov.toCatalog({ dimension, status: "active" }); },
  clickSrc(src, status) {
    if (status === "review") { location.hash = "#/rules/review"; return; }
    if (status === "proposed") {
      Saved.st = { scope: Ov.f.asset_id ? "asset" : "all", set: Ov.f.category || "" };
      if (Ov.f.asset_id) State.studioAsset = Number(Ov.f.asset_id);
      location.hash = "#/rules/saved";
    } else Ov.toCatalog({ status });
  },
  clickSev(severity) { Ov.toIncidents({ severity, status: "open" }); },
  clickIncDs(asset_id) { Ov.toIncidents({ asset_id, status: "all" }); },
  clickIncDom(domain) { Ov.toIncidents({ domain, status: "all" }); },
  clickAge() { Ov.toIncidents({ status: "open" }); },
};

Pages.overview = async (tab = "summary") => {
  if (!OV_TABS.some(([k]) => k === tab)) tab = "summary";
  if (State.prevRoute !== "overview" || !Ov.f) { Ov.f = Ov.defaults(); Ov.sort = {}; }
  Ov.opts = await api("/overview/options");
  const head = `<div class="page-head"><h1>Data quality overview</h1><span class="grow"></span>
    <button class="btn" onclick="act(this, () => post('/scheduler/tick'), r => 'Ran ' + r.ran.length + ' datasets')">Run due checks</button></div>
  ${Ov.filterBar(tab)}
  <div class="tabs">${OV_TABS.map(([k, l]) => `<a href="#/overview/${k}" class="${k === tab ? "active" : ""}">${l}</a>`).join("")}</div>`;
  if (tab === "rules" || tab === "incidents") {
    const d = await api(`/overview/${tab}?` + Ov.qs());
    Ov.cache = { tab, data: d };
    return head + `<div id="ov-body">${tab === "rules" ? Ov.rulesHtml(d) : Ov.incidentsHtml(d)}</div>`;
  }
  const [o, ins] = await Promise.all([api("/overview/summary?" + Ov.qs()), api("/insights?days=30" + (Ov.f && Ov.f.platform ? "&platform=" + encodeURIComponent(Ov.f.platform) : "")).catch(() => null)]);
  return head + Ov.summaryHtml(o, ins);
};

Ov.summaryHtml = (o, ins) => {
  const dims = [...new Set(Object.values(o.heatmap).flatMap((d) => Object.keys(d)))];
  const sev = o.incidents_by_severity;
  const cell = (v) => {
    if (v == null) return '<td class="cell muted">-</td>';
    const c = v >= 95 ? "var(--ok-bg)" : v >= 80 ? "var(--warn-bg)" : "var(--bad-bg)";
    const t = v >= 95 ? "var(--ok)" : v >= 80 ? "var(--warn)" : "var(--bad)";
    return `<td class="cell" style="background:${c};color:${t}">${v.toFixed(0)}</td>`;
  };
  const days = (o.filters && o.filters.days) || 30;
  return `
  <div class="grid g4">
    <div class="card kpi ${kpiTone("score", o.overall)}"><div class="label">Overall DQ score</div><div class="value">${score(o.overall)}</div><div class="hint">${o.scored_assets} of ${o.assets} datasets monitored</div></div>
    <div class="card kpi ${kpiTone("count", sev.critical + sev.high)}"><div class="label">Open incidents</div><div class="value">${o.open_incidents}</div><div class="hint">${sev.critical} critical · ${sev.high} high · ${sev.medium} medium</div></div>
    <div class="card kpi ${kpiTone("count", o.sla_breaches.length)}"><div class="label">Freshness SLA breaches</div><div class="value">${o.sla_breaches.length}</div><div class="hint">late or missing loads</div></div>
    <div class="card kpi ${kpiTone("soft", o.policy_violations)}"><div class="label">Policy violations</div><div class="value"><a href="#/governance/policies">${o.policy_violations}</a></div><div class="hint">masking, retention, ownership</div></div>
    <div class="card kpi info"><div class="label">Mean time to resolve</div><div class="value">${o.mttr_hours != null ? o.mttr_hours + "h" : "-"}</div><div class="hint">incidents resolved in the last ${days} days</div></div>
  </div><div class="sp"></div>
  ${Metrics.section(o.custom_metrics || [])}<div class="sp"></div>
  <div class="grid g2">
    <div class="card"><h2>Score trend (${days} days)</h2>${lineChart(o.trend.map((t) => ({ ts: t.date, value: t.score })), { label: "DQ score trend" })}</div>
    <div class="card"><h2>${esc(GL())} × dimension</h2>${dims.length && Object.keys(o.heatmap).some((g) => g !== "unassigned") ? `<div class="wrap"><table class="t heat"><tr><th>${esc(GL())}</th>${dims.map((d) => `<th>${esc(d)}</th>`).join("")}</tr>
      ${Object.entries(o.heatmap).map(([dom, ds]) => `<tr><td>${esc(dom)}</td>${dims.map((d) => cell(ds[d])).join("")}</tr>`).join("")}</table></div>` : '<div class="empty">Run checks to populate</div>'}</div>
    <div class="card"><h2>Lowest scores</h2><table class="t">${o.lowest.map((a) => `<tr><td><a href="#/asset/${a.id}">${esc(a.fqn)}</a></td><td>${esc(a.domain || "")}</td><td class="num">${score(a.score)}</td></tr>`).join("") || '<tr><td class="empty">No scores yet</td></tr>'}</table></div>
    <div class="card"><h2>Freshness SLA breaches</h2>${o.sla_breaches.length ? `<table class="t">${o.sla_breaches.map((b) => `<tr><td><a href="#/asset/${b.asset_id}">${esc(b.asset)}</a></td><td>${esc(b.name)}</td></tr>`).join("")}</table>` : '<div class="empty">All loads on time</div>'}</div>
  </div><div class="sp"></div>
  <div class="card"><div class="row"><h2 style="margin:0">Patterns and learnings</h2><span class="sub">all data, last 30 days</span><span style="flex:1"></span><a class="btn sm" href="#/explore/patterns">See all insights</a></div>
    ${ins && ins.highlights.length ? `<div class="grid g3" style="margin-top:12px">${ins.highlights.slice(0, 3).map(Insights.card).join("")}</div>`
      : '<div class="empty">Patterns appear here as checks run and people give feedback.</div>'}</div>`;
};

/* Operate has three entries: a simple Overview, Explore (Datasets, Incidents, Patterns) and Runs. Dashboards and charts live in BI tools. */
Pages.overviewFull = Pages.overview;  // the earlier, filter-heavy Overview, kept in the file but no longer reachable
Pages.overview = async () => {
  const pq = State.platform ? "?platform=" + encodeURIComponent(State.platform) : "";
  const [o, rules, incs, picker, sched, pscanRes] = await Promise.all([api("/overview/summary" + pq), api("/overview/rules" + pq),
    api("/incidents?status=open" + (State.platform ? "&platform=" + encodeURIComponent(State.platform) : "")), platformPicker(), api("/schedules").catch(() => null), api("/policy-scans/latest").catch(() => null)]);
  const pscan = pscanRes && pscanRes.scan;
  const pv = pscan ? pscan.violations.filter((x) => !State.platform || x.platform === State.platform) : null;
  const next = sched && sched.schedules.filter((x) => x.enabled && x.next_run).sort((a, b) => a.next_run.localeCompare(b.next_run))[0];
  const nextRun = next ? `Next scheduled run: <strong>${esc(next.name)}</strong> at ${ts(next.next_run)}. <a href="#/runs">Runs</a>`
    : `No schedule is switched on. <a href="#/runs">Set one up in Runs</a>`;
  const sev = o.incidents_by_severity, t = rules.tiles, days = (o.filters && o.filters.days) || 30;
  const tile = (cls, label, value, hint, href) => `<div class="card kpi ${cls}"><div class="label">${esc(label)}</div><div class="value">${href ? `<a href="${href}">${value}</a>` : value}</div><div class="hint">${esc(hint)}</div></div>`;
  return `<div class="page-head"><h1>Overview</h1><span class="sub">Is anything broken, and where to go next</span><span class="grow"></span>${picker}
      <button class="btn" onclick="act(this, () => post('/scheduler/tick'), r => 'Ran ' + r.ran.length + ' datasets')">Run due checks</button></div>
    <div class="grid g4">
      ${tile(kpiTone("score", o.overall), "Overall DQ score", score(o.overall), `${o.scored_assets} of ${o.assets} datasets monitored`)}
      ${tile(kpiTone("count", (sev.critical || 0) + (sev.high || 0)), "Open incidents", o.open_incidents, `${sev.critical || 0} critical, ${sev.high || 0} high, ${sev.medium || 0} medium`, "#/explore/incidents")}
      ${tile(t.in_review ? "warn" : "info", "Rules in review", t.in_review, "waiting for an administrator", "#/rules/review")}
      ${tile(kpiTone("count", o.sla_breaches.length), "Freshness SLA breaches", o.sla_breaches.length, "late or missing loads")}
    </div><div class="sp"></div>
    <div class="grid g4">
      ${tile("ok", "Active rules", t.active, "running on schedule", "#/rules/catalog")}
      ${tile(t.saved ? "warn" : "ok", "Saved drafts", t.saved, "not sent for approval yet", "#/rules/saved")}
      ${tile(t.failing ? "bad" : "ok", "Failing now", t.failing, "active rules whose latest check failed", "#/explore/datasets")}
      ${pv ? tile(pv.length ? "bad" : "ok", "Policy violations", pv.length, `last scan ${ts(pscan.ts)}${pscan.new_count ? ", " + pscan.new_count + " new" : ""}`, "#/explore/violations")
        : tile("info", "Policy violations", "-", "not scanned yet", "#/explore/violations")}
    </div>
    <p class="sub" style="margin:10px 0 12px">${nextRun}</p>
    <div class="grid g2">
      <div class="card"><h2>Score trend (${days} days)</h2>${lineChart(o.trend.map((p) => ({ ts: p.date, value: p.score })), { label: "DQ score trend" })}</div>
      <div class="card"><div class="row"><h2 style="margin:0">Open incidents</h2><span style="flex:1"></span><a class="btn sm" href="#/explore/incidents">See all (${incs.length})</a></div>
        ${incs.length ? `<div style="margin-top:8px">${Overview.incidentRows(incs.slice(0, 5))}</div>` : '<div class="empty">No open incidents</div>'}</div>
    </div><div class="sp"></div>
    <p class="sub" style="margin-top:12px">Charts and dashboards belong in your BI tool. Explore has the datasets, the incidents with their fix actions, and the patterns behind them.</p>`;
};
const Overview = {
  incidentRows(incs) {
    return `<table class="t">${incs.map((i) => `<tr><td>${pill(i.severity)}</td><td><a href="#/incident/${i.id}">${esc(i.title)}</a><div class="sub">${esc(short(i.root_fqn))} · ${ts(i.created)}</div></td></tr>`).join("")}</table>`;
  },
};

const EX_TABS = [["datasets", "Datasets"], ["incidents", "Incidents"], ["violations", "Violations"], ["patterns", "Patterns and Insights"]];
const Explore = {
  attn: false,
  noOwner: false,
  sensitive: false,
  needsAttention: (a) => (a.open_incidents || 0) > 0 || (a.rules_failing || 0) > 0 || (a.score != null && a.score < 80),
  toIncidents(assetId) { State.incStatus = "open"; State.incF = { asset_id: assetId }; location.hash = "#/explore/incidents"; },
  async datasets() {
    const qs = new URLSearchParams({ q: State.q, ...(State.platform ? { platform: State.platform } : {}) });
    const all = await api("/assets?" + qs);
    const unowned = all.filter((a) => !a.owner).length;
    const sens = all.filter((a) => a.sensitive_columns).length;
    const assets = all.filter((a) => (!Explore.attn || Explore.needsAttention(a)) && (!Explore.noOwner || !a.owner) && (!Explore.sensitive || a.sensitive_columns));
    const need = all.filter(Explore.needsAttention).length;
    return `<div class="row" style="gap:10px;flex-wrap:wrap;margin:10px 0">
        <input placeholder="Search datasets" value="${esc(State.q)}" aria-label="Search datasets" onkeydown="if(event.key==='Enter'){State.q=this.value;render()}">
        <label class="row sub" style="gap:6px"><input type="checkbox" ${Explore.attn ? "checked" : ""} onchange="Explore.attn=this.checked; render(true)"> Needs attention (${need})</label>
        <label class="row sub" style="gap:6px"><input type="checkbox" ${Explore.noOwner ? "checked" : ""} onchange="Explore.noOwner=this.checked; render(true)"> No owner (${unowned})</label>
        <label class="row sub" style="gap:6px"><input type="checkbox" ${Explore.sensitive ? "checked" : ""} onchange="Explore.sensitive=this.checked; render(true)"> Has sensitive data (${sens})</label>
        <span class="sub">${assets.length} of ${all.length} datasets</span><span style="flex:1"></span>
        ${isAdminUser() ? '<button class="btn" onclick="Conn.sync(this)">Sync catalog</button>' : ""}</div>
      <div class="card wrap"><table class="t"><tr><th>Dataset</th><th>Platform</th><th>${esc(GL())}</th><th>Owner</th><th class="num" title="Columns detected as personal or sensitive">Sensitive</th><th class="num">Score</th><th class="num">Rules</th><th class="num">Failing</th><th class="num">Incidents</th><th></th></tr>
      ${assets.map((a) => `<tr><td><a href="#/asset/${a.id}">${esc(a.fqn)}</a>${a.kind !== "table" ? " " + pill("info", a.kind) : ""}</td><td>${plat(a.platform)}</td><td>${esc(a.domain || "")}</td>
        <td>${a.owner ? esc(a.owner) : '<span class="muted">no owner</span>'}</td>
        <td class="num">${a.sensitive_columns ? `<a href="#/governance/pii" onclick="State.govAsset=''; Pii.f = {sens:'', status:'all', q:${jsq(short(a.fqn))}}" title="Review these columns">${a.sensitive_columns}</a>` : '<span class="muted">0</span>'}</td><td class="num">${score(a.score)}</td><td class="num">${a.rules_active}${a.rules_proposed ? ` <span class="muted">+${a.rules_proposed}</span>` : ""}</td>
        <td class="num">${a.rules_failing ? `<span class="score lo">${a.rules_failing}</span>` : 0}</td>
        <td class="num">${a.open_incidents ? `<a href="#/explore/incidents" onclick="Explore.toIncidents(${a.id}); return false" title="Show these incidents">${a.open_incidents} open</a>` : 0}</td>
        <td>${a.certified ? pill("ok", "certified") : ""}</td></tr>`).join("") || `<tr><td colspan="10" class="empty">${Explore.attn || Explore.noOwner || Explore.sensitive ? "Nothing matches these filters." : "No datasets. Add a connection and sync."}</td></tr>`}
      </table></div>`;
  },
  async incidents() {
    const html = await Pages.incidents();
    return html.replace(/^\s*<div class="page-head">[\s\S]*?<\/div>\s*/, "");  // Explore has its own header and platform picker
  },
  /* Patterns and Insights: the app computes the facts, the configured model writes them up. Only the write-up is shown. */
  async patterns() {
    const pq = State.platform ? "?platform=" + encodeURIComponent(State.platform) : "";
    const [st, r] = await Promise.all([api("/ai-insights" + pq), api("/insights?" + platQ("days=30"))]);
    const rep = st.report, lr = r.last_refresh, can = !iAmViewer();
    const model = st.model && st.model.provider !== "rules" && st.model.provider !== "error" ? `${st.model.provider}${st.model.model ? " · " + st.model.model : ""}` : null;
    const status = !rep ? "Not generated yet."
      : `Generated ${ts(rep.generated_at)} by ${esc(rep.generated_by || "")} with ${esc(rep.provider || "a model")}${rep.model ? " · " + esc(rep.model) : ""}. `
        + (st.fresh ? "Up to date with your data." : "<strong>Your data has changed since:</strong> generate again to refresh it.")
        + (rep.dropped ? ` <span class="muted">${rep.dropped} statement(s) were removed because they could not be checked against the data.</span>` : "");
    const gen = can ? `<button class="btn ${rep && st.fresh ? "" : "primary"}" ${st.configured ? "" : "disabled"} onclick="Explore.generate(this, ${rep && st.fresh ? "true" : "false"})">${rep ? (st.fresh ? "Regenerate" : "Generate with AI") : "Generate with AI"}</button>` : "";
    const banner = `<div class="card ai-banner"><div class="row" style="gap:8px;flex-wrap:wrap"><h2 style="margin:0">AI-powered Patterns and Insights</h2><span class="pill info">AI</span><span style="flex:1"></span>${gen}
        <select class="sel-sm" id="ins-mode" aria-label="What to refresh" title="What the refresh pulls from the connected platforms">${Object.entries(INSIGHT_MODES).map(([k, l]) => `<option value="${k}" ${k === Insights.mode ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>
        <button class="btn" onclick="Insights.refresh(this)" title="Syncs metadata and can run due checks, so there is fresh data to write up">Refresh insights</button></div>
      <p class="sub" style="margin:6px 0 0">The app computes the facts from your checks, incidents and feedback. The model you chose in <a href="#/settings/llm">Settings &gt; LLM</a>${model ? ` (${esc(model)})` : ""} writes them up as insights, learnings and recommendations,
        following built-in guidance. It sees counts and dataset names, never rows. While your data is unchanged, you see the same text, whichever model is set.</p>
      <p class="sub" style="margin:4px 0 0;font-size:11.5px">${status}${lr ? ` Data last refreshed ${ts(lr.at)} (${esc(INSIGHT_MODES[lr.mode] || lr.mode)}).` : ""}</p></div>`;
    if (!st.configured && !rep) {
      return banner + '<div class="callout" style="margin-top:12px">AI insights need a model. Choose a provider and add its API key in <a href="#/settings/llm">Settings &gt; LLM</a>, then come back and click <strong>Generate with AI</strong>.</div>';
    }
    if (!rep) return banner + '<div class="card empty" style="margin-top:12px">Click <strong>Generate with AI</strong> to write up what your checks, incidents and feedback show. If it is empty, run some checks first.</div>';
    const sect = (title, items, render) => `<div class="card" style="margin-top:12px"><h2>${title}</h2>${items.length ? items.map(render).join("") : '<div class="sub">Nothing to report here yet.</div>'}</div>`;
    const sevTone = { high: "bad", medium: "warn", low: "info" };
    return banner
      + sect("Insights", rep.insights, (i) => `<div class="insight-row"><span class="pill ${sevTone[i.severity] || "info"}">${esc(i.severity || "medium")}</span><span>${esc(i.text)}</span></div>`)
      + sect("Learnings", rep.learnings, (i) => `<div class="insight-row"><span>${esc(i.text)}</span></div>`)
      + sect("Recommendations", rep.recommendations, (i) => `<div class="insight-row"><span>${esc(i.text)}</span>${i.href ? `<a class="btn sm" href="${esc(i.href)}">Open</a>` : ""}</div>`);
  },
  async generate(btn, force) {
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = "Writing…";
    try {
      const r = await post("/ai-insights/generate", { platform: State.platform || null, force });
      toastOk(r.reused ? "Your data has not changed, so the saved text is current." : "Insights written.");
      await render(true);
    } catch (e) { btn.disabled = false; btn.textContent = label; toastError(e.message); }
  }
};
Pages.explore = async (tab = "datasets") => {
  if (!EX_TABS.some(([k]) => k === tab)) tab = "datasets";
  const picker = await platformPicker();
  const head = `<div class="page-head"><h1>Explore</h1><span class="sub">Datasets, incidents and the patterns behind them</span><span class="grow"></span>${picker}</div>
    <div class="tabs">${EX_TABS.map(([k, l]) => `<a href="#/explore/${k}" class="${k === tab ? "active" : ""}">${esc(l)}${k === "incidents" && State.openIncCount ? ` <span class="pill warn">${State.openIncCount}</span>` : ""}</a>`).join("")}</div>`;
  return head + await Explore[tab]();
};


Pages.catalog = async () => {
  // Only platforms with an enabled connection are offered, with how many datasets each holds.
  const conns = (await api("/connections").catch(() => [])).filter((c) => c.enabled !== false);
  const counts = {};
  conns.forEach((c) => { counts[c.type] = (counts[c.type] || 0) + (c.assets || 0); });
  const connected = Object.keys(counts).sort((a, b) => (PLATFORMS[a] || a).localeCompare(PLATFORMS[b] || b));
  if (State.platform && !connected.includes(State.platform)) State.platform = "";
  const qs = new URLSearchParams({ q: State.q, ...(State.platform ? { platform: State.platform } : {}) });
  const assets = await api("/assets?" + qs);
  const platforms = [...new Set(assets.map((a) => a.platform))];
  const where = connected.length === 1 ? `on ${PLATFORMS[connected[0]] || connected[0]}` : connected.length ? `across ${connected.length} connected platforms` : "no platform connected yet";
  return `
  <div class="page-head"><h1>Catalog</h1><span class="sub">${assets.length} datasets ${esc(where)}</span><span class="grow"></span>
    <input placeholder="Search datasets" value="${esc(State.q)}" onkeydown="if(event.key==='Enter'){State.q=this.value;render()}">
    ${connected.length > 1 ? `<select aria-label="Platform" onchange="State.platform=this.value;render()"><option value="">All connected platforms</option>${connected.map((p) => `<option value="${esc(p)}" ${State.platform === p ? "selected" : ""}>${esc(PLATFORMS[p] || p)} (${counts[p]})</option>`).join("")}</select>` : ""}
    <button class="btn primary" onclick="Conn.sync(this)">Sync catalog</button></div>
  <div class="card wrap"><table class="t"><tr><th>Dataset</th><th>Platform</th><th>${esc(GL())}</th><th>Owner</th><th class="num">Score</th><th class="num">Rules</th><th class="num">Failing</th><th class="num">Incidents</th><th></th></tr>
  ${assets.map((a) => `<tr><td><a href="#/asset/${a.id}">${esc(a.fqn)}</a>${a.kind !== "table" ? " " + pill("info", a.kind) : ""}</td><td>${plat(a.platform)}</td><td>${esc(a.domain || "")}</td>
    <td>${esc(a.owner || "")}</td><td class="num">${score(a.score)}</td><td class="num">${a.rules_active}${a.rules_proposed ? ` <span class="muted">+${a.rules_proposed}</span>` : ""}</td>
    <td class="num">${a.rules_failing ? `<span class="score lo">${a.rules_failing}</span>` : 0}</td><td class="num">${a.open_incidents || 0}</td><td>${a.certified ? pill("ok", "certified") : ""}</td></tr>`).join("") || '<tr><td colspan="9" class="empty">No datasets. Add a connection and sync.</td></tr>'}
  </table></div>${platforms.length ? `<p class="sub">Platforms: ${platforms.map(plat).join(" ")}</p>` : ""}`;
};

Pages.asset = async (id, tab = "overview") => {
  const a = await api("/assets/" + id);
  State.ctx = { asset_id: a.id, label: short(a.fqn) };
  const tabs = ["overview", "profile", "rules", "anomalies", "lineage", "impact", "incidents", "governance", "contract", "history"];
  const body = await AssetTabs[tab](a);
  return `
  <div class="page-head"><div><h1>${esc(a.fqn)}</h1><div class="sub">${plat(a.platform)} ${a.certified ? pill("ok", "certified") : ""} ${esc(a.kind)} · ${esc(GLl())} ${esc(a.domain || "unassigned")} · owner ${esc(a.owner || "none")} · ${a.row_count != null ? Number(a.row_count).toLocaleString() + " rows" : "not profiled"}</div></div>
    <span class="grow"></span><div style="font-size:24px">${score(a.score)}</div>
    <div class="btns">
      <button class="btn primary" onclick="act(this, () => post('/assets/${a.id}/run'), r => 'Ran ' + r.checks + ' checks, ' + r.failed + ' failed')">Run checks</button>
      <button class="btn" onclick="act(this, () => post('/assets/${a.id}/profile'), 'Profiled')">Profile</button>
      <button class="btn" onclick="act(this, () => post('/assets/${a.id}/suggest'), r => r.length + ' rules proposed')">Suggest rules</button>
      <button class="btn" onclick="act(this, () => post('/assets/${a.id}/classify'), 'Scanned for sensitive data')" title="Profile this dataset again and look for sensitive columns">Rescan sensitive data</button>
      <a class="btn" href="#/impact/${a.id}">Impact</a>
      <button class="btn" onclick="Agent.ask('What is the state of ${esc(short(a.fqn))} and what should I fix first?')">Ask agent</button>
    </div></div>
  <div class="tabs">${tabs.map((t) => `<a href="#/asset/${a.id}/${t}" class="${t === tab ? "active" : ""}">${t[0].toUpperCase() + t.slice(1)}</a>`).join("")}</div>
  ${body}`;
};

const AssetTabs = {};
AssetTabs.overview = async (a) => {
  const rules = await api("/rules?asset_id=" + a.id);
  const rmap = Object.fromEntries(rules.map((r) => [r.id, r]));
  const latest = Object.entries(a.latest);
  const dims = Object.entries(a.dimension_scores || {});
  return `<div class="grid g2">
    <div class="card"><h2>Score by dimension</h2>${dims.length ? dims.map(([d, s]) => `<div class="row" style="margin:6px 0"><span style="width:110px">${esc(d)}</span>
      <div class="bar"><div style="width:${s}%;background:${s >= 95 ? "var(--ok)" : s >= 80 ? "#e3a008" : "var(--bad)"}"></div></div>
      <span style="width:46px;text-align:right">${score(s)}</span></div>`).join("") : '<div class="empty">No checks have run</div>'}</div>
    <div class="card"><h2>Ownership</h2>
      <div class="grid" style="grid-template-columns:1fr 1fr;gap:8px">
        <label class="f">Owner<input id="m-owner" value="${esc(a.owner || "")}"></label>
        <label class="f">Steward<input id="m-steward" value="${esc(a.steward || "")}"></label>
        <label class="f">${esc(GL())}<input id="m-domain" value="${esc(a.domain || "")}" title="Typed values are kept when the catalog syncs. Clear it to use the configured grouping again."></label>
        <label class="f">Certified<select id="m-cert"><option value="false">No</option><option value="true" ${a.certified ? "selected" : ""}>Yes</option></select></label>
      </div><div class="sp"></div>
      <button class="btn" onclick="act(this, () => patch('/assets/${a.id}', {owner: $('#m-owner').value || null, steward: $('#m-steward').value || null, domain: $('#m-domain').value || null, certified: $('#m-cert').value === 'true'}), 'Saved')">Save</button>
      ${a.glossary.length ? `<p class="sub">Business terms: ${a.glossary.map((g) => esc(g.term)).join(", ")}</p>` : ""}
    </div></div><div class="sp"></div>
  <div class="card wrap"><h2>Latest checks</h2><table class="t"><tr><th>Rule</th><th>Dimension</th><th>Status</th><th>Result</th><th class="num">Pass rate</th><th>When</th></tr>
    ${latest.map(([rid, r]) => `<tr><td>${esc(rmap[rid]?.name || rid)}</td><td>${esc(rmap[rid]?.dimension || "")}</td><td>${pill(r.status)}</td><td>${esc(r.message || "")}</td>
      <td class="num">${pct(r.pass_rate)}</td><td>${ts(r.ts)}</td></tr>`).join("") || '<tr><td colspan="6" class="empty">Run checks to see results</td></tr>'}</table></div>`;
};

AssetTabs.profile = async (a) => {
  const p = await api(`/assets/${a.id}/profile`);
  if (!p.columns) return `<div class="card empty">Not profiled yet. <button class="btn" onclick="act(this, () => post('/assets/${a.id}/profile'), 'Profiled')">Profile now</button></div>`;
  return `<div class="card wrap"><h2>${Number(p.row_count).toLocaleString()} rows · profiled ${ts(p.profiled_at)}</h2>
  <table class="t"><tr><th>Column</th><th>Type</th><th class="num">Nulls</th><th class="num">Distinct</th><th>Min</th><th>Max</th><th class="num">Mean</th><th>Top values / patterns</th></tr>
  ${Object.entries(p.columns).map(([c, s]) => `<tr><td><strong>${esc(c)}</strong></td><td class="mono">${esc(s.data_type || s.family)}</td>
    <td class="num">${pct(s.null_rate)}</td><td class="num">${fmtVal(s.distinct)}</td><td>${fmtVal(s.min)}</td><td>${fmtVal(s.max)}</td><td class="num">${fmtVal(s.mean)}</td>
    <td class="sub">${s.top_values ? s.top_values.slice(0, 4).map((t) => `${esc(t.value)} (${t.count})`).join(", ") : s.patterns ? s.patterns.slice(0, 2).map((t) => `<code>${esc(t.pattern)}</code> ${(t.share * 100).toFixed(0)}%`).join(", ") : ""}</td></tr>`).join("")}
  </table></div>`;
};

AssetTabs.rules = async (a) => {
  const rules = await api("/rules?asset_id=" + a.id);
  return `<div class="card"><h2>Plain-English rule</h2>
    <div class="row"><input id="nl" style="flex:1" placeholder="kwh cannot be negative" onkeydown="if(event.key==='Enter')this.nextElementSibling.click()"><button class="btn primary" onclick="Studio.nl(this, ${a.id}, $('#nl').value)">Draft and dry-run on the platform</button></div>
    <div id="nl-out"></div></div><div class="sp"></div>
  <div class="card wrap"><div class="row"><h2 style="margin:0">Rules</h2>${RuleTable.setCounts(rules)}<span class="grow" style="flex:1"></span>
    ${rules.some((r) => ["proposed", "rejected"].includes(r.status)) ? '<a class="btn" href="#/rules/saved">Drafts waiting in Saved rules</a>' : ""}
    ${rules.some((r) => r.status === "review") ? '<a class="btn" href="#/rules/review">Rules in the Review queue</a>' : ""}
    </div>${RuleTable.render(rules, { feedback: true })}</div><div class="sp"></div>${Exporter.panel(a.id, [a])}`;
};

/* ------------------------------------------------------------------ rules catalog: set, severity, edit */
const RULE_SETS = { core: "Core data", business: "Business domain", governance: "Data governance" };
const SET_PILL = { core: "info", business: "ok", governance: "warn" };
const RuleTable = {
  cache: {},
  canEdit: () => !State.user || State.user.role !== "viewer",
  setCounts(rules) {
    const n = (k) => rules.filter((r) => (r.category || "core") === k).length;
    return Object.entries(RULE_SETS).map(([k, l]) => `<span class="pill ${SET_PILL[k]}" title="${esc(l)}">${esc(l)} ${n(k)}</span>`).join(" ");
  },
  sel(id, field, value, options, label) {
    if (!RuleTable.canEdit()) return field === "severity" ? pill(value) : pill(SET_PILL[value] || "", RULE_SETS[value] || value);
    return `<select class="sel-sm ${field === "severity" ? "sev-" + esc(value) : ""}" aria-label="${esc(label)}" onchange="RuleTable.change(this, ${id}, '${field}')">
      ${options.map(([v, l]) => `<option value="${esc(v)}" ${v === value ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
  },
  /* drafts can be edited by anyone who edits; anything past a draft (in review, active, disabled) only by administrators */
  canEditRule(r) { return RuleTable.canEdit() && (["proposed", "rejected"].includes(r.status) || iAmAdmin()); },
  statusPill(r) {
    const m = { proposed: ["muted", "draft"], review: ["warn", "in review"], approved: ["info", "approved"] }[r.status];
    return m ? pill(m[0], m[1]) : pill(r.status);
  },
  render(rules, opts = {}) {
    rules.forEach((r) => (RuleTable.cache[r.id] = r));
    if (!rules.length) return '<div class="empty">No rules match. Use AI rule generation, Plain-English rule or Manual rule builder to add some.</div>';
    const sevs = ["critical", "high", "medium", "low"].map((s) => [s, s]);
    const sel = !!opts.select, viewer = !RuleTable.canEdit(), admin = iAmAdmin();
    return `<table class="t"><tr>${sel ? `<th style="width:28px"><input type="checkbox" aria-label="Select all rules" ${Catalog.sel.size && rules.every((r) => Catalog.sel.has(r.id)) ? "checked" : ""} onchange="Catalog.all(this.checked)"></th>` : ""}
      <th>Rule</th>${opts.showAsset ? "<th>Dataset</th>" : ""}<th>Set</th><th>Type</th><th>Severity</th><th>Status</th><th>Last result</th><th></th></tr>
    ${rules.map((r) => { const can = RuleTable.canEditRule(r); return `<tr>${sel ? `<td><input type="checkbox" ${Catalog.sel.has(r.id) ? "checked" : ""} onchange="Catalog.pick(${r.id}, this.checked)" aria-label="Select ${esc(r.name)}"></td>` : ""}
      <td><strong>${esc(r.name)}</strong><div class="sub">${esc(r.dimension)} · ${esc(r.source)}${r.reason ? " · " + esc(r.reason.slice(0, 160)) : ""}</div></td>
      ${opts.showAsset ? `<td class="sub">${esc(short(r.asset))}</td>` : ""}
      <td>${pill(SET_PILL[r.category || "core"] || "", RULE_SETS[r.category || "core"] || r.category)}</td>
      <td class="mono">${esc(r.type)}${(r.params || {}).negate ? ' <span class="pill muted">must not match</span>' : ""}</td>
      <td>${can ? RuleTable.sel(r.id, "severity", r.severity, sevs, "Severity of " + r.name) : pill(r.severity)}</td>
      <td>${RuleTable.statusPill(r)}</td><td>${r.last_status ? pill(r.last_status) : ""}</td>
      <td class="btns">${can ? `<button class="btn sm" onclick="RuleEdit.open(${r.id})">Edit</button>` : ""}
        ${["proposed", "rejected"].includes(r.status) && !viewer ? '<a class="btn sm" href="#/rules/saved">Send for approval</a>' : ""}
        ${["review", "approved"].includes(r.status) ? '<a class="btn sm" href="#/rules/review">Review queue</a>' : ""}
        ${r.status === "active" && !viewer ? `<button class="btn sm" onclick="act(this, () => patch('/rules/${r.id}', {status:'disabled'}), 'Disabled')">Disable</button>` : ""}
        ${r.status === "disabled" && admin ? `<button class="btn sm" onclick="act(this, () => patch('/rules/${r.id}', {status:'active'}), 'Enabled')">Enable</button>` : ""}
        ${opts.feedback && r.last_status === "fail" && !viewer ? `<button class="btn sm" onclick="act(this, () => post('/feedback', {verdict:'false_positive', rule_id:${r.id}}), r => 'Learned: ' + JSON.stringify(r.effects))">False positive</button>` : ""}</td></tr>`; }).join("")}
    </table>`;
  },
  async change(el, id, field) {
    const r = RuleTable.cache[id], before = r ? r[field] : null;
    el.disabled = true;
    try {
      const upd = await patch(`/rules/${id}`, { [field]: el.value });
      RuleTable.cache[id] = { ...r, ...upd };
      if (field === "severity") el.className = "sel-sm sev-" + el.value;
      toastOk(`${field === "severity" ? "Severity" : "Set"} of “${upd.name}” is now ${field === "severity" ? upd.severity : RULE_SETS[upd.category]}`);
    } catch (e) { toastError(e.message); if (before != null) el.value = before; }
    el.disabled = false;
  },
};

const RuleEdit = {
  async open(id) {
    const r = RuleTable.cache[id];
    if (!r) return toastError("Reload the page and try again");
    const a = await api("/assets/" + r.asset_id);
    RuleEdit.r = r;
    RuleEdit.asset = a;
    const types = State.meta?.rule_types || {};
    const dims = State.meta?.dimensions || [];
    const opt = (list, cur) => list.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(cur ?? "") ? "selected" : ""}>${esc(l)}</option>`).join("");
    Modal.open(`${Modal.head("Edit rule", esc(a.fqn))}
      <div class="modal-body">
        <label class="f">Name<input id="re-name" value="${esc(r.name)}"></label>
        <div class="grid" style="grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:8px">
          <label class="f">Set<select id="re-category">${opt(Object.entries(RULE_SETS), r.category || "core")}</select></label>
          <label class="f">Severity<select id="re-severity">${opt(["critical", "high", "medium", "low"].map((s) => [s, s]), r.severity)}</select></label>
          ${iAmAdmin() && ["active", "disabled"].includes(r.status) ? `<label class="f">Status<select id="re-status">${opt([["active", "active"], ["disabled", "disabled"]], r.status)}</select></label>`
            : `<div class="f"><span>Status</span><div style="padding:6px 0">${RuleTable.statusPill(r)}</div></div>`}
          <label class="f">Type<select id="re-type">${opt(Object.keys(types).map((t) => [t, t]), r.type)}</select></label>
          <label class="f">Column<select id="re-column"><option value="">(none)</option>${opt((a.columns || []).map((c) => [c.name, c.name]), r.column)}</select></label>
          <label class="f">Dimension<select id="re-dimension">${opt(dims.map((d) => [d, d]), r.dimension)}</select></label>
          <label class="f">Min pass rate (0-1)<input id="re-threshold" type="number" min="0" max="1" step="any" value="${esc(r.threshold)}"></label></div>
        <label class="f" style="margin-top:8px">Params (JSON)<textarea id="re-params" class="mono" rows="5">${esc(JSON.stringify(r.params || {}, null, 2))}</textarea></label>
        <label class="f" style="margin-top:8px">Description<input id="re-description" value="${esc(r.description || "")}" placeholder="optional"></label>
        ${r.reason ? `<details style="margin-top:8px"><summary class="sub">Why it was proposed</summary><div class="sub">${esc(r.reason)}</div></details>` : ""}
        <div class="row" style="margin-top:12px;gap:8px"><button class="btn sm" onclick="RuleEdit.dry(this)">Dry run</button><div id="re-out" class="preview-box" style="flex:1">Dry run checks the edited rule on current data without saving it.</div></div>
      </div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn primary" onclick="RuleEdit.save(this)">Save changes</button></div>`, { wide: true });
  },
  collect() {
    let params;
    try { params = JSON.parse($("#re-params").value || "{}"); } catch (e) { throw new Error("Params must be valid JSON: " + e.message); }
    return { name: $("#re-name").value.trim(), category: $("#re-category").value, severity: $("#re-severity").value, ...($("#re-status") ? { status: $("#re-status").value } : {}),
      type: $("#re-type").value, column: $("#re-column").value || null, dimension: $("#re-dimension").value,
      threshold: Number($("#re-threshold").value === "" ? 1 : $("#re-threshold").value), params, description: $("#re-description").value };
  },
  async dry(btn) {
    const out = $("#re-out");
    btn.disabled = true;
    try {
      const v = RuleEdit.collect();
      out.textContent = "Running on the platform…";
      const d = await post("/rules/dry-run", { asset_id: RuleEdit.r.asset_id, type: v.type, column: v.column, params: v.params, severity: v.severity, threshold: v.threshold });
      out.innerHTML = dryHtml(d);
    } catch (e) { out.innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span>`; }
    btn.disabled = false;
  },
  async save(btn) {
    const r = RuleEdit.r;
    let v;
    try { v = RuleEdit.collect(); } catch (e) { return toastError(e.message); }
    const changes = {};
    for (const [k, val] of Object.entries(v)) {
      const cur = k === "params" ? JSON.stringify(r.params || {}) : String(r[k] ?? (k === "category" ? "core" : ""));
      const nv = k === "params" ? JSON.stringify(val) : String(val ?? "");
      if (cur !== nv) changes[k] = val;
    }
    if (!Object.keys(changes).length) { Modal.close(); return toastOk("No changes"); }
    btn.disabled = true;
    try {
      await patch(`/rules/${r.id}`, changes);
      Modal.close();
      toastOk(`Saved “${v.name}” (version ${(r.version || 1) + 1})`);
      await render(true);
    } catch (e) { toastError(e.message); btn.disabled = false; }
  },
};

/* ------------------------------------------------------------------ governance context for rule generation: contract, policies, standards */
const GovCtx = {
  sel: (() => { try { return { contracts: true, policies: true, glossary: true, standards: [], ...(JSON.parse(localStorage.getItem("dt.govctx")) || {}) }; } catch (e) { return { contracts: true, policies: true, glossary: true, standards: [] }; } })(),
  last: null,
  save() { try { localStorage.setItem("dt.govctx", JSON.stringify(GovCtx.sel)); } catch (e) { /* per-viewer convenience only */ } },
  body() { return { contracts: !!GovCtx.sel.contracts, policies: !!GovCtx.sel.policies, glossary: !!GovCtx.sel.glossary, standards: GovCtx.sel.standards.slice() }; },
  set(k, v) { GovCtx.sel[k] = v; GovCtx.save(); GovCtx.load(GovCtx.assetId); },
  std(k, on) { const l = new Set(GovCtx.sel.standards); if (on) l.add(k); else l.delete(k); GovCtx.sel.standards = [...l]; GovCtx.save(); GovCtx.load(GovCtx.assetId); },
  sumText(r) {
    const bits = [];
    if (GovCtx.sel.contracts) bits.push(r.contract ? `contract v${r.contract.version}` : "no contract");
    if (GovCtx.sel.policies) bits.push(`${r.policies.length} polic${r.policies.length === 1 ? "y" : "ies"}`);
    if (GovCtx.sel.glossary) bits.push(`${r.glossary.length} term${r.glossary.length === 1 ? "" : "s"}`);
    if (r.standards.length) bits.push(r.standards.map((x) => x.title.split(" (")[0]).join(", "));
    return bits.length ? bits.join(" · ") : "no governance context";
  },
  async load(assetId) {
    GovCtx.assetId = assetId;
    const el = $("#govctx");
    if (!el) return;
    let r;
    try {
      // always ask for the contract and policies so the counts show next to an unticked box too
      r = await api(`/assets/${assetId}/governed-context?contracts=true&policies=true&glossary=true&standards=${GovCtx.sel.standards.join(",")}`);
    } catch (e) { el.innerHTML = `<span class="sub">${esc(e.message)}</span>`; return; }
    GovCtx.last = r;
    const fw = (State.meta && State.meta.frameworks) || {};
    const sum = $("#ctx-sum");
    if (sum) sum.textContent = Refs.summary();
    el.innerHTML = `<label class="row sub" style="gap:6px"><input type="checkbox" ${GovCtx.sel.contracts ? "checked" : ""} onchange="GovCtx.set('contracts', this.checked)">
        <span><strong>Data contract</strong> ${r.contract ? `<span class="muted">${esc(r.contract.name)} v${esc(r.contract.version)}: its promises that no active rule covers become proposals</span>` : '<span class="muted">none for this dataset</span>'}</span></label>
      <label class="row sub" style="gap:6px;margin-top:4px"><input type="checkbox" ${GovCtx.sel.policies ? "checked" : ""} onchange="GovCtx.set('policies', this.checked)">
        <span><strong>Policies</strong> <span class="muted">${r.policies.length ? `${r.policies.length} apply to this dataset` : "none apply to this dataset"}</span></span></label>
      <label class="row sub" style="gap:6px;margin-top:4px"><input type="checkbox" ${GovCtx.sel.glossary ? "checked" : ""} onchange="GovCtx.set('glossary', this.checked)">
        <span><strong>Business glossary</strong> <span class="muted">${r.glossary.length ? `${r.glossary.length} term${r.glossary.length === 1 ? "" : "s"} mapped to this dataset: a definition that states a rule becomes a proposal` : "no terms mapped to this dataset"}</span></span></label>
      ${r.glossary.length ? `<details style="margin:2px 0 0 22px"><summary class="sub">Which terms</summary>${r.glossary.map((t) => `<div class="sub">&bull; <strong>${esc(t.name)}</strong>: ${esc((t.definition || "").slice(0, 160))}</div>`).join("")}</details>` : ""}
      ${r.policies.length ? `<details style="margin:2px 0 0 22px"><summary class="sub">Which policies</summary>${r.policies.map((p) => `<div class="sub">&bull; <span class="mono">${esc(p.key)}</span>: ${esc(p.description)}</div>`).join("")}</details>` : ""}
      <div class="sub" style="margin-top:6px"><strong>Standards</strong> <span class="muted">proposals that help meet a control you have not met yet are tagged</span></div>
      <div class="row" style="gap:12px;flex-wrap:wrap;margin:2px 0 0 0">${Object.entries(fw).map(([k, title]) => {
        const got = r.standards.find((x) => x.key === k);
        return `<label class="row sub" style="gap:4px"><input type="checkbox" ${GovCtx.sel.standards.includes(k) ? "checked" : ""} onchange="GovCtx.std('${k}', this.checked)"> ${esc(title.split(" (")[0])}${got ? ` <span class="muted">(${got.unmet} not met)</span>` : ""}</label>`;
      }).join("")}</div>`;
  },
};

/* ------------------------------------------------------------------ reference files */
const Refs = {
  meta: null,
  docs: null,
  sel: (() => { try { return JSON.parse(localStorage.getItem("dt.refsel")) || { mode: "all", ids: [] }; } catch (e) { return { mode: "all", ids: [] }; } })(),
  save() { try { localStorage.setItem("dt.refsel", JSON.stringify(Refs.sel)); } catch (e) { /* per-viewer convenience only */ } },
  async load(force) {
    if (!Refs.meta) Refs.meta = await api("/references/kinds");
    if (!Refs.docs || force) Refs.docs = await api("/references");
    return Refs.docs;
  },
  body() {
    if (Refs.sel.mode === "none") return { use_references: false };
    if (Refs.sel.mode === "selected") return { reference_ids: Refs.sel.ids.filter((id) => (Refs.docs || []).some((d) => d.id === id)) };
    return { reference_ids: null };
  },
  kindLabel(k) { return (Refs.meta && Refs.meta.kinds[k] && Refs.meta.kinds[k].label) || k; },
  summary(d) {
    const s = d.summary || {};
    if (d.status === "error") return `<span style="color:var(--bad)">${esc(d.error || "Could not read the file")}</span>`;
    if (s.note) return esc(s.note);
    const parts = [];
    if (s.tables) parts.push(`${s.tables.toLocaleString()} tables`);
    if (s.terms) parts.push(`${s.terms} terms`);
    if (s.rows) parts.push(`${s.rows.toLocaleString()} rows`);
    if (s.rule_sentences) parts.push(`${s.rule_sentences} rule sentences`);
    parts.push(`${(s.facts || 0).toLocaleString()} facts`);
    const top = Object.entries(s.by_kind || {}).slice(0, 4).map(([k, n]) => `${k.replace(/_/g, " ")} ${n.toLocaleString()}`).join(" · ");
    return esc(parts.join(" · ")) + (top ? `<div class="sub">${esc(top)}</div>` : "");
  },
  async upload(onDone, opts = {}) {
    await Refs.load();
    const kinds = Refs.meta.kinds;
    let domains = [];
    try { domains = [...new Set((await api("/assets")).map((a) => a.domain).filter(Boolean))]; } catch (e) { /* optional */ }
    Refs.onDone = onDone || null;
    setTimeout(() => { const el = $("#ru-domain"); if (el && opts.domain) el.value = opts.domain; const k = $("#ru-kind"); if (k && opts.kind) { k.value = opts.kind; k.onchange(); } }, 0);
    Modal.open(`${Modal.head("Add reference files", opts.domain
      ? `Saved to Reference files and used as AI context for <strong>${esc(opts.domain)}</strong> datasets. Clear the business domain to use them everywhere.`
      : "Models, ontologies, UML, XML, glossaries, master data and business or policy documents")}
      <div class="modal-body">
        <label class="f">Files<input type="file" id="ru-files" multiple accept="${esc(Object.values(kinds).flatMap((k) => k.ext).concat([".json", ".csv"]).join(","))}"></label>
        <div class="grid" style="grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">
          <label class="f">What the file is<select id="ru-kind" onchange="$('#ru-help').textContent = this.value ? Refs.meta.kinds[this.value].help : 'The type is detected from the extension and content.'">
            <option value="">Detect automatically</option>${Object.entries(kinds).map(([k, v]) => `<option value="${k}">${esc(v.label)}</option>`).join("")}</select></label>
          <label class="f">Business domain<input id="ru-domain" list="ru-domains" placeholder="all domains"><datalist id="ru-domains">${domains.concat(["governance"]).map((d) => `<option value="${esc(d)}">`).join("")}</datalist></label></div>
        <div class="sub" id="ru-help" style="margin-top:4px">The type is detected from the extension and content.</div>
        <label class="f" style="margin-top:8px">Description<input id="ru-desc" placeholder="optional: what it covers, owner, version"></label>
        <p class="sub" style="margin:10px 0 0">Up to ${Refs.meta.max_mb} MB per file. Files with a business domain are used only for datasets in that domain; leave it empty to use a file everywhere.</p>
        <div id="ru-out" style="margin-top:8px"></div>
      </div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Close</button><button class="btn primary" id="ru-go" onclick="Refs.doUpload(this)">Upload</button></div>`);
  },
  readB64(file) {
    return new Promise((ok, bad) => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.onerror = () => bad(fr.error); fr.readAsDataURL(file); });
  },
  async doUpload(btn) {
    const files = [...($("#ru-files").files || [])];
    if (!files.length) return toastError("Choose at least one file");
    const out = $("#ru-out"), max = Refs.meta.max_mb * 1048576;
    btn.disabled = true;
    const done = [];
    out.innerHTML = "";
    for (const f of files) {
      const line = document.createElement("div");
      line.className = "sub";
      line.textContent = `${f.name}: uploading and reading…`;
      out.appendChild(line);
      if (f.size > max) { line.innerHTML = `${esc(f.name)}: <span style="color:var(--bad)">larger than ${Refs.meta.max_mb} MB</span>`; continue; }
      try {
        const d = await post("/references", { name: f.name, content_b64: await Refs.readB64(f), kind: $("#ru-kind").value || null,
          domain: $("#ru-domain").value || null, description: $("#ru-desc").value || null });
        done.push(d);
        line.innerHTML = d.status === "error" ? `${pill("bad", "error")} <strong>${esc(f.name)}</strong>: ${esc(d.error)}`
          : `${pill(d.status === "parsed" ? "ok" : "info", d.status === "parsed" ? "read" : "stored")} <strong>${esc(f.name)}</strong> as ${esc(Refs.kindLabel(d.kind))}: ${(d.summary || {}).facts || 0} facts`;
        if (d.status === "error") toastError(`${f.name} was stored, but it couldn't be read:\n${d.error}`);
      } catch (e) { line.innerHTML = `${pill("bad", "failed")} <strong>${esc(f.name)}</strong>: ${esc(e.message)}`; toastError(`${f.name}: ${e.message}`); }
    }
    btn.disabled = false;
    $("#ru-files").value = "";
    await Refs.load(true);
    if (done.length) {
      toastOk(`Added ${done.length} reference file${done.length === 1 ? "" : "s"}`);
      if (Refs.sel.mode === "selected") { done.forEach((d) => Refs.sel.ids.push(d.id)); Refs.save(); }
      if (Refs.onDone) Refs.onDone(done);
    }
  },
  async view(id) {
    const d = await api(`/references/${id}?limit=300`);
    Modal.open(`${Modal.head(d.name, `${esc(Refs.kindLabel(d.kind))}${d.domain ? " · domain " + esc(d.domain) : ""} · ${(d.size / 1024).toFixed(0)} KB · uploaded by ${esc(d.uploaded_by || "")} ${esc(ts(d.created))}`)}
      <div class="modal-body">${d.description ? `<p>${esc(d.description)}</p>` : ""}
        <div>${Refs.summary(d)}</div>
        <div class="grid" style="grid-template-columns:1fr 1fr;gap:8px;margin-top:10px">
          <label class="f">What the file is<select id="rv-kind">${Object.entries(Refs.meta.kinds).map(([k, v]) => `<option value="${k}" ${k === d.kind ? "selected" : ""}>${esc(v.label)}</option>`).join("")}</select></label>
          <label class="f">Business domain<input id="rv-domain" value="${esc(d.domain || "")}" placeholder="all domains"></label></div>
        <label class="f" style="margin-top:8px">Description<input id="rv-desc" value="${esc(d.description || "")}"></label>
        <h3 style="margin-top:14px">What was read (first ${d.facts.length})</h3>
        <div class="wrap" style="max-height:320px;overflow:auto"><table class="t"><tr><th>Table</th><th>Column</th><th>Fact</th><th>Value</th></tr>
        ${d.facts.map((x) => `<tr><td class="mono sub">${esc(x.table || "")}</td><td class="mono">${esc(x.column || "")}</td><td>${esc(x.kind.replace(/_/g, " "))}</td>
          <td class="sub">${esc(x.value != null ? (typeof x.value === "object" ? JSON.stringify(x.value) : x.value) : x.text || "").slice(0, 160)}</td></tr>`).join("") || '<tr><td colspan="4" class="empty">Nothing was extracted</td></tr>'}</table></div>
      </div>
      <div class="modal-foot"><a class="btn" href="/api/references/${d.id}/download">Download</a><button class="btn" onclick="Refs.reparse(this, ${d.id})">Read again</button>
        <span style="flex:1"></span><button class="btn" onclick="Modal.close()">Close</button><button class="btn primary" onclick="Refs.saveMeta(this, ${d.id})">Save</button></div>`, { wide: true });
  },
  async saveMeta(btn, id) {
    btn.disabled = true;
    try {
      const d = await patch(`/references/${id}`, { kind: $("#rv-kind").value, domain: $("#rv-domain").value, description: $("#rv-desc").value });
      Modal.close();
      toastOk(`Saved ${d.name}` + (d.status === "error" ? "" : `: ${(d.summary || {}).facts || 0} facts`));
      if (d.status === "error") toastError(`${d.name} couldn't be read as ${Refs.kindLabel(d.kind)}:\n${d.error}`);
      await Refs.load(true);
      await render(true);
    } catch (e) { toastError(e.message); btn.disabled = false; }
  },
  async reparse(btn, id) {
    btn.disabled = true;
    try { const d = await post(`/references/${id}/reparse`); Modal.close(); d.status === "error" ? toastError(d.error) : toastOk(`Read ${d.name} again: ${(d.summary || {}).facts || 0} facts`); await render(true); }
    catch (e) { toastError(e.message); btn.disabled = false; }
  },
  async toggle(el, id) {
    el.disabled = true;
    try { const d = await patch(`/references/${id}`, { enabled: el.checked }); toastOk(`${d.name} ${d.enabled ? "will" : "won't"} be used by default`); await Refs.load(true); }
    catch (e) { toastError(e.message); el.checked = !el.checked; }
    el.disabled = false;
  },
  askDelete(id, name) {
    Modal.open(`${Modal.head("Delete " + name)}<div class="modal-body"><p>The file and everything read from it are removed. Rules already created from it stay.</p></div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn danger" onclick="Refs.doDelete(this, ${id})">Delete file</button></div>`);
  },
  async doDelete(btn, id) {
    btn.disabled = true;
    try { await api(`/references/${id}`, { method: "DELETE" }); Modal.close(); toastOk("Reference file deleted"); Refs.sel.ids = Refs.sel.ids.filter((x) => x !== id); Refs.save(); await Refs.load(true); await render(true); }
    catch (e) { toastError(e.message); btn.disabled = false; }
  },
  /* AI context inside AI rule generation: which saved reference files to use, upload more, and what they say about the dataset */
  contextBar(asset) {
    const docs = Refs.docs || [];
    const llm = State.meta?.llm || {};
    const usable = docs.filter((d) => d.status !== "error");
    const edit = RuleTable.canEdit();
    const modelNote = llm.provider && llm.provider !== "rules" && llm.provider !== "error"
      ? `Matching facts are sent to the model (${esc(llm.provider)}${llm.model ? " · " + esc(llm.model) : ""}) as context.`
      : "No model is configured (llm.provider: rules), so the built-in reader turns these facts into rules.";
    const tok = Math.random().toString(36).slice(2, 10);
    setTimeout(() => { Refs.match(asset.id, tok); GovCtx.load(asset.id); }, 0);
    return `<div class="ctxbar" id="refctx"><div class="row" style="gap:8px;flex-wrap:wrap"><strong>AI context</strong>
      <span class="sub" id="ctx-sum">${Refs.summary()}</span><span style="flex:1"></span>
      <button class="btn sm" id="ctx-toggle" aria-expanded="${Refs.open}" onclick="Refs.toggleCtx()">${Refs.open ? "Hide context" : "Change context"}</button></div>
      <div id="ctx-body" ${Refs.open ? "" : "hidden"}><div class="sub" style="margin:6px 0">Business documents, glossary, master data, models and policies the proposals can draw on.</div>
      <div class="row" style="gap:8px;flex-wrap:wrap"><select aria-label="Which reference files to use" onchange="Refs.sel.mode=this.value; if (this.value === 'selected' && !Refs.sel.ids.length) Refs.sel.ids = (Refs.docs || []).filter((d) => d.status !== 'error').map((d) => d.id); Refs.save(); render(true)">
        <option value="all" ${Refs.sel.mode === "all" ? "selected" : ""}>All saved files for this domain</option>
        <option value="selected" ${Refs.sel.mode === "selected" ? "selected" : ""}>Only the saved files I pick</option>
        <option value="none" ${Refs.sel.mode === "none" ? "selected" : ""}>No reference files</option></select>
      ${edit ? `<button class="btn sm" onclick="Refs.upload(Refs.afterStudioUpload, {domain: ${jsq(asset.domain || "")}})">Upload file</button>` : ""}
      <a class="btn sm" href="#/rules/references">Reference files</a></div>
      ${Refs.sel.mode === "selected" ? Refs.picker(docs, edit) : ""}
      <div class="sub" id="refctx-out" data-t="${tok}" style="margin-top:6px">${Refs.sel.mode === "none" ? "Proposals won't use reference files." : "Matching reference facts to this dataset…"}</div>
      <div class="sub">${modelNote}</div>
      <div style="margin-top:10px;padding-top:8px;border-top:1px solid var(--border)"><div class="sub" style="margin-bottom:4px"><strong>Governance context</strong>: what you have already decided, so proposals follow it. Tick what to include.</div><div id="govctx"><span class="sub">Loading…</span></div></div></div></div>`;
  },
  open: false,  // the file list stays closed until someone asks for it
  summary() {
    const docs = Refs.docs || [], usable = docs.filter((d) => d.status !== "error");
    const used = Refs.sel.mode === "all" ? "all saved files for this domain" : Refs.sel.mode === "none" ? "no reference files"
      : `${usable.filter((d) => Refs.sel.ids.includes(d.id)).length} picked file(s)`;
    return `${used} · ${usable.length} saved${docs.length > usable.length ? `, ${docs.length - usable.length} can't be read` : ""}${GovCtx.last ? " · " + GovCtx.sumText(GovCtx.last) : ""}`;
  },
  toggleCtx() {
    Refs.open = !Refs.open;
    $("#ctx-body").hidden = !Refs.open;
    const b = $("#ctx-toggle");
    b.textContent = Refs.open ? "Hide context" : "Change context";
    b.setAttribute("aria-expanded", String(Refs.open));
  },
  /* the multi-file picker: tick any of the saved files; unreadable ones are shown with why, and can be re-read */
  picker(docs, edit) {
    if (!docs.length) return '<div class="refpick"><span class="sub">No saved files yet. Use Upload file.</span></div>';
    const ok = docs.filter((d) => d.status !== "error");
    const n = ok.filter((d) => Refs.sel.ids.includes(d.id)).length;
    return `<div class="refpick"><div class="row" style="gap:8px"><strong id="refpick-count">${n} of ${ok.length} file${ok.length === 1 ? "" : "s"} selected</strong><span style="flex:1"></span>
      <button class="btn sm" onclick="Refs.pickAll(true)">Select all</button><button class="btn sm" onclick="Refs.pickAll(false)">Clear</button></div>
      <div class="refpick-list">${docs.map((d) => d.status === "error"
        ? `<div class="refpick-row bad"><input type="checkbox" disabled aria-label="${esc(d.name)} can't be used"> <span><strong>${esc(d.name)}</strong> <span class="pill bad">can't be read</span>
            <div class="sub">${esc((d.error || "").slice(0, 220))}</div></span>${edit ? `<button class="btn sm" onclick="Refs.reread(this, ${d.id})">Read again</button>` : ""}</div>`
        : `<label class="refpick-row"><input type="checkbox" data-ref="${d.id}" ${Refs.sel.ids.includes(d.id) ? "checked" : ""} onchange="Refs.pick(${d.id}, this.checked)">
            <span><strong>${esc(d.name)}</strong> <span class="muted">${esc(Refs.kindLabel(d.kind))}${d.domain ? " · for " + esc(d.domain) + " datasets" : " · all datasets"}</span>
            <div class="sub">${(d.summary && d.summary.facts != null) ? Number(d.summary.facts).toLocaleString() + " facts read" : ""}</div></span></label>`).join("")}</div></div>`;
  },
  pickAll(on) {
    const ok = (Refs.docs || []).filter((d) => d.status !== "error");
    Refs.sel.ids = on ? ok.map((d) => d.id) : [];
    Refs.save();
    document.querySelectorAll("#refctx input[data-ref]").forEach((el) => { el.checked = on; });
    Refs.count();
    const el = $("#refctx-out");
    if (State.studioAsset && el) Refs.match(Number(State.studioAsset), el.dataset.t);
  },
  count() {
    const sum = $("#ctx-sum");
    if (sum) sum.textContent = Refs.summary();
    const ok = (Refs.docs || []).filter((d) => d.status !== "error");
    const el = $("#refpick-count");
    if (el) el.textContent = `${ok.filter((d) => Refs.sel.ids.includes(d.id)).length} of ${ok.length} file${ok.length === 1 ? "" : "s"} selected`;
  },
  async reread(btn, id) {
    btn.disabled = true;
    try {
      const d = await post(`/references/${id}/reparse`);
      if (d.status === "error") toastError(`${d.name}: ${d.error}`);
      else { toastOk(`${d.name} was read: ${((d.summary && d.summary.facts) || 0).toLocaleString()} facts`); if (!Refs.sel.ids.includes(d.id)) { Refs.sel.ids.push(d.id); Refs.save(); } }
      await Refs.load(true);
      render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  afterStudioUpload(done) {  // files uploaded from AI Rule Studio are used straight away
    if (Refs.sel.mode === "none") Refs.sel = { mode: "selected", ids: [] };
    if (Refs.sel.mode === "selected") done.forEach((d) => { if (!Refs.sel.ids.includes(d.id)) Refs.sel.ids.push(d.id); });
    Refs.save();
    Modal.close();
    render(true);
  },
  pick(id, on) {
    Refs.sel.ids = Refs.sel.ids.filter((x) => x !== id).concat(on ? [id] : []);
    Refs.save();
    Refs.count();
    const el = $("#refctx-out");
    if (State.studioAsset && el) Refs.match(Number(State.studioAsset), el.dataset.t);
  },
  async match(assetId, tok) {
    // the panel is built before the rest of the page has loaded; wait for this render's panel, never an older one
    const find = () => (tok ? document.querySelector(`#refctx-out[data-t="${tok}"]`) : $("#refctx-out"));
    let out = find();
    for (let i = 0; !out && i < 50; i++) {
      await new Promise((r) => setTimeout(r, 100));
      out = find();
    }
    if (!out || Refs.sel.mode === "none") return;
    try {
      const v = await post(`/assets/${assetId}/reference-context`, Refs.body());
      Refs.lastContext = v.context_text;
      const files = v.files.filter((f) => f.facts);
      out.innerHTML = v.facts
        ? `<strong>${v.facts.toLocaleString()} facts</strong> about this dataset from ${files.map((f) => `${esc(f.name)} (${f.facts})`).join(", ")}
          ${v.columns.length ? ` · columns: ${v.columns.slice(0, 12).map((c) => `<code>${esc(c)}</code>`).join(" ")}${v.columns.length > 12 ? " …" : ""}` : ""}
          ${v.sentences ? ` · ${v.sentences} rule sentences to check` : ""} · <a onclick="Refs.showContext()">What the model sees</a>`
        : v.files.length ? `None of the ${v.files.length} file(s) mention this dataset's table or columns.` : "No reference files apply to this dataset's domain.";
    } catch (e) { out.innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span>`; }
  },
  showContext() {
    Modal.open(`${Modal.head("Reference context for the model", "The summary sent with rule proposals and described rules when a model is configured")}
      <div class="modal-body"><pre style="max-height:420px;white-space:pre-wrap">${esc(Refs.lastContext || "Nothing applies to this dataset.")}</pre></div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Close</button></div>`, { wide: true });
  },
};

/* Reference files live in AI Rule Studio; the old #/references address still works */
Pages.references = async () => {
  location.replace("#/rules/references");
  return "";
};

/* The reference library: the Reference files tab of AI Rule Studio */
Refs.library = async () => {
  const docs = await Refs.load(true);
  const kinds = Refs.meta.kinds;
  const edit = RuleTable.canEdit();
  const add = edit ? '<button class="btn primary" onclick="Refs.upload(() => render(true))">Add files</button>' : "";
  return `<div class="row" style="margin-bottom:12px"><span class="sub">Saved files that AI rule generation and Plain-English rule use as context. Pick which ones per dataset in <a href="#/rules/generation">Rule generation</a>.</span><span style="flex:1"></span>${add}</div>
  <div class="card wrap">${docs.length ? `<table class="t"><tr><th>File</th><th>Type</th><th>Domain</th><th>What was read</th><th>Uploaded</th><th>Use by default</th><th></th></tr>
    ${docs.map((d) => `<tr><td><strong>${esc(d.name)}</strong>${d.description ? `<div class="sub">${esc(d.description)}</div>` : ""}</td>
      <td>${esc(Refs.kindLabel(d.kind))}</td><td>${d.domain ? esc(d.domain) : '<span class="muted">all</span>'}</td>
      <td style="max-width:340px">${Refs.summary(d)}</td><td class="sub">${esc(d.uploaded_by || "")}<br>${esc(ts(d.created))}</td>
      <td>${edit ? `<label class="switch"><input type="checkbox" ${d.enabled ? "checked" : ""} onchange="Refs.toggle(this, ${d.id})" aria-label="Use ${esc(d.name)} by default"></label>` : d.enabled ? "Yes" : "No"}</td>
      <td class="btns"><button class="btn sm" onclick="Refs.view(${d.id})">View</button><a class="btn sm" href="/api/references/${d.id}/download">Download</a>
        ${edit ? `<button class="btn sm" onclick="Refs.askDelete(${d.id}, ${jsq(d.name)})">Delete</button>` : ""}</td></tr>`).join("")}</table>`
    : '<div class="empty">No reference files yet. Add your data models, ontology, glossary, master data or business documents, and AI Rule Studio will propose rules from them.</div>'}</div>
  <div class="sp"></div>
  <div class="card wrap"><h2>What you can add</h2><table class="t">${Object.values(kinds).map((k) => `<tr><td style="width:220px"><strong>${esc(k.label)}</strong>
    <div class="sub mono">${esc(k.ext.join(" ") || ".csv .xlsx .json")}</div></td><td class="sub">${esc(k.help)}</td></tr>`).join("")}</table>
    <p class="sub">Rule proposals are grouped into three sets: <strong>Core data</strong> (nulls, types, formats, keys), <strong>Business domain</strong> (allowed values, ranges and logic from your documents, glossary and master data) and <strong>Data governance</strong> (privacy, security, retention, consent and regulatory rules).
    When a model is configured, the facts that match a dataset are also sent to it as context.</p></div>`;
};

AssetTabs.lineage = async (a) => `<div class="card"><h2>Lineage</h2>${lineageSvg(await api("/lineage?depth=4&fqn=" + encodeURIComponent(a.fqn)))}</div>`;

AssetTabs.incidents = async (a) => {
  const incs = (await api("/incidents?status=all")).filter((i) => i.assets.includes(a.fqn) || i.root_fqn === a.fqn);
  return `<div class="card">${incidentTable(incs)}</div>`;
};

AssetTabs.governance = async (a) => {
  const vio = (await api("/policies/violations")).filter((v) => v.asset_id === a.id);
  return `<div class="grid g2"><div class="card wrap"><h2>Sensitive columns</h2>${classTable(a.classifications.map((c) => ({ ...c, asset: a.fqn })))}</div>
    <div class="card wrap"><h2>Policy violations</h2>${violationTable(vio)}</div></div>`;
};

AssetTabs.contract = async (a) => {
  const gen = await api(`/assets/${a.id}/contract`);
  const c = a.contract;
  return `<div class="grid g2">
    <div class="card"><h2>Current contract</h2>${c ? `<div class="kv"><div>Name</div><div>${esc(c.name)}</div><div>Version</div><div>${esc(c.version)}</div><div>Status</div><div>${pill(c.status === "active" ? "ok" : "warn", c.status)}</div>
      <div>Schema check</div><div>${c.last_validation?.ok ? pill("ok", "compatible") : pill("bad", "breaking changes")}</div></div>
      ${(c.last_validation?.breaking || []).map((b) => `<div class="sub">• ${esc(b)}</div>`).join("")}${(c.last_validation?.warnings || []).map((b) => `<div class="sub muted">• ${esc(b)}</div>`).join("")}
      <div class="sp"></div><button class="btn" onclick="act(this, () => post('/contracts/${c.id}/validate'), r => r.ok ? 'Compatible' : 'Breaking changes found')">Validate against live schema</button>`
      : '<div class="empty">No contract yet. Generate one from the current rules, review it, and save.</div>'}</div>
    <div class="card"><h2>Generated ODCS v3 contract</h2><textarea id="ctr" style="min-height:320px">${esc(gen.yaml)}</textarea>
      <div class="sp"></div><button class="btn primary" onclick="act(this, () => post('/contracts', {yaml: $('#ctr').value}), r => 'Saved; ' + r.rules_created.length + ' rules created')">Save as contract</button></div></div>`;
};

AssetTabs.history = async (a) => {
  const [rc, sc, res] = await Promise.all([api(`/assets/${a.id}/metrics?metric=row_count`), api(`/assets/${a.id}/metrics?metric=dq_score`), api(`/assets/${a.id}/results?limit=60`)]);
  return `<div class="grid g2"><div class="card"><h2>Row count</h2>${lineChart(rc, { label: "row count" })}</div><div class="card"><h2>DQ score</h2>${lineChart(sc, { label: "DQ score" })}</div></div><div class="sp"></div>
  <div class="card wrap"><h2>Recent results</h2><table class="t"><tr><th>When</th><th>Rule</th><th>Status</th><th>Result</th><th class="num">Seconds</th></tr>
  ${res.map((r) => `<tr><td>${ts(r.ts)}</td><td>#${r.rule_id}</td><td>${pill(r.status)}</td><td>${esc(r.message || "")}</td><td class="num">${r.duration_s}</td></tr>`).join("")}</table></div>`;
};

function incidentTable(incs) {
  if (!incs.length) return '<div class="empty">No incidents</div>';
  return `<div class="wrap"><table class="t"><tr><th>#</th><th>Severity</th><th>Incident</th><th>Root cause</th><th class="num">Assets</th><th class="num">Downstream</th><th>Assignee</th><th>Status</th><th>Opened</th></tr>
  ${incs.map((i) => `<tr><td>${i.id}</td><td>${pill(i.severity)}</td><td><a href="#/incident/${i.id}">${esc(i.title)}</a></td><td class="mono">${esc(short(i.root_fqn))}</td>
    <td class="num">${i.assets.length}</td><td class="num">${i.downstream.length}</td><td>${esc(i.assignee || "")}</td><td>${pill(i.status)}</td><td>${ts(i.created)}</td></tr>`).join("")}</table></div>`;
}

/* Incidents: status tabs, plus filters carried over from an Overview chart (shown as removable chips) */
const INC_F_LABEL = { severity: "Severity", platform: "Platform", domain: "Domain", asset_id: "Dataset" };
Pages.incidents = async () => {
  const f = Object.fromEntries(Object.entries(State.incF || {}).filter(([, v]) => v !== "" && v != null));
  const q = new URLSearchParams({ status: State.incStatus, ...(State.platform ? { platform: State.platform } : {}), ...f });
  const [incs, assets, picker] = await Promise.all([api("/incidents?" + q), f.asset_id ? api("/assets") : Promise.resolve([]), platformPicker()]);
  const name = (k, v) => (k === "asset_id" ? (assets.find((a) => String(a.id) === String(v)) || {}).fqn || "#" + v : k === "platform" ? PLATFORMS[v] || v : v);
  const chips = Object.entries(f).map(([k, v]) => `<span class="chip">${esc(INC_F_LABEL[k] || k)}: <strong>${esc(name(k, v))}</strong>
    <button class="toast-x" style="color:var(--text-2);font-size:15px" aria-label="Remove ${esc(INC_F_LABEL[k] || k)} filter" onclick="delete State.incF.${k}; render()">&times;</button></span>`).join("");
  return `<div class="page-head"><h1>Incidents</h1><span class="grow"></span>${picker}</div>
  <div class="tabs">${["open", "resolved", "muted", "all"].map((s) => `<a class="${State.incStatus === s ? "active" : ""}" onclick="State.incStatus='${s}';render()">${s[0].toUpperCase() + s.slice(1)}</a>`).join("")}</div>
  ${chips ? `<div class="inc-chips"><span class="sub">Filtered:</span>${chips}<a onclick="State.incF = {}; render()">Clear filters</a></div>` : ""}
  <div class="card">${incidentTable(incs)}</div>`;
};

Pages.incident = async (id) => {
  const i = await api("/incidents/" + id);
  State.ctx = { incident_id: i.id, label: "incident #" + i.id };
  const fixesOn = !!(State.meta && State.meta.features && State.meta.features.fixes_and_quarantine);
  const [g, corrections] = await Promise.all([api("/lineage?depth=3&fqn=" + encodeURIComponent(i.root_fqn)),
    fixesOn ? api(`/incidents/${i.id}/fixes`).catch(() => []) : Promise.resolve([])]);
  const rca = i.rca || {};
  const a = (name, label, extra = "") => `<button class="btn" onclick="act(this, () => post('/incidents/${i.id}/action', {action:'${name}'${extra}}), '${label}')">${label}</button>`;
  return `
  <div class="page-head"><div><div class="row">${pill(i.severity)} ${pill(i.status)} <span class="sub">#${i.id} · opened ${ts(i.created)} · assignee ${esc(i.assignee || "none")}</span></div>
    <h1 style="margin-top:6px">${esc(i.title)}</h1></div><span class="grow"></span>
    <div class="btns">${i.status === "open" ? a("ack", "Acknowledge") : ""}
      <button class="btn" onclick="const w=prompt('Assign to'); if(w) act(this, () => post('/incidents/${i.id}/action', {action:'assign', assignee:w}), 'Assigned')">Assign</button>
      ${i.status !== "resolved" ? a("resolve", "Resolve") : a("reopen", "Reopen")} ${i.status !== "muted" ? a("mute", "Mute") : ""}
      <button class="btn" onclick="act(this, () => post('/incidents/${i.id}/ticket'), 'Ticket opened')">Open ticket</button>
      ${i.root_asset_id ? `<a class="btn" href="#/impact/${i.root_asset_id}">Impact</a>` : ""}
      <button class="btn primary" onclick="Agent.ask('Why did incident #${i.id} happen and what should we do?')">Ask agent</button></div></div>
  <div class="callout ${i.severity === "critical" || i.severity === "high" ? "bad" : ""}"><strong>${esc(rca.hypothesis || "")}</strong><br>${esc(i.summary || "")}</div><div class="sp"></div>
  <div class="grid g2">
    <div class="card"><h2>Evidence</h2>${(rca.evidence || []).map((e) => `<div class="ev ${e.is_root ? "root" : ""}"><div class="when">${ts(e.at)} · ${esc(short(e.asset))}${e.is_root ? " · root" : ""}</div>
      <strong>${esc(e.rule)}</strong> <span class="pill">${esc(e.dimension || "")}</span><div class="sub">${esc(e.message)}</div></div>`).join("") || '<div class="empty">No evidence</div>'}</div>
    <div class="card"><h2>Lineage around the root cause</h2>${lineageSvg(g)}
      ${i.downstream.length ? `<p class="sub">Downstream at risk: ${i.downstream.map((d) => `<code>${esc(short(d))}</code>`).join(" ")}</p>` : ""}</div>
  </div><div class="sp"></div>
  <div class="card wrap"><h2>Failing checks</h2><table class="t"><tr><th>Dataset</th><th>Rule</th><th>Dimension</th><th>Result</th><th></th></tr>
    ${i.rules.map((r) => `<tr><td>${esc(short(r.asset))}</td><td>${esc(r.name)}</td><td>${esc(r.dimension)}</td><td>${r.last ? pill(r.last.status) + " " + esc(r.last.message || "") : ""}
      ${r.last?.failing_sql ? `<details><summary class="sub">Query for failing rows</summary><pre>${esc(r.last.failing_sql)}</pre></details>` : ""}</td>
      <td><button class="btn sm" onclick="act(this, () => post('/feedback', {verdict:'false_positive', rule_id:${r.id}}), r => 'Learned: ' + JSON.stringify(r.effects))">False positive</button></td></tr>`).join("")}</table></div><div class="sp"></div>
  <div class="grid g2">
    <div class="card"><h2>Suggested fixes</h2>
      ${corrections.length ? `<h3>Corrections</h3>${corrections.map((f) => Fixes.card(f, i.id)).join("")}<div class="sp"></div>` : ""}
      ${i.remediations.length ? `<h3>Other actions</h3>` + i.remediations.map((s, k) => `<div class="approval"><div class="t1">${esc(s.kind)} · risk ${esc(s.risk)} · ${s.reversible ? "reversible" : "not reversible"}</div>
      <strong>${esc(s.title)}</strong>${s.note ? `<div class="sub">${esc(s.note)}</div>` : ""}${s.statements ? `<details><summary class="sub">SQL</summary><pre>${esc(s.statements.join(";\n"))}</pre></details>` : ""}
      <div class="sp" style="height:6px"></div>${s.kind === "quarantine"
        ? `<button class="btn sm primary" onclick="Quarantine.start(${s.rule_id}, ${i.id})">Quarantine…</button>`
        : `<button class="btn sm" onclick="act(this, () => post('/incidents/${i.id}/remediate?index=${k}'), (r) => r.status === 'approved' ? 'Done' : 'Failed: ' + ((r.result || {}).error || ''))">Run now</button>`}</div>`).join("") : ""}
      ${!corrections.length && !i.remediations.length ? '<div class="empty">No automatic fix applies</div>' : ""}</div>
    <div class="card"><h2>Was this alert right?</h2><p class="sub">Feedback tunes thresholds and sensitivity for these rules.</p><div class="btns">
      <button class="btn" onclick="act(this, () => post('/feedback', {verdict:'true_positive', incident_id:${i.id}}), 'Recorded')">Real issue</button>
      <button class="btn" onclick="act(this, () => post('/feedback', {verdict:'false_positive', incident_id:${i.id}}), 'Recorded')">False positive</button>
      <button class="btn" onclick="act(this, () => post('/feedback', {verdict:'expected_change', incident_id:${i.id}}), 'Baseline reset')">Expected change</button></div>
      ${i.ticket && i.ticket.status ? `<div class="sp"></div><h3>Ticket</h3><div class="sub">${esc(i.ticket.provider)} ${esc(i.ticket.key || i.ticket.status)} ${i.ticket.url ? `<a href="${esc(i.ticket.url)}" target="_blank" rel="noopener">open</a>` : ""}</div>` : ""}
      <div class="sp"></div><h3>Timeline</h3>${i.events.map((e) => `<div class="ev"><div class="when">${ts(e.ts)} · ${esc(e.actor)} · ${esc(e.kind)}</div><div class="sub">${esc(e.text)}</div></div>`).join("")}</div>
  </div>`;
};

const Studio = {
  drafts: {},
  /* Plain-English rule: each line is drafted and dry-run on the platform. Nothing is stored until Save as draft. */
  async nl(btn, assetId, text) {
    const lines = String(text || "").split(/\n+/).map((l) => l.replace(/^\s*[-*•\d.)]+\s*/, "").trim()).filter(Boolean);
    const out = $("#nl-out");
    if (!lines.length) {
      out.innerHTML = '<div class="ferr" style="display:block;margin-top:8px">Write a requirement first, for example "kwh cannot be negative".</div>';
      return;
    }
    btn.disabled = true;
    out.innerHTML = `<p class="sub" style="margin-top:10px">Drafting ${lines.length} rule(s) and running each on the platform…</p>`;
    Studio.drafts = {};
    const cards = [];
    for (const [i, line] of lines.entries()) {
      try {
        const setSel = $("#nl-set");
        const r = await post("/rules/nl", { asset_id: Number(assetId), text: line, save: false, category: setSel ? setSel.value || null : null, ...Refs.body() });
        Studio.drafts[i] = { asset_id: Number(assetId), rule: r.rule, saved: false };
        cards.push(`<div class="approval" id="dr-${i}" style="margin-top:10px;border-left-color:var(--accent)">
          <div class="t1">“${esc(line)}”${(r.aliases_used || []).length ? ` · business term ${r.aliases_used.map((x) => `<code>${esc(x)}</code>`).join(", ")} recognised` : ""}</div>
          <div><strong>${esc(r.interpretation || r.rule.name)}</strong> <code>${esc(r.rule.type)}</code> ${pill(r.rule.severity)} ${pill(SET_PILL[r.rule.category] || "", RULE_SETS[r.rule.category] || "")}</div>
          <div class="sub" id="dr-out-${i}">${dryHtml(r.dry_run)}</div>
          <div class="btns" style="margin-top:6px"><button class="btn sm primary" id="dr-save-${i}" onclick="Studio.saveDraft(this, ${i})">Save as draft</button>
            <button class="btn sm" onclick="Studio.redry(this, ${i})">Dry run again</button><span class="sub" id="dr-note-${i}">Not saved yet (${esc(r.parser)} parser)</span></div></div>`);
      } catch (e) {
        cards.push(`<div class="approval" style="margin-top:10px;border-left-color:var(--bad)"><div class="t1">“${esc(line)}”</div>
          <div class="sub" style="color:var(--bad)">${esc(e.message)}</div></div>`);
      }
    }
    const ok = Object.keys(Studio.drafts).length;
    out.innerHTML = cards.join("") + (ok > 1 ? `<div class="btns" style="margin-top:10px"><button class="btn primary" onclick="Studio.saveAll(this)">Save all ${ok} as drafts</button></div>` : "");
    btn.disabled = false;
  },
  async redry(btn, i) {
    const d = Studio.drafts[i], out = $("#dr-out-" + i);
    btn.disabled = true;
    out.innerHTML = "Running on the platform…";
    try { out.innerHTML = dryHtml(await post("/rules/dry-run", { asset_id: d.asset_id, ...ruleBody(d.rule) })); }
    catch (e) { out.innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span>`; }
    btn.disabled = false;
  },
  async saveOne(i) {
    const d = Studio.drafts[i];
    if (!d || d.saved) return;
    const r = d.rule;
    await post("/rules", { asset_id: d.asset_id, name: r.name, type: r.type, column: r.column, params: r.params, severity: r.severity, threshold: r.threshold,
      dimension: r.dimension, description: r.description, category: r.category, source: r.source || "nl", status: "proposed" });
    d.saved = true;
    const btn = $("#dr-save-" + i);
    if (btn) { btn.disabled = true; btn.textContent = "Saved"; }
    const note = $("#dr-note-" + i);
    if (note) note.innerHTML = 'Saved as a draft. Send it for approval in <a href="#/rules/saved">Saved rules</a>.';
  },
  async saveDraft(btn, i) {
    btn.disabled = true;
    try { await Studio.saveOne(i); toastOk("Saved as a draft. Send it for approval in Saved rules."); }
    catch (e) { btn.disabled = false; toastError(e.message); }
  },
  async saveAll(btn) {
    btn.disabled = true;
    let n = 0;
    for (const i of Object.keys(Studio.drafts)) {
      try { if (!Studio.drafts[i].saved) { await Studio.saveOne(i); n++; } } catch (e) { toastError(e.message); }
    }
    toastOk(`${n} rule${n === 1 ? "" : "s"} saved as drafts. Send them for approval in Saved rules.`);
  },
  /* Manual rule builder: Dry run (on the platform) or Save as draft. There is no way to go live from here. */
  async manual(btn, mode) {
    let params = {};
    try { params = JSON.parse($("#m-params").value || "{}"); } catch (e) { return toast("Params must be valid JSON"); }
    const body = { asset_id: Number($("#m-asset").value), type: $("#m-type").value, column: $("#m-col").value || null, params,
      severity: $("#m-sev").value, threshold: $("#m-thr").value ? Number($("#m-thr").value) : null, status: "proposed" };
    btn.disabled = true;
    try {
      if (mode === "dry") {
        $("#m-out").innerHTML = '<div class="sub" style="margin-top:8px">Running on the platform…</div>';
        $("#m-out").innerHTML = `<div class="sub" style="margin-top:8px">${dryHtml(await post("/rules/dry-run", body))}</div>`;
      } else {
        const set = $("#m-set") ? $("#m-set").value : "";
        await post("/rules", { ...body, ...(set ? { category: set } : {}) });
        toastOk("Saved as a draft. Send it for approval in Saved rules.");
        await render(true);
      }
    } catch (e) { $("#m-out").innerHTML = `<div class="callout bad" style="margin-top:8px">${esc(e.message)}</div>`; }
    btn.disabled = false;
  },
};

/* Rule export panel: preview, copy, download one format, or a zip of every format. */
const Exporter = {
  st: { fmt: "dqx", asset: null, proposed: false, ids: null },
  ctx: { fixedId: null, assets: [] },
  code: "",
  open(assets, ids) {  // the export panel in a pop-up (AI Rule Studio > Rule catalog); ids = only the rules picked in the table
    Exporter.st.ids = ids && ids.length ? ids.slice() : null;
    Modal.open(`${Modal.head("Export rules", "Run these rules in the tool your team already uses")}
      <div class="modal-body">${Exporter.panel(null, assets, { bare: true })}</div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Close</button></div>`, { size: "xl" });
  },
  panel(fixedId, assets, opts = {}) {
    this.ctx = { fixedId, assets, opts };
    if (fixedId) this.st.ids = null;  // a dataset's own export panel never carries the catalog selection
    const fmts = State.meta?.export_formats || {};
    if (fixedId) this.st.asset = String(fixedId);
    else if (this.st.asset == null || (this.st.asset !== "all" && !assets.some((x) => String(x.id) === this.st.asset)))
      this.st.asset = String(State.studioAsset || (assets[0] && assets[0].id) || "all");
    const f = fmts[this.st.fmt] || {};
    const picked = this.st.ids && this.st.ids.length;
    const all = !picked && this.st.asset === "all";
    setTimeout(() => this.preview(), 0);
    const groups = {};
    Object.entries(fmts).forEach(([k, x]) => (groups[x.group || "Other"] = groups[x.group || "Other"] || []).push([k, x]));
    return `<div ${opts.bare ? 'class="xpanel"' : 'class="card"'} id="exporter">${opts.bare ? "" : `<div class="row"><h2 style="margin:0">Export rules</h2>
      <span class="sub">Run these rules in the tool your team already uses</span></div>`}
      <div class="xbar">
        ${picked ? `<span class="sub" style="align-self:center"><strong>${picked}</strong> rule${picked === 1 ? "" : "s"} selected in the Rule catalog.
          <a onclick="Exporter.set('ids', null)">Export a whole dataset instead</a></span>` : ""}
        ${fixedId || picked ? "" : `<label class="f">Dataset<select onchange="Exporter.set('asset', this.value)"><option value="all" ${all ? "selected" : ""}>All datasets</option>
          ${assets.map((x) => `<option value="${x.id}" ${String(x.id) === this.st.asset ? "selected" : ""}>${esc(x.fqn)}</option>`).join("")}</select></label>`}
        <label class="f">Format<select onchange="Exporter.set('fmt', this.value)">${Object.entries(groups).map(([g, items]) =>
          `<optgroup label="${esc(g)}">${items.map(([k, x]) => `<option value="${k}" ${k === this.st.fmt ? "selected" : ""}>${esc(x.label)}</option>`).join("")}</optgroup>`).join("")}</select></label>
        ${picked ? "" : `<label class="row sub xcheck"><input type="checkbox" ${this.st.proposed ? "checked" : ""} onchange="Exporter.set('proposed', this.checked)">Include drafts</label>`}
        <span class="grow"></span>
        <div class="btns">${all ? "" : `<button class="btn" onclick="Exporter.copy()">Copy</button>`}
          <button class="btn" onclick="Exporter.download()">Download .${esc(all ? "zip" : f.ext || "txt")}</button>
          <button class="btn primary" onclick="Exporter.zip()">All formats (.zip)</button></div>
      </div>
      <div class="sub xdesc">${esc(f.desc || "")}. Rules a format can't express are listed, never dropped silently.</div>
      <div id="x-out"></div></div>`;
  },
  set(k, v) {
    this.st[k] = k === "asset" ? String(v) : v;
    if (k === "ids") this.st.ids = null;
    const el = $("#exporter");
    if (el) el.outerHTML = this.panel(this.ctx.fixedId, this.ctx.assets, this.ctx.opts || {});
  },
  q() { return this.st.ids && this.st.ids.length ? `rule_ids=${this.st.ids.join(",")}` : `include_proposed=${this.st.proposed}`; },
  async preview() {
    const out = $("#x-out");
    if (!out) return;
    if (this.st.ids && this.st.ids.length) {
      try {
        const r = await api(`/rules/export?target=${this.st.fmt}&${this.q()}`);
        if (r.multi) { out.innerHTML = `<p class="sub" style="margin-top:10px">The ${r.rules} selected rules are in ${r.datasets} datasets, so the download is a zip with one folder per dataset. Preview shows one dataset at a time.</p>`; return; }
        this.code = r.code;
        out.innerHTML = `<div class="sub" style="margin-top:10px">${r.rules} selected rule(s) exported to ${esc(r.label)} as <code>${esc(r.filename)}</code>.
          ${r.skipped.length ? `<span class="pill warn">${r.skipped.length} not expressible</span> ${esc(r.skipped.join(", "))}` : `<span class="pill ok">all selected rules exported</span>`}</div>
          <pre class="xpre"><code>${esc(r.code)}</code></pre>`;
      } catch (e) { out.innerHTML = `<div class="callout bad" style="margin-top:10px">${esc(e.message)}</div>`; }
      return;
    }
    if (this.st.asset === "all") {
      out.innerHTML = '<p class="sub">Preview shows one dataset at a time. Downloads include every dataset that has rules, one folder per dataset.</p>';
      return;
    }
    try {
      const r = await api(`/rules/export?asset_id=${this.st.asset}&target=${this.st.fmt}&${this.q()}`);
      this.code = r.code;
      out.innerHTML = `<div class="sub" style="margin-top:10px">${r.rules} rule(s) exported to ${esc(r.label)} as <code>${esc(r.filename)}</code>.
        ${r.skipped.length ? `<span class="pill warn">${r.skipped.length} not expressible</span> ${esc(r.skipped.join(", "))}` : `<span class="pill ok">all rules exported</span>`}
        ${r.proposed_excluded ? `<br>${r.proposed_excluded} proposed rule${r.proposed_excluded === 1 ? " isn't" : "s aren't"} included. <a onclick="Exporter.set('proposed', true)">Include proposed</a>` : ""}</div>
        <pre class="xpre"><code>${esc(r.code)}</code></pre>`;
    } catch (e) { out.innerHTML = `<div class="callout bad" style="margin-top:10px">${esc(e.message)}</div>`; }
  },
  async copy() {
    try { await navigator.clipboard.writeText(this.code); toast("Copied"); } catch (e) { toast("Copy isn't available here; use Download"); }
  },
  download() {
    if (this.st.ids && this.st.ids.length) { location.href = `/api/rules/export?target=${this.st.fmt}&download=true&${this.q()}`; return; }
    location.href = this.st.asset === "all"
      ? `/api/rules/export/bundle?formats=${this.st.fmt}&${this.q()}`
      : `/api/rules/export?asset_id=${this.st.asset}&target=${this.st.fmt}&download=true&${this.q()}`;
  },
  zip() {
    if (this.st.ids && this.st.ids.length) { location.href = `/api/rules/export/bundle?${this.q()}`; return; }
    location.href = `/api/rules/export/bundle?${this.st.asset === "all" ? "" : "asset_id=" + this.st.asset + "&"}${this.q()}`;
  },
};

const Catalog = {
  st: { scope: "asset", set: "", status: "", severity: "", dimension: "" },
  sel: new Set(),
  ids: [],
  set(k, v) { Catalog.st[k] = v; Catalog.sel.clear(); render(true); },
  pick(id, on) { if (on) Catalog.sel.add(id); else Catalog.sel.delete(id); render(true); },
  all(on) { Catalog.sel = new Set(on ? Catalog.ids : []); render(true); },
  assets: [],
  async html(asset, assets = []) {
    const st = Catalog.st;
    Catalog.assets = assets;
    Catalog.asset = asset;
    const status = st.status === "" ? "active,disabled" : st.status === "all" ? "" : st.status;  // saved rules have their own tab
    const q = new URLSearchParams({ ...platformQ(), ...(st.scope === "asset" && asset ? { asset_id: asset.id } : {}), ...(st.set ? { category: st.set } : {}), ...(status ? { status } : {}),
      ...(st.severity ? { severity: st.severity } : {}), ...(st.dimension ? { dimension: st.dimension } : {}) });
    const [rules, proposedAll] = await Promise.all([api("/rules?" + q), api("/rules?status=proposed,rejected")]);
    Catalog.ids = rules.map((r) => r.id);
    Catalog.sel = new Set([...Catalog.sel].filter((id) => Catalog.ids.includes(id)));
    const selF = (k, opts) => `<select onchange="Catalog.set('${k}', this.value)" aria-label="${k}">${opts.map(([v, l]) => `<option value="${v}" ${st[k] === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
    return `<div class="card wrap" id="catalog"><div class="row" style="flex-wrap:wrap;gap:8px"><h2 style="margin:0">Rules catalog</h2>${RuleTable.setCounts(rules)}<span style="flex:1"></span>
      ${selF("scope", [["asset", "This dataset"], ["all", "All datasets"]])}
      ${selF("set", [["", "All sets"], ...Object.entries(RULE_SETS)])}
      ${selF("status", [["", "Active and disabled"], ["active", "Active"], ["disabled", "Disabled"], ["all", "All, including saved"]])}
      ${selF("severity", [["", "All severities"], ...["critical", "high", "medium", "low"].map((x) => [x, x])])}
      ${selF("dimension", [["", "All dimensions"], ...(State.meta?.dimensions || []).map((x) => [x, x])])}
      ${assets.length ? `<button class="btn" ${Catalog.sel.size ? "" : "disabled"} title="${Catalog.sel.size ? "" : "Tick the rules to export first"}" onclick="Exporter.open(Catalog.assets, [...Catalog.sel])">Export selected${Catalog.sel.size ? " (" + Catalog.sel.size + ")" : ""}</button>
        <button class="btn" onclick="Exporter.open(Catalog.assets)">Export a whole dataset</button>` : ""}
      <button class="btn" onclick="RuleFiles.download()" title="Rules as YAML files: one file for this dataset, or a zip with a file per dataset">Download rule files</button>
      ${iAmViewer() ? "" : `<button class="btn" onclick="RuleFiles.open()" title="Read rule files and save them as drafts for review">Import rule files…</button>`}
      ${gitOn() && !iAmViewer() ? `<button class="btn" onclick="Git.exportOpen()" title="Write the rule files to your GitHub repository">Export to Git…</button>` : ""}</div>
      ${proposedAll.length ? `<p class="sub" style="margin:6px 0 0">${proposedAll.length} saved draft${proposedAll.length === 1 ? "" : "s"} not live yet.
        <a href="#/rules/saved">Send them for approval in Saved rules</a></p>` : ""}
      <div style="margin-top:8px">${RuleTable.render(rules, { showAsset: st.scope === "all", select: true })}</div>
      <p class="sub" style="margin:8px 0 0">Tick rules to <strong>Export selected</strong>: only those go into the export, whatever their status. Administrators can change a live rule's severity in the table and use <strong>Edit</strong> for anything else; every change keeps a version history.</p></div>`;
  },
};

/* Rules as files: download rule files (YAML, one per dataset) and import them back as drafts. Works without any repository. */
const RuleFiles = {
  files: [],
  download() {
    const a = Catalog.st.scope === "asset" && Catalog.asset ? Catalog.asset : null;
    location.href = "/api/rules/files/download" + (a ? "?asset_id=" + a.id : "");
  },
  open() {
    RuleFiles.files = [];
    Modal.open(`${Modal.head("Import rule files", "YAML files from Download rule files, edited by hand, or kept in a repository. Nothing is saved until you confirm, and everything arrives as drafts.")}
      <div class="modal-body">
        <input type="file" id="rf-files" multiple accept=".yaml,.yml,.zip" onchange="RuleFiles.preview()">
        <p class="sub" style="margin:6px 0 0">One or more .yaml files, or a .zip of them. A rule is matched by its key (type, column and name). A live rule is never changed: a different version arrives as a new draft to approve. Nothing is deleted.</p>
        <div id="rf-out" style="margin-top:12px"></div>
      </div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Close</button><button class="btn primary" id="rf-save" disabled onclick="RuleFiles.apply(this)">Save as drafts</button></div>`, { wide: true });
  },
  async body() {
    const input = $("#rf-files"), files = [];
    let zip = null;
    for (const f of input.files) {
      if (/\.zip$/i.test(f.name)) {
        const buf = new Uint8Array(await f.arrayBuffer());
        let bin = "";
        for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
        zip = btoa(bin);
      } else files.push({ name: f.name, text: await f.text() });
    }
    return { files, zip_b64: zip };
  },
  async preview() {
    const out = $("#rf-out"), save = $("#rf-save");
    save.disabled = true;
    if (!$("#rf-files").files.length) { out.innerHTML = ""; return; }
    out.innerHTML = '<span class="sub">Reading…</span>';
    try {
      const p = await post("/rules/files/preview", await RuleFiles.body());
      const t = p.totals, tone = { new: "ok", update_draft: "info", propose_change: "warn", unchanged: "muted", invalid: "bad" };
      const label = { new: "new draft", update_draft: "updates a draft", propose_change: "proposes a change", unchanged: "no change", invalid: "invalid" };
      const chg = (c) => c.map((x) => `${esc(x.field)}: ${esc(JSON.stringify(x.from))} → ${esc(JSON.stringify(x.to))}`).join("; ");
      out.innerHTML = `<p style="margin:0 0 8px"><strong>${t.datasets}</strong> dataset(s): ${t.new} new, ${t.update_draft} draft update(s), ${t.propose_change} proposed change(s), ${t.unchanged} unchanged${t.invalid ? `, <span style="color:var(--bad)">${t.invalid} invalid</span>` : ""}${t.not_in_file ? `, ${t.not_in_file} in the app but not in the files` : ""}.</p>
        ${p.errors.map((e) => `<div class="callout bad" style="margin-bottom:6px">${esc(e)}</div>`).join("")}
        ${p.datasets.map((d) => `<div class="card" style="margin-bottom:8px"><strong>${esc(d.dataset)}</strong> <span class="sub">${esc(d.file)}</span>
          <table class="t" style="margin-top:6px">${d.items.filter((i) => i.action !== "unchanged").map((i) => `<tr><td style="width:150px">${pill(tone[i.action], label[i.action])}</td><td>${esc(i.name)}${i.column ? ` <span class="mono sub">${esc(i.column)}</span>` : ""}</td>
            <td class="sub">${i.detail ? esc(i.detail) : i.changes ? chg(i.changes) : ""}${i.action === "propose_change" ? ` (live rule #${i.rule_id} stays as it is)` : ""}</td></tr>`).join("") || '<tr><td class="sub">Nothing to change in this file.</td></tr>'}
          ${d.not_in_file.map((m) => `<tr><td>${pill("muted", "not in file")}</td><td>${esc(m.name)}</td><td class="sub">${esc(m.status)} in the app; it is left as it is</td></tr>`).join("")}</table></div>`).join("")}`;
      save.disabled = !p.will_save || !!t.invalid || !!p.errors.length;
      save.textContent = t.invalid || p.errors.length ? "Fix the errors first" : p.will_save ? `Save ${p.will_save} draft${p.will_save === 1 ? "" : "s"}` : "Nothing to save";
      if (t.invalid || p.errors.length) out.insertAdjacentHTML("beforeend", '<p class="sub">Fix the problems above, then choose the files again. Nothing is saved while any file or rule is invalid.</p>');
    } catch (e) { out.innerHTML = `<div class="callout bad">${esc(e.message)}</div>`; }
  },
  async apply(btn) {
    btn.disabled = true;
    try {
      const r = await post("/rules/files/apply", await RuleFiles.body());
      Modal.close();
      toastOk(`${r.created.length} new draft(s)${r.updated.length ? `, ${r.updated.length} updated` : ""}. Send them for approval in Saved rules.`);
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
};

/* Operate > Runs: run rules now, schedule rule sets, and watch their runs. */
const RUN_STATUS = { ok: ["ok", "passed"], failures: ["bad", "failures"], error: ["warn", "errors"], empty: ["muted", "nothing ran"] };
const RUN_TRIGGERS = { manual: "Run now", schedule: "Schedule", agent: "Agent", refresh: "Insights refresh", "auto-correct": "Re-check after auto-correct",
  correction: "Re-check after a fix", cli: "Command line", demo: "Demo seed" };
const CADENCE_CHOICES = [["15", "Every 15 minutes"], ["30", "Every 30 minutes"], ["60", "Every hour"], ["120", "Every 2 hours"], ["360", "Every 6 hours"],
  ["720", "Every 12 hours"], ["1440", "Every 24 hours"], ["daily", "At a time of day…"]];
const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const RUN_SETS = [["", "All rule sets"], ...Object.entries(RULE_SETS)];
const SEV_FLOORS = [["", "Any severity"], ["critical", "Critical only"], ["high", "High and above"], ["medium", "Medium and above"]];
const Runs = {
  st: { days: 7, trigger: "", status: "", asset: "", schedule: null },
  scope: { category: "", severity: "", which: "all", platform: "" },
  data: null,
  scopeBody(asset) {
    const s = Runs.scope;
    return { category: s.category || null, severity: s.severity || null, platform: State.platform || null,
      asset_ids: s.which === "current" && asset ? [asset.id] : [] };
  },
  sel(k, items, obj, onchange, label) {
    return `<select class="sel-sm" aria-label="${esc(label || k)}" onchange="${onchange}">${items.map(([v, l]) =>
      `<option value="${esc(v)}" ${String(obj[k] ?? "") === String(v) ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
  },
  async html(asset, assets) {
    const st = Runs.st;
    const q = new URLSearchParams({ days: st.days, ...(st.trigger ? { trigger: st.trigger } : {}), ...(st.status ? { status: st.status } : {}),
      ...(st.schedule ? { schedule_id: st.schedule } : {}), ...(st.asset === "current" && asset ? { asset_id: asset.id } : {}) });
    const [r, sc, platforms, pv] = await Promise.all([api("/runs?" + q), api("/schedules"), connectedPlatforms(),
      post("/rules/run/preview", { scope: Runs.scopeBody(asset) }).catch(() => null)]);
    Runs.data = { asset, assets, schedules: sc.schedules, platforms };
    const t = r.stats, win = `last ${r.days === 1 ? "24 hours" : r.days + " days"}`;
    const next = sc.schedules.filter((s) => s.enabled && s.next_run).sort((a, b) => a.next_run.localeCompare(b.next_run))[0];
    const plats = [["", "All connected platforms"], ...platforms.map((p) => [p, PLATFORMS[p] || p])];
    const which = [["all", "All datasets"], ...(asset ? [["current", short(asset.fqn) + " only"]] : [])];
    const histWhich = [["", "All datasets"], ...(asset ? [["current", short(asset.fqn) + " only"]] : [])];
    const bg = sc.background;
    const schedName = st.schedule ? (sc.schedules.find((s) => s.id === st.schedule) || {}).name : null;
    return `<div class="grid g4">
      ${Ov.tile("info", "Runs", Viz.num(t.runs), `${win} · ${t.datasets} dataset(s)`)}
      ${Ov.tile(t.failed ? "bad" : "ok", "Checks run", Viz.num(t.checks), `${Viz.num(t.failed)} failed, ${win}`)}
      ${Ov.tile(t.errors ? "warn" : "ok", "Checks that errored", Viz.num(t.errors), "could not run: SQL or connection error")}
      ${Ov.tile("info", "Next scheduled run", next ? ts(next.next_run) : "-", next ? next.name : "no schedule enabled")}</div><div class="sp"></div>
    <div class="grid g2">
      <div class="card"><h2>Run rules now</h2>
        <div class="ov-filters" style="margin:8px 0">
          ${Runs.sel("category", RUN_SETS, Runs.scope, "Runs.setScope('category', this.value)", "Rule set")}
          ${Runs.sel("severity", SEV_FLOORS, Runs.scope, "Runs.setScope('severity', this.value)", "Severity")}
          ${Runs.sel("which", which, Runs.scope, "Runs.setScope('which', this.value)", "Datasets")}
</div>
        <div id="rn-preview">${Runs.previewHtml(pv)}</div>
        <div class="btns" style="margin-top:10px"><button class="btn primary" id="rn-go" ${pv && pv.rules ? "" : "disabled"} onclick="Runs.runNow(this)">Run now</button>
          <button class="btn" onclick="Runs.edit(null, true)">Save as schedule…</button></div></div>
      ${Viz.card({ id: "rundays", title: "Checks per day", sub: win,
        chart: Viz.lines("rundays", r.by_day, [{ key: "passed", label: "Passed", color: "var(--viz-3)" }, { key: "failed", label: "Failed", color: "var(--viz-2)" },
          { key: "errors", label: "Errored", color: "var(--viz-1)" }], { label: "Checks per day by outcome", empty: "No runs in this window" }),
        table: Viz.table(["Day", "Runs", "Passed", "Failed", "Errored"], r.by_day.filter((d) => d.runs).map((d) => [d.date, d.runs, d.passed, d.failed, d.errors])) })}
    </div><div class="sp"></div>
    <div class="card"><div class="row"><h2 style="margin:0">Schedules</h2><span class="sub">${sc.schedules.length} schedule(s). Cadence times are UTC; next and last run show your local time</span><span style="flex:1"></span>
      <button class="btn sm primary" onclick="Runs.edit(null)">New schedule</button></div>
      ${bg.enabled ? `<p class="sub" style="margin:8px 0 0">The background scheduler looks for due work every ${Math.max(1, Math.round((bg.tick_seconds || 300) / 60))} minute(s). Rules in an enabled schedule follow it;
        other active rules run every ${bg.default_interval_minutes || 60} minutes. Scheduled runs share a daily budget of ${Viz.num(Math.round((bg.daily_budget_seconds || 3600) / 60))} compute minutes.</p>`
        : `<div class="callout bad" style="margin-top:10px">The background scheduler is off (<code>scheduler.enabled: false</code> in <code>config.yaml</code>), so schedules only run when you click <strong>Run now</strong>.
          Turn it on and restart the app to run them on time.</div>`}
      <div class="wrap" style="margin-top:10px"><table class="t"><tr><th>Name</th><th>What runs</th><th>When</th><th>Next run</th><th>Last run</th><th>On</th><th></th></tr>
      ${sc.schedules.map((s) => {
        const [cls, lbl] = RUN_STATUS[s.last_status] || ["muted", "never run"];
        const ls = s.last_summary;
        return `<tr><td><strong>${esc(s.name)}</strong></td>
          <td class="sub">${esc(s.scope_text)}<br>${s.rules} rule(s) on ${s.datasets} dataset(s)${s.skipped.length ? ` · <span title="${esc(s.skipped.map((x) => x.fqn + ": " + x.reason).join("\n"))}">${s.skipped.length} skipped</span>` : ""}</td>
          <td>${esc(s.cadence_text)}</td><td>${s.enabled && s.next_run ? ts(s.next_run) : '<span class="muted">paused</span>'}</td>
          <td>${s.last_run ? `${ts(s.last_run)} ${pill(cls, lbl)}${ls ? `<div class="sub">${ls.checks} checks, ${ls.failed} failed${ls.errors ? `, ${ls.errors} errored` : ""}</div>` : ""}` : pill(cls, lbl)}</td>
          <td><label class="switch"><input type="checkbox" ${s.enabled ? "checked" : ""} onchange="Runs.toggle(this, ${s.id})" aria-label="Enable ${esc(s.name)}"></label></td>
          <td><div class="btns"><button class="btn sm" onclick="Runs.runSchedule(this, ${s.id})">Run now</button><button class="btn sm" onclick="Runs.edit(${s.id})">Edit</button>
            <button class="btn sm" onclick="Runs.filterBy(${s.id})" title="Show this schedule's runs">Runs</button><button class="btn sm danger" onclick="Runs.remove(${s.id})">Delete</button></div></td></tr>`;
      }).join("") || '<tr><td colspan="7" class="empty">No schedules yet. Pick rules under Run rules now and click <strong>Save as schedule…</strong>, or use <strong>New schedule</strong>.</td></tr>'}</table></div></div>
    <div class="sp"></div>
    <div class="card" id="run-history"><div class="row" style="flex-wrap:wrap"><h2 style="margin:0">Run history</h2><span class="sub">${t.runs} run(s), ${win}${schedName ? `, schedule ${esc(schedName)}` : ""}${r.truncated ? ", newest 200 shown" : ""}</span><span style="flex:1"></span>
      <div class="ov-filters">
        ${Runs.sel("days", [["1", "Last 24 hours"], ["7", "Last 7 days"], ["30", "Last 30 days"], ["90", "Last 90 days"]], st, "Runs.set('days', this.value)", "Time window")}
        ${Runs.sel("trigger", [["", "Started by anything"], ...Object.keys(RUN_TRIGGERS).filter((k) => k === st.trigger || r.triggers.includes(k)).map((k) => [k, RUN_TRIGGERS[k]])], st, "Runs.set('trigger', this.value)", "Started by")}
        ${Runs.sel("status", [["", "Any outcome"], ["ok", "Passed"], ["failures", "With failures"], ["error", "With errors"]], st, "Runs.set('status', this.value)", "Outcome")}
        ${Runs.sel("asset", histWhich, st, "Runs.set('asset', this.value)", "Dataset")}
        ${st.schedule ? '<button class="btn sm" onclick="Runs.filterBy(null)">Clear schedule filter</button>' : ""}</div></div>
      <div class="wrap" style="margin-top:10px"><table class="t runs"><tr><th>When</th><th>Dataset</th><th>Started by</th><th class="num">Checks</th><th class="num">Failed</th><th class="num">Errored</th><th class="num">Seconds</th><th>Outcome</th></tr>
      ${r.runs.map((x) => {
        const [cls, lbl] = RUN_STATUS[x.status] || ["muted", x.status];
        return `<tr class="clickable" tabindex="0" onclick="Runs.open(this, ${x.id})" onkeydown="if(event.key==='Enter')Runs.open(this, ${x.id})" title="Show the checks in this run">
          <td>${ts(x.ts)}</td><td><a href="#/asset/${x.asset_id}" onclick="event.stopPropagation()">${esc(short(x.fqn))}</a></td>
          <td>${esc(x.schedule ? "Schedule: " + x.schedule : x.trigger_label)}${x.actor && !x.schedule && x.trigger === "manual" ? `<div class="sub">${esc(x.actor)}</div>` : ""}</td>
          <td class="num">${x.checks}</td><td class="num">${x.failed ? `<span class="score lo">${x.failed}</span>` : 0}</td><td class="num">${x.errors || 0}</td>
          <td class="num">${x.duration_s < 10 ? Number(x.duration_s).toFixed(2) : Viz.num(x.duration_s)}</td><td>${pill(cls, lbl)}</td></tr>`;
      }).join("") || '<tr><td colspan="8" class="empty">No runs match</td></tr>'}</table></div>
      <p class="sub" style="font-size:11.5px">Click a run to see each check's result.</p></div>`;
  },
  previewHtml(pv) {
    if (!pv) return '<div class="empty">Could not work out which rules match.</div>';
    if (!pv.rules) return `<div class="callout">No active rules match: ${esc(pv.text)}. Activate rules in <a href="#/rules/saved">Saved rules</a>, or widen the selection.</div>`;
    return `<p class="sub" style="margin:0">Runs <strong>${pv.rules}</strong> active rule(s) on <strong>${pv.datasets}</strong> dataset(s)
      (${pv.est_seconds < 1 ? "under a second" : "about " + Viz.num(Math.round(pv.est_seconds)) + " s"}, judging by recent runs).${pv.skipped.length ? ` ${pv.skipped.length} dataset(s) skipped: ${esc(pv.skipped.map((x) => short(x.fqn) + " (" + x.reason + ")").join(", "))}.` : ""}</p>`;
  },
  async setScope(k, v) {
    Runs.scope[k] = v;
    const pv = await post("/rules/run/preview", { scope: Runs.scopeBody(Runs.data.asset) }).catch(() => null);
    $("#rn-preview").innerHTML = Runs.previewHtml(pv);
    $("#rn-go").disabled = !(pv && pv.rules);
  },
  set(k, v) { Runs.st[k] = k === "days" ? Number(v) : v; render(true); },
  filterBy(id) {
    Runs.st.schedule = id;
    if (id) Runs.st.trigger = "";
    render(true).then(() => { if (id) { const h = $("#run-history"); if (h) h.scrollIntoView({ block: "start" }); } });
  },
  async runNow(btn) {
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = "Running…";
    try {
      const r = await post("/rules/run", { scope: Runs.scopeBody(Runs.data.asset) });
      const msg = `Ran ${r.checks} checks on ${r.datasets} dataset(s): ${r.failed} failed${r.errors ? `, ${r.errors} errored` : ""}${r.incidents ? `, ${r.incidents} incident(s) opened or updated` : ""}.`;
      (r.failures.length || r.errors ? toastWarn : toastOk)(msg + (r.failures.length ? "\n" + r.failures.map((f) => short(f.fqn) + ": " + f.error).join("\n") : ""));
      Object.assign(Runs.st, { trigger: "", status: "", schedule: null });
      await render(true);
    } catch (e) { toastError(e.message); } finally { btn.disabled = false; btn.textContent = label; }
  },
  async runSchedule(btn, id) {
    btn.disabled = true;
    try {
      const r = await post(`/schedules/${id}/run`);
      (r.status === "error" ? toastWarn : toastOk)(`${r.name}: ${r.checks} checks on ${r.datasets} dataset(s), ${r.failed} failed${r.errors ? `, ${r.errors} errored` : ""}.`);
      await render(true);
    } catch (e) { toastError(e.message); } finally { btn.disabled = false; }
  },
  async toggle(input, id) {
    input.disabled = true;
    try { await patch(`/schedules/${id}`, { enabled: input.checked }); toastOk(input.checked ? "Schedule on" : "Schedule paused"); await render(true); }
    catch (e) { input.checked = !input.checked; toastError(e.message); } finally { input.disabled = false; }
  },
  remove(id) {
    const s = (Runs.data.schedules || []).find((x) => x.id === id);
    Modal.open(`${Modal.head("Delete schedule", esc(s ? s.name : ""))}<div class="modal-body"><p>The rules stay active and go back to the default interval. Past runs stay in the history.</p></div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn danger" onclick="Runs.doRemove(this, ${id})">Delete schedule</button></div>`);
  },
  async doRemove(btn, id) {
    btn.disabled = true;
    try { await api(`/schedules/${id}`, { method: "DELETE" }); Modal.close(); toastOk("Schedule deleted"); await render(true); }
    catch (e) { btn.disabled = false; toastError(e.message); }
  },
  async open(tr, id) {
    const nxt = tr.nextElementSibling;
    if (nxt && nxt.classList.contains("run-detail")) { nxt.remove(); return; }
    const row = document.createElement("tr");
    row.className = "run-detail";
    row.innerHTML = '<td colspan="8"><div class="sub">Loading…</div></td>';
    tr.after(row);
    try {
      const d = await api("/runs/" + id);
      const tone = { pass: "ok", fail: "bad", warn: "warn", error: "warn" };
      row.firstElementChild.innerHTML = `<table class="t inner"><tr><th>Rule</th><th>Severity</th><th>Dimension</th><th>Result</th><th class="num">Pass rate</th><th class="num">Failing rows</th><th>Message</th></tr>
        ${d.checks.map((c) => `<tr><td>${esc(c.rule)}</td><td>${c.severity ? pill(c.severity) : ""}</td><td>${esc(c.dimension || "")}</td><td>${pill(tone[c.status] || "muted", c.status)}</td>
          <td class="num">${pct(c.pass_rate)}</td><td class="num">${c.failed != null ? Number(c.failed).toLocaleString() : ""}</td><td class="sub">${esc((c.message || "").slice(0, 220))}</td></tr>`).join("")
          || '<tr><td colspan="7" class="empty">No checks recorded</td></tr>'}</table>`;
    } catch (e) { row.firstElementChild.innerHTML = `<div class="callout bad">${esc(e.message)}</div>`; }
  },
  /* create or edit a schedule; fromScope pre-fills it from the "Run rules now" picks */
  edit(id, fromScope) {
    const d = Runs.data, assets = d.assets || [];
    const s = id ? d.schedules.find((x) => x.id === id) : null;
    const sc = s ? s.scope : fromScope ? Runs.scopeBody(d.asset) : { category: null, severity: null, platform: null, asset_ids: [] };
    const cad = s ? (s.cadence === "daily" ? "daily" : String(s.every_minutes)) : "60";
    const days = new Set(s ? s.weekdays : []);
    const opt = (v, l, cur) => `<option value="${esc(v)}" ${String(cur ?? "") === String(v) ? "selected" : ""}>${esc(l)}</option>`;
    const ids = new Set(sc.asset_ids || []);
    const suggested = s ? s.name : fromScope ? [RUN_SETS.find(([v]) => v === (sc.category || ""))[1], sc.asset_ids.length === 1 && d.asset ? "on " + short(d.asset.fqn) : ""].filter(Boolean).join(" ") : "";
    Modal.open(`${Modal.head(s ? "Edit schedule" : "New schedule", "Runs the matching active rules on a cadence. Times are UTC.")}
      <div class="modal-body">
        <label class="f">Name<input id="sc-name" value="${esc(suggested)}" placeholder="e.g. Core checks every morning" autofocus></label>
        <div class="grid g2" style="margin-top:10px">
          <label class="f">Rule set<select id="sc-set">${RUN_SETS.map(([v, l]) => opt(v, l, sc.category)).join("")}</select></label>
          <label class="f">Severity<select id="sc-sev">${SEV_FLOORS.map(([v, l]) => opt(v, l, sc.severity)).join("")}</select></label>
          ${d.platforms.length > 1 ? `<label class="f">Platform<select id="sc-plat">${opt("", "All connected platforms", sc.platform)}${d.platforms.map((p) => opt(p, PLATFORMS[p] || p, sc.platform)).join("")}</select></label>` : ""}
          <label class="f">Datasets<select id="sc-assets" multiple size="5" aria-describedby="sc-assets-help">${assets.map((a) => `<option value="${a.id}" ${ids.has(a.id) ? "selected" : ""}>${esc(a.fqn)}</option>`).join("")}</select>
            <span class="sub" id="sc-assets-help" style="font-weight:400">None selected means every dataset. Ctrl-click to pick several.</span></label>
        </div>
        <div class="grid g2" style="margin-top:10px">
          <label class="f">When<select id="sc-cad" onchange="Runs.cadSync()">${CADENCE_CHOICES.map(([v, l]) => opt(v, l, cad)).join("")}</select></label>
          <label class="f" id="sc-time-wrap">Time of day (UTC)<input id="sc-time" type="time" value="${esc(s && s.at_time ? s.at_time : "06:00")}"></label>
        </div>
        <div id="sc-days-wrap" style="margin-top:8px"><span class="sub">On these days (none ticked means every day):</span>
          <div class="btns" style="margin-top:4px">${WEEKDAYS.map((w, i) => `<label class="row sub" style="gap:4px"><input type="checkbox" class="sc-day" value="${i}" ${days.has(i) ? "checked" : ""}> ${w}</label>`).join("")}</div></div>
        <label class="row sub" style="gap:8px;margin-top:12px"><input type="checkbox" id="sc-on" ${!s || s.enabled ? "checked" : ""}> Enabled</label>
      </div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn primary" onclick="Runs.save(this, ${id || "null"})">${s ? "Save changes" : "Create schedule"}</button></div>`, { wide: true });
    Runs.cadSync();
  },
  cadSync() {
    const daily = $("#sc-cad").value === "daily";
    $("#sc-time-wrap").hidden = !daily;
    $("#sc-days-wrap").hidden = !daily;
  },
  async save(btn, id) {
    const cad = $("#sc-cad").value, daily = cad === "daily";
    const body = { name: $("#sc-name").value.trim(), enabled: $("#sc-on").checked,
      cadence: daily ? "daily" : "interval", every_minutes: daily ? null : Number(cad), at_time: daily ? $("#sc-time").value : null,
      weekdays: daily ? [...document.querySelectorAll(".sc-day:checked")].map((c) => Number(c.value)) : [],
      scope: { category: $("#sc-set").value || null, severity: $("#sc-sev").value || null, platform: $("#sc-plat") ? $("#sc-plat").value || null : null,
        asset_ids: [...$("#sc-assets").selectedOptions].map((o) => Number(o.value)) } };
    btn.disabled = true;
    try {
      const r = id ? await patch(`/schedules/${id}`, body) : await post("/schedules", body);
      Modal.close();
      toastOk(`${r.name}: ${r.cadence_text}, ${r.rules} rule(s) on ${r.datasets} dataset(s).` + (r.next_run ? ` Next run ${ts(r.next_run)}.` : ""));
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
};

Pages.runs = async () => {
  const [allAssets, picker] = await Promise.all([api("/assets"), platformPicker()]);
  const assets = State.platform ? allAssets.filter((x) => x.platform === State.platform) : allAssets;
  const asset = assets.find((x) => String(x.id) === String(State.runsAsset)) || null;
  const head = `<div class="page-head"><h1>Runs</h1><span class="sub">Run rules, schedule them, and see what ran ${Info.btn("rules")}</span><span class="grow"></span>${picker}
    <select aria-label="Dataset" onchange="State.runsAsset=this.value; render()"><option value="">All datasets</option>${assets.map((x) => `<option value="${x.id}" ${asset && x.id === asset.id ? "selected" : ""}>${esc(x.fqn)}</option>`).join("")}</select></div>
    <p class="sub" style="margin:0 0 12px">These are the runs started here: by hand, by a schedule, by the agent or by Refresh insights. Checks you run in DQX, Soda, Great Expectations or dbt are not shown yet.</p>`;
  return head + (await Runs.html(asset, assets));
};

const STUDIO_TABS = [["generation", "Rule generation"], ["saved", "Saved rules"], ["review", "Review queue"], ["catalog", "Rule catalog"], ["references", "Reference files"]];

Pages.rules = async (tab = "generation") => {
  if (!STUDIO_TABS.some(([k]) => k === tab)) tab = "generation";
  const [allAssets, drafts, inReview, platforms] = await Promise.all([api("/assets"), api("/rules?status=proposed,rejected"), api("/rules?status=review"),
    connectedPlatforms(), tab === "generation" ? Refs.load(true) : null]);
  if (State.studioPlatform && !platforms.includes(State.studioPlatform)) State.studioPlatform = "";
  const assets = State.studioPlatform ? allAssets.filter((x) => x.platform === State.studioPlatform) : allAssets;
  if (!assets.some((x) => x.id === Number(State.studioAsset))) State.studioAsset = assets.length ? assets[0].id : "";
  const asset = assets.find((x) => x.id === Number(State.studioAsset));
  const fq = new Set(assets.map((x) => x.fqn));
  const badge = { saved: drafts.filter((r) => fq.has(r.asset)).length, review: inReview.filter((r) => fq.has(r.asset)).length };
  const tip = { saved: "Saved drafts, across the selected platform", review: "Rules waiting for an administrator" };
  const head = `<div class="page-head head-split"><div class="head-left"><div class="row"><h1>AI Rule Studio</h1>${Info.btn("rules")}</div><span class="agent-tag"><b>Your data quality AI agent</b>, fully aware of your <b>metadata</b>, <b>business context</b>, <b>policies</b> and <b>standards</b></span></div><div class="pick-stack">
    ${platforms.length ? `<select aria-label="Platform" title="Platform" onchange="State.studioPlatform=this.value; render()"><option value="">${platforms.length > 1 ? "All connected platforms" : "Connected platform"}</option>${platforms.map((p) => `<option value="${esc(p)}" ${State.studioPlatform === p ? "selected" : ""}>${esc(PLATFORMS[p] || p)}</option>`).join("")}</select>` : ""}
    ${tab === "references" ? "" : `<select aria-label="Dataset" onchange="State.studioAsset=this.value; if (Exporter.st.asset !== 'all') Exporter.st.asset = String(this.value); render()">${assets.map((x) => `<option value="${x.id}" ${x.id === Number(State.studioAsset) ? "selected" : ""}>${esc(x.fqn)}</option>`).join("")}</select>`}</div></div>
  <div class="tabs">${STUDIO_TABS.map(([k, l]) => `<a href="#/rules/${k}" class="${k === tab ? "active" : ""}">${esc(l)}${badge[k] ? ` <span class="pill warn" title="${tip[k]}">${badge[k]}</span>` : ""}</a>`).join("")}</div>`;
  if (tab === "saved") return head + (await Saved.html(asset));
  if (tab === "review") return head + (await Review.html(asset));
  if (tab === "catalog") return head + (await Catalog.html(asset, assets));
  if (tab === "references") return head + (await Refs.library());
  return head + Studio.generation(asset);
};

/* A dry run on the platform: the result, where it ran, how long it took, and the queries. Nothing is stored by a dry run. */
function dryHtml(d) {
  const ran = d.ran_on;
  const sql = (ran && ran.sql) || [];
  return `${pill(d.status)} ${esc(d.message || "")}
    ${ran ? `<div class="sub" style="font-size:11.5px">Ran on ${plat(ran.platform)} <span class="mono">${esc(ran.connection)}</span> in ${ran.seconds} s (${ran.queries} quer${ran.queries === 1 ? "y" : "ies"}). Nothing was saved.</div>` : ""}
    ${sql.length || d.failing_sql ? `<details><summary class="sub">Queries that ran on the platform</summary>${sql.map((q) => `<pre>${esc(q)}</pre>`).join("")}
      ${d.failing_sql ? `<div class="sub">To list the failing rows:</div><pre>${esc(d.failing_sql)}</pre>` : ""}</details>` : ""}`;
}
const ruleBody = (r) => ({ type: r.type, column: r.column, params: r.params, severity: r.severity, threshold: r.threshold });
const platformQ = () => (State.studioPlatform ? { platform: State.studioPlatform } : {});
const iAmAdmin = () => !State.user || State.user.role === "admin";
const iAmViewer = () => !!State.user && State.user.role === "viewer";

/* Saved rules: drafts. The only things to do here are Edit and Send for approval. */
const Saved = {
  st: { scope: "all", set: "" },
  sel: new Set(),
  set(k, v) { Saved.st[k] = v; Saved.sel.clear(); render(true); },
  async html(asset) {
    const st = Saved.st;
    const q = new URLSearchParams({ status: "proposed,rejected", ...platformQ(), ...(st.scope === "asset" && asset ? { asset_id: asset.id } : {}), ...(st.set ? { category: st.set } : {}) });
    const rules = await api("/rules?" + q);
    rules.forEach((r) => (RuleTable.cache[r.id] = r));
    Saved.ids = rules.map((r) => r.id);
    Saved.sel = new Set([...Saved.sel].filter((id) => Saved.ids.includes(id)));
    const edit = !iAmViewer();
    const selF = (k, opts) => `<select onchange="Saved.set('${k}', this.value)" aria-label="${k}">${opts.map(([v, l]) => `<option value="${v}" ${st[k] === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
    return `<div class="card wrap"><div class="row" style="flex-wrap:wrap;gap:8px"><h2 style="margin:0">Saved rules</h2>${RuleTable.setCounts(rules)}<span style="flex:1"></span>
      ${selF("scope", [["all", "All datasets"], ["asset", "This dataset"]])}${selF("set", [["", "All sets"], ...Object.entries(RULE_SETS)])}</div>
      <p class="sub" style="margin:6px 0 8px">Drafts from AI rule generation, Plain-English rule and Manual rule builder. They don't run. To run or schedule rules that are already active, open <a href="#/runs">Runs</a>. Edit a draft until it's right, then <strong>send it for approval</strong>:
        an administrator approves and activates it in the <a href="#/rules/review">Review queue</a>.</p>
      ${rules.length ? `<table class="t"><tr>${edit ? `<th style="width:28px"><input type="checkbox" aria-label="Select all" ${Saved.sel.size && Saved.sel.size === rules.length ? "checked" : ""} onchange="Saved.all(this.checked)"></th>` : ""}
        <th>Rule</th><th>Dataset</th><th>Set</th><th>Type</th><th>Severity</th><th>Status</th><th>Saved</th><th></th></tr>
      ${rules.map((r) => `<tr>${edit ? `<td><input type="checkbox" ${Saved.sel.has(r.id) ? "checked" : ""} onchange="Saved.pick(${r.id}, this.checked)" aria-label="Select ${esc(r.name)}"></td>` : ""}
        <td><strong>${esc(r.name)}</strong><div class="sub">${esc(r.dimension)} · ${esc(r.source)}${r.reason ? " · " + esc(r.reason.slice(0, 160)) : ""}</div></td>
        <td class="sub">${esc(short(r.asset))}</td><td>${pill(SET_PILL[r.category || "core"] || "", RULE_SETS[r.category || "core"])}</td>
        <td class="mono">${esc(r.type)}</td><td>${pill(r.severity)}</td>
        <td>${r.status === "rejected" ? `${pill("rejected")}<div class="sub" style="max-width:260px">${esc(r.decision_note || "")}<br>${esc(r.decided_by || "")} ${esc(ts(r.decided_ts))}</div>` : pill("muted", "draft")}</td>
        <td class="sub">${esc(r.created_by || "")}<br>${esc(ts(r.created))}</td>
        <td class="btns">${edit ? `<button class="btn sm" onclick="RuleEdit.open(${r.id})">Edit</button>
          <button class="btn sm primary" onclick="Saved.send([${r.id}])">Send for approval</button>` : ""}</td></tr>`).join("")}</table>
      ${edit ? `<div class="btns" style="margin-top:10px"><span class="sub">${Saved.sel.size} selected</span><span style="flex:1"></span>
        <button class="btn primary" ${Saved.sel.size ? "" : "disabled"} onclick="Saved.send([...Saved.sel])">Send selected for approval</button></div>` : ""}`
      : `<div class="empty">No saved rules${st.scope === "asset" ? " for this dataset" : ""}. Save drafts from <a href="#/rules/generation">Rule generation</a> and they wait here.</div>`}</div>`;
  },
  pick(id, on) { if (on) Saved.sel.add(id); else Saved.sel.delete(id); render(true); },
  all(on) { Saved.sel = new Set(on ? Saved.ids : []); render(true); },
  send(ids) {
    const names = ids.map((i) => (RuleTable.cache[i] || {}).name).filter(Boolean);
    Modal.open(`${Modal.head("Send for approval", `${ids.length} rule${ids.length === 1 ? "" : "s"}`)}
      <div class="modal-body"><p class="sub">${names.slice(0, 6).map(esc).join("<br>")}${names.length > 6 ? `<br>and ${names.length - 6} more` : ""}</p>
        <label class="f">Note for the reviewer (optional)<textarea id="sd-note" rows="3" placeholder="Why this rule, and what you checked"></textarea></label>
        <p class="sub" style="margin-top:8px">The rules stay locked while they wait. Withdraw them in the Review queue if you need to change them.</p></div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn primary" onclick="Saved.doSend(this, ${jsq(ids)})">Send for approval</button></div>`);
  },
  async doSend(btn, ids) {
    btn.disabled = true;
    try {
      const r = await post("/rules/submit", { rule_ids: ids, note: $("#sd-note").value });
      Modal.close();
      Saved.sel.clear();
      toastOk(`${r.submitted.length} rule${r.submitted.length === 1 ? "" : "s"} sent for approval. An administrator reviews them in the Review queue.`);
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
};

/* Review queue: rules sent for approval. Administrators approve, reject and activate; everyone can follow progress. */
const Review = {
  st: { status: "waiting", scope: "all" },
  sel: new Set(),
  data: null,
  set(k, v) { Review.st[k] = v; Review.sel.clear(); render(true); },
  async html(asset) {
    const st = Review.st;
    const q = new URLSearchParams({ status: st.status, ...platformQ(), ...(st.scope === "asset" && asset ? { asset_id: asset.id } : {}) });
    const d = await api("/rules/review?" + q);
    Review.data = d;
    d.rules.forEach((r) => (RuleTable.cache[r.id] = r));
    const ids = d.rules.map((r) => r.id);
    Review.sel = new Set([...Review.sel].filter((id) => ids.includes(id)));
    const admin = iAmAdmin(), me = State.user && State.user.email;
    const segs = [["waiting", "Waiting for review", d.counts.waiting], ["approved", "Approved, not active", d.counts.approved], ["rejected", "Rejected", d.counts.rejected], ["all", "All", d.counts.waiting + d.counts.approved + d.counts.rejected]];
    const act = (r) => {
      if (!admin) return (r.submitted_by === me && ["review", "approved"].includes(r.status)) ? `<button class="btn sm" onclick="Review.withdraw(this, [${r.id}])">Withdraw</button>` : "";
      if (r.status === "review") return `<button class="btn sm" onclick="Review.decide(this, [${r.id}], 'approve')">Approve</button>
        <button class="btn sm primary" onclick="Review.decide(this, [${r.id}], 'approve_activate')">Approve and activate</button>
        <button class="btn sm danger" onclick="Review.reject([${r.id}])">Reject…</button>`;
      if (r.status === "approved") return `<button class="btn sm primary" onclick="Review.decide(this, [${r.id}], 'activate')">Activate</button>
        <button class="btn sm danger" onclick="Review.reject([${r.id}])">Reject…</button>`;
      return "";
    };
    const stateCell = (r) => r.status === "rejected" ? `${pill("rejected")}<div class="sub" style="max-width:240px">${esc(r.decision_note || "")}<br>${esc(r.decided_by || "")} ${esc(ts(r.decided_ts))}</div>`
      : r.status === "approved" ? `${pill("approved")}<div class="sub">${esc(r.decided_by || "")} ${esc(ts(r.decided_ts))}${r.decision_note ? "<br>" + esc(r.decision_note) : ""}</div>`
      : pill("warn", "waiting");
    const sel = admin && st.status !== "rejected";
    return `<div class="card wrap"><div class="row" style="flex-wrap:wrap;gap:8px"><h2 style="margin:0">Review queue</h2><span class="sub">${admin ? "You can approve, reject and activate" : "Only administrators approve and activate"}</span><span style="flex:1"></span>
      <select aria-label="Scope" onchange="Review.set('scope', this.value)"><option value="all" ${st.scope === "all" ? "selected" : ""}>All datasets</option><option value="asset" ${st.scope === "asset" ? "selected" : ""}>This dataset</option></select></div>
      <div class="segs" role="tablist" aria-label="Review state" style="margin:10px 0">${segs.map(([k, l, n]) => `<button class="seg ${st.status === k ? "on" : ""}" onclick="Review.set('status', '${k}')">${esc(l)} <span class="n">${n}</span></button>`).join("")}</div>
      <p class="sub" style="margin:0 0 8px">Drafts sent from <a href="#/rules/saved">Saved rules</a> land here. <strong>Approve</strong> accepts a rule; <strong>Activate</strong> puts it live on its schedule (<strong>Approve and activate</strong> does both);
        <strong>Reject</strong> sends it back to the author with your reason. Use <strong>Dry run</strong> to see how a rule behaves on the platform first.</p>
      ${d.rules.length ? `<table class="t"><tr>${sel ? `<th style="width:28px"><input type="checkbox" aria-label="Select all" ${Review.sel.size && Review.sel.size === d.rules.length ? "checked" : ""} onchange="Review.all(this.checked)"></th>` : ""}
        <th>Rule</th><th>Dataset</th><th>Set</th><th>Severity</th><th>Sent by</th><th>State</th><th>Dry run</th><th></th></tr>
      ${d.rules.map((r) => `<tr>${sel ? `<td><input type="checkbox" ${Review.sel.has(r.id) ? "checked" : ""} onchange="Review.pick(${r.id}, this.checked)" aria-label="Select ${esc(r.name)}"></td>` : ""}
        <td><strong>${esc(r.name)}</strong><div class="sub"><code>${esc(r.type)}</code>${r.column ? " on <code>" + esc(r.column) + "</code>" : ""} · ${esc(r.dimension)} · ${esc(r.source)}</div>
          <details><summary class="sub">Rule details</summary><pre>${esc(JSON.stringify(r.params || {}, null, 2))}</pre>${r.reason ? `<div class="sub">${esc(r.reason)}</div>` : ""}</details></td>
        <td class="sub">${esc(short(r.asset))}<div>${plat(r.platform)}</div></td><td>${pill(SET_PILL[r.category || "core"] || "", RULE_SETS[r.category || "core"])}</td><td>${pill(r.severity)}</td>
        <td class="sub">${esc(r.submitted_by || "")}<br>${esc(ts(r.submitted_ts))}${r.submit_note ? `<div style="max-width:220px">“${esc(r.submit_note)}”</div>` : ""}</td>
        <td>${stateCell(r)}</td>
        <td class="sub" id="rv-dr-${r.id}">${r.status !== "rejected" && !iAmViewer() ? `<button class="btn sm" onclick="Review.dry(this, ${r.id})">Dry run</button>` : ""}</td>
        <td class="btns">${act(r)}</td></tr>`).join("")}</table>
      ${sel ? `<div class="btns" style="margin-top:10px"><span class="sub">${Review.sel.size} selected</span><span style="flex:1"></span>
        <button class="btn danger" ${Review.sel.size ? "" : "disabled"} onclick="Review.reject([...Review.sel])">Reject selected…</button>
        <button class="btn" ${Review.sel.size ? "" : "disabled"} onclick="Review.decide(this, [...Review.sel], 'approve')">Approve selected</button>
        <button class="btn primary" ${Review.sel.size ? "" : "disabled"} onclick="Review.decide(this, [...Review.sel], 'approve_activate')">Approve and activate selected</button></div>` : ""}`
      : `<div class="empty">${st.status === "waiting" ? "Nothing is waiting for review." : "No rules in this state."}</div>`}</div>`;
  },
  pick(id, on) { if (on) Review.sel.add(id); else Review.sel.delete(id); render(true); },
  all(on) { Review.sel = new Set(on ? Review.data.rules.map((r) => r.id) : []); render(true); },
  async dry(btn, id) {
    const r = RuleTable.cache[id], out = $("#rv-dr-" + id);
    btn.disabled = true;
    out.innerHTML = '<span class="sub">Running on the platform…</span>';
    try { out.innerHTML = dryHtml(await post("/rules/dry-run", { asset_id: r.asset_id, ...ruleBody(r) })); }
    catch (e) { out.innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span>`; }
  },
  async decide(btn, ids, decision, note) {
    if (!ids.length) return;
    btn.disabled = true;
    try {
      const r = await post("/rules/review/decide", { rule_ids: ids, decision, note: note || null });
      const n = r.rules.length, s = n === 1 ? "" : "s";
      toastOk(decision === "reject" ? `${n} rule${s} rejected and sent back to the author.`
        : decision === "approve" ? `${n} rule${s} approved. Activate ${n === 1 ? "it" : "them"} when ready.`
        : `${n} rule${s} activated. ${n === 1 ? "It runs" : "They run"} on the schedule; see the Rule catalog.`);
      Review.sel.clear();
      Modal.close();
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  reject(ids) {
    if (!ids.length) return;
    Modal.open(`${Modal.head("Reject " + (ids.length === 1 ? "rule" : ids.length + " rules"), "The author sees your reason in Saved rules")}
      <div class="modal-body"><label class="f">Why is it rejected?<textarea id="rj-note" rows="3" autofocus placeholder="What should change before it is sent again"></textarea></label></div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn danger" onclick="Review.rejectGo(this, ${jsq(ids)})">Reject</button></div>`);
  },
  rejectGo(btn, ids) {
    const note = $("#rj-note").value.trim();
    if (!note) return toastError("Say why it is rejected, so the author knows what to change");
    Review.decide(btn, ids, "reject", note);
  },
  async withdraw(btn, ids) {
    btn.disabled = true;
    try { await post("/rules/withdraw", { rule_ids: ids }); toastOk("Withdrawn. The rule is a draft again in Saved rules."); await render(true); }
    catch (e) { btn.disabled = false; toastError(e.message); }
  },
};

Studio.genTab = () => { try { return localStorage.getItem("dt.gentab") || "ai"; } catch (e) { return "ai"; } };
Studio.genSwitch = (k) => {
  try { localStorage.setItem("dt.gentab", k); } catch (e) { /* a convenience only */ }
  ["ai", "builder", "nl"].forEach((x) => { const el = $("#gen-" + x); if (el) el.hidden = x !== k; });
  document.querySelectorAll("[data-gen]").forEach((b) => { const on = b.dataset.gen === k; b.classList.toggle("on", on); b.setAttribute("aria-selected", String(on)); });
};
Studio.generation = (asset) => {
  const types = State.meta?.rule_types || {};
  const typeHints = { range: '{"min": 0, "max": 500}', accepted_values: '{"values": ["A", "B"]}', regex: '{"pattern": "[A-Z]{3}-[0-9]{6}"}', freshness: '{"max_age_hours": 24}',
    row_count: '{"min": 1000}', unique: '{"columns": ["id"]}', referential: '{"ref_table": "cat.schema.table", "ref_column": "id"}', anomaly: '{"metric": "row_count", "sensitivity": 3}',
    custom_sql: '{"expression": "end_ts >= start_ts"}', timeseries: '{"check": "flatline", "id_column": "sensor_id", "ts_column": "ts", "value_column": "value", "flatline_s": 21600}',
    reconciliation: '{"expression": "SUM(kwh)", "ref_table": "cat.schema.other", "ref_expression": "SUM(kwh)", "tolerance_pct": 0.5}', length: '{"min": 1, "max": 20}',
    schema: '{"expected_columns": [{"name": "id", "type": "bigint"}]}' };
  const cur = Studio.genTab(), vis = (k) => (cur === k ? "" : "hidden");
  const tabs = [["ai", "AI rule generation"], ["nl", "Plain-English rule"], ["builder", "Manual rule builder"]];
  return `${asset ? `<div class="segs" role="tablist" aria-label="How to create a rule" style="margin-bottom:12px">${tabs.map(([k, l]) => `<button class="seg ${cur === k ? "on" : ""}" role="tab" data-gen="${k}" aria-selected="${cur === k}" onclick="Studio.genSwitch('${k}')">${esc(l)}</button>`).join("")}</div>
    <div id="gen-ai" ${vis("ai")}>${Discovery.panel(asset)}</div>
    <div id="gen-nl" ${vis("nl")}><div class="card"><h2>Plain-English rule</h2><p class="sub">Write requirements the way you'd say them, one per line. Business terms from your glossary and models are recognised. Each is interpreted, dry-run on current data, and saved as a proposal you can activate.</p>
      <textarea id="nl" style="min-height:96px;font-family:var(--font)" placeholder="One requirement per line, for example:&#10;kwh cannot be negative&#10;reading timestamp must not be in the future&#10;data must be refreshed every 3 hours&#10;customer_id must exist in customers"></textarea><div class="sp"></div>
      <div class="row" style="gap:8px"><button class="btn primary" onclick="Studio.nl(this, ${asset.id}, $('#nl').value)">Draft and dry-run on the platform</button>
        <label class="row sub" style="gap:6px">Set<select id="nl-set"><option value="">Detect</option>${Object.entries(RULE_SETS).map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join("")}</select></label></div><details style="margin-top:10px"><summary class="sub">Tips for rules that run well as SQL</summary><ul class="sub" style="margin:6px 0 0 18px;line-height:1.5">
        <li>One requirement per line, naming the column: <em>discount_pct must be between 0 and 30</em>.</li>
        <li>Give real limits and allowed values. The app never invents them; a limit you don't state is left out.</li>
        <li>For cross-column rules say both columns: <em>ship_date must be on or after order_date</em>.</li>
        <li>Say how often data must arrive: <em>data must be refreshed every 24 hours</em>.</li>
        <li>For conditional rules use <strong>Manual rule builder</strong> with type <code>custom_sql</code>: one boolean expression that is TRUE for valid rows, using only this table's columns. Handle nulls yourself, for example <code>ship_date IS NULL OR ship_date &gt;= order_date</code>.</li>
        <li>Prefer the specific types (not null, unique, range, accepted values, regex) over custom SQL when one fits. Always <strong>Dry run</strong> before saving: it runs on the platform and shows the query.</li></ul></details>
      <div id="nl-out"></div></div></div>
    <div id="gen-builder" ${vis("builder")}><div class="card"><h2>Manual rule builder</h2><input type="hidden" id="m-asset" value="${asset.id}">
      <div class="grid" style="grid-template-columns:1fr 1fr;gap:8px">
        <label class="f">Type<select id="m-type" onchange="$('#m-params').value=(${jsq(typeHints)})[this.value]||'{}';$('#m-desc').textContent=(${jsq(Object.fromEntries(Object.entries(types).map(([k, v]) => [k, v.desc])))})[this.value]">${Object.keys(types).map((t) => `<option>${t}</option>`).join("")}</select></label>
        <label class="f">Column<select id="m-col"><option value="">(none)</option>${(asset.columns || []).map((c) => `<option>${esc(c.name)}</option>`).join("")}</select></label>
        <label class="f">Severity<select id="m-sev">${["critical", "high", "medium", "low"].map((s) => `<option ${s === "medium" ? "selected" : ""}>${s}</option>`).join("")}</select></label>
        <label class="f">Min pass rate (0-1)<input id="m-thr" placeholder="1.0"></label>
        <label class="f">Set<select id="m-set"><option value="">Detect from type</option>${Object.entries(RULE_SETS).map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join("")}</select></label></div>
      <div class="sub" id="m-desc" style="margin:6px 0">${esc(Object.values(types)[0]?.desc || "")}</div>
      <label class="f">Params (JSON)<textarea id="m-params" style="min-height:60px">{}</textarea></label><div class="sp"></div>
      <div class="btns"><button class="btn" onclick="Studio.manual(this, 'dry')">Dry run on the platform</button><button class="btn primary" onclick="Studio.manual(this, 'draft')">Save as draft</button></div><div id="m-out"></div></div></div>
    <p class="sub" style="margin-top:12px">New rules are saved as drafts. Edit them and send them for approval in <a href="#/rules/saved">Saved rules</a>; an administrator activates them from the <a href="#/rules/review">Review queue</a>.</p>`
    : '<div class="card empty">Sync a connection first</div>'}`;
};

/* Lineage lives in Impact analysis now; the old #/lineage address still works */
Pages.lineage = async () => {
  location.replace("#/impact/lineage");
  return "";
};

/* Impact analysis > Lineage tab: the whole lineage graph and where it comes from */
async function lineageTab() {
  let g = await api("/lineage");
  if (State.platform) {  // only the selected platform's datasets, and the edges between them
    const keep = new Set(g.nodes.filter((x) => x.platform === State.platform).map((x) => x.id));
    g = { ...g, nodes: g.nodes.filter((x) => keep.has(x.id)), edges: g.edges.filter((e) => keep.has(e.source) && keep.has(e.target)) };
  }
  return `<div class="row" style="margin-bottom:12px"><span class="sub">${g.nodes.length} datasets · ${g.edges.length} lineage edges. Click a dataset to open it; choose one in the Impact analysis tab to see what depends on it.</span>
    <span style="flex:1"></span><button class="btn" onclick="act(this, () => post('/lineage/sync'), r => r.added + ' edges added')">Sync from platforms</button></div>
  <div class="card">${lineageSvg(g)}</div><div class="sp"></div>
  <div class="grid g2"><div class="card"><h2>Add an edge</h2><div class="row"><input id="e-src" placeholder="source fqn" style="flex:1"><input id="e-tgt" placeholder="target fqn" style="flex:1">
    <button class="btn" onclick="act(this, () => post('/lineage/edges', {source: $('#e-src').value, target: $('#e-tgt').value}), 'Edge added')">Add</button></div></div>
  <div class="card"><h2>Other sources</h2><p class="sub">Spark and Airflow: point the OpenLineage transport at <code>POST /api/lineage/openlineage</code>. dbt: post <code>target/manifest.json</code> to <code>POST /api/lineage/dbt</code>. Databricks and Snowflake lineage sync from system tables.</p></div></div>`;
}

function classTable(rows) {
  if (!rows.length) return '<div class="empty">No sensitive columns detected</div>';
  return `<table class="t"><tr><th>Dataset</th><th>Column</th><th>Label</th><th>Sensitivity</th><th class="num">Confidence</th><th>Status</th><th></th></tr>
  ${rows.map((c) => `<tr><td>${esc(short(c.asset))}</td><td class="mono">${esc(c.column)}</td><td>${esc(c.label)}</td><td>${pill(c.sensitivity === "restricted" ? "bad" : c.sensitivity === "confidential" ? "warn" : "info", c.sensitivity)}</td>
    <td class="num">${Math.round(c.confidence * 100)}%</td><td>${c.applied ? pill("ok", "tagged") : pill(c.status)}</td>
    <td class="btns">${!c.applied && c.status !== "rejected" ? `<button class="btn sm" onclick="act(this, () => post('/classifications/${c.id}/decide', {approve:true}), 'Tagged in platform')">Tag</button>
      <button class="btn sm" onclick="act(this, () => post('/classifications/${c.id}/decide', {approve:false}), 'Rejected')">Not PII</button>` : ""}</td></tr>`).join("")}</table>`;
}
function violationTable(v) {
  if (!v.length) return '<div class="empty">No violations</div>';
  return `<table class="t"><tr><th>Severity</th><th>Policy</th><th>Dataset</th><th>Issue</th><th></th></tr>
  ${v.map((x) => `<tr><td>${pill(x.severity)}</td><td class="mono">${esc(x.policy)}</td><td><a href="#/asset/${x.asset_id}">${esc(short(x.asset))}</a>${x.column ? "." + esc(x.column) : ""}</td><td>${esc(x.message)}${x.new ? ' ' + pill('warn', 'new') : ''}</td>
    <td>${x.enforceable ? `<button class="btn sm" onclick="act(this, () => post('/policies/enforce', {policy:'${esc(x.policy)}', asset_id:${x.asset_id}, column:${x.column ? `'${esc(x.column)}'` : "null"}}), 'Enforced in the platform')">Enforce</button>` : ""}</td></tr>`).join("")}</table>`;
}

Pages.governance = async (tab = "policies") => {
  if (tab === "compliance") { location.replace("#/governance/standards"); return ""; }  // folded into Standards
  if (tab === "ownership" || tab === "coverage") { location.replace("#/governance/policies"); return ""; }  // removed: owners are in Explore, coverage evidence in Standards
  const tabs = ["policies", "standards", "glossary", "contracts", "pii"];
  if (!GovTabs[tab]) tab = "policies";  // e.g. the removed Learning tab
  let pick = "";
  if (tab === "pii" || tab === "contracts") {  // the tabs about datasets can be limited to a platform or one dataset
    const [picker, all] = await Promise.all([platformPicker(), api("/assets")]);
    const list = State.platform ? all.filter((x) => x.platform === State.platform) : all;
    if (State.govAsset && !list.some((x) => String(x.id) === String(State.govAsset))) State.govAsset = "";
    pick = `<div class="pick-stack">${picker}<select aria-label="Dataset" onchange="State.govAsset=this.value; Pii.sel = new Set(); render(true)"><option value="">All datasets</option>${list.map((x) => `<option value="${x.id}" ${String(x.id) === String(State.govAsset) ? "selected" : ""}>${esc(x.fqn)}</option>`).join("")}</select></div>`;
  }
  const body = await GovTabs[tab]();
  return `<div class="page-head head-split"><div class="head-left"><div class="row"><h1>Intelligent Governance</h1>${Info.btn("policies")}</div><span class="agent-tag"><b>Policies</b>, <b>standards</b>, <b>glossary</b>, <b>contracts</b> and <b>sensitive data</b></span></div>${pick}</div>
  <div class="tabs">${tabs.map((t) => `<a href="#/governance/${t}" class="${t === tab ? "active" : ""}">${t === "pii" ? "Sensitive data" : t[0].toUpperCase() + t.slice(1)}</a>`).join("")}</div>${body}`;
};
const GovTabs = {};
/* ------------------------------------------------------------------ Governance > Sensitive data: scan, status, filters, bulk review */
const Pii = {
  f: { sens: "", status: "all", q: "" },
  sel: new Set(),
  rows: [],
  set(k, v) { Pii.f[k] = v; Pii.sel = new Set(); render(true); },
  async scan(btn, onlyNew) {
    btn.disabled = true;
    try {
      const r = await post("/pii-scans/run", { platform: State.platform || null, asset_ids: State.govAsset ? [Number(State.govAsset)] : null, only_unscanned: !!onlyNew });
      toastOk(`Scanned ${r.scanned} dataset(s): ${r.new} new sensitive column(s)${r.error_count ? `, ${r.error_count} could not be scanned` : ""}.`);
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  scoped() { return Pii.rows.filter((c) => (!State.platform || c.platform === State.platform) && (!State.govAsset || String(c.asset_id) === String(State.govAsset))); },
  shown() {
    const f = Pii.f, q = f.q.toLowerCase();
    return Pii.scoped().filter((c) => (!f.sens || c.sensitivity === f.sens)
      && (f.status === "all" || (f.status === "review" ? !c.applied : c.applied)) && (!q || (c.asset + " " + c.column + " " + c.label).toLowerCase().includes(q)));
  },
  pick(id, on) { if (on) Pii.sel.add(id); else Pii.sel.delete(id); Pii.count(); },
  pickAll(on) { Pii.shown().forEach((c) => (on ? Pii.sel.add(c.id) : Pii.sel.delete(c.id))); document.querySelectorAll(".pii-pick").forEach((el) => { el.checked = on; }); Pii.count(); },
  count() {
    const n = Pii.sel.size, el = $("#pii-count");
    if (el) el.textContent = n ? `${n} selected` : "Select columns to tag or dismiss several at once";
    document.querySelectorAll(".pii-bulk").forEach((b) => { b.disabled = !n; });
  },
  async bulk(btn, approve) {
    const ids = [...Pii.sel];
    if (!ids.length) return;
    btn.disabled = true;
    try {
      const r = await post("/classifications/decide-bulk", { ids, approve });
      Pii.sel = new Set();
      toastOk(approve ? `Tagged ${r.tagged} column(s) in the platform.` + (r.failed.length ? ` ${r.failed.length} dataset(s) failed: ${r.failed[0].error}` : "") : `${r.rejected} column(s) marked Not PII.`);
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  schedule(s) {
    const cad = s.cadence === "daily" ? "daily" : String(s.every_minutes || 60), days = new Set(s.weekdays || []);
    const opt = (v, l) => `<option value="${esc(v)}" ${cad === String(v) ? "selected" : ""}>${esc(l)}</option>`;
    Modal.open(`${Modal.head("Sensitive-data scan schedule", "Scans every dataset for sensitive columns on a cadence. Times are UTC.")}
      <div class="modal-body">
        <label class="row sub" style="gap:8px"><input type="checkbox" id="pz-on" ${s.enabled ? "checked" : ""}> Scan on this schedule</label>
        <div class="grid g2" style="margin-top:8px"><label class="f">When<select id="pz-cad" onchange="Pii.cadSync()">${CADENCE_CHOICES.map(([v, l]) => opt(v, l)).join("")}</select></label>
          <label class="f" id="pz-time-wrap">Time of day (UTC)<input id="pz-time" type="time" value="${esc(s.at_time || "06:00")}"></label></div>
        <div id="pz-days-wrap" style="margin-top:8px"><span class="sub">On these days (none ticked means every day):</span>
          <div class="btns" style="margin-top:4px">${WEEKDAYS.map((w, i) => `<label class="row sub" style="gap:4px"><input type="checkbox" class="pz-day" value="${i}" ${days.has(i) ? "checked" : ""}> ${w}</label>`).join("")}</div></div>
        <label class="row sub" style="gap:8px;margin-top:12px"><input type="checkbox" id="pz-sync" ${s.after_sync ? "checked" : ""}> Also scan new datasets right after a catalog sync</label>
      </div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn primary" onclick="Pii.saveSchedule(this)">Save</button></div>`);
    Pii.cadSync();
  },
  cadSync() { const d = $("#pz-cad").value === "daily"; $("#pz-time-wrap").hidden = !d; $("#pz-days-wrap").hidden = !d; },
  async saveSchedule(btn) {
    const cad = $("#pz-cad").value, daily = cad === "daily";
    btn.disabled = true;
    try {
      const r = await api("/pii-scans/schedule", { method: "PUT", body: { enabled: $("#pz-on").checked, cadence: daily ? "daily" : "interval", every_minutes: daily ? null : Number(cad),
        at_time: daily ? $("#pz-time").value : null, weekdays: daily ? [...document.querySelectorAll(".pz-day:checked")].map((c) => Number(c.value)) : [], after_sync: $("#pz-sync").checked } });
      Modal.close();
      toastOk(r.enabled ? `Scanning ${r.text}.` : r.after_sync ? "New datasets are scanned after a catalog sync." : "Scheduled scans are off.");
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
};

GovTabs.pii = async () => {
  const [st, s, conns] = await Promise.all([api("/pii-scans/status"), api("/governance/summary"), connectedPlatforms()]);
  Pii.rows = s.pii;
  const keep = new Set(Pii.rows.map((c) => c.id));
  Pii.sel = new Set([...Pii.sel].filter((id) => keep.has(id)));
  const admin = iAmAdmin(), canScan = !iAmViewer(), f = Pii.f, last = st.last, sch = st.schedule, rows = Pii.shown(), sc = Pii.scoped();
  const tile = (l, v, tone, sub) => `<div class="card kpi"><div class="label">${l}</div><div class="value ${tone || ""}">${v}</div>${sub ? `<div class="sub">${sub}</div>` : ""}</div>`;
  const lastLine = last
    ? `Last scan <strong>${ts(last.ts)}</strong> (${esc(last.trigger)}${last.actor && last.trigger === "manual" ? " by " + esc(last.actor) : ""}): ${last.scanned} dataset(s), ${last.new} new column(s)${last.skipped ? `, ${last.skipped} skipped (connection off)` : ""}${last.error_count ? `, <span style="color:var(--bad)">${last.error_count} could not be scanned</span>` : ""}.`
    : "No scan has run yet.";
  const schedLine = sch.enabled ? `Scanning ${esc(sch.text || "")}${sch.next_run ? `, next ${ts(sch.next_run)}` : ""}` : "Not scheduled";
  return `<p class="sub" style="margin:0 0 8px">Find personal or sensitive columns across your datasets, then tag them in the platform or dismiss false hits.</p>
  <div class="row" style="gap:8px;flex-wrap:wrap"><p class="sub" style="margin:0;flex:1;min-width:280px">${lastLine} ${schedLine}${sch.after_sync ? "; new datasets are scanned after a sync" : ""}.
      ${admin ? '<a href="#" onclick="event.preventDefault(); Pii.schedule(' + esc(JSON.stringify(sch)) + ')">Change schedule</a>' : ""}</p>
    ${canScan ? `<button class="btn primary" onclick="Pii.scan(this, false)">Scan${State.govAsset ? " this dataset" : State.platform ? " " + esc(PLATFORMS[State.platform] || State.platform) : " all datasets"}</button>
      ${st.never_scanned ? `<button class="btn" onclick="Pii.scan(this, true)" title="Only datasets that were never scanned">Scan ${st.never_scanned} new</button>` : ""}` : ""}</div>
  ${st.never_scanned ? `<div class="callout warn" style="margin-top:8px">${st.never_scanned} of ${st.datasets} dataset(s) were never scanned: ${st.unscanned.slice(0, 5).map((a) => `<a href="#/asset/${a.id}">${esc(short(a.fqn))}</a>`).join(", ")}${st.never_scanned > 5 ? " …" : ""}. They show no sensitive data until scanned.</div>` : ""}
  <div class="sp"></div>
  <div class="grid g4">${tile("Sensitive columns", sc.length, "", "across " + new Set(sc.map((c) => c.asset_id)).size + " dataset(s)")}
    ${tile("To review", sc.filter((c) => !c.applied).length, sc.some((c) => !c.applied) ? "bad" : "ok", "not tagged in the platform yet")}
    ${tile("Tagged", sc.filter((c) => c.applied).length, "ok", "in the platform")}
    ${tile("Restricted", sc.filter((c) => c.sensitivity === "restricted").length, sc.some((c) => c.sensitivity === "restricted") ? "bad" : "", "card, SSN, IBAN, passport, national id")}</div>
  <div class="sp"></div>
  <div class="card wrap"><div class="row" style="gap:8px;margin-bottom:8px;flex-wrap:wrap">
    <select aria-label="Sensitivity" onchange="Pii.set('sens', this.value)"><option value="">All sensitivity levels</option>${["restricted", "confidential", "internal"].map((x) => `<option value="${x}" ${f.sens === x ? "selected" : ""}>${x}</option>`).join("")}</select>
    <select aria-label="Status" onchange="Pii.set('status', this.value)">${[["all", "All"], ["review", "To review"], ["tagged", "Tagged"]].map(([v, l]) => `<option value="${v}" ${f.status === v ? "selected" : ""}>${l}</option>`).join("")}</select>
    <input type="search" placeholder="Search dataset, column or label" value="${esc(f.q)}" onchange="Pii.set('q', this.value)" style="min-width:220px">
    <span class="grow"></span><span class="sub">${rows.length} of ${Pii.rows.length}</span></div>
    ${canScan ? `<div class="row" style="gap:8px;margin-bottom:8px"><span class="sub" id="pii-count"></span><span class="grow"></span>
      <button class="btn sm pii-bulk" onclick="Pii.bulk(this, true)">Tag selected</button><button class="btn sm pii-bulk" onclick="Pii.bulk(this, false)">Not PII</button></div>` : ""}
    ${rows.length ? `<table class="t"><tr>${canScan ? `<th style="width:28px"><input type="checkbox" aria-label="Select all shown" onchange="Pii.pickAll(this.checked)"></th>` : ""}<th>Dataset</th><th>Column</th><th>Label</th><th>Sensitivity</th><th class="num">Confidence</th><th>Status</th><th></th></tr>
    ${rows.map((c) => `<tr>${canScan ? `<td><input type="checkbox" class="pii-pick" ${Pii.sel.has(c.id) ? "checked" : ""} onchange="Pii.pick(${c.id}, this.checked)" aria-label="Select ${esc(c.column)}"></td>` : ""}
      <td><a href="#/asset/${c.asset_id}">${esc(short(c.asset))}</a></td><td class="mono">${esc(c.column)}</td><td>${esc(c.label)}</td>
      <td>${pill(c.sensitivity === "restricted" ? "bad" : c.sensitivity === "confidential" ? "warn" : "info", c.sensitivity)}</td><td class="num">${Math.round(c.confidence * 100)}%</td>
      <td>${c.applied ? pill("ok", "tagged") : pill(c.status)}</td>
      <td class="btns">${canScan && !c.applied ? `<button class="btn sm" onclick="act(this, () => post('/classifications/${c.id}/decide', {approve:true}), 'Tagged in platform')">Tag</button>
        <button class="btn sm" onclick="act(this, () => post('/classifications/${c.id}/decide', {approve:false}), 'Rejected')">Not PII</button>` : ""}</td></tr>`).join("")}</table>`
    : `<div class="empty">${Pii.rows.length ? "No columns match these filters." : last ? "No sensitive columns detected." : "Nothing yet. Run a scan to look for sensitive columns."}</div>`}
    <p class="sub" style="margin:8px 0 0">Detected from column names and a small local sample. Raw values are never stored or sent to a model. <strong>Tag</strong> writes the label to the platform; <strong>Not PII</strong> dismisses a false hit, and a rescan will not bring it back.</p></div>
  ${setTimeout(() => Pii.count(), 0) && ""}`;
};
GovTabs.glossary = async () => {
  const terms = await api("/glossary");
  return `<div class="grid g2"><div class="card wrap"><h2>Business terms</h2><table class="t"><tr><th>Term</th><th>Definition</th><th>Mapped to</th></tr>
    ${terms.map((t) => `<tr><td><strong>${esc(t.name)}</strong><div class="sub">${esc(t.domain || "")}</div></td><td>${esc(t.definition)}</td><td class="mono sub">${t.links.map((l) => esc(short(l.ref))).join(", ")}</td></tr>`).join("") || '<tr><td class="empty" colspan="3">No terms</td></tr>'}</table>
    <div class="sp"></div><button class="btn" onclick="act(this, () => post('/glossary/sync-neo4j'), r => r.status === 'synced' ? 'Synced to Neo4j' : r.note)">Sync to Neo4j</button></div>
  <div class="card"><h2>Add a term</h2><div class="grid" style="gap:8px"><label class="f">Name<input id="g-name"></label><label class="f">Definition<input id="g-def"></label>
    <label class="f">Domain<input id="g-dom"></label><label class="f">Maps to dataset (fqn, optional)<input id="g-ref"></label></div><div class="sp"></div>
    <button class="btn primary" onclick="act(this, async () => { const t = await post('/glossary', {name: $('#g-name').value, definition: $('#g-def').value, domain: $('#g-dom').value || null}); if ($('#g-ref').value) await post('/glossary/' + t.id + '/link', {target_type:'asset', target_ref: $('#g-ref').value}); }, 'Term saved')">Save term</button></div></div>`;
};
GovTabs.contracts = async () => {
  const [all, plat] = await Promise.all([api("/contracts"), api("/assets")]);
  const pf = Object.fromEntries(plat.map((a) => [a.id, a.platform]));
  const cs = all.filter((c) => (!State.platform || pf[c.asset_id] === State.platform) && (!State.govAsset || String(c.asset_id) === String(State.govAsset)));
  return `<div class="grid g2"><div class="card wrap"><h2>Data contracts (ODCS v3) ${Info.btn("contracts")}</h2><p class="sub" style="margin:0 0 8px">${esc(INFO.contracts.short)}</p><table class="t"><tr><th>Dataset</th><th>Version</th><th>Status</th><th>Schema</th></tr>
    ${cs.map((c) => `<tr><td><a href="#/asset/${c.asset_id}/contract">${esc(c.asset)}</a></td><td>${esc(c.version)}</td><td>${pill(c.status === "active" ? "ok" : "warn", c.status)}</td><td>${c.last_validation?.ok ? pill("ok", "compatible") : pill("bad", "breaking")}</td></tr>`).join("") || '<tr><td colspan="4" class="empty">No contracts</td></tr>'}</table>
    <p class="sub">CI gate: <code>python -m dqga contract-check contract.yaml</code> exits non-zero on breaking changes.</p></div>
  <div class="card"><h2>Import a contract</h2><textarea id="ci" placeholder="Paste ODCS YAML"></textarea><div class="sp"></div>
    <button class="btn primary" onclick="act(this, () => post('/contracts', {yaml: $('#ci').value}), r => 'Imported; ' + r.rules_created.length + ' rules created')">Import</button></div></div>`;
};

/* ------------------------------------------------------------------ info icons: a short line on the page, the detail one click away */
const INFO = {
  rules: { title: "Data quality rules", short: "Checks on the data itself: are the values correct right now?",
    points: ["Read actual values: nulls, ranges, formats, uniqueness, freshness and business logic.", "Apply to one dataset or column.",
      "Written by stewards or proposed by AI Rule Studio, then reviewed by an administrator before they run.", "Run on each check or on a schedule (Operate > Runs).",
      "A failure opens an <strong>incident</strong> with root cause and lineage.", "Example: <code>meter_reading &gt;= 0</code>."], doc: "ui-guide/ai-rule-studio" },
  policies: { title: "Policies", short: "Governance requirements across many datasets: is this dataset governed the way we require?",
    points: ["Look at metadata, not values: owner, steward, DQ score, contract, masking of sensitive columns, certification.", "Apply to many datasets at once: all, a domain, certified ones, a platform, or those holding sensitive data.",
      "Created by administrators with no review step: Suggest, a plain-English sentence, or a form.", "Checked when you scan in Operate > Violations.",
      "A failure is a <strong>violation</strong>, sometimes with an Enforce action (mask, retention delete) that runs at once.", "Example: every certified dataset needs an owner, a contract and 3 active rules.", "AI rule generation reads the policies that apply: a retention policy sets the retention rule, and proposals that serve a policy are tagged Policy."], doc: "ui-guide/governance" },
  contracts: { title: "Data contracts", short: "What the producer promised consumers about a dataset: schema, freshness and quality.",
    points: ["Describe structure: columns, types, nullability, freshness SLA and quality expectations (ODCS v3).", "Apply to one dataset and one version.",
      "Written by the producer or owner; can be generated from a dataset's active rules, or imported as YAML.", "Validated against the live schema, in CI (<code>contract-check</code>) or on the dataset's Contract tab.",
      "A failure is a <strong>breaking change</strong>, such as a dropped or retyped column.", "Importing a contract creates matching quality rules and the freshness SLA.", "AI rule generation reads it too: promises no active rule covers become proposals tagged Contract."], doc: "ui-guide/governance" },
  violations: { title: "Violations", short: "What your policies find wrong, kept from each scan.",
    points: ["A scan checks every enabled policy against what the app knows (metadata only, no data queries).", "Each scan is saved, so you see what is <strong>new</strong> and what was <strong>resolved</strong>.",
      "The first scan has nothing to compare with.", "Run it by hand, or schedule it (administrators).", "Data value problems are not here: they are incidents, from quality rules."], doc: "ui-guide/violations", col: "policies" },
  standards: { title: "Standards", short: "How your catalog stands against GDPR, SOX and others, and which policies would cover them.",
    points: ["Each control is met, partial or a gap, scored from facts the app tracks.", "Shows which policy types cover the standard, and suggests the missing ones.",
      "Upload your own standard: a configured model reads it and proposes policies, checked against your real datasets.", "Mapping guidance to organize evidence, not legal advice."], doc: "ui-guide/governance", col: "policies" },
};
const INFO_TABLE = [["Question", "Is the data correct now?", "Is it governed as required?", "What was promised to consumers?"],
  ["Looks at", "Actual values", "Metadata", "Schema, freshness, quality terms"], ["Scope", "One dataset or column", "Many datasets", "One dataset, one version"],
  ["Written by", "Stewards or AI, reviewed", "Administrators, directly", "Producer or owner"], ["Run by", "Runs", "Violation scans", "Schema validation"],
  ["Failure is", "An incident", "A violation", "A breaking change"]];
const Info = {
  btn(key) { return `<button class="info-btn" aria-label="About ${esc(INFO[key].title)}" title="${esc(INFO[key].short)}" onclick="Info.open('${key}')">i</button>`; },
  line(key) { return `<span class="sub">${esc(INFO[key].short)} ${Info.btn(key)}</span>`; },
  open(key) {
    const i = INFO[key], col = { rules: 1, policies: 2, contracts: 3 }[i.col || key];
    const cell = (v, c) => `<td ${c === col ? 'style="background:var(--info-bg);font-weight:600"' : ""}>${esc(v)}</td>`;
    Modal.open(`${Modal.head(i.title, esc(i.short))}<div class="modal-body">
      <ul style="margin:0 0 12px 18px;padding:0">${i.points.map((p) => `<li style="margin:3px 0">${p}</li>`).join("")}</ul>
      <h3 style="margin:10px 0 6px;font-size:14px">Rules, policies and contracts</h3>
      <table class="t"><tr><th></th><th>Quality rules</th><th>Policies</th><th>Data contracts</th></tr>${INFO_TABLE.map((r) => `<tr><td class="sub">${esc(r[0])}</td>${r.slice(1).map((v, c) => cell(v, c + 1)).join("")}</tr>`).join("")}</table>
      <p class="sub" style="margin:10px 0 0">They connect: a policy can require a contract or enough active rules, and importing a contract creates rules. Rules catch bad data, contracts catch broken promises, policies catch missing governance.</p></div>
      <div class="modal-foot"><a class="btn" href="#/guide/${esc(i.doc)}" onclick="Modal.close()">Read more in the guide</a><button class="btn primary" onclick="Modal.close()">Close</button></div>`, { wide: true });
  },
};

/* ------------------------------------------------------------------ Operate > Violations: scan policies, see what is wrong, what is new and what was fixed */
const SCAN_SCHEDULE_CHOICES = CADENCE_CHOICES;
const Vio = {
  f: { sev: "", pol: "", nw: false, q: "" },
  set(k, v) { Vio.f[k] = v; render(true); },
  async scan(btn) {
    btn.disabled = true;
    try {
      const r = await post("/policy-scans/run");
      toastOk(!r.total ? "No violations. Every enabled policy is met." : Vio.known === false ? `${r.total} violation(s) found. Later scans show what is new and what was fixed.`
        : `${r.total} violation(s): ${r.new_count} new, ${r.resolved_count} resolved since the last scan.`);
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  schedule(s) {
    const cad = s.cadence === "daily" ? "daily" : String(s.every_minutes || 60);
    const days = new Set(s.weekdays || []);
    const opt = (v, l) => `<option value="${esc(v)}" ${cad === String(v) ? "selected" : ""}>${esc(l)}</option>`;
    Modal.open(`${Modal.head("Scan schedule", "Scans every enabled policy on a cadence and keeps each result. Times are UTC.")}
      <div class="modal-body">
        <div class="grid g2"><label class="f">When<select id="vs-cad" onchange="Vio.cadSync()">${SCAN_SCHEDULE_CHOICES.map(([v, l]) => opt(v, l)).join("")}</select></label>
          <label class="f" id="vs-time-wrap">Time of day (UTC)<input id="vs-time" type="time" value="${esc(s.at_time || "06:00")}"></label></div>
        <div id="vs-days-wrap" style="margin-top:8px"><span class="sub">On these days (none ticked means every day):</span>
          <div class="btns" style="margin-top:4px">${WEEKDAYS.map((w, i) => `<label class="row sub" style="gap:4px"><input type="checkbox" class="vs-day" value="${i}" ${days.has(i) ? "checked" : ""}> ${w}</label>`).join("")}</div></div>
        <label class="row sub" style="gap:8px;margin-top:12px"><input type="checkbox" id="vs-on" ${s.enabled ? "checked" : ""}> Scan on this schedule</label>
      </div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn primary" onclick="Vio.saveSchedule(this)">Save</button></div>`);
    Vio.cadSync();
  },
  cadSync() { const d = $("#vs-cad").value === "daily"; $("#vs-time-wrap").hidden = !d; $("#vs-days-wrap").hidden = !d; },
  async saveSchedule(btn) {
    const cad = $("#vs-cad").value, daily = cad === "daily";
    btn.disabled = true;
    try {
      const r = await api("/policy-scans/schedule", { method: "PUT", body: { enabled: $("#vs-on").checked, cadence: daily ? "daily" : "interval",
        every_minutes: daily ? null : Number(cad), at_time: daily ? $("#vs-time").value : null,
        weekdays: daily ? [...document.querySelectorAll(".vs-day:checked")].map((c) => Number(c.value)) : [] } });
      Modal.close();
      toastOk(r.enabled ? `Scanning ${r.text}.` : "Scheduled scans are off.");
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
};

Explore.violations = async () => {  // Explore > Violations (the platform picker is in the Explore header)
  const [latest, hist] = await Promise.all([api("/policy-scans/latest"), api("/policy-scans?limit=12")]);
  const scan = latest.scan, sch = latest.schedule, admin = iAmAdmin(), canScan = !iAmViewer();
  Vio.known = !!scan;
  const head = (extra = "") => `<div class="row" style="gap:8px;margin-bottom:10px"><span class="sub" style="flex:1">What your policies find wrong, scanned on demand or on a schedule ${Info.btn("violations")}</span>${extra}</div>`;
  if (!scan) {
    return head() + `<div class="card empty-card"><h2>No scan yet</h2><p class="sub">A scan checks every enabled policy against what the app knows about your datasets (owners, scores, rules, contracts and detected sensitive columns).
      It does not query your data. Each scan is kept, so you can see what is new and what was fixed.</p>
      ${canScan ? '<button class="btn primary" onclick="Vio.scan(this)">Run first scan</button>' : '<p class="sub">Ask a steward or administrator to run the first scan.</p>'}
      <p class="sub" style="margin-top:10px">No policies yet? Create them in <a href="#/governance/policies">Governance &gt; Policies</a>.</p></div>`;
  }
  const f = Vio.f;
  const all = scan.violations.filter((x) => !State.platform || x.platform === State.platform);
  const rows = all.filter((x) => (!f.sev || x.severity === f.sev) && (!f.pol || x.policy === f.pol) && (!f.nw || x.new)
    && (!f.q || (x.asset + " " + (x.column || "") + " " + x.message + " " + x.policy).toLowerCase().includes(f.q.toLowerCase())));
  const sev = {};
  all.forEach((x) => { sev[x.severity] = (sev[x.severity] || 0) + 1; });
  const pols = [...new Set(scan.violations.map((x) => x.policy))].sort();
  const tile = (l, v, tone, sub) => `<div class="card kpi"><div class="label">${l}</div><div class="value ${tone || ""}">${v}</div>${sub ? `<div class="sub">${sub}</div>` : ""}</div>`;
  const first = hist.length === 1;
  const schedLine = sch.enabled ? `Scanning ${esc(sch.text || "")}${sch.next_run ? `, next ${ts(sch.next_run)}` : ""}` : "Not scheduled";
  return head(canScan ? '<button class="btn primary" onclick="Vio.scan(this)">Run scan</button>' : "") + `
  <p class="sub" style="margin:0 0 12px">Last scan <strong>${ts(scan.ts)}</strong> (${esc(scan.trigger)}${scan.actor && scan.trigger === "manual" ? " by " + esc(scan.actor) : ""}): ${scan.policies} policies on ${scan.datasets} datasets in ${scan.duration_s}s.
    ${schedLine}. ${admin ? '<a href="#" onclick="event.preventDefault(); Vio.schedule(' + esc(JSON.stringify(sch)) + ')">Change schedule</a>' : ""}</p>
  <div class="grid g4">${tile("Violations", scan.total, scan.total ? "bad" : "ok", State.platform ? `${all.length} on this platform` : "")}
    ${tile("New since last scan", first ? "-" : scan.new_count, !first && scan.new_count ? "bad" : "", first ? "first scan, nothing to compare" : "")}
    ${tile("Resolved", first ? "-" : scan.resolved_count, !first && scan.resolved_count ? "ok" : "", "")}
    ${tile("By severity", ["critical", "high", "medium", "low"].filter((s) => sev[s]).map((s) => pill(s, `${sev[s]} ${s}`)).join(" ") || pill("ok", "none"), "", "")}</div>
  <div class="sp"></div>
  <div class="card wrap"><div class="row" style="gap:8px;margin-bottom:8px;flex-wrap:wrap">
    <select aria-label="Severity" onchange="Vio.set('sev', this.value)"><option value="">All severities</option>${["critical", "high", "medium", "low"].map((s) => `<option value="${s}" ${f.sev === s ? "selected" : ""}>${s}</option>`).join("")}</select>
    <select aria-label="Policy" onchange="Vio.set('pol', this.value)"><option value="">All policies</option>${pols.map((p) => `<option value="${esc(p)}" ${f.pol === p ? "selected" : ""}>${esc(p)}</option>`).join("")}</select>
    <label class="row sub" style="gap:4px"><input type="checkbox" ${f.nw ? "checked" : ""} onchange="Vio.set('nw', this.checked)"> New only</label>
    <input type="search" placeholder="Search dataset, column or issue" value="${esc(f.q)}" onchange="Vio.set('q', this.value)" style="min-width:220px">
    <span class="grow"></span><span class="sub">${rows.length} of ${all.length}</span></div>
    ${violationTable(rows)}</div>
  <div class="sp"></div>
  <div class="card wrap"><h2>Scan history</h2><table class="t"><tr><th>When</th><th>Trigger</th><th class="num">Violations</th><th class="num">New</th><th class="num">Resolved</th><th class="num">Policies</th></tr>
    ${hist.map((h, i) => `<tr><td>${ts(h.ts)}</td><td>${esc(h.trigger)}</td><td class="num">${h.total}</td><td class="num">${i === hist.length - 1 ? "-" : h.new_count}</td><td class="num">${i === hist.length - 1 ? "-" : h.resolved_count}</td><td class="num">${h.policies}</td></tr>`).join("")}</table></div>`;
};

/* ------------------------------------------------------------------ Governance > Policies and Standards */
const POLICY_TYPES = [["masking", "Mask sensitive data"], ["retention", "Retention limit"], ["ownership", "Owner and steward required"], ["quality_gate", "Minimum DQ score"],
  ["classification_required", "Scan for sensitive data"], ["certification", "Certification requirements"], ["contract_required", "Data contract required"]];
const POLICY_SOURCE = { file: "policies.yaml", manual: "manual", nl: "plain English", suggested: "suggested", standard: "standard", upload: "uploaded standard" };
const SCOPES = [["all", "All datasets"], ["domain", "A domain"], ["fqn_pattern", "Name pattern"], ["certified", "Certified datasets"], ["uncertified", "Uncertified datasets"], ["platform", "A platform"], ["classification", "Datasets with sensitive data"]];
const SENS_LABELS = ["email", "phone", "ssn", "credit_card", "person_name", "address", "iban", "date_of_birth", "passport", "national_id", "ip_address", "geo_location"];

function scopeText(ap) {
  ap = ap || {};
  if (ap.all) return "All datasets";
  const out = [];
  if (ap.domain) out.push("domain " + [].concat(ap.domain).join(", "));
  if (ap.fqn_pattern) out.push(ap.fqn_pattern);
  if ("certified" in ap) out.push(ap.certified ? "certified" : "uncertified");
  if (ap.platform) out.push(PLATFORMS[ap.platform] || ap.platform);
  if (ap.classification) out.push("holding " + [].concat(ap.classification).join(", "));
  return out.join(" · ") || "-";
}
function scopeFromSpec(ap) {
  ap = ap || {};
  if (ap.domain) return ["domain", [].concat(ap.domain).join(", ")];
  if (ap.fqn_pattern) return ["fqn_pattern", ap.fqn_pattern];
  if ("certified" in ap) return [ap.certified ? "certified" : "uncertified", ""];
  if (ap.platform) return ["platform", ap.platform];
  if (ap.classification) return ["classification", [].concat(ap.classification).join(", ")];
  return ["all", ""];
}
const splitList = (s) => String(s || "").split(",").map((x) => x.trim()).filter(Boolean);

const Pol = {
  tab: "suggest",
  sugg: null,
  draftRes: null,
  form: null,
  setTab(t) { Pol.readForm(); Pol.tab = t; render(true); },
  blankForm() { return { id: "", type: "ownership", severity: "", description: "", scope: "all", scopeVal: "", labels: "email, phone", column: "", max_age_days: 1095, owner: true, steward: false, min_score: 95, min_rules: 3, except_group: "pii_readers", enabled: true }; },
  fromSpec(sp) {
    const [scope, scopeVal] = scopeFromSpec(sp.applies_to), req = sp.require || ["owner"];
    return { ...Pol.blankForm(), id: sp.id, type: sp.type, severity: sp.severity || "", description: sp.description || "", scope, scopeVal, labels: (sp.labels || []).join(", "), column: sp.column || "",
      max_age_days: sp.max_age_days || 1095, owner: req.includes("owner"), steward: req.includes("steward"), min_score: sp.min_score ?? 95, min_rules: sp.min_rules || 3, except_group: sp.except_group || "pii_readers", enabled: sp.enabled !== false };
  },
  readForm() {
    if (!$("#pf-id")) return;
    const g = (id) => $("#" + id), F = Pol.form || Pol.blankForm();
    Pol.form = { ...F, id: g("pf-id").value, type: g("pf-type").value, severity: g("pf-sev").value, description: g("pf-desc").value, scope: g("pf-scope").value,
      scopeVal: g("pf-scopeval") ? g("pf-scopeval").value : "", labels: g("pf-labels") ? g("pf-labels").value : F.labels, column: g("pf-col") ? g("pf-col").value : F.column,
      max_age_days: g("pf-days") ? g("pf-days").value : F.max_age_days, owner: g("pf-owner") ? g("pf-owner").checked : F.owner, steward: g("pf-steward") ? g("pf-steward").checked : F.steward,
      min_score: g("pf-score") ? g("pf-score").value : F.min_score, min_rules: g("pf-rules") ? g("pf-rules").value : F.min_rules, except_group: g("pf-grp") ? g("pf-grp").value : F.except_group };
  },
  formChanged() { Pol.readForm(); render(true); },
  specFromForm() {
    Pol.readForm();
    const f = Pol.form, ap = {};
    if (f.scope === "all") ap.all = true;
    else if (f.scope === "domain") ap.domain = splitList(f.scopeVal);
    else if (f.scope === "fqn_pattern") ap.fqn_pattern = f.scopeVal.trim();
    else if (f.scope === "certified") ap.certified = true;
    else if (f.scope === "uncertified") ap.certified = false;
    else if (f.scope === "platform") ap.platform = f.scopeVal.trim();
    else if (f.scope === "classification") ap.classification = splitList(f.scopeVal);
    const s = { id: f.id.trim(), type: f.type, applies_to: ap, enabled: f.enabled };
    if (f.severity) s.severity = f.severity;
    if (f.description.trim()) s.description = f.description.trim();
    if (f.type === "masking") { s.labels = splitList(f.labels); s.except_group = f.except_group.trim() || "pii_readers"; }
    if (f.type === "retention") { s.column = f.column.trim(); s.max_age_days = Number(f.max_age_days); }
    if (f.type === "ownership") s.require = [f.owner ? "owner" : null, f.steward ? "steward" : null].filter(Boolean);
    if (f.type === "quality_gate") s.min_score = Number(f.min_score);
    if (f.type === "certification") s.min_rules = Number(f.min_rules);
    return s;
  },
  async saveForm(btn) {
    const s = Pol.specFromForm();
    btn.disabled = true;
    try { await post("/policies", { ...s, source: "manual" }); Pol.form = null; toastOk(`Policy ${s.id} saved.`); await render(true); } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  async saveJson(btn) {
    let s;
    try { s = JSON.parse($("#pf-json").value); } catch (e) { return toastError("That is not valid JSON: " + e.message); }
    btn.disabled = true;
    try { await post("/policies", { ...s, source: "manual" }); toastOk(`Policy ${s.id} saved.`); await render(true); } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  edit(key, pols) {
    const p = (pols || Pol.list || []).find((x) => x.key === key);
    if (!p) return;
    Pol.form = Pol.fromSpec({ ...p.spec, id: p.key, type: p.type, enabled: p.enabled });
    Pol.tab = "manual";
    render(false);
  },
  async toggle(key, on) { try { await api("/policies/" + encodeURIComponent(key), { method: "PATCH", body: { enabled: on } }); await render(true); } catch (e) { toastError(e.message); render(true); } },
  askDelete(key) {
    Modal.open(`${Modal.head("Delete policy " + key + "?")}<div class="modal-body"><p>Its violations disappear at the next scan. The policy cannot be recovered; you can create it again.</p></div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn danger" onclick="Pol.del(this, ${jsq(key)})">Delete</button></div>`);
  },
  async del(btn, key) {
    btn.disabled = true;
    try { await api("/policies/" + encodeURIComponent(key), { method: "DELETE" }); Modal.close(); toastOk("Policy deleted."); await render(true); } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  async suggest(btn) {
    btn.disabled = true;
    try {
      Pol.sugg = await post("/policies/suggest", { standards: $("#ps-std").value ? [$("#ps-std").value] : [], use_uploads: $("#ps-up").checked });
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  async suggestFor(std) { Pol.tab = "suggest"; Pol.sugg = await post("/policies/suggest", { standards: std ? [std] : [], use_uploads: true }).catch((e) => { toastError(e.message); return null; }); Pol.std = std || ""; location.hash = "#/governance/policies"; render(false); },
  async saveSugg(i, btn) {
    const x = Pol.sugg.suggestions[i];
    btn.disabled = true;
    try {
      await post("/policies", { ...x.spec, source: x.source === "upload" ? "upload" : x.standards.length ? "standard" : "suggested" });
      Pol.sugg.suggestions.splice(i, 1);
      toastOk(`Policy ${x.spec.id} saved. Run a scan in Violations to see what it finds.`);
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  async draft(btn) {
    const text = $("#pn-text").value;
    Pol.text = text;
    btn.disabled = true;
    try { Pol.draftRes = await post("/policies/draft", { text }); await render(true); } catch (e) { btn.disabled = false; Pol.draftRes = null; toastError(e.message); }
  },
  async saveDraft(btn) {
    btn.disabled = true;
    try { const s = Pol.draftRes.spec; await post("/policies", { ...s, source: "nl", description: s.description || Pol.text }); toastOk(`Policy ${s.id} saved.`); Pol.draftRes = null; Pol.text = ""; await render(true); } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  editDraft() { Pol.form = Pol.fromSpec(Pol.draftRes.spec); Pol.tab = "manual"; render(false); },
  wouldFlag(w) { return w ? (w.count ? pill("warn", `would flag ${w.count} now`) : pill("ok", "would flag nothing now")) : ""; },
  card(x, actions) {
    return `<div class="card" style="margin-bottom:8px"><div class="row" style="gap:8px;flex-wrap:wrap"><strong>${esc(x.interpretation)}</strong><span class="grow"></span>${Pol.wouldFlag(x.would_flag)}</div>
      ${x.reason ? `<div class="sub" style="margin-top:4px">${esc(x.reason)}</div>` : ""}
      <div class="sub mono" style="margin-top:4px">${esc(x.spec.id)} · ${esc(x.spec.type)} · ${esc(x.spec.severity)}${(x.controls || []).length ? " · " + esc(x.controls.join(", ")) : ""}</div>
      ${x.would_flag && x.would_flag.examples.length ? `<div class="sub" style="margin-top:4px">For example: ${x.would_flag.examples.map((e) => esc(short(e.asset) + (e.column ? "." + e.column : "") + ": " + e.message)).join("; ")}</div>` : ""}
      <div class="btns" style="margin-top:8px">${actions}</div></div>`;
  },
  suggestTab(stds) {
    const s = Pol.sugg;
    const opts = `<option value="">What my data shows</option>${stds.map((f) => `<option value="${f.framework}" ${Pol.std === f.framework ? "selected" : ""}>${esc(f.title)}</option>`).join("")}`;
    return `<p class="sub">Ideas drawn from your data and the standard you pick. Nothing is saved until you save it.</p>
      <div class="row" style="gap:8px;flex-wrap:wrap"><label class="f" style="margin:0">Based on<select id="ps-std" onchange="Pol.std=this.value">${opts}</select></label>
        <label class="row sub" style="gap:6px;margin-top:18px"><input type="checkbox" id="ps-up" checked> Include uploaded standards</label>
        <button class="btn primary" style="margin-top:18px" onclick="Pol.suggest(this)">Suggest policies</button></div>
      ${s ? `<div class="sp"></div>${(s.notes || []).map((n) => `<div class="callout warn">${esc(n)}</div>`).join("")}
        ${s.suggestions.length ? s.suggestions.map((x, i) => Pol.card(x, `<button class="btn primary sm" onclick="Pol.saveSugg(${i}, this)">Save policy</button>
          <button class="btn sm" onclick="Pol.form = Pol.fromSpec(Pol.sugg.suggestions[${i}].spec); Pol.tab = 'manual'; render(false)">Edit first</button>`)).join("")
          : '<div class="empty">Nothing new to suggest. The policies you have already cover these signals.</div>'}` : ""}`;
  },
  plainTab() {
    const d = Pol.draftRes;
    return `<p class="sub">Write the requirement in a sentence. Common ones are understood directly; anything else is read by the model chosen in Settings &gt; LLM. You see the result and how many violations it would raise before saving.</p>
      <textarea id="pn-text" rows="2" placeholder="e.g. certified datasets must keep a DQ score of at least 95">${esc(Pol.text || "")}</textarea>
      <div class="sub" style="margin:4px 0 8px">Examples: ${["customer emails and phone numbers must be masked", "every dataset needs an owner and a steward", "finance datasets need a data contract"].map((e) =>
        `<a href="#" onclick="event.preventDefault(); $('#pn-text').value = ${jsq(e)}">${esc(e)}</a>`).join(" · ")}</div>
      <button class="btn primary" onclick="Pol.draft(this)">Draft policy</button>
      ${d ? `<div class="sp"></div>${Pol.card({ ...d, reason: d.parser === "llm" ? "Read by the model. Check it says what you meant." : "" }, `<button class="btn primary sm" onclick="Pol.saveDraft(this)">Save policy</button><button class="btn sm" onclick="Pol.editDraft()">Edit first</button>`)}` : ""}`;
  },
  manualTab(domains) {
    const f = Pol.form || (Pol.form = Pol.blankForm()), v = (x) => esc(x ?? "");
    const t = f.type, needVal = ["domain", "fqn_pattern", "platform", "classification"].includes(f.scope);
    const json = JSON.stringify(Pol.specFromFormSafe(), null, 2);
    return `<div class="grid g2">
      <label class="f">Policy id<input id="pf-id" value="${v(f.id)}" placeholder="e.g. pii-masking" onchange="Pol.readForm()"></label>
      <label class="f">What it requires<select id="pf-type" onchange="Pol.formChanged()">${POLICY_TYPES.map(([k, l]) => `<option value="${k}" ${t === k ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label>
      <label class="f">Applies to<select id="pf-scope" onchange="Pol.formChanged()">${SCOPES.map(([k, l]) => `<option value="${k}" ${f.scope === k ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label>
      ${needVal ? `<label class="f">${f.scope === "domain" ? "Domain(s), comma separated" : f.scope === "fqn_pattern" ? "Name pattern, e.g. utility.finance.*" : f.scope === "platform" ? "Platform, e.g. databricks" : "Sensitive-data labels, comma separated"}
        <input id="pf-scopeval" value="${v(f.scopeVal)}" ${f.scope === "domain" ? 'list="pf-doms"' : ""}><datalist id="pf-doms">${domains.map((d) => `<option value="${esc(d)}">`).join("")}</datalist></label>` : "<span></span>"}
      ${t === "masking" ? `<label class="f">Labels to mask, comma separated<input id="pf-labels" value="${v(f.labels)}" list="pf-labs"><datalist id="pf-labs">${SENS_LABELS.map((d) => `<option value="${d}">`).join("")}</datalist></label>
        <label class="f">Group that may see them<input id="pf-grp" value="${v(f.except_group)}"></label>` : ""}
      ${t === "retention" ? `<label class="f">Date column<input id="pf-col" value="${v(f.column)}" placeholder="e.g. reading_ts"></label><label class="f">Keep for (days)<input id="pf-days" type="number" min="1" value="${v(f.max_age_days)}"></label>` : ""}
      ${t === "ownership" ? `<div class="f">Each dataset needs<div class="row" style="gap:14px"><label class="row sub" style="gap:4px"><input type="checkbox" id="pf-owner" ${f.owner ? "checked" : ""}> an owner</label>
        <label class="row sub" style="gap:4px"><input type="checkbox" id="pf-steward" ${f.steward ? "checked" : ""}> a steward</label></div></div>` : ""}
      ${t === "quality_gate" ? `<label class="f">Minimum DQ score (0-100)<input id="pf-score" type="number" min="0" max="100" value="${v(f.min_score)}"></label>` : ""}
      ${t === "certification" ? `<label class="f">Minimum active rules<input id="pf-rules" type="number" min="1" value="${v(f.min_rules)}"></label>` : ""}
      <label class="f">Severity<select id="pf-sev"><option value="">Default for this type</option>${["critical", "high", "medium", "low"].map((s) => `<option value="${s}" ${f.severity === s ? "selected" : ""}>${s}</option>`).join("")}</select></label>
      <label class="f">Description (optional)<input id="pf-desc" value="${v(f.description)}"></label></div>
      <div class="btns" style="margin-top:10px"><button class="btn primary" onclick="Pol.saveForm(this)">Save policy</button><button class="btn" onclick="Pol.form = null; render(true)">Clear</button></div>
      <details style="margin-top:10px"><summary class="sub">Edit as JSON</summary><textarea id="pf-json" rows="9">${esc(json)}</textarea><div class="sp"></div><button class="btn sm" onclick="Pol.saveJson(this)">Save JSON</button></details>`;
  },
  specFromFormSafe() { try { return Pol.specFromForm(); } catch (e) { return {}; } },
};

GovTabs.policies = async () => {
  const [pols, stds, assets] = await Promise.all([api("/policies"), api("/standards"), Pol.tab === "manual" && iAmAdmin() ? api("/assets") : Promise.resolve([])]);
  Pol.list = pols;
  const admin = iAmAdmin();
  const domains = [...new Set(assets.map((a) => a.domain).filter(Boolean))];
  const tabs = [["suggest", "Suggest"], ["plain", "Plain-English policy"], ["manual", "Manual creation"]];
  const create = admin ? `<div class="card" style="margin-bottom:12px"><h2>Create a policy ${Info.btn("policies")}</h2>
      <p class="sub" style="margin:0 0 8px">A policy is a rule about how datasets must be governed, such as owners, masking or retention. It is checked across many datasets when you scan in Violations.</p>
      <div class="tabs">${tabs.map(([k, l]) => `<a class="${Pol.tab === k ? "active" : ""}" onclick="Pol.setTab('${k}')">${l}</a>`).join("")}</div>
      ${Pol.tab === "suggest" ? Pol.suggestTab(stds.frameworks) : Pol.tab === "plain" ? Pol.plainTab() : Pol.manualTab(domains)}</div>`
    : '<p class="sub">Only administrators create and change policies.</p>';
  return `${create}<div class="card wrap"><h2>Policies (${pols.length}) ${Info.btn("policies")}</h2>
    <p class="sub">Each policy is checked when you scan in <a href="#/explore/violations">Violations</a>. Violation counts are from the last scan.</p>
    ${pols.length ? `<table class="t"><tr><th>Policy</th><th>Applies to</th><th>Severity</th><th>Source</th><th class="num">Violations</th><th>On</th><th></th></tr>
    ${pols.map((p) => `<tr><td><strong class="mono">${esc(p.key)}</strong><div class="sub">${esc(p.description)}</div></td><td class="sub">${esc(scopeText((p.spec || {}).applies_to))}</td><td>${pill(p.severity)}</td>
      <td class="sub">${esc(POLICY_SOURCE[p.source] || p.source || "policies.yaml")}</td>
      <td class="num">${p.violations == null ? '<span class="muted">not scanned</span>' : p.violations ? `<a href="#/explore/violations" onclick="Vio.f = {sev:'', pol:${jsq(p.key)}, nw:false, q:''}">${p.violations}</a>` : "0"}</td>
      <td>${admin ? `<input type="checkbox" ${p.enabled ? "checked" : ""} aria-label="Enabled" onchange="Pol.toggle(${jsq(p.key)}, this.checked)">` : p.enabled ? pill("ok", "yes") : pill("muted", "no")}</td>
      <td class="btns">${admin ? `<button class="btn sm" onclick="Pol.edit(${jsq(p.key)})">Edit</button><button class="btn sm" onclick="Pol.askDelete(${jsq(p.key)})">Delete</button>` : ""}</td></tr>`).join("")}</table>`
    : '<div class="empty">No policies yet. Use Suggest to start from your data or a standard.</div>'}</div>`;
};

GovTabs.standards = async () => {
  const r = await api("/standards");
  const admin = iAmAdmin();
  const fw = r.frameworks.find((x) => x.framework === State.framework) || r.frameworks[0];
  const tl = { masking: "mask sensitive data", retention: "retention limits", ownership: "owner and steward", quality_gate: "minimum DQ score", classification_required: "sensitive-data scan", certification: "certification requirements", contract_required: "data contracts" };
  return `<p class="sub">How your catalog stands against a reference standard, control by control, and which policies would cover it. Mapping guidance to organize evidence; not legal advice. ${Info.btn("standards")}</p>
  <div class="row" style="gap:10px;flex-wrap:wrap"><select aria-label="Standard" onchange="State.framework=this.value;render(true)">${r.frameworks.map((f) => `<option value="${f.framework}" ${f.framework === fw.framework ? "selected" : ""}>${esc(f.title)}</option>`).join("")}</select>
    <span>${pill("met", fw.summary.met + " met")} ${pill("partial", fw.summary.partial + " partial")} ${pill("gap", fw.summary.gap + " gaps")}</span></div><div class="sp"></div>
  <div class="card wrap"><table class="t"><tr><th>Control</th><th>Requirement</th><th>Status</th><th>Evidence</th></tr>
    ${fw.controls.map((c) => `<tr><td class="mono">${esc(c.id)}</td><td>${esc(c.title)}</td><td>${pill(c.status)}</td><td class="sub">${esc(c.evidence)}</td></tr>`).join("")}</table></div><div class="sp"></div>
  <div class="grid g2"><div class="card"><h2>Policies for this standard</h2>
    <div style="margin:6px 0">${fw.recommended_types.map((t) => pill(fw.covered_types.includes(t) ? "ok" : "warn", (fw.covered_types.includes(t) ? "covered: " : "missing: ") + (tl[t] || t))).join(" ")}</div>
    ${admin ? `<button class="btn primary" onclick="Pol.suggestFor('${fw.framework}')">Suggest policies for ${esc(fw.title.split(" (")[0])}</button>` : '<p class="sub">Administrators can create policies from here.</p>'}</div>
  <div class="card wrap"><h2>Your own standards</h2><p class="sub">Upload an internal policy, regulation or standard. When a model is configured in Settings &gt; LLM, Suggest reads it and proposes policies, checked against your real datasets and columns.</p>
    ${r.uploads.length ? `<table class="t">${r.uploads.map((d) => `<tr><td>${esc(d.name)}</td><td>${d.status === "error" ? pill("bad", "unreadable") : pill("ok", "ready")}</td></tr>`).join("")}</table>` : '<div class="empty">None uploaded yet</div>'}
    <div class="btns" style="margin-top:8px">${admin ? '<button class="btn" onclick="Refs.upload(() => render(true), {kind: \'policy\'})">Upload a standard</button>' : ""}
      ${admin && r.uploads.length ? '<button class="btn" onclick="Pol.suggestFor(\'\')">Suggest from my standards</button>' : ""}</div></div></div>`;
};

Pages.settings = async (tab = "connections") => {
  const tabs = ["connections", "llm", ...(gitOn() ? ["git"] : []), "environment", "scheduler", "notifications", "audit", "maintenance"];
  const body = await (SetTabs[tab] || SetTabs.connections)();
  return `<div class="page-head"><h1>Settings</h1><span class="sub">Connections, the LLM, environment variables, scheduling, alerts, audit and maintenance</span><span class="grow"></span>
    ${isAdminUser() ? '<button class="btn danger" onclick="Maint.start()" title="Erase the application database and start fresh">Reset app data…</button>' : ""}</div>
  <div class="tabs">${tabs.map((t) => `<a href="#/settings/${t}" class="${t === tab ? "active" : ""}">${t === "llm" ? "LLM" : t === "git" ? "Git" : t[0].toUpperCase() + t.slice(1)}</a>`).join("")}</div>${body}`;
};
const SetTabs = {};
const gitOn = () => !!(State.meta && State.meta.features && State.meta.features.git_sync);
const isAdminUser = () => !State.user || State.user.role === "admin";

/* Optional GitHub sync (features.git_sync): Settings > Git, and Export to Git in the Rule catalog. */
const Git = {
  async save(btn) {
    btn.disabled = true;
    try {
      const body = { repo: $("#g-repo").value, branch: $("#g-branch").value, folder: $("#g-folder").value, mode: $("#g-mode").value, api_url: $("#g-api").value || null };
      const t = $("#g-token").value;
      if (t) body.token = t;
      await api("/git", { method: "PUT", body });
      toastOk("Saved. Use Test connection to check it.");
      await render(true);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  async test(btn) {
    btn.disabled = true;
    try {
      const r = await post("/git/test");
      (r.ok ? toastOk : toastError)(r.detail);
    } catch (e) { toastError(e.message); }
    btn.disabled = false;
  },
  async remove() {
    if (!confirm("Remove the repository and its saved token? Rules in the app and files in the repository are not touched.")) return;
    try { await api("/git", { method: "DELETE" }); toastOk("Git is no longer configured."); await render(true); } catch (e) { toastError(e.message); }
  },
  async exportOpen() {
    let g;
    try { g = await api("/git"); } catch (e) { return toastError(e.message); }
    if (!g.configured) { toastError("Connect a repository first in Settings > Git."); location.hash = "#/settings/git"; return; }
    const one = Catalog.st.scope === "asset" && Catalog.asset;
    const pr = g.mode === "pr";
    Modal.open(`${Modal.head("Export rules to Git", `${esc(g.repo)}, branch ${esc(g.branch)}, folder ${esc(g.folder)}`)}
      <div class="modal-body" id="gx-body">
        <p style="margin:0 0 8px">${pr ? `Opens a <strong>pull request</strong> from a new branch. Nothing changes on ${esc(g.branch)} until it is merged.` : `Commits straight to <strong>${esc(g.branch)}</strong>.`}
          Files are added or updated; nothing in the repository is deleted.</p>
        <label class="row sub" style="gap:6px"><input type="radio" name="gx-scope" value="one" ${one ? "checked" : "disabled"}> This dataset${one ? ` (${esc(short(Catalog.asset.fqn))})` : ""}</label>
        <label class="row sub" style="gap:6px"><input type="radio" name="gx-scope" value="all" ${one ? "" : "checked"}> All datasets with rules</label>
        <label class="row sub" style="gap:6px;margin-top:8px"><input type="checkbox" id="gx-drafts"> Include saved drafts (default: active and disabled rules)</label>
        <label class="f" style="margin-top:8px">Commit message (optional)<input id="gx-msg" placeholder="Update DQ rules"></label>
      </div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn primary" onclick="Git.doExport(this)">${pr ? "Open pull request" : "Commit"}</button></div>`);
  },
  async doExport(btn) {
    btn.disabled = true;
    const one = (document.querySelector('input[name="gx-scope"]:checked') || {}).value === "one";
    try {
      const r = await post("/git/export", { asset_ids: one && Catalog.asset ? [Catalog.asset.id] : null, include_drafts: $("#gx-drafts").checked, message: $("#gx-msg").value || null });
      $("#gx-body").innerHTML = r.status === "unchanged"
        ? `<div class="callout">${esc(r.detail)}</div>`
        : `<div class="callout ok"><strong>${r.mode === "pr" ? "Pull request opened" : "Committed"}</strong>: ${r.files} dataset file(s), commit ${esc(r.commit)}${r.branch ? " on " + esc(r.branch) : ""}.
            ${r.url ? `<br><a href="${esc(r.url)}" target="_blank" rel="noopener">${esc(r.url)}</a>` : ""}</div>`;
      btn.outerHTML = '<button class="btn primary" onclick="Modal.close()">Close</button>';
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
};

SetTabs.git = async () => {
  const g = await api("/git"), admin = isAdminUser(), last = g.last;
  const ro = admin ? "" : "disabled";
  return `<div class="card wrap" style="max-width:760px"><h2>Git: rules as files in GitHub</h2>
    <p class="sub" style="margin:0 0 10px">Optional. Writes the rules as YAML files to a GitHub repository, as a pull request or a commit. The app works fully without it, and rule files can always be downloaded and imported by hand.
      Imported files still arrive as drafts for review.${admin ? "" : " Only administrators change these settings."}</p>
    <div class="grid g2">
      <label class="f">Repository<input id="g-repo" ${ro} placeholder="my-org/data-rules" value="${esc(g.repo || "")}"></label>
      <label class="f">Base branch<input id="g-branch" ${ro} value="${esc(g.branch)}"></label>
      <label class="f">Rules folder<input id="g-folder" ${ro} value="${esc(g.folder)}"></label>
      <label class="f">When exporting<select id="g-mode" ${ro}><option value="pr" ${g.mode === "pr" ? "selected" : ""}>Open a pull request (recommended)</option><option value="commit" ${g.mode === "commit" ? "selected" : ""}>Commit to the base branch</option></select></label>
      <label class="f">Access token<input id="g-token" type="password" autocomplete="off" ${ro} placeholder="${g.token_set ? "saved; leave empty to keep it" : "GitHub token with contents and pull requests access"}"></label>
      <label class="f">GitHub API address<input id="g-api" ${ro} value="${esc(g.api_url)}"></label>
    </div>
    <p class="sub" style="margin:6px 0 0">Use a fine-grained token limited to this one repository, with <em>Contents</em> and <em>Pull requests</em> set to read and write. It is stored encrypted and never shown again. For GitHub Enterprise use https://HOST/api/v3.</p>
    ${admin ? `<div class="btns" style="margin-top:12px"><button class="btn primary" onclick="Git.save(this)">Save</button>
      ${g.configured ? `<button class="btn" onclick="Git.test(this)">Test connection</button><button class="btn danger" onclick="Git.remove()">Remove</button>` : ""}</div>` : ""}
    ${last ? `<p class="sub" style="margin:12px 0 0">Last export ${ts(last.ts)} by ${esc(last.actor)}: ${last.status === "unchanged" ? "nothing had changed" : `${last.files} file(s), commit ${esc(last.commit || "")}`}${last.url ? ` · <a href="${esc(last.url)}" target="_blank" rel="noopener">open</a>` : ""}.</p>` : ""}
  </div>`;
};

/* Connections: test, sync, enable/disable, delete. Outcomes are saved on the connection, so they stay visible. */
const CONN_HEALTH = { ok: ["ok", "connected"], error: ["bad", "error"], disabled: ["muted", "disabled"], untested: ["warn", "not tested"] };
const Conn = {
  async save(btn) {
    let config;
    try { config = JSON.parse($("#c-cfg").value || "{}"); } catch (e) { return toastError("Config must be valid JSON: " + e.message); }
    const name = $("#c-name").value.trim();
    if (!name) return toastError("Give the connection a name");
    btn.disabled = true;
    try {
      const c = await post("/connections", { name, type: $("#c-type").value, config });
      if (c.health === "error") toastError(`Saved ${name}, but it could not start:\n${c.health_detail}`);
      else toastOk(`Saved ${name}. Use Test to check it, then Sync.`);
      await render(true);
    } catch (e) { toastError(e.message); btn.disabled = false; }
  },
  async test(btn, name) {
    btn.disabled = true;
    try {
      const r = await post(`/connections/${encodeURIComponent(name)}/test`);
      if (r.ok) toastOk(`${name}: ${r.detail || "connected"}`);
      else toastError(`Test failed for ${name}:\n${r.detail}`);
      await render(true);
    } catch (e) { toastError(e.message); btn.disabled = false; }
  },
  async sync(btn, name) {
    btn.disabled = true;
    try {
      const r = await post("/catalog/sync" + (name ? `?connection=${encodeURIComponent(name)}` : ""));
      Conn.reportSync(r);
      await render(true);
    } catch (e) { toastError(e.message); btn.disabled = false; }
  },
  reportSync(r) {
    const failed = Object.entries(r.errors || {});
    const lineage = Object.entries((r.lineage && r.lineage.errors) || {});
    if (failed.length) toastError(failed.map(([n, m]) => `Sync failed for ${n}:\n${m}`).join("\n\n"));
    if (!failed.length || r.assets) toastOk(`Synced ${r.assets} datasets (${r.new} new)`);
    if (lineage.length) toastWarn("Datasets synced, but lineage could not be read:\n" + lineage.map(([n, m]) => `${n}: ${m}`).join("\n"));
  },
  async toggle(input, name) {
    const on = input.checked;
    input.disabled = true;
    try {
      const c = await patch(`/connections/${encodeURIComponent(name)}`, { enabled: on });
      if (on && c.health === "error") toastError(`${name} is enabled but could not start:\n${c.health_detail}`);
      else toastOk(on ? `${name} enabled` : `${name} disabled. Checks and syncs will skip it.`);
      await render(true);
    } catch (e) { toastError(e.message); input.checked = !on; input.disabled = false; }
  },
  askDelete(name, assets, inConfig) {
    Modal.open(`${Modal.head("Delete connection " + name)}
      <div class="modal-body">
        <p>The connection is removed from TCS DataTrustAI. Nothing is changed on the platform itself.</p>
        ${assets ? `<label class="row sub" style="gap:8px"><input type="checkbox" id="del-purge" checked>
          Also remove its ${assets} dataset${assets === 1 ? "" : "s"} and their rules, results, profiles and incidents</label>` : ""}
        ${inConfig ? `<div class="callout" style="margin-top:10px">This connection is defined in <code>config.yaml</code>, so it comes back the next time the app starts.
          Remove it from <code>config.yaml</code> as well, or use the <strong>Enabled</strong> switch to turn it off instead.</div>` : ""}
      </div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button>
        <button class="btn danger" onclick="Conn.doDelete(this, ${jsq(name)})">Delete connection</button></div>`);
  },
  async doDelete(btn, name) {
    const purge = $("#del-purge") ? $("#del-purge").checked : true;
    btn.disabled = true;
    try {
      const r = await api(`/connections/${encodeURIComponent(name)}?purge=${purge}`, { method: "DELETE" });
      Modal.close();
      toastOk(`Deleted ${name}` + (r.assets_removed ? ` and ${r.assets_removed} datasets` : "") + (r.assets_kept ? `; kept ${r.assets_kept} datasets` : ""));
      await render(true);
    } catch (e) { toastError(e.message); btn.disabled = false; }
  },
};

SetTabs.connections = async () => {
  const cs = await api("/connections");
  const admin = isAdminUser();
  const tally = cs.reduce((t, c) => ((t[c.health] = (t[c.health] || 0) + 1), t), {});
  const summary = Object.entries(CONN_HEALTH).filter(([k]) => tally[k]).map(([k, [cls, label]]) => pill(cls, `${tally[k]} ${label}`)).join(" ");
  const when = (c) => [c.last_test_at ? "tested " + ts(c.last_test_at) : "", c.last_sync ? "synced " + ts(c.last_sync) : ""].filter(Boolean).join(" · ");
  const rows = cs.map((c) => {
    const [cls, label] = CONN_HEALTH[c.health] || ["muted", c.health];
    const n = jsq(c.name);
    return `<tr class="${c.enabled === false ? "off" : ""}">
    <td><strong>${esc(c.name)}</strong>${c.in_config ? ' <span class="pill info" title="Defined in config.yaml">config.yaml</span>' : ""}
      <div class="sub">${c.capabilities ? ["sql", "tags", "lineage", "timeseries"].filter((k) => c.capabilities[k]).join(", ") : ""}</div></td>
    <td>${plat(c.type)}</td>
    <td class="keep">${pill(cls, label)} <span class="sub">${esc(when(c))}</span>
      <div class="conn-detail ${c.health === "error" ? "bad" : ""}" title="Click to show all" onclick="this.classList.toggle('open')">${esc(c.health_detail || "")}</div></td>
    <td class="num">${c.assets}</td>
    <td class="keep">${admin ? `<label class="switch"><input type="checkbox" ${c.enabled !== false ? "checked" : ""} onchange="Conn.toggle(this, ${n})" aria-label="Enable ${esc(c.name)}"></label>`
      : (c.enabled !== false ? "On" : "Off")}</td>
    <td class="btns">${admin ? `<button class="btn sm" onclick="Conn.test(this, ${n})">Test</button>
      <button class="btn sm" ${c.enabled === false ? 'disabled title="Enable the connection to sync"' : ""} onclick="Conn.sync(this, ${n})">Sync</button>
      <button class="btn sm" onclick="Conn.askDelete(${n}, ${c.assets}, ${c.in_config})">Delete</button>` : ""}</td></tr>`;
  }).join("");
  const examples = {
    databricks: { host_env: "DATABRICKS_HOST", warehouse_id_env: "DATABRICKS_WAREHOUSE_ID", token_env: "DATABRICKS_TOKEN", catalogs: ["main"] },
    snowflake: { account_env: "SNOWFLAKE_ACCOUNT", user_env: "SNOWFLAKE_USER", private_key_file_env: "SNOWFLAKE_KEY_FILE", warehouse: "COMPUTE_WH", databases: ["ANALYTICS"] },
    cognite: { project_env: "CDF_PROJECT", base_url: "https://westeurope-1.cognitedata.com", tenant_id_env: "AZURE_TENANT_ID", client_id_env: "CDF_CLIENT_ID", client_secret_env: "CDF_CLIENT_SECRET" },
    aws_glue: { region: "eu-west-1", databases: ["lake"], athena_output: "s3://my-athena-results/" },
    azure_purview: { account: "my-purview", tenant_id_env: "AZURE_TENANT_ID", client_id_env: "PURVIEW_CLIENT_ID", client_secret_env: "PURVIEW_CLIENT_SECRET" },
    spark: { master: "local[*]" }, duckdb: { path: "data/warehouse.duckdb" },
  };
  const llm = State.meta?.llm || {};
  return `<div class="card wrap"><div class="row" style="margin-bottom:8px"><h2 style="margin:0">Connections</h2><span class="sub">${cs.length} total</span> ${summary}
    <span style="flex:1"></span>${admin && cs.some((c) => c.enabled !== false) ? '<button class="btn sm" onclick="Conn.sync(this)">Sync all enabled</button>' : ""}</div>
  <table class="t"><tr><th>Name</th><th>Platform</th><th>Status</th><th class="num">Datasets</th><th>Enabled</th><th></th></tr>
  ${rows || '<tr><td colspan="6" class="empty">No connections yet. Add one below or in config.yaml.</td></tr>'}</table>
  <p class="sub" style="margin:8px 0 0">Disabled connections keep their datasets and history, but checks, syncs and the scheduler skip them. Click a status message to see all of it.</p></div><div class="sp"></div>
  ${admin ? "" : '<div class="callout">Only administrators can add, test, enable, disable or delete connections.</div><div class="sp"></div>'}
  <div class="grid g2"><div class="card"><h2>Add a connection</h2><p class="sub">Use <code>*_env</code> keys so secrets stay in environment variables, not in the database.</p>
    <div class="grid" style="grid-template-columns:1fr 1fr;gap:8px"><label class="f">Name<input id="c-name" placeholder="databricks-prod"></label>
    <label class="f">Type<select id="c-type" onchange="$('#c-cfg').value=JSON.stringify((${jsq(examples)})[this.value]||{}, null, 2)">${Object.keys(examples).map((t) => `<option>${t}</option>`).join("")}</select></label></div>
    <label class="f" style="margin-top:8px">Config (JSON)<textarea id="c-cfg">${esc(JSON.stringify(examples.databricks, null, 2))}</textarea></label><div class="sp"></div>
    <button class="btn primary" onclick="Conn.save(this)">Save connection</button></div>
  <div class="card"><h2>Agent model</h2><div class="kv"><div>Provider</div><div>${esc(llm.provider || "rules")}</div><div>Model</div><div>${esc(llm.model || "built-in router (no LLM)")}</div></div>
    <p class="sub">One model serves the whole app. Choose the provider, add the API key and test it in <a href="#/settings/llm">Settings > LLM</a>.</p></div>
  <div class="card"><h2>Dataset grouping</h2><div class="kv"><div>Called</div><div>${esc(GL())}</div><div>Taken from</div><div>${esc((State.meta.grouping || {}).source_text || "")}${(State.meta.grouping || {}).source === "tag" ? ` <code>${esc(State.meta.grouping.tag)}</code>` : ""}</div></div>
    <p class="sub">Set in <code>grouping</code> in config.yaml: a table tag, the catalog, the schema, the connection or the owner, plus the label. A value typed on a dataset page is kept through syncs.</p>
    ${isAdminUser() ? '<button class="btn" onclick="act(this, () => post(\'/grouping/reapply\'), r => r.changed + \' of \' + r.datasets + \' datasets regrouped\')">Re-apply to all datasets</button>' : ""}</div></div>`;
};
/* Settings > LLM: saved connections (one is in use) and a form to add or edit them. The one in use serves the whole app. */
const LLM_USED_BY = "the agent, AI rule generation, Plain-English rule and rule suggestions";
SetTabs.llm = async () => {
  const v = await api("/llm");
  LlmSet.v = v;
  if (LlmSet.editId && !v.profiles.some((p) => p.id === LlmSet.editId)) LlmSet.editId = null;
  return `<div id="llm-tab">${LlmSet.html(v)}</div>`;
};
const LlmSet = {
  v: null,
  editId: null,   // saved connection being edited; null = a new one
  form: null,     // values shown in the form
  keyState: null, // key status of the connection in the form
  redraw() { $("#llm-tab").innerHTML = LlmSet.html(LlmSet.v); },
  field(name, spec, cur, admin) {
    const id = "llm-" + name, dis = admin ? "" : "disabled", val = cur[name] ?? (spec.defaults || {})[name] ?? "";
    const label = LlmSet.v.field_labels[name] || name;
    if (name === "azure") return `<label class="row sub" style="gap:8px"><input type="checkbox" id="${id}" ${cur.azure ? "checked" : ""} ${dis}> ${esc(label)}</label>`;
    if (name === "model") return `<label class="f">${esc(label)}<input id="${id}" value="${esc(val)}" ${dis} list="llm-models" autocomplete="off" placeholder="${esc((spec.defaults || {}).model || "")}">
      <datalist id="llm-models">${(spec.models || []).map((m) => `<option value="${esc(m)}">`).join("")}</datalist></label>`;
    if (name === "api_key") {
      const k = LlmSet.keyState || { needed: true, set: false };
      const state = k.set ? `A key is set (${k.source === "env" ? "from the " + esc(k.env) + " environment variable" : "saved in the app"}${k.hint ? ", ends " + esc(k.hint) : ""}). Leave this blank to keep it.`
        : k.needed ? "No key yet." : "";
      return `<label class="f">${esc(label)}<input id="${id}" type="password" autocomplete="new-password" ${dis} placeholder="${k.set && k.source === "saved" ? "•••••••• (saved)" : "Paste the key"}">
        <span class="sub" style="font-weight:400">${state}</span></label>
        <label class="f">Or read it from an environment variable<input id="llm-api_key_env" value="${esc(cur.api_key_env || spec.key_env || "")}" ${dis} placeholder="${esc(spec.key_env || "")}"></label>
        ${k.set && k.source === "saved" && admin ? '<label class="row sub" style="gap:8px"><input type="checkbox" id="llm-clear_key"> Remove the saved key</label>' : ""}`;
    }
    return `<label class="f">${esc(label)}<input id="${id}" value="${esc(val)}" ${dis} autocomplete="off"></label>`;
  },
  list(v, admin) {
    const rows = v.profiles.map((p) => `<tr class="${p.id === LlmSet.editId ? "sel-row" : ""}"><td><strong>${esc(p.name)}</strong></td><td>${esc(p.provider_label)}</td><td class="mono">${esc(p.model || "")}</td>
      <td>${!p.key.needed ? '<span class="muted">not needed</span>' : p.key_unreadable ? pill("bad", "unreadable") : p.key.set ? pill("ok", p.key.source === "env" ? "from " + p.key.env : "saved " + (p.key.hint || "")) : pill("warn", "no key")}</td>
      <td>${p.active ? pill("ok", "in use") : ""}</td>
      <td class="btns">${admin ? `${p.active ? "" : `<button class="btn sm primary" onclick="LlmSet.use(this, '${p.id}')">Use</button>`}
        <button class="btn sm" onclick="LlmSet.edit('${p.id}')">Edit</button><button class="btn sm" onclick="LlmSet.testSaved(this, '${p.id}')">Test</button>
        <button class="btn sm danger" onclick="LlmSet.remove('${p.id}')">Delete</button>` : ""}</td></tr>`).join("");
    return `<div class="card wrap"><div class="row"><h2 style="margin:0">Saved connections</h2><span class="sub">${v.profiles.length} saved. The one marked <strong>in use</strong> serves ${LLM_USED_BY}.</span><span style="flex:1"></span>
      ${admin ? '<button class="btn sm primary" onclick="LlmSet.edit(null)">Add connection</button>' : ""}</div>
      <table class="t" style="margin-top:8px"><tr><th>Name</th><th>Provider</th><th>Model</th><th>API key</th><th></th><th></th></tr>
      ${rows || '<tr><td colspan="6" class="empty">Nothing saved yet. Choose a provider below and click Save.</td></tr>'}
      ${v.source === "config" ? `<tr><td><em>config.yaml / environment</em></td><td>${esc((v.providers[v.active.provider] || {}).label || v.active.provider || "")}</td><td class="mono">${esc(v.active.model || "")}</td><td></td><td>${pill("ok", "in use")}</td><td></td></tr>` : ""}</table>
      <div id="llm-listtest" style="margin-top:8px"></div></div><div class="sp"></div>`;
  },
  html(v) {
    const admin = isAdminUser(), editing = v.profiles.find((p) => p.id === LlmSet.editId);
    if (!LlmSet.form) { LlmSet.form = { ...v.current }; LlmSet.keyState = v.key; }
    const cur = LlmSet.form, spec = v.providers[cur.provider] || v.providers.rules;
    const active = v.active || {};
    return `${LlmSet.list(v, admin)}<div class="grid g2">
      <div class="card"><h2>${editing ? "Edit “" + esc(editing.name) + "”" : "New connection"}</h2>
        <p class="sub">${admin ? "Save adds it to the list and puts it in use." : "Only administrators can change this."}</p>
        <label class="f" style="margin-top:8px">Name<input id="llm-name" value="${esc(editing ? editing.name : "")}" ${admin ? "" : "disabled"} placeholder="e.g. Claude (team key)"></label>
        <label class="f" style="margin-top:8px">Provider<select id="llm-provider" ${admin ? "" : "disabled"} onchange="LlmSet.provider(this.value)">
          ${Object.entries(v.providers).map(([k, p]) => `<option value="${k}" ${k === cur.provider ? "selected" : ""}>${esc(p.label)}</option>`).join("")}</select></label>
        <p class="sub" id="llm-help" style="margin:6px 0">${esc(spec.help || "")}</p>
        <div id="llm-fields" style="display:grid;gap:8px">${spec.fields.map((f) => LlmSet.field(f, spec, cur, admin)).join("")}</div>
        <div id="llm-test" style="margin-top:10px"></div>
        ${admin ? `<div class="btns" style="margin-top:12px"><button class="btn" id="llm-test-btn" onclick="LlmSet.test(this)">Test connection</button>
          <button class="btn primary" onclick="LlmSet.save(this)">${editing ? "Save changes" : "Save and use"}</button>
          ${editing ? '<button class="btn" onclick="LlmSet.edit(null)">Cancel</button>' : ""}
          ${v.source === "app" ? '<button class="btn" onclick="LlmSet.reset(this)" title="Stop using a saved connection; config.yaml and environment variables take over (the list stays)">Use config.yaml instead</button>' : ""}</div>` : ""}</div>
      <div class="card"><h2>In use now</h2>
        <div class="kv"><div>Provider</div><div>${esc((v.providers[active.provider] || {}).label || active.provider || "-")}</div>
          <div>Model</div><div>${esc(active.model || (active.provider === "rules" ? "none, built-in rules" : "-"))}</div>
          <div>Set in</div><div>${v.source === "app" ? "A saved connection" : "config.yaml or environment variables"}</div>
          ${v.updated ? `<div>Last changed</div><div>${esc(ts(v.updated.at))} by ${esc(v.updated.by || "")}</div>` : ""}</div>
        ${active.provider === "error" ? `<div class="callout bad" style="margin-top:10px">The connection in use can't start: ${esc(active.model || "")}</div>` : ""}
        ${(active.provider || "rules") === "rules" ? '<div class="callout" style="margin-top:10px">No model is set. AI rule generation asks for one and stops with an error until you add it; the agent and Plain-English rule use their built-in rules.</div>' : ""}
        <h3 style="margin-top:14px">About API keys</h3>
        <p class="sub">Keys you paste here are stored encrypted in the app database and are never shown again, only the last four characters. The encryption key comes from ${esc(v.secret_key_from)}.
          On Databricks Apps or in a container, set <code>DQGA_SECRET_KEY</code> so saved keys survive a restart. You can also keep the key out of the database and point to an environment variable (for example a Databricks secret).</p></div></div>`;
  },
  edit(pid) {
    const v = LlmSet.v, p = v.profiles.find((x) => x.id === pid);
    LlmSet.editId = p ? p.id : null;
    LlmSet.form = p ? { ...p.form } : { provider: "rules" };
    LlmSet.keyState = p ? p.key : { needed: true, set: false };
    LlmSet.redraw();
    const n = $("#llm-name"); if (n) n.focus();
  },
  provider(p) {
    const v = LlmSet.v, spec = v.providers[p];
    const same = LlmSet.editId && (v.profiles.find((x) => x.id === LlmSet.editId) || {}).provider === p;
    LlmSet.form = same ? { ...v.profiles.find((x) => x.id === LlmSet.editId).form } : { provider: p };
    LlmSet.keyState = same ? v.profiles.find((x) => x.id === LlmSet.editId).key : { needed: spec.key, set: false };
    $("#llm-help").textContent = spec.help || "";
    $("#llm-fields").innerHTML = spec.fields.map((f) => LlmSet.field(f, spec, LlmSet.form, true)).join("");
    $("#llm-test").innerHTML = "";
  },
  collect() {
    const body = { provider: $("#llm-provider").value, name: $("#llm-name").value, profile_id: LlmSet.editId };
    ["model", "base_url", "aws_region", "api_version", "host", "api_key", "api_key_env"].forEach((f) => { const el = $("#llm-" + f); if (el) body[f] = el.value; });
    const az = $("#llm-azure"); if (az) body.azure = az.checked;
    const cl = $("#llm-clear_key"); if (cl && cl.checked) body.clear_key = true;
    return body;
  },
  shown(r) {
    return r.ok ? `<div class="callout ok"><strong>Connected.</strong> ${esc(r.model || "")} answered in ${r.latency_s} s${r.reply ? ` (“${esc(r.reply)}”)` : ""}.</div>`
      : `<div class="callout bad"><strong>Test failed.</strong> ${esc(r.error)}</div>`;
  },
  async test(btn) {
    const out = $("#llm-test");
    btn.disabled = true;
    out.innerHTML = '<div class="sub">Sending a one-word test request…</div>';
    try { out.innerHTML = LlmSet.shown(await post("/llm/test", LlmSet.collect())); } catch (e) { out.innerHTML = `<div class="callout bad">${esc(e.message)}</div>`; }
    btn.disabled = false;
  },
  async testSaved(btn, pid) {
    const p = LlmSet.v.profiles.find((x) => x.id === pid), out = $("#llm-listtest");
    btn.disabled = true;
    out.innerHTML = `<div class="sub">Testing “${esc(p.name)}”…</div>`;
    try { out.innerHTML = `<div class="sub"><strong>${esc(p.name)}</strong></div>` + LlmSet.shown(await post("/llm/test", { ...p.form, profile_id: pid })); } catch (e) { out.innerHTML = `<div class="callout bad">${esc(e.message)}</div>`; }
    btn.disabled = false;
  },
  after(v, msg) {
    State.meta = { ...State.meta, llm: v.active };
    $("#chip-llm").textContent = `Agent: ${v.active.provider}${v.active.model ? " · " + v.active.model : ""}`;
    toastOk(msg);
    LlmSet.form = null;
    return render(true);
  },
  async save(btn) {
    btn.disabled = true;
    try {
      const v = await api("/llm", { method: "PUT", body: LlmSet.collect() });
      if (!LlmSet.editId) LlmSet.editId = null;
      await LlmSet.after(v, v.active.provider === "rules" ? "Saved. No model is set, so the app uses its built-in rules." : `Saved. ${v.active.model || v.active.provider} is now used across the app.`);
    } catch (e) { btn.disabled = false; toastError(e.message); }
  },
  async use(btn, pid) {
    btn.disabled = true;
    try { const v = await post(`/llm/profiles/${pid}/activate`); await LlmSet.after(v, `${v.active.model || v.active.provider} is now used across the app.`); }
    catch (e) { btn.disabled = false; toastError(e.message); }
  },
  remove(pid) {
    const p = LlmSet.v.profiles.find((x) => x.id === pid);
    Modal.open(`${Modal.head("Delete saved connection", esc(p.name))}<div class="modal-body"><p>${p.active ? "It is in use now: the app will go back to config.yaml and environment variables. " : ""}Its saved API key is deleted with it.</p></div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button><button class="btn danger" onclick="LlmSet.doRemove(this, '${pid}')">Delete</button></div>`);
  },
  async doRemove(btn, pid) {
    btn.disabled = true;
    try { const v = await api(`/llm/profiles/${pid}`, { method: "DELETE" }); Modal.close(); if (LlmSet.editId === pid) LlmSet.editId = null; await LlmSet.after(v, "Deleted."); }
    catch (e) { btn.disabled = false; toastError(e.message); }
  },
  async reset(btn) {
    btn.disabled = true;
    try { await LlmSet.after(await api("/llm", { method: "DELETE" }), "Back to config.yaml and environment variables."); }
    catch (e) { btn.disabled = false; toastError(e.message); }
  },
};
SetTabs.environment = async () => {
  const e = await api("/settings/env");
  const groups = {};
  e.variables.forEach((v) => (groups[v.group] = groups[v.group] || []).push(v));
  const setCount = e.variables.filter((v) => v.set).length;
  return `<div class="grid g3">
    <div class="card kpi ${e.runtime.platform === "databricks_apps" ? "bad" : "info"}" style="${e.runtime.platform === "databricks_apps" ? "border-top-color:var(--p-databricks)" : ""}">
      <div class="label">Running on</div><div class="value" style="font-size:20px">${esc(e.runtime.label)}</div>
      <div class="hint">${esc(e.runtime.workspace || e.runtime.app_url || "This machine")}</div></div>
    <div class="card kpi info"><div class="label">.env files loaded</div><div class="value" style="font-size:20px">${e.dotenv.files.length}</div>
      <div class="hint mono">${e.dotenv.files.map(esc).join("<br>") || "none found"}</div></div>
    <div class="card kpi info"><div class="label">Variables set</div><div class="value" style="font-size:20px">${setCount}</div>
      <div class="hint">config: <span class="mono">${esc(e.config_file || "defaults")}</span></div></div></div><div class="sp"></div>
  <div class="card"><h2>How values are resolved</h2><ol class="steps sub">
    <li>Real environment variables win (on Databricks Apps they come from <code>app.yaml</code> and app resources).</li>
    <li>Then <code>.env</code>: copy <code>.env.example</code> to <code>.env</code> and fill in what you use. It never overrides real variables.</li>
    <li>Then <code>config.yaml</code>, which can reference variables as <code>\${VAR}</code> or <code>\${VAR:-default}</code>, and keeps secrets out via <code>*_env</code> keys.</li>
    <li>Any setting can be overridden with <code>DQGA__SECTION__KEY</code>, for example <code>DQGA__SCHEDULER__ENABLED=false</code>.</li></ol>
    <p class="sub">Secret values (tokens, passwords, keys, webhooks) are never shown here, only whether they are set. Restart the app after changing <code>.env</code>.</p></div><div class="sp"></div>
  ${Object.entries(groups).map(([g, vs]) => `<div class="card wrap" style="margin-bottom:12px"><h2>${esc(g)}</h2><table class="t">
    <tr><th style="width:250px">Variable</th><th>Purpose</th><th style="width:90px">Status</th><th style="width:100px">Source</th><th>Value</th></tr>
    ${vs.map((v) => `<tr><td class="mono">${esc(v.name)}${v.referenced ? ' <span class="pill info">in config</span>' : ""}</td><td class="sub">${esc(v.description)}</td>
      <td>${v.set ? pill("ok", "set") : pill("muted", "not set")}</td><td class="sub">${esc(v.source || "")}</td>
      <td class="mono sub">${v.set ? (v.secret ? "•••••• (hidden)" : esc(v.value)) : ""}</td></tr>`).join("")}</table></div>`).join("")}`;
};
SetTabs.scheduler = async () => {
  const s = await api("/scheduler");
  return `<div class="grid g4"><div class="card kpi"><div class="label">Background scheduler</div><div class="value">${s.enabled ? "On" : "Off"}</div><div class="hint">every ${s.tick_seconds}s</div></div>
    <div class="card kpi"><div class="label">Compute used today</div><div class="value">${Number(s.budget_used_today_s).toFixed(1)}s</div><div class="hint">budget ${s.daily_budget_seconds}s</div></div>
    <div class="card kpi"><div class="label">Change-aware</div><div class="value">${s.change_aware ? "Yes" : "No"}</div><div class="hint">skips unchanged tables</div></div>
    <div class="card kpi"><div class="label">Last tick</div><div class="value" style="font-size:16px">${ts(s.last_tick) || "never"}</div></div></div><div class="sp"></div>
  <div class="card wrap"><div class="row"><h2 style="margin:0">Next run plan</h2><span style="flex:1"></span><button class="btn primary" onclick="act(this, () => post('/scheduler/tick'), r => 'Ran ' + r.ran.length + ', skipped ' + r.skipped.length)">Run tick now</button></div>
  <table class="t"><tr><th>Dataset</th><th class="num">Rules due</th><th class="num">Est. seconds</th><th class="num">Downstream</th><th class="num">Priority</th><th>Note</th></tr>
  ${s.plan.map((p) => `<tr><td>${esc(p.fqn)}</td><td class="num">${p.rules.length}</td><td class="num">${p.est_cost_s}</td><td class="num">${p.downstream}</td><td class="num">${p.priority}</td><td class="sub">${esc(p.skipped || "")}</td></tr>`).join("") || '<tr><td colspan="6" class="empty">Nothing due</td></tr>'}</table>
  ${s.last_summary ? `<details><summary class="sub">Last tick summary</summary><pre>${esc(JSON.stringify(s.last_summary, null, 2))}</pre></details>` : ""}</div>`;
};
SetTabs.notifications = async () => {
  const n = await api("/notifications");
  return `<div class="card wrap"><p class="sub">Configure Slack, Teams (Workflows webhook), or SMTP in config.yaml under <code>notifications</code>.</p><table class="t"><tr><th>When</th><th>Channel</th><th>Title</th><th>Status</th></tr>
  ${n.map((x) => `<tr><td>${ts(x.ts)}</td><td>${esc(x.channel)}</td><td>${esc(x.title)}</td><td class="sub">${esc(x.status)}</td></tr>`).join("") || '<tr><td colspan="4" class="empty">No notifications yet</td></tr>'}</table></div>`;
};
SetTabs.audit = async () => {
  const a = await api("/audit?limit=300");
  return `<div class="card wrap"><table class="t"><tr><th>When</th><th>Actor</th><th>Action</th><th>Target</th><th>Detail</th></tr>
  ${a.map((x) => `<tr><td>${ts(x.ts)}</td><td>${esc(x.actor)}</td><td class="mono">${esc(x.action)}</td><td class="mono sub">${esc(short(x.target || ""))}</td><td class="sub mono">${esc(JSON.stringify(x.detail).slice(0, 160))}</td></tr>`).join("")}</table></div>`;
};

/* Maintenance: reset or delete the app's own database (admins only). */
const TABLE_LABELS = { assets: "Datasets", rules: "Rules", check_results: "Check results", runs: "Check runs", incidents: "Incidents",
  approvals: "Action history", custom_metrics: "Custom metrics", connections: "Connections", users: "User accounts", audit_log: "Audit entries",
  metric_points: "Metric history", profiles: "Profiles", classifications: "Classifications", lineage_edges: "Lineage edges",
  policies: "Policies", contracts: "Contracts", glossary_terms: "Glossary terms", chat_messages: "Agent chat messages",
  fix_runs: "Fixes", quarantine_batches: "Quarantine batches", notifications: "Notifications", feedback: "Feedback",
  reference_docs: "Reference files", reference_facts: "Facts read from reference files", rule_schedules: "Rule schedules", policy_scans: "Policy scans", app_settings: "App settings (LLM)" };
SetTabs.maintenance = async () => {
  if (!isAdminUser()) return '<div class="callout bad">Only administrators can reset the application database.</div>';
  const m = await api("/admin/maintenance");
  State.maint = m;
  const c = m.counts;
  const total = Object.values(c).reduce((a, b) => a + b, 0);
  const demoCard = `<div class="card" style="margin-bottom:12px"><div class="row"><div><h2 style="margin:0">Demo data</h2>
      <p class="sub" style="margin:4px 0 0">${m.demo_loaded ? "The demo is loaded: a utility lakehouse (smart meters, customers, billing, finance, sensors) on a local DuckDB file, shown next to your own platforms. Use the platform picker to switch between them. To remove it, delete the <strong>demo</strong> connection in Settings > Connections."
        : "Adds a ready-made utility lakehouse on a local DuckDB file, with incidents, anomalies, insights, run history, schedules, rules in every review state, corrections, quarantine, metrics and reference files, so every screen has something to show. Your existing datasets, rules and settings are not touched. It takes about a minute."}</p></div>
      <span style="flex:1"></span><button class="btn primary" id="demo-load" ${m.demo_loaded ? "disabled" : ""} onclick="Maint.loadDemo(this)">${m.demo_loaded ? "Demo loaded" : "Load demo data"}</button></div></div>`;
  const size = m.size_bytes != null ? (m.size_bytes / 1048576).toFixed(m.size_bytes > 10485760 ? 0 : 2) + " MB" : "";
  const fx = !!(State.meta && State.meta.features && State.meta.features.fixes_and_quarantine);
  const shown = Object.keys(TABLE_LABELS).filter((t) => c[t] != null && (fx || !["fix_runs", "quarantine_batches"].includes(t)));
  return `${demoCard}<div class="grid g3">
    <div class="card kpi info"><div class="label">Application database</div><div class="value" style="font-size:20px">${esc(m.dialect === "sqlite" ? "SQLite" : m.dialect || "")}</div>
      <div class="hint mono">${esc(m.database || "server database")}${size ? " · " + size : ""}</div></div>
    <div class="card kpi info"><div class="label">Rows stored</div><div class="value" style="font-size:20px">${total.toLocaleString()}</div><div class="hint">across ${Object.keys(c).length} tables</div></div>
    <div class="card kpi info"><div class="label">Datasets · rules · incidents</div><div class="value" style="font-size:20px">${c.assets || 0} · ${c.rules || 0} · ${c.incidents || 0}</div><div class="hint">${c.users || 0} user accounts, ${c.connections || 0} connections</div></div></div>
  <div class="sp"></div>
  <div class="card wrap"><h2>What is stored</h2><table class="t">${shown.map((t) => `<tr><td>${esc(TABLE_LABELS[t])}</td><td class="mono sub">${esc(t)}</td><td class="num">${c[t].toLocaleString()}</td></tr>`).join("")}</table></div>
  <div class="sp"></div>
  <div class="card danger-zone"><h2>Reset or delete application data</h2>
    <p class="sub">Clears the app's own database so you can start fresh: datasets, rules, check results, incidents, custom metrics, history and the audit log.
      Choose whether to keep user accounts, connections and reference files. Data in Databricks, Snowflake and the other platforms is never touched, including quarantine tables and fix snapshots.
      Connections and policies defined in <code>config.yaml</code> and <code>policies.yaml</code> are loaded again afterwards.</p>
    <button class="btn danger" onclick="Maint.ask()">Reset application data…</button></div>`;
};
const Maint = {
  async loadDemo(btn) {
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = "Loading… about a minute";
    try {
      const r = await post("/admin/demo/load");
      toastOk(`Demo data loaded: ${r.datasets} datasets and ${r.open_incidents} open incidents. Open the Overview.`);
      State.platform = "";
      await render(true);
    } catch (e) { btn.disabled = false; btn.textContent = label; toastError(e.message); }
  },
  async start() {  // from the Settings header on any tab
    try { State.maint = await api("/admin/maintenance"); } catch (e) { toastError(e.message); return; }
    Maint.ask();
  },
  fresh() {  // erase everything: untick every keep box
    ["#rs-users", "#rs-conns", "#rs-refs"].forEach((id) => { $(id).checked = false; });
    Maint.sync();
    $("#rs-confirm").focus();
  },
  ask() {
    const m = State.maint || {};
    const canBackup = m.dialect === "sqlite" && m.database;
    Modal.open(`${Modal.head("Reset application data", "This can't be undone from the app.")}
      <div class="modal-body">
        <div class="row" style="gap:8px;margin-bottom:10px"><span class="sub">Keep some data, or</span><button class="btn sm danger" onclick="Maint.fresh()">Fresh start: erase everything</button></div>
        <label class="row sub" style="gap:8px"><input type="checkbox" id="rs-users" checked onchange="Maint.sync()"> Keep user accounts and sign-ins</label>
        <label class="row sub" style="gap:8px;margin-top:6px"><input type="checkbox" id="rs-conns" checked onchange="Maint.sync()"> Keep connections (definitions and enabled/disabled state)</label>
        <label class="row sub" style="gap:8px;margin-top:6px"><input type="checkbox" id="rs-refs" checked onchange="Maint.sync()"> Keep reference files (models, glossaries, master data, documents)</label>
        <label class="row sub" style="gap:8px;margin-top:6px"><input type="checkbox" id="rs-backup" ${canBackup ? "checked" : "disabled"}>
          Save a backup copy of the database first${canBackup ? ` <span class="mono">(${esc(m.backups_dir)})</span>` : " (SQLite only)"}</label>
        <div id="rs-note" class="callout" style="margin-top:12px"></div>
        <label class="f" style="margin-top:12px"><span>Type <strong>${esc(m.confirm_word || "RESET")}</strong> to confirm</span>
          <input id="rs-confirm" autocomplete="off" oninput="Maint.sync()" autofocus></label>
      </div>
      <div class="modal-foot"><button class="btn" onclick="Modal.close()">Cancel</button>
        <button class="btn danger" id="rs-go" disabled onclick="Maint.run(this)">Reset data</button></div>`);
    Maint.sync();
  },
  sync() {
    const users = $("#rs-users").checked, conns = $("#rs-conns").checked, refs = $("#rs-refs").checked;
    const word = (State.maint && State.maint.confirm_word) || "RESET";
    const all = !users && !conns && !refs;
    $("#rs-go").textContent = all ? "Delete everything" : "Reset data";
    $("#rs-go").disabled = $("#rs-confirm").value.trim().toUpperCase() !== word;
    $("#rs-note").className = "callout" + (users ? "" : " bad");
    $("#rs-note").innerHTML = (all ? "<strong>Everything in the app database is deleted.</strong> " : "")
      + (users ? "You stay signed in." : "All user accounts are deleted and you are signed out. The next visit starts the first-run setup, where you create a new administrator.")
      + (conns ? "" : " Connections you added in the app are removed; those in <code>config.yaml</code> come back.");
  },
  async run(btn) {
    btn.disabled = true;
    const body = { confirm: $("#rs-confirm").value, keep_users: $("#rs-users").checked, keep_connections: $("#rs-conns").checked,
      keep_references: $("#rs-refs").checked, backup: $("#rs-backup").checked };
    try {
      const r = await post("/admin/reset", body);
      Modal.close();
      const removed = Object.values(r.removed || {}).reduce((a, b) => a + b, 0);
      toast(`Reset complete: removed ${removed.toLocaleString()} rows.` + (r.backup ? `\nBackup saved to ${r.backup}` : ""), 15000, "ok");
      if (r.signed_out) { setTimeout(() => location.reload(), 1500); return; }
      location.hash = "#/overview";
      await render(false);
    } catch (e) { toastError(e.message); btn.disabled = false; }
  },
};

function inlineMd(s) {
  return esc(s).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/`([^`]+)`/g, "<code>$1</code>");
}
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast("Copied"); } catch (e) { toast("Copy isn't available here; select the text instead"); }
}
function cmdBlock(lines) {
  const id = "cmd-" + Math.random().toString(36).slice(2, 9);
  return `<div class="cmd"><button class="btn sm cmd-copy" onclick="copyText(document.getElementById('${id}').innerText)">Copy</button>
    <pre id="${id}"><code>${esc(lines.join("\n"))}</code></pre></div>`;
}

/* Deploy page: one target at a time, chosen from a dropdown. Targets come from dqga/deploy_targets.yaml. */
const Deploy = {
  pick(id) {
    State.deployTarget = id;
    try { localStorage.setItem("dq-deploy-target", id); } catch (e) { /* storage unavailable */ }
    render(true);
  },
};

Pages.deploy = async () => {
  const d = await api("/deploy/targets");
  let want = State.deployTarget;
  if (!want) { try { want = localStorage.getItem("dq-deploy-target"); } catch (e) { /* storage unavailable */ } }
  const t = d.targets.find((x) => x.id === want) || d.targets.find((x) => x.id === d.default) || d.targets[0];
  State.deployTarget = t.id;
  const groups = {};
  d.targets.forEach((x) => (groups[x.group] = groups[x.group] || []).push(x));
  const onDbx = d.runtime.platform === "databricks_apps";
  return `<div class="page-head"><h1>Deploy</h1><span class="sub">Run TCS DataTrustAI where your data and users are</span></div>
  ${onDbx ? `<div class="callout ok">This instance is running on <strong>Databricks Apps</strong>${d.runtime.app_name ? ` as <code>${esc(d.runtime.app_name)}</code>` : ""}. It authenticates as the app's service principal and signs users in with workspace SSO.</div><div class="sp"></div>` : ""}
  <div class="card option" style="--p: var(--p-${platKey(t.platform)})">
    <div class="xbar" style="margin-top:0">
      <label class="f">Deploy to<select onchange="Deploy.pick(this.value)">${Object.entries(groups).map(([g, xs]) =>
        `<optgroup label="${esc(g)}">${xs.map((x) => `<option value="${esc(x.id)}" ${x.id === t.id ? "selected" : ""}>${esc(x.label)}${x.current ? " (current)" : ""}</option>`).join("")}</optgroup>`).join("")}</select></label>
      <div class="row xcheck">${plat(t.platform, t.badge)}${t.current ? pill("ok", "current") : ""}${t.verified ? pill("ok", "verified") : pill("warn", "not yet verified live")}</div>
      <span class="grow"></span>
      <div class="btns">${t.link ? `<a class="btn" href="${esc(t.link.url)}" target="_blank" rel="noopener">${esc(t.link.label)}</a>` : ""}
        ${t.package ? `<a class="btn primary" href="/api/deploy/package/${esc(t.id)}.zip">Download package (.zip)</a>` : ""}</div>
    </div>
    <p class="sub" style="margin:12px 0 4px">${inlineMd(t.summary)}</p>
    <ol class="steps">${t.steps.map((s) => `<li><strong>${esc(s.title)}.</strong> ${s.text ? inlineMd(s.text) : ""}
      ${s.commands ? cmdBlock(s.commands) : ""}${s.alt ? `<div class="sub">${esc(s.alt.label)}:</div>${cmdBlock(s.alt.commands)}` : ""}</li>`).join("")}</ol>
    ${t.package ? `<p class="sub">The package has ${t.package_files} files: code, configs, <code>Dockerfile</code> and docs. It never includes <code>.env</code>, data or tests.${t.docs ? ` Full guide inside: <code>${esc(t.docs)}</code>.` : ""}</p>` : ""}
    ${t.files.length ? `<h3 style="margin-top:14px">Files</h3>${t.files.map((f) => `<details><summary class="sub">${esc(f.name)}</summary><pre><code>${esc(f.content)}</code></pre></details>`).join("")}` : ""}
  </div>
  <p class="sub" style="margin-top:10px">${d.targets.length} targets. Need another platform? Add an entry to <code>dqga/deploy_targets.yaml</code>; it appears in this list without code changes.</p>`;
};

/* ------------------------------------------------------------------ small charts */
function bandChart(points, opts = {}) {
  const pts = points.filter((p) => p.value != null);
  if (pts.length < 2) return '<div class="empty">Not enough history yet</div>';
  const W = opts.width || 560, H = opts.height || 150, L = 44, R = 12, T = 12, B = 22;
  const vals = pts.flatMap((p) => [p.value, p.low, p.high].filter((v) => v != null));
  let lo = Math.min(...vals), hi = Math.max(...vals);
  if (lo === hi) { lo -= 1; hi += 1; }
  const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
  const x = (i) => L + (i / (pts.length - 1)) * (W - L - R);
  const y = (v) => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
  const banded = pts.map((p, i) => ({ i, p })).filter(({ p }) => p.low != null);
  const band = banded.length > 1 ? `<path d="${banded.map(({ i, p }, k) => `${k ? "L" : "M"}${x(i).toFixed(1)},${y(p.high).toFixed(1)}`).join(" ")} ${banded.slice().reverse().map(({ i, p }) => `L${x(i).toFixed(1)},${y(p.low).toFixed(1)}`).join(" ")} Z" style="fill:var(--accent-bg)"/>` : "";
  const line = pts.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(" ");
  const f = opts.fmt || ((v) => Math.abs(v) >= 1000 ? Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 }) : Math.abs(v) < 0.1 && v !== 0 ? Number(v).toPrecision(2) : Number(v).toLocaleString(undefined, { maximumFractionDigits: 2 }));
  const dots = pts.map((p, i) => p.anomaly ? `<circle cx="${x(i)}" cy="${y(p.value)}" r="4.5" style="fill:var(--bad)"><title>${esc(ts(p.ts))}: ${esc(f(p.value))} (expected ${esc(f(p.low))} to ${esc(f(p.high))})</title></circle>` : "").join("");
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="${esc(opts.label || "metric with expected band")}">
    ${band}<path d="${line}" fill="none" style="stroke:var(--accent)" stroke-width="1.8"/>${dots}
    <text x="${L - 6}" y="${y(hi - pad) + 4}" font-size="10.5" text-anchor="end" style="fill:var(--text-3)">${esc(f(hi - pad))}</text>
    <text x="${L - 6}" y="${y(lo + pad) + 4}" font-size="10.5" text-anchor="end" style="fill:var(--text-3)">${esc(f(lo + pad))}</text>
    <text x="${L}" y="${H - 4}" font-size="10.5" style="fill:var(--text-3)">${esc(ts(pts[0].ts))}</text>
    <text x="${W - R}" y="${H - 4}" font-size="10.5" text-anchor="end" style="fill:var(--text-3)">${esc(ts(pts[pts.length - 1].ts))}</text></svg>
    <div class="row sub" style="font-size:11.5px;gap:14px"><span><span class="legend-sw" style="background:var(--accent-bg)"></span>expected range</span>
    <span><span class="legend-sw" style="background:var(--bad);border-radius:50%"></span>anomaly</span></div>`;
}
function bars(items, opts = {}) {
  if (!items.length) return '<div class="empty">Nothing yet</div>';
  const max = Math.max(...items.map((i) => i.value), 1);
  return items.map((i) => `<div class="hbar"><span class="hbar-l" title="${esc(i.label)}">${i.href ? `<a href="${i.href}">${esc(i.label)}</a>` : esc(i.label)}</span>
    <span class="bar"><div style="width:${(i.value / max * 100).toFixed(1)}%;background:${i.color || opts.color || "var(--accent)"}"></div></span>
    <span class="hbar-v">${esc(i.text ?? i.value)}</span></div>`).join("");
}
function confBar(c) {
  const pctv = Math.round(c * 100), col = c >= 0.85 ? "var(--ok)" : c >= 0.7 ? "var(--accent)" : "#e3a008";
  return `<span class="conf"><span class="bar"><div style="width:${pctv}%;background:${col}"></div></span><b>${pctv}%</b></span>`;
}

/* ------------------------------------------------------------------ AI rule generation (AI Rule Studio) */
const SRC_PILL = { Contract: "ok", Policy: "warn", Standard: "info", Glossary: "glossary" };  // source tags that come from your governance decisions
const DISC_INTRO = '<p class="sub" style="margin:10px 0 0">Every proposal comes with a confidence score, the evidence behind it, and a dry run on the platform. Nothing is saved until you save it as a draft.</p>';
const Discovery = {
  res: null, assetId: null, sel: new Set(), set: "all", hidden: false, useLlm: true,
  panel(asset) {
    const fresh = this.res && this.assetId === asset.id;
    return `<div class="card" id="disc"><div class="row"><h2 style="margin:0">AI rule generation</h2>
      <span class="sub">Proposes three sets of rules (core data, business domain, data governance) from schema, statistics, history, relationships, reference files, glossary, other datasets and your business glossary, data contracts, policies and standards, with the model chosen in <a href="#/settings/llm">Settings > LLM</a></span>
      <span style="flex:1"></span>
      <button class="btn sm" id="disc-hide" ${fresh ? "" : "hidden"} onclick="Discovery.toggle()">${this.hidden ? "Show results" : "Hide results"}</button>
      <button class="btn sm" id="disc-reset" ${fresh ? "" : "hidden"} onclick="Discovery.reset()" title="Discard these proposals and start over">Reset</button>
      <label class="row sub" style="gap:4px" title="Uses the model chosen in Settings > LLM. Untick to propose rules from statistics, history and reference files only."><input type="checkbox" id="disc-llm" ${this.useLlm ? "checked" : ""} onchange="Discovery.useLlm=this.checked"> Use the AI model</label>
      <button class="btn primary" id="disc-run" onclick="Discovery.run(this, ${asset.id})">${fresh ? "Run again" : "Generate rules"}</button></div>
      ${Refs.contextBar(asset)}
      <div id="disc-out" ${fresh && this.hidden ? "hidden" : ""}>${fresh ? this.body() : DISC_INTRO}</div></div>`;
  },
  toggle() {
    this.hidden = !this.hidden;
    $("#disc-out").hidden = this.hidden;
    $("#disc-hide").textContent = this.hidden ? "Show results" : "Hide results";
  },
  reset() {
    this.res = null;
    this.sel = new Set();
    this.set = "all";
    this.hidden = false;
    $("#disc-out").hidden = false;
    $("#disc-out").innerHTML = DISC_INTRO;
    $("#disc-hide").hidden = $("#disc-reset").hidden = true;
    $("#disc-run").textContent = "Generate rules";
  },
  async run(btn, id) {
    btn.disabled = true;
    this.hidden = false;
    $("#disc-out").hidden = false;
    $("#disc-hide").textContent = "Hide results";
    $("#disc-out").innerHTML = '<p class="sub" style="margin-top:10px">Reading the profile, history, reference files, glossary and related datasets, then dry-running every candidate…</p>';
    try {
      this.res = await post(`/assets/${id}/discover?use_llm=${this.useLlm}`, { ...Refs.body(), context: GovCtx.body() });
      this.set = "all";
      const err = this.res.context.llm_error || (this.res.context.reference || {}).error;
      if (err) toastWarn("Some proposals are missing:\n" + err);
      this.assetId = id;
      this.sel = new Set(this.res.candidates.map((c, i) => (c.confidence >= 0.8 && (!c.dry_run || c.dry_run.status === "pass") ? i : -1)).filter((i) => i >= 0));
      $("#disc-out").innerHTML = this.body();
      $("#disc-hide").hidden = $("#disc-reset").hidden = false;
    } catch (e) {
      const llmProblem = /Settings > LLM/.test(e.message);
      $("#disc-out").innerHTML = `<div class="callout bad" style="margin-top:10px"><strong>AI rule generation stopped.</strong> ${esc(e.message)}
        ${llmProblem ? '<div class="btns" style="margin-top:8px"><a class="btn sm primary" href="#/settings/llm">Open Settings > LLM</a></div>' : ""}</div>`;
      toastError(e.message);
    }
    btn.disabled = false;
    btn.textContent = "Run again";
  },
  visible() { return this.res.candidates.map((x, i) => [x, i]).filter(([x]) => this.set === "all" || x.rule_category === this.set); },
  show(set) { this.set = set; $("#disc-out").innerHTML = this.body(); },
  body() {
    const r = this.res, c = r.context, cov = r.coverage;
    const dims = Object.keys(cov.before).filter((d) => cov.before[d] || cov.after[d]);
    const maxCov = Math.max(1, ...dims.map((d) => cov.after[d]));
    const ref = c.reference || { files: [], facts: 0 };
    const refUsed = ref.files.filter((f) => f.facts);
    const selIn = (k) => [...this.sel].filter((i) => k === "all" || r.candidates[i].rule_category === k).length;
    const tabs = [["all", "All"], ...Object.entries(RULE_SETS)].map(([k, l]) => `<button class="seg ${this.set === k ? "on" : ""}" onclick="Discovery.show('${k}')">
      ${esc(l)} <span class="n">${k === "all" ? r.candidates.length : r.sets[k] || 0}</span>${selIn(k) ? ` <span class="sel">${selIn(k)} selected</span>` : ""}</button>`).join("");
    const rows = this.visible();
    const dr = c.dry_runs || {};
    const dryNote = dr.unavailable ? `<div class="callout bad" style="margin:10px 0">${esc(dr.unavailable)}</div>`
      : dr.ran ? `<div class="sub" style="margin:10px 0 0">Every candidate was dry-run on ${plat(dr.platform)} (<span class="mono">${esc(dr.connection)}</span>): ${dr.ran} ran${dr.errors ? `, <strong style="color:var(--bad)">${dr.errors} could not run</strong> (see the Dry run column)` : ""}. Nothing was saved.</div>` : "";
    return `${dryNote}<div class="sub" style="margin:10px 0">${r.candidates.length} candidate(s) for <strong>${esc(r.asset)}</strong> from
      ${Object.entries(c.by_source).map(([k, v]) => `<span class="pill info">${esc(k)} ${v}</span>`).join(" ")}
      ${refUsed.length ? `<br>Reference files used: ${refUsed.map((f) => `${esc(f.name)} (${f.facts} facts)`).join(", ")}${c.llm && ref.llm_context_chars ? ` · ${ref.llm_context_chars.toLocaleString()} characters of reference context sent to the model` : ""}`
        : ref.files.length ? "<br>None of the selected reference files mention this dataset." : ""}
      ${c.governed && (c.governed.contract || c.governed.policies.length || c.governed.standards.length || (c.governed.glossary || []).length) ? `<br>Governance context used: ${[c.governed.contract ? `contract ${esc(c.governed.contract.name)} v${esc(c.governed.contract.version)}` : "", c.governed.policies.length ? `${c.governed.policies.length} polic${c.governed.policies.length === 1 ? "y" : "ies"} (${c.governed.policies.map((p) => esc(p.key)).join(", ")})` : "",
        (c.governed.glossary || []).length ? `${c.governed.glossary.length} glossary term${c.governed.glossary.length === 1 ? "" : "s"} (${c.governed.glossary.slice(0, 4).map((t) => esc(t.name)).join(", ")}${c.governed.glossary.length > 4 ? " …" : ""})` : "",
        c.governed.standards.length ? "standards " + c.governed.standards.map((x) => esc(x.title.split(" (")[0])).join(", ") : ""].filter(Boolean).join(" · ")}${c.governed.llm_chars ? ` · ${c.governed.llm_chars.toLocaleString()} characters sent to the model` : ""}` : ""}
      ${Object.keys(c.semantic_types).length ? `<br>Column meanings: ${Object.entries(c.semantic_types).map(([k, v]) => `<code>${esc(k)}</code> ${esc(v.replace("_", " "))}`).join(" · ")}` : ""}
      ${c.glossary_terms.length ? `<br>Business terms: ${c.glossary_terms.slice(0, 20).map(esc).join(", ")}${c.glossary_terms.length > 20 ? " …" : ""}` : ""}${c.llm ? " · model suggestions included" : ""}</div>
    <div class="segs" role="tablist" aria-label="Rule sets">${tabs}</div>
    ${this.set !== "all" ? `<p class="sub" style="margin:6px 0 8px">${esc((Refs.meta && Refs.meta.categories[this.set] || {}).desc || "")}</p>` : ""}
    <div class="grid" style="grid-template-columns:minmax(0,1fr) 260px;gap:16px;align-items:start">
      <div class="wrap"><table class="t"><tr><th style="width:28px"><input type="checkbox" aria-label="Select all shown" onchange="Discovery.all(this.checked)"></th><th>Confidence</th><th>Proposed rule</th>${this.set === "all" ? "<th>Set</th>" : ""}<th>Source</th><th>Why</th><th>Dry run</th></tr>
      ${rows.map(([x, i]) => `<tr><td><input type="checkbox" ${this.sel.has(i) ? "checked" : ""} onchange="Discovery.pick(${i}, this.checked)" aria-label="Select ${esc(x.name)}"></td>
        <td>${confBar(x.confidence)}</td><td><strong>${esc(x.name)}</strong><div class="sub"><code>${esc(x.type)}</code> · ${esc(x.dimension)} · ${esc(x.severity)}</div></td>
        ${this.set === "all" ? `<td>${pill(SET_PILL[x.rule_category] || "", RULE_SETS[x.rule_category] || x.rule_category)}</td>` : ""}
        <td>${x.sources.map((s) => `<span class="pill ${SRC_PILL[s] || ""}">${esc(s)}</span>`).join(" ")}${(x.ref_docs || []).map((d) => `<div class="sub mono" title="Where it came from: a reference file, a contract, a policy or a standard control">${esc(d)}</div>`).join("")}</td>
        <td class="sub" style="max-width:360px">${esc(x.evidence[0] || "")}${x.evidence.length > 1 ? `<details><summary>${x.evidence.length - 1} more</summary>${x.evidence.slice(1).map((e) => `<div>• ${esc(e)}</div>`).join("")}</details>` : ""}</td>
        <td>${x.dry_run ? pill(x.dry_run.status) + `<div class="sub" style="font-size:11.5px">${esc(x.dry_run.message || "")}</div>` : '<span class="muted">-</span>'}</td></tr>`).join("")
        || `<tr><td colspan="7" class="empty">${this.set === "all" ? "Coverage already looks complete for this dataset." : "No new proposals in this set. Add reference files (glossary, policies, models) to get more."}</td></tr>`}</table></div>
      <div><h3>Coverage by dimension</h3>${dims.map((d) => `<div class="hbar"><span class="hbar-l">${esc(d)}</span>
        <span class="bar" title="${cov.before[d]} now, ${cov.after[d]} with high-confidence proposals"><div style="width:${cov.after[d] / maxCov * 100}%;background:var(--accent-bg);position:relative">
        <div style="width:${cov.after[d] ? cov.before[d] / cov.after[d] * 100 : 0}%;height:8px;background:var(--accent)"></div></div></span>
        <span class="hbar-v">${cov.before[d]}→${cov.after[d]}</span></div>`).join("")}
        <p class="sub" style="font-size:11.5px">Dark: active rules now. Light: added by proposals at 70%+ confidence.</p></div></div>
    <div class="btns" style="margin-top:10px"><span class="sub" id="disc-count">${this.sel.size} selected</span>
      <button class="btn sm" onclick="Discovery.above(0.8)">Select 80%+ that pass</button>
      <span style="flex:1"></span><button class="btn primary" onclick="Discovery.accept(this)">Save selected as drafts</button></div>
    <p class="sub" style="font-size:11.5px;margin:6px 0 0">Drafts wait in <a href="#/rules/saved">Saved rules</a>. Send them for approval; an administrator activates them.</p>`;
  },
  pick(i, on) { if (on) this.sel.add(i); else this.sel.delete(i); $("#disc-out").innerHTML = this.body(); },
  all(on) { this.visible().forEach(([, i]) => (on ? this.sel.add(i) : this.sel.delete(i))); $("#disc-out").innerHTML = this.body(); },
  above(t) {
    this.visible().forEach(([c, i]) => this.sel.delete(i));
    this.visible().forEach(([c, i]) => { if (c.confidence >= t && (!c.dry_run || c.dry_run.status === "pass")) this.sel.add(i); });
    $("#disc-out").innerHTML = this.body();
  },
  async accept(btn) {
    const rules = [...this.sel].map((i) => this.res.candidates[i]);
    if (!rules.length) return toast("Select at least one proposed rule");
    const id = this.assetId;
    this.res = null;
    await act(btn, () => post(`/assets/${id}/discover/accept`, { rules }), (r) => `${r.created.length} rule(s) saved as drafts. Send them for approval in Saved rules.`);
  },
};

/* ------------------------------------------------------------------ anomalies */
AssetTabs.impact = async (a) => {
  const rep = await api(`/impact?asset_id=${a.id}&change=data`);
  const lvl = { critical: "bad", high: "bad", medium: "warn", low: "ok" }[rep.level];
  return `<div class="row" style="margin-bottom:12px"><span class="sub">What breaks downstream if this dataset's data is wrong.</span><span style="flex:1"></span>
      <a class="btn" href="#/impact/${a.id}">Open the full analysis (drop columns, change types)</a></div>
    <div class="grid g3">
      <div class="card kpi ${lvl}"><div class="label">Impact score</div><div class="value">${rep.score}<span class="sub" style="font-size:14px"> / 100</span></div><div class="hint">${pill(rep.level)}</div></div>
      <div class="card kpi info"><div class="label">Downstream datasets</div><div class="value">${rep.impacted.length}</div><div class="hint">${rep.impacted.filter((i) => i.certified).length} certified</div></div>
      <div class="card kpi info"><div class="label">Contracts and rules</div><div class="value">${(rep.contracts || []).length} · ${(rep.rules || []).length}</div><div class="hint">contract(s) · rule(s) involved</div></div></div><div class="sp"></div>
    <div class="card wrap"><h2>Impacted datasets</h2><table class="t"><tr><th class="num">Hops</th><th>Dataset</th><th>Owner</th><th>Score</th><th>Open incidents</th></tr>
      ${rep.impacted.map((i) => `<tr><td class="num">${i.distance}</td><td>${i.asset_id ? `<a href="#/asset/${i.asset_id}">${esc(i.fqn)}</a>` : esc(i.fqn)} ${i.certified ? pill("ok", "certified") : ""}</td>
        <td class="sub">${esc(i.owner || "")}</td><td>${score(i.score)}</td><td class="num">${i.open_incidents || ""}</td></tr>`).join("") || '<tr><td colspan="5" class="empty">Nothing downstream</td></tr>'}</table></div>
    <p class="sub" style="margin-top:8px">${esc(rep.summary || "")}</p>`;
};

AssetTabs.anomalies = async (a) => {
  const v = await api(`/assets/${a.id}/anomalies`);
  const active = v.monitors.filter((m) => m.status === "active");
  return `<div class="row" style="margin-bottom:12px"><span class="sub">${active.length} active anomaly monitor(s). Bands show what the detector expected from earlier points (weekly seasonality when there's enough history).</span>
    <span style="flex:1"></span><button class="btn primary" onclick="act(this, () => post('/assets/${a.id}/monitor'), r => r.created.length ? r.created.length + (r.as_drafts ? ' monitor(s) saved as drafts: send them for approval in Saved rules' : ' monitor(s) added') : 'Already fully monitored')">Monitor this dataset</button></div>
  <div class="grid g2">${v.series.map((s) => `<div class="card"><div class="row"><h3 style="margin:0">${esc(s.label)}</h3><span style="flex:1"></span>
      ${s.anomalies ? pill("bad", s.anomalies + " anomal" + (s.anomalies > 1 ? "ies" : "y")) : pill("ok", "normal")}
      ${s.level_shift ? pill("warn", `level shift ${s.level_shift.pct > 0 ? "+" : ""}${s.level_shift.pct}%`) : ""}</div>
      ${bandChart(s.points, { label: s.label })}</div>`).join("") || '<div class="card empty">No metric history yet. Run checks a few times, or start monitoring.</div>'}</div>`;
};

Pages.anomalies = async () => {
  const [r, picker] = await Promise.all([api("/anomalies?" + platQ("days=30")), platformPicker()]);
  const s = r.summary;
  const kindPill = (k) => pill(k === "level_shift" ? "warn" : k === "drop" ? "info" : "bad", k.replace("_", " "));
  const fmt = (v) => v == null ? "-" : Math.abs(v) >= 1000 ? Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 }) : Math.abs(v) < 0.1 && v !== 0 ? Number(v).toPrecision(2) : Number(v).toLocaleString(undefined, { maximumFractionDigits: 2 });
  return `<div class="page-head"><h1>Anomalies</h1><span class="sub">Unusual changes in volume, completeness, freshness, values and sensors over the last ${r.days} days</span><span class="grow"></span>${picker}</div>
  <div class="grid g4">
    <div class="card kpi ${s.total ? "bad" : "ok"}"><div class="label">Anomalies</div><div class="value">${s.total}</div><div class="hint">${s.datasets_affected} dataset(s) affected</div></div>
    <div class="card kpi warn"><div class="label">Level shifts</div><div class="value">${s.by_kind.level_shift || 0}</div><div class="hint">sustained changes</div></div>
    <div class="card kpi info"><div class="label">Spikes and drops</div><div class="value">${(s.by_kind.spike || 0) + (s.by_kind.drop || 0)}</div><div class="hint">outside the expected band</div></div>
    <div class="card kpi ${s.monitored < s.datasets ? "warn" : "ok"}"><div class="label">Monitored datasets</div><div class="value">${s.monitored}/${s.datasets}</div><div class="hint">with anomaly monitors</div></div></div><div class="sp"></div>
  <div class="card wrap"><h2>Detected anomalies</h2><table class="t"><tr><th>When</th><th>Dataset</th><th>Signal</th><th>Observed</th><th>Expected</th><th class="num">Change</th><th>Type</th><th>Severity</th></tr>
    ${r.items.map((i) => `<tr><td>${ts(i.ts)}</td><td><a href="#/asset/${i.asset_id}/anomalies">${esc(short(i.fqn))}</a></td><td>${esc(i.label)}${i.message ? `<div class="sub">${esc(i.message)}</div>` : ""}</td>
      <td>${fmt(i.value)}</td><td class="sub">${i.expected_low != null ? `${fmt(i.expected_low)} to ${fmt(i.expected_high)}` : "-"}</td>
      <td class="num">${i.pct_change != null ? (i.pct_change > 0 ? "+" : "") + i.pct_change + "%" : ""}</td><td>${kindPill(i.kind)}</td><td>${pill(i.severity)}</td></tr>`).join("")
      || '<tr><td colspan="8" class="empty">No anomalies in this period</td></tr>'}</table></div><div class="sp"></div>
  <div class="card"><h2>Datasets without anomaly monitoring (${r.unmonitored.length})</h2>${r.unmonitored.length ? `<table class="t">${r.unmonitored.map((a) => `<tr><td><a href="#/asset/${a.id}/anomalies">${esc(a.fqn)}</a></td><td>${esc(a.domain || "")}</td>
      <td class="num"><button class="btn sm" onclick="act(this, () => post('/assets/${a.id}/monitor'), r => r.created.length + ' monitor(s) added')">Start monitoring</button></td></tr>`).join("")}</table>`
      : '<div class="empty">Every dataset is monitored</div>'}</div>`;
};

/* ------------------------------------------------------------------ corrections and quarantine */
const Fixes = {
  vis(s) { return String(s).replace(/^ +| +$/g, (m) => "␠".repeat(m.length)); },
  card(f, incidentId) {
    const riskPill = pill(f.risk === "low" ? "ok" : f.risk === "medium" ? "warn" : "bad", `${f.risk} risk`);
    return `<div class="approval" style="border-left-color:${f.risk === "low" ? "var(--ok)" : f.risk === "medium" ? "#e3a008" : "var(--bad)"}">
      <div class="t1">${riskPill} ${f.auto_eligible ? '<span class="pill info">auto-correct eligible</span>' : ""} · undo available</div>
      <strong>${esc(f.title)}</strong>${f.asset ? `<div class="sub">${esc(f.asset)}</div>` : ""}
      <div class="sub">${f.risk_reasons.map(esc).join("; ")}</div>
      <table class="t" style="margin:6px 0"><tr><th>Before</th><th>After</th><th class="num">Rows</th></tr>
        ${f.preview.slice(0, 6).map((p) => `<tr><td><code>${esc(Fixes.vis(p.before))}</code></td><td><code>${esc(Fixes.vis(p.after))}</code></td><td class="num">${p.rows.toLocaleString()}</td></tr>`).join("")}</table>
      <button class="btn sm ${f.risk === "low" ? "primary" : ""}" onclick="Fixes.apply(this, ${jsq(f.id)}, ${incidentId || "null"})">Apply correction</button></div>`;
  },
  async apply(btn, id, incidentId) {
    await act(btn, () => post("/fixes/apply", { fix_id: id, incident_id: incidentId }),
      (r) => `Corrected ${r.fix_run.rows} row(s); re-check: ${r.fix_run.detail.recheck || "done"}`);
  },
  async undo(btn, id) {
    try { await post(`/fixes/${id}/undo`, { force: false }); toast("Undone"); }
    catch (e) {
      if (!/changed after/.test(e.message) || !confirm(e.message)) { toastError(e.message); return; }
      await post(`/fixes/${id}/undo`, { force: true }); toast("Undone");
    }
    render(true);
  },
};

const Quarantine = {
  pre: null,
  start(ruleId, incidentId) { this.pre = { rule_id: ruleId, incident_id: incidentId }; location.hash = "#/fixes/quarantine"; },
  async plan(btn) {
    const f = $("#q-form"), d = Object.fromEntries(new FormData(f));
    if (!d.rule_id) { $("#q-plan").innerHTML = '<div class="ferr" style="display:block">Choose a failing rule.</div>'; return; }
    btn.disabled = true;
    try {
      const p = await post("/quarantine/plan", { rule_id: Number(d.rule_id), mode: d.mode, target: d.target || null, clean_table: d.clean_table || null });
      $("#q-plan").innerHTML = `<div class="callout ${p.rows ? "" : "bad"}" style="margin-top:10px"><strong>${p.rows.toLocaleString()} row(s)</strong> fail “${esc(p.rule)}”.
        ${{ move: `They'll be copied to <code>${esc(p.target)}</code> and removed from <code>${esc(p.asset)}</code>.`,
           copy: `They'll be copied to <code>${esc(p.target)}</code>; <code>${esc(p.asset)}</code> is not changed.`,
           split: `Good rows go to <code>${esc(p.clean_table)}</code>, bad rows to <code>${esc(p.target)}</code>; <code>${esc(p.asset)}</code> is not changed.` }[p.mode]}
        ${p.rows ? `<div class="btns" style="margin-top:8px"><button class="btn primary" onclick="Quarantine.go(this)">Quarantine ${p.rows.toLocaleString()} row(s)</button></div>` : ""}</div>`;
    } catch (e) { $("#q-plan").innerHTML = `<div class="callout bad" style="margin-top:10px">${esc(e.message)}</div>`; }
    btn.disabled = false;
  },
  async go(btn) {
    const d = Object.fromEntries(new FormData($("#q-form")));
    this.pre = null;
    await act(btn, () => post("/quarantine", { rule_id: Number(d.rule_id), mode: d.mode, target: d.target || null, clean_table: d.clean_table || null,
      incident_id: d.incident_id ? Number(d.incident_id) : null, note: d.note || null }),
      (r) => `Quarantined ${r.batch.rows} row(s), batch ${r.batch.batch_key}`);
  },
  async view(id) {
    const box = $("#qb-" + id);
    if (!box.hidden) { box.hidden = true; return; }
    box.hidden = false;
    box.innerHTML = '<td colspan="9" class="sub">Loading…</td>';
    try {
      const b = await api(`/quarantine/${id}`);
      const cols = b.columns.filter((c) => !["_dq_batch", "_dq_rule"].includes(c));
      box.innerHTML = `<td colspan="9"><div class="wrap"><table class="t"><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join("")}</tr>
        ${b.rows.map((r) => `<tr>${cols.map((c) => `<td class="sub">${esc(r[c] ?? "")}</td>`).join("")}</tr>`).join("") || `<tr><td class="empty" colspan="${cols.length}">No rows left in this batch</td></tr>`}</table></div>
        ${b.masked.length ? `<p class="sub">Sensitive columns are masked: ${b.masked.map(esc).join(", ")}.</p>` : ""}
        <div class="sub">History: ${(b.history || []).map((h) => `${ts(h.at)} ${esc(h.action)} ${h.rows ?? ""} by ${esc(h.actor)}`).join(" · ")}</div></td>`;
    } catch (e) { box.innerHTML = `<td colspan="9" class="callout bad">${esc(e.message)}</td>`; }
  },
  async release(btn, id, revalidate) {
    if (!revalidate && !confirm("Release every row without re-checking it against the rule?")) return;
    await act(btn, () => post(`/quarantine/${id}/release`, { revalidate }),
      (r) => `${r.released} row(s) released, ${r.remaining} still quarantined${r.note ? ". " + r.note : ""}`);
  },
  async purge(btn, id, rows) {
    if (!confirm(`Permanently delete ${rows} quarantined row(s)? This can't be undone.`)) return;
    await act(btn, () => post(`/quarantine/${id}/purge`), (r) => `${r.purged} row(s) purged`);
  },
};

Pages.fixes = async (tab = "corrections") => {
  const tabs = ["corrections", "quarantine"];
  const body = tab === "quarantine" ? await FixTabs.quarantine() : await FixTabs.corrections();
  return `<div class="page-head"><h1>Fixes and quarantine</h1><span class="sub">Correct bad values, or set bad rows aside without losing them</span></div>
  <div class="tabs">${tabs.map((t) => `<a href="#/fixes/${t}" class="${t === tab ? "active" : ""}">${t === "corrections" ? "Corrections" : "Quarantine"}</a>`).join("")}</div>${body}`;
};
const FixTabs = {};
FixTabs.corrections = async () => {
  const r = await api("/fixes");
  const st = r.settings;
  return `<div class="callout ${st.auto_correct_low_risk ? "ok" : ""}">Automatic correction of low-risk issues is <strong>${st.auto_correct_low_risk ? "on" : "off"}</strong>
    ${st.auto_correct_low_risk ? `: after a check fails, low-risk corrections (up to ${st.auto_correct_max_rows.toLocaleString()} rows) are applied, then the check runs again.` : "."}
    Corrections run at once. Every correction snapshots the table first, so it can be undone.
    Turn it on or off with <code>remediation.auto_correct_low_risk</code> in config.yaml.</div><div class="sp"></div>
  <div class="card"><h2>Suggested corrections (${r.suggestions.length})</h2>
    ${r.suggestions.length ? `<div class="grid g2">${r.suggestions.map((f) => Fixes.card(f)).join("")}</div>` : '<div class="empty">No correctable issues right now. Corrections apply when the intended value is clear: case and spacing, close misspellings of an allowed value, surrounding spaces, exact duplicate rows.</div>'}</div><div class="sp"></div>
  <div class="card wrap"><h2>Correction history</h2><table class="t"><tr><th>When</th><th>Dataset</th><th>Correction</th><th>Risk</th><th class="num">Rows</th><th>By</th><th>Re-check</th><th>Status</th><th></th></tr>
    ${r.history.map((h) => `<tr><td>${ts(h.ts)}</td><td>${esc(short(h.asset))}</td><td>${esc(h.title)}</td><td>${pill(h.risk === "low" ? "ok" : h.risk === "medium" ? "warn" : "bad", h.risk)}</td>
      <td class="num">${h.rows.toLocaleString()}</td><td class="sub">${h.auto ? "automatic" : esc(h.actor)}</td><td>${h.detail && h.detail.recheck ? pill(h.detail.recheck) : ""}</td>
      <td>${pill(h.status === "applied" ? "ok" : "muted", h.status)}</td><td>${h.status === "applied" ? `<button class="btn sm" onclick="Fixes.undo(this, ${h.id})">Undo</button>` : ""}</td></tr>`).join("")
      || '<tr><td colspan="9" class="empty">No corrections yet</td></tr>'}</table></div>`;
};
FixTabs.quarantine = async () => {
  const [r, rules, assets] = await Promise.all([api("/quarantine?status=all"), api("/rules?status=active"), api("/assets")]);
  const s = r.summary, pre = Quarantine.pre || {};
  const qrules = rules.filter((x) => (["not_null", "accepted_values", "range", "regex", "length", "not_future", "custom_sql", "referential"].includes(x.type))
    && (x.last_status === "fail" || x.id === pre.rule_id));
  const isAdmin = !State.user || State.user.role === "admin";
  return `<div class="grid g4">
    <div class="card kpi warn"><div class="label">Rows held</div><div class="value">${s.rows_held.toLocaleString()}</div><div class="hint">${s.open_batches} open batch(es) in ${s.datasets} dataset(s)</div></div>
    <div class="card kpi ok"><div class="label">Rows released</div><div class="value">${s.released_rows.toLocaleString()}</div><div class="hint">re-checked and put back</div></div>
    <div class="card kpi info"><div class="label">Batches</div><div class="value">${s.batches}</div><div class="hint">${s.purged_batches} purged</div></div>
    <div class="card kpi info"><div class="label">Retention</div><div class="value">${r.retention_days}d</div><div class="hint">then purged automatically</div></div></div><div class="sp"></div>
  <div class="card"><h2>Quarantine bad rows</h2>
    <form id="q-form" class="grid" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px" onsubmit="return false">
      <label class="f">Failing rule<select name="rule_id"><option value="">Choose a rule…</option>${qrules.map((x) => `<option value="${x.id}" ${x.id === pre.rule_id ? "selected" : ""}>${esc(short(x.asset))} · ${esc(x.name)}</option>`).join("")}</select></label>
      <label class="f">Mode<select name="mode" onchange="$('#q-clean').hidden = this.value !== 'split'">
        <option value="move">Move: take bad rows out of the table</option><option value="copy">Copy: keep the table, inspect bad rows</option>
        <option value="split">Split: write good rows to a separate clean table</option></select></label>
      <label class="f">Quarantine table (optional)<input name="target" placeholder="default: <catalog>.dq_quarantine.<table>_quarantine"></label>
      <label class="f" id="q-clean" hidden>Clean table (optional)<input name="clean_table" placeholder="default: <table>_clean"></label>
      <label class="f">Note (optional)<input name="note" placeholder="Why these rows are set aside"></label>
      <input type="hidden" name="incident_id" value="${pre.incident_id || ""}">
    </form><div class="btns" style="margin-top:10px"><button class="btn" onclick="Quarantine.plan(this)">Preview</button>
      ${qrules.length ? "" : '<span class="sub">No failing rule can quarantine rows right now (row-level and reference rules can).</span>'}</div><div id="q-plan"></div></div><div class="sp"></div>
  <div class="card wrap"><h2>Batches</h2><table class="t"><tr><th>Batch</th><th>Dataset</th><th>Rule</th><th>Mode</th><th class="num">Held / total</th><th>Quarantine table</th><th>Created</th><th>Status</th><th></th></tr>
    ${r.batches.map((b) => `<tr><td class="mono">${esc(b.batch_key)}</td><td>${esc(short(b.asset))}</td><td>${esc(b.rule || "")}</td><td>${esc(b.mode)}${b.clean_table ? `<div class="sub">clean: ${esc(short(b.clean_table))}</div>` : ""}</td>
      <td class="num">${(b.status === "purged" ? 0 : b.held).toLocaleString()} / ${b.rows.toLocaleString()}</td><td class="mono sub">${esc(b.target_table)}</td>
      <td>${ts(b.created)}${b.expires && b.status !== "purged" ? `<div class="sub">expires ${ts(b.expires)}</div>` : ""}</td>
      <td>${pill(b.status === "quarantined" ? "warn" : b.status === "purged" ? "muted" : "ok", b.status.replace("_", " "))}</td>
      <td class="btns">${b.status !== "purged" ? `<button class="btn sm" onclick="Quarantine.view(${b.id})">Rows</button>` : ""}
        ${["quarantined", "partially_released"].includes(b.status) ? `<button class="btn sm" onclick="Quarantine.release(this, ${b.id}, true)" title="Put back rows that now pass the rule">Release</button>
        ${isAdmin ? `<button class="btn sm" onclick="Quarantine.release(this, ${b.id}, false)">Release all</button>` : ""}
        <button class="btn sm danger" onclick="Quarantine.purge(this, ${b.id}, ${b.held})">Purge</button>` : ""}</td></tr>
      <tr id="qb-${b.id}" hidden></tr>`).join("") || '<tr><td colspan="9" class="empty">Nothing quarantined</td></tr>'}</table></div>`;
};

/* ------------------------------------------------------------------ impact analysis */
const Impact = {
  st: { change: "data", columns: [] },
  set(k, v) { this.st[k] = v; render(true); },
  toggleCol(c, on) { const s = new Set(this.st.columns); if (on) s.add(c); else s.delete(c); this.st.columns = [...s]; },
  async notify(btn, id) {
    const note = $("#imp-note").value;
    await act(btn, () => post("/impact/notify", { asset_id: id, columns: this.st.columns, change: this.st.change, note }),
      (r) => `Notified ${r.owners.length} owner(s): ${r.sent.map((s) => s.channel + " " + s.status).join(", ")}`);
  },
};
Pages.impact = async (id) => {
  const tabs = (active) => `<div class="tabs"><a href="#/impact${Impact.st.asset ? "/" + Impact.st.asset : ""}" class="${active === "analysis" ? "active" : ""}">Impact analysis</a>
    <a href="#/impact/lineage" class="${active === "lineage" ? "active" : ""}">Lineage</a></div>`;
  if (id === "lineage") {
    return `<div class="page-head"><h1>Impact analysis</h1><span class="sub">How data flows between datasets, and what breaks downstream when something goes wrong</span><span class="grow"></span>${await platformPicker()}</div>
      ${tabs("lineage")}${await lineageTab()}`;
  }
  const [allAssets, picker] = await Promise.all([api("/assets"), platformPicker()]);
  const assets = State.platform ? allAssets.filter((x) => x.platform === State.platform) : allAssets;
  const a = allAssets.find((x) => String(x.id) === String(id)) || null;
  if (a && State.platform && a.platform !== State.platform) State.platform = "";  // opened from elsewhere: show where it lives
  if (a && Impact.st.asset !== a.id) { Impact.st = { change: "data", columns: [], asset: a.id }; }
  const st = Impact.st;
  const head = `<div class="page-head"><h1>Impact analysis</h1><span class="sub">What breaks downstream if this data is wrong, or if its schema changes</span><span class="grow"></span><div class="pick-stack">${picker}
    <select aria-label="Dataset" onchange="location.hash='#/impact/'+this.value"><option value="">Choose a dataset…</option>${assets.map((x) => `<option value="${x.id}" ${a && x.id === a.id ? "selected" : ""}>${esc(x.fqn)}</option>`).join("")}</select></div></div>
    ${tabs("analysis")}`;
  if (!a) return head + '<div class="card empty">Choose a dataset to see its downstream impact. You can also open this from any dataset or incident with the Impact button, or browse the whole graph in the Lineage tab.</div>';
  const q = new URLSearchParams({ asset_id: a.id, change: st.change, columns: st.columns.join(",") });
  const [rep, g] = await Promise.all([api("/impact?" + q), api("/lineage?depth=6&fqn=" + encodeURIComponent(a.fqn))]);
  const lvl = { critical: "bad", high: "bad", medium: "warn", low: "ok" }[rep.level];
  return head + `<div class="card"><div class="xbar" style="margin-top:0">
      <label class="f">Scenario<select onchange="Impact.set('change', this.value)">
        <option value="data" ${st.change === "data" ? "selected" : ""}>Data quality problem in this dataset</option>
        <option value="drop" ${st.change === "drop" ? "selected" : ""}>Drop columns</option>
        <option value="retype" ${st.change === "retype" ? "selected" : ""}>Change column types</option></select></label>
      <div class="f" style="flex:1"><span class="sub" style="font-size:12px">Columns ${st.change === "data" ? "(optional: limit to these columns)" : ""}</span>
        <div class="row" style="gap:8px;flex-wrap:wrap;max-height:70px;overflow:auto">${(a.columns || []).map((c) => `<label class="row sub" style="gap:4px"><input type="checkbox" ${st.columns.includes(c.name) ? "checked" : ""}
          onchange="Impact.toggleCol(${jsq(c.name)}, this.checked)">${esc(c.name)}</label>`).join("")}</div></div>
      <button class="btn primary" onclick="render(true)">Analyse</button></div></div><div class="sp"></div>
  <div class="grid g4">
    <div class="card kpi ${lvl}"><div class="label">Impact score</div><div class="value">${rep.score}<span class="sub" style="font-size:14px"> / 100</span></div><div class="hint">${pill(rep.level)}</div></div>
    <div class="card kpi info"><div class="label">Downstream datasets</div><div class="value">${rep.impacted.length}</div><div class="hint">${rep.impacted.filter((i) => i.certified).length} certified</div></div>
    <div class="card kpi info"><div class="label">Rules involved</div><div class="value">${rep.rules.length}</div><div class="hint">${rep.policies.length} policy link(s)</div></div>
    <div class="card kpi ${rep.contracts.some((c) => c.breaking) ? "bad" : "info"}"><div class="label">Contracts</div><div class="value">${rep.contracts.length}</div><div class="hint">${rep.contracts.filter((c) => c.breaking).length} breaking</div></div></div><div class="sp"></div>
  <div class="callout ${lvl === "bad" ? "bad" : ""}">${esc(rep.summary)}${rep.columns.length && !rep.column_lineage ? " Column-level lineage isn't available for this dataset, so downstream columns are matched by name." : ""}</div><div class="sp"></div>
  <div class="grid g2">
    <div class="card"><h2>Downstream lineage</h2>${lineageSvg(g)}</div>
    <div class="card"><h2>People to tell</h2>${rep.owners.map((o) => `<div class="row" style="margin:4px 0"><span class="avatar" style="width:26px;height:26px;font-size:11px">${esc(initials(o.name))}</span>
        <span><strong>${esc(o.name)}</strong><div class="sub">${o.datasets.map((d) => esc(short(d))).join(", ")}</div></span></div>`).join("") || '<div class="empty">No owners on record</div>'}
      <label class="f" style="margin-top:10px">Note for the message (optional)<input id="imp-note" placeholder="e.g. Fix expected by 14:00 UTC"></label>
      <div class="btns" style="margin-top:8px"><button class="btn primary" onclick="Impact.notify(this, ${a.id})">Notify owners</button></div></div></div><div class="sp"></div>
  <div class="card wrap"><h2>Impacted datasets</h2><table class="t"><tr><th class="num">Hops</th><th>Dataset</th><th>Owner</th><th>${esc(GL())}</th><th>Score</th><th>Open incidents</th>${rep.columns.length ? "<th>Affected columns</th>" : ""}<th class="num">Weight</th></tr>
    ${rep.impacted.map((i) => `<tr><td class="num">${i.distance}</td><td>${i.asset_id ? `<a href="#/asset/${i.asset_id}">${esc(i.fqn)}</a>` : esc(i.fqn)} ${i.certified ? pill("ok", "certified") : ""}</td>
      <td class="sub">${esc(i.owner || "")}</td><td>${esc(i.domain || "")}</td><td>${score(i.score)}</td><td class="num">${i.open_incidents || ""}</td>
      ${rep.columns.length ? `<td>${i.columns.map((c) => `<code>${esc(c)}</code>`).join(" ")}${i.column_match ? `<div class="sub">${esc(i.column_match)}</div>` : ""}</td>` : ""}<td class="num">${i.weight}</td></tr>`).join("")
      || '<tr><td colspan="8" class="empty">Nothing downstream</td></tr>'}</table></div><div class="sp"></div>
  <div class="grid g2">
    <div class="card wrap"><h2>Rules</h2><table class="t">${rep.rules.map((r) => `<tr><td>${esc(r.name)}<div class="sub">${esc(short(r.asset))} · ${esc(r.why)}</div></td><td>${pill(r.severity)}</td></tr>`).join("") || '<tr><td class="empty">None</td></tr>'}</table></div>
    <div class="card wrap"><h2>Contracts and policies</h2><table class="t">${rep.contracts.map((c) => `<tr><td>Contract on <a href="#/asset/${c.asset_id}/contract">${esc(short(c.asset))}</a> v${esc(c.version)}${c.columns.length ? `<div class="sub">columns ${c.columns.map(esc).join(", ")}</div>` : ""}</td><td>${c.breaking ? pill("bad", "breaking") : pill("ok", "ok")}</td></tr>`).join("")}
      ${rep.policies.map((p) => `<tr><td>Policy ${esc(p.policy)}<div class="sub">${esc(p.type)} on ${esc(p.column)}</div></td><td>${pill("warn", "review")}</td></tr>`).join("")}
      ${!rep.contracts.length && !rep.policies.length ? '<tr><td class="empty">None</td></tr>' : ""}</table></div></div>`;
};

/* ------------------------------------------------------------------ insights */
const INSIGHT_MODES = { due: "Sync metadata and run due checks", all: "Sync metadata and run every active check", sync: "Sync metadata only" };
const Insights = {
  mode: "due",
  async refresh(btn) {
    Insights.mode = $("#ins-mode").value;
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = "Refreshing…";
    try {
      const r = await post("/insights/refresh", { mode: Insights.mode });
      const parts = [`Synced ${r.sync.datasets} dataset(s)` + (r.sync.new ? `, ${r.sync.new} new` : "")];
      if (r.checks && !r.checks.checks && r.mode === "due") parts.push("no checks were due (they ran recently, or their tables haven't changed). Pick \"run every active check\" to run them anyway");
      else if (r.checks) parts.push(`ran ${r.checks.checks} check(s) on ${r.checks.datasets} dataset(s), ${r.checks.failed} failed` + (r.checks.schedules ? ` (${r.checks.schedules} schedule(s))` : ""));
      if (r.datasets_without_rules) parts.push(`${r.datasets_without_rules} dataset(s) have no active rules yet: use AI Rule Studio to add some`);
      const errs = [...Object.entries(r.sync.errors || {}).map(([k, v]) => `${k}: ${v}`), ...((r.checks && r.checks.errors) || [])];
      (errs.length ? toastWarn : toastOk)(parts.join("; ") + "." + (errs.length ? "\nProblems:\n" + errs.join("\n") : ""));
      await render(true);
    } catch (e) { toastError(e.message); } finally { btn.disabled = false; btn.textContent = label; }
  },
  card(h) {
    const col = { high: "var(--bad)", medium: "#e3a008", low: "var(--accent)" }[h.severity] || "var(--accent)";
    const icon = { recurring: "↻", timing: "◷", dimension: "▦", source: "⇢", learning: "✦" }[h.kind] || "•";
    return `<div class="insight" style="border-left-color:${col}"><div class="row" style="gap:8px;align-items:flex-start"><span class="ins-ic" style="color:${col}">${icon}</span>
      <div><div>${esc(h.text)}</div><div class="sub" style="margin-top:4px">${esc(h.tip)}</div>${h.link ? `<a class="sub" href="${h.link}">Open →</a>` : ""}</div></div></div>`;
  },
};
Pages.insights = async () => {
  const [r, picker] = await Promise.all([api("/insights?" + platQ("days=30")), platformPicker()]);
  const L = r.learnings, maxHeat = Math.max(1, ...r.heat.flat());
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const lr = r.last_refresh;
  return `<div class="page-head"><div><h1>Insights</h1><div class="sub">Patterns found in the last ${r.days} days (${r.totals.failures} failed checks out of ${r.totals.checks}, ${r.totals.incidents} incidents) and what the system has learned</div>
      <div class="sub" style="font-size:11.5px">${lr ? `Last refreshed ${ts(lr.at)} by ${esc(lr.actor)} (${esc(INSIGHT_MODES[lr.mode] || lr.mode)})` : "Not refreshed from the platforms yet: patterns use the checks already stored."}</div></div><span class="grow"></span>
    <div class="btns">${picker}<select class="sel-sm" id="ins-mode" aria-label="What to refresh" title="What the refresh pulls from the connected platforms">
      ${Object.entries(INSIGHT_MODES).map(([k, l]) => `<option value="${k}" ${k === Insights.mode ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>
      <button class="btn primary" onclick="Insights.refresh(this)">Refresh insights</button></div></div>
  <div class="grid g3">${r.highlights.map(Insights.card).join("") || '<div class="card empty">Patterns appear here as checks run and people give feedback.</div>'}</div><div class="sp"></div>
  <div class="grid g2">
    <div class="card wrap"><h2>Recurring incidents</h2><table class="t"><tr><th>Source</th><th class="num">Incidents</th><th>Usual day</th><th>Usual cause</th><th class="num">Avg hours to fix</th></tr>
      ${r.recurring.map((x) => `<tr><td>${x.asset_id ? `<a href="#/asset/${x.asset_id}">${esc(short(x.root))}</a>` : esc(short(x.root))}</td><td class="num">${x.count}</td>
        <td>${esc(x.common_day || "-")}</td><td class="sub">${esc((x.hypotheses[0] || ["-"])[0])}</td><td class="num">${x.mttr_hours ?? "-"}</td></tr>`).join("")
        || '<tr><td colspan="5" class="empty">No repeat incidents</td></tr>'}</table></div>
    <div class="card"><h2>When checks fail</h2><div class="heatgrid">${r.heat.map((row, d) => `<span class="hl">${days[d]}</span>${row.map((v, h) =>
        `<span class="hc" title="${days[d]} ${String(h).padStart(2, "0")}:00 UTC: ${v} failure(s)" style="background:${v ? `color-mix(in srgb, var(--bad) ${Math.round(15 + 85 * v / maxHeat)}%, transparent)` : "var(--surface-3)"}"></span>`).join("")}`).join("")}
        <span></span>${Array.from({ length: 24 }, (_, h) => `<span class="hx">${h % 6 === 0 ? h : ""}</span>`).join("")}</div>
      <p class="sub" style="font-size:11.5px">Hour of day (UTC) across, weekday down. Darker means more failures.</p>
      ${bars(r.by_day.map((v, d) => ({ label: days[d], value: v })), { color: "var(--bad)" })}</div>
  </div><div class="sp"></div>
  <div class="grid g3">
    <div class="card"><h2>Hotspots</h2>${bars(r.hotspots.map((h) => ({ label: short(h.fqn), value: h.fails, text: `${h.fails} (${Math.round(h.fail_rate * 100)}%)`, href: `#/asset/${h.asset_id}` })), { color: "var(--bad)" })}</div>
    <div class="card"><h2>Root-cause patterns</h2>${bars(r.root_causes.map(([k, v]) => ({ label: k, value: v })), { color: "#e3a008" })}</div>
    <div class="card"><h2>Failures by dimension</h2>${bars(Object.entries(r.dimensions).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ label: k, value: v })))}</div>
  </div><div class="sp"></div>
  <h2>What the system has learned</h2>
  <div class="grid g4">
    <div class="card kpi info"><div class="label">Alert precision</div><div class="value">${L.precision != null ? Math.round(L.precision * 100) + "%" : "-"}</div><div class="hint">from steward feedback</div></div>
    <div class="card kpi info"><div class="label">Feedback</div><div class="value">${(L.feedback.true_positive || 0) + (L.feedback.false_positive || 0) + (L.feedback.expected_change || 0)}</div>
      <div class="hint">${L.feedback.true_positive || 0} real · ${L.feedback.false_positive || 0} false · ${L.feedback.expected_change || 0} expected</div></div>
    <div class="card kpi ok"><div class="label">Rows corrected</div><div class="value">${L.rows_corrected.toLocaleString()}</div><div class="hint">${L.auto_corrections} automatic · ${L.manual_corrections} manual · ${L.undone} undone</div></div>
    <div class="card kpi warn"><div class="label">Rows quarantined</div><div class="value">${L.rows_quarantined.toLocaleString()}</div><div class="hint">${L.rows_released.toLocaleString()} released</div></div></div><div class="sp"></div>
  <div class="grid g3">
    <div class="card"><h2>Tuning from feedback</h2>${L.tuned.map((t) => `<div class="ev"><div class="when">${ts(t.at)} · ${esc(t.verdict.replace("_", " "))}</div><strong>${esc(t.rule || "")}</strong><div class="sub">${esc(t.effect)}</div></div>`).join("")
      || '<div class="empty">No tuning yet</div>'}</div>
    <div class="card"><h2>Rules by origin</h2>${bars(Object.entries(L.rules_by_source).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ label: k, value: v })))}
      <p class="sub" style="font-size:11.5px">Rules added per week (last 8): ${L.rules_added_per_week.join(" · ")}</p></div>
    <div class="card"><h2>Needs attention</h2>
      ${L.noisy_rules.map((n) => `<div class="ev"><strong>${esc(n.name)}</strong><div class="sub">${esc(short(n.asset))} · ${n.fp} false positives</div></div>`).join("")}
      ${r.flaky.map((f) => `<div class="ev"><strong>${esc(f.name)}</strong><div class="sub">${esc(short(f.asset))} · flips between pass and fail (${f.flips} of ${f.runs} runs)</div></div>`).join("")}
      ${!L.noisy_rules.length && !r.flaky.length ? '<div class="empty">No noisy or flaky rules</div>' : ""}</div>
  </div>`;
};

/* ------------------------------------------------------------------ guide: Markdown docs from docs/index.yaml */
const MD = {
  slug(s) { return String(s).toLowerCase().replace(/[^a-z0-9\s-]/g, "").trim().replace(/\s+/g, "-"); },
  link(href, doc) {
    if (/^https?:/i.test(href)) return `href="${href}" target="_blank" rel="noopener"`;
    if (href.startsWith("#")) return `href="#/guide/${doc}/${href.slice(1)}"`;
    const m = href.match(/^(?:\.\/)?(?:docs\/)?([\w.-]+\.md)(?:#([\w-]+))?$/);
    if (m) {
      const d = (Guide.docs || []).find((x) => x.file === m[1]);
      if (d) return `href="#/guide/${d.id}${m[2] ? "/" + m[2] : ""}"`;
    }
    return `href="${href}"`;
  },
  inline(s, doc) {
    const codes = [];
    let t = esc(s).replace(/`([^`]+)`/g, (_, c) => { codes.push(c); return `\u0000${codes.length - 1}\u0000`; });
    t = t.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (_, txt, href) => `<a ${MD.link(href, doc)}>${txt}</a>`)
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      .replace(/(^|[\s(])\*([^*\s][^*]*?)\*(?=[\s).,;:!?]|$)/g, "$1<em>$2</em>")
      .replace(/(^|[\s(])_([^_\s][^_]*?)_(?=[\s).,;:!?]|$)/g, "$1<em>$2</em>");
    return t.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${codes[+i]}</code>`);
  },
  LIST: /^(\s*)([-*]|\d+\.)\s+(.*)$/,
  list(lines, start, doc) {
    const items = [];
    let i = start, inFence = false;
    while (i < lines.length) {
      const l = lines[i];
      if (inFence || (/^\s+```/.test(l) && items.length)) {
        if (/^\s*```/.test(l)) inFence = !inFence;
        items[items.length - 1].body.push(l); i++; continue;
      }
      const m = l.match(MD.LIST);
      if (m) { items.push({ indent: m[1].length, ordered: /\d/.test(m[2]), first: m[3], body: [], ci: m[1].length + m[2].length + 1 }); i++; continue; }
      if (!l.trim()) {
        let j = i + 1;
        while (j < lines.length && !lines[j].trim()) j++;
        if (items.length && j < lines.length && (MD.LIST.test(lines[j]) || /^\s+\S/.test(lines[j]))) { items[items.length - 1].body.push(""); i++; continue; }
        break;
      }
      if (/^\s+\S/.test(l) && items.length) { items[items.length - 1].body.push(l); i++; continue; }
      break;
    }
    const root = { children: [], indent: -1 }, stack = [root];
    for (const it of items) {
      while (stack.length > 1 && it.indent <= stack[stack.length - 1].indent) stack.pop();
      it.children = [];
      stack[stack.length - 1].children.push(it);
      stack.push(it);
    }
    const html = (nodes) => {
      let out = "", cur = null;
      for (const n of nodes) {
        const tag = n.ordered ? "ol" : "ul";
        if (cur !== tag) { if (cur) out += `</${cur}>`; out += `<${tag}>`; cur = tag; }
        const body = n.body.map((b) => b.slice(Math.min(n.ci, b.match(/^\s*/)[0].length))).join("\n").trim();
        out += `<li>${MD.inline(n.first, doc)}${body ? MD.render(body, doc).html : ""}${html(n.children)}</li>`;
      }
      return cur ? out + `</${cur}>` : "";
    };
    return { html: html(root.children), next: i };
  },
  render(src, doc) {
    const lines = String(src).replace(/\r/g, "").split("\n");
    const out = [], toc = [], used = {};
    const hid = (text) => {
      let s = MD.slug(text.replace(/[`*]/g, ""));
      if (used[s] != null) { used[s] += 1; s = `${s}-${used[s]}`; } else used[s] = 0;
      return s;
    };
    const isSep = (l) => /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)*\|?\s*$/.test(l);
    const cells = (r) => r.trim().replace(/^\|/, "").replace(/\|$/, "").split(/(?<!\\)\|/).map((c) => c.trim().replace(/\\\|/g, "|"));
    let i = 0, m;
    while (i < lines.length) {
      const l = lines[i];
      if (!l.trim()) { i++; continue; }
      if ((m = l.match(/^\s*```(\w*)/))) {
        const ind = l.match(/^\s*/)[0].length, buf = [];
        i++;
        while (i < lines.length && !/^\s*```/.test(lines[i])) { buf.push(lines[i].slice(Math.min(ind, lines[i].match(/^\s*/)[0].length))); i++; }
        i++;
        out.push(cmdBlock(buf));
        continue;
      }
      if ((m = l.match(/^(#{1,4})\s+(.*)$/))) {
        const level = m[1].length, text = m[2].trim(), id = hid(text);
        if (level === 2 || level === 3) toc.push({ level, text, id });
        out.push(`<h${level} id="${id}">${MD.inline(text, doc)}<a class="anchor" href="#/guide/${doc}/${id}" aria-label="Link to this section">#</a></h${level}>`);
        i++; continue;
      }
      if (/^\s*(---|\*\*\*)\s*$/.test(l)) { out.push("<hr>"); i++; continue; }
      if (/^\s*\|/.test(l) && i + 1 < lines.length && isSep(lines[i + 1])) {
        const head = cells(l), rows = [];
        i += 2;
        while (i < lines.length && /^\s*\|/.test(lines[i])) { rows.push(cells(lines[i])); i++; }
        out.push(`<div class="wrap"><table class="t"><tr>${head.map((h) => `<th>${MD.inline(h, doc)}</th>`).join("")}</tr>` +
          rows.map((r) => `<tr>${r.map((c) => `<td>${MD.inline(c, doc)}</td>`).join("")}</tr>`).join("") + "</table></div>");
        continue;
      }
      if (/^\s*>/.test(l)) {
        const buf = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) { buf.push(lines[i].replace(/^\s*>\s?/, "")); i++; }
        out.push(`<blockquote>${MD.render(buf.join("\n"), doc).html}</blockquote>`);
        continue;
      }
      if (MD.LIST.test(l)) { const r = MD.list(lines, i, doc); out.push(r.html); i = r.next; continue; }
      const buf = [];
      while (i < lines.length && lines[i].trim() && !MD.LIST.test(lines[i]) && !/^\s*(```|#{1,4}\s|\||>)/.test(lines[i])) { buf.push(lines[i].trim()); i++; }
      if (!buf.length) { buf.push(lines[i].trim()); i++; }
      out.push(`<p>${MD.inline(buf.join(" "), doc)}</p>`);
    }
    return { html: out.join("\n"), toc };
  },
};

const Guide = {
  docs: null, index: null, q: "", current: "", _t: null,
  async load() {
    if (!this.docs) this.docs = (await api("/docs")).docs;
    return this.docs;
  },
  buildIndex() {
    const secs = [];
    for (const d of this.docs) {
      const tpl = document.createElement("template");
      tpl.innerHTML = MD.render(d.markdown, d.id).html;
      tpl.content.querySelectorAll("button, .anchor").forEach((el) => el.remove());
      let cur = { doc: d, id: "", title: d.title, text: "" };
      for (const el of tpl.content.children) {
        if (/^H[1-4]$/.test(el.tagName)) {
          if (cur.text.trim()) secs.push(cur);
          cur = { doc: d, id: el.id, title: el.textContent.trim(), text: "" };
        } else cur.text += " " + el.textContent;
      }
      if (cur.text.trim()) secs.push(cur);
    }
    this.index = secs.map((s) => ({ ...s, text: s.text.replace(/\s+/g, " ").trim(), hay: (s.title + " " + s.text).toLowerCase() }));
  },
  search(q) {
    this.q = q;
    clearTimeout(this._t);
    this._t = setTimeout(() => {
      const box = $("#guide-content");
      if (!box) return;
      const words = q.toLowerCase().split(/\s+/).filter((w) => w.length > 1);
      if (!words.length) { box.innerHTML = this.current; return; }
      if (!this.index) this.buildIndex();
      const hits = this.index.filter((s) => words.every((w) => s.hay.includes(w)))
        .map((s) => ({ s, score: words.reduce((a, w) => a + (s.title.toLowerCase().includes(w) ? 10 : 0) + s.hay.split(w).length - 1, 0) }))
        .sort((a, b) => b.score - a.score).slice(0, 30);
      const snip = (t) => {
        const low = t.toLowerCase(), at = Math.max(0, low.indexOf(words[0]) - 70);
        let s = esc((at ? "…" : "") + t.slice(at, at + 220) + (t.length > at + 220 ? "…" : ""));
        words.forEach((w) => { s = s.replace(new RegExp(w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi"), (x) => `<mark>${x}</mark>`); });
        return s;
      };
      box.innerHTML = `<h1>Search results</h1><p class="sub">${hits.length} section(s) match “${esc(q)}”</p>` +
        (hits.map(({ s }) => `<a class="gres" href="#/guide/${s.doc.id}${s.id ? "/" + s.id : ""}" onclick="Guide.q=''">
          <div class="gt">${esc(s.doc.title)}${s.id ? " › " + esc(s.title) : ""}</div><div class="sub">${snip(s.text)}</div></a>`).join("")
          || '<div class="empty">Nothing found. Try fewer or different words.</div>');
    }, 120);
  },
};

Pages.guide = async (docId, anchor) => {
  const docs = await Guide.load();
  if (!docs.length) return '<div class="card empty">No documentation found. Make sure the docs folder is deployed with the app.</div>';
  const d = docs.find((x) => x.id === docId) || docs[0];
  const { html, toc } = MD.render(d.markdown, d.id);
  const groups = {};
  docs.forEach((x) => (groups[x.group] = groups[x.group] || []).push(x));
  const k = docs.indexOf(d), prev = docs[k - 1], next = docs[k + 1];
  Guide.current = html + `<div class="doc-nav">${prev ? `<a href="#/guide/${prev.id}">← ${esc(prev.title)}</a>` : "<span></span>"}${next ? `<a href="#/guide/${next.id}">${esc(next.title)} →</a>` : ""}</div>`;
  setTimeout(() => {
    if (Guide.q) Guide.search(Guide.q);
    else if (anchor) { const el = document.getElementById(anchor); if (el) el.scrollIntoView({ block: "start" }); }
  }, 0);
  return `<div class="guide">
    <aside class="guide-nav">
      <input type="search" placeholder="Search the guide" value="${esc(Guide.q)}" oninput="Guide.search(this.value)" autocomplete="off" aria-label="Search the guide">
      ${Object.entries(groups).map(([g, xs]) => `<div class="gs">${esc(g)}</div>${xs.map((x) =>
        `<a class="gdoc ${x.id === d.id ? "active" : ""}" href="#/guide/${x.id}" title="${esc(x.summary)}" onclick="Guide.q=''">${esc(x.title)}</a>`).join("")}`).join("")}
      ${toc.length ? `<div class="gs">On this page</div><nav class="gtoc">${toc.map((t) =>
        `<a class="l${t.level}" href="#/guide/${d.id}/${t.id}">${esc(t.text.replace(/[`*]/g, ""))}</a>`).join("")}</nav>` : ""}
    </aside>
    <article class="card doc" id="guide-content">${Guide.current}</article>
  </div>`;
};

/* ------------------------------------------------------------------ sign-in, sign-up, administrator sign-in */
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const ROLE_DESC = {
  admin: "Everything, plus the Admin console (users and roles), connections, policies, environment settings and deploy packages.",
  steward: "Monitor data, author and approve rules, triage incidents, approve changes, and manage governance.",
  viewer: "See everything and ask the agent, but not change anything.",
};

const Auth = {
  cfg: { mode: "local", signup: "approval", min_password_length: 10 },
  async start() {
    try { this.cfg = await (await fetch("/api/auth/config")).json(); } catch (e) { /* keep defaults */ }
    let r;
    try { r = await fetch("/api/auth/me", { headers: { "X-Requested-With": "DataTrustAI" } }); } catch (e) { r = null; }
    if (r && r.ok) {
      const u = await r.json();
      return u.must_change_password ? this.show("change") : App.enter(u);
    }
    if (this.cfg.mode === "sso") {
      let detail = "";
      try { detail = (await r.json()).detail; } catch (e) { /* no body */ }
      return this.show("sso", detail);
    }
    this.show(this.cfg.needs_setup ? "setup" : location.hash.startsWith("#/admin") ? "admin" : "signin");
  },
  expired() {
    if (State.user) { State.user = null; this.show("signin", "Your session has ended. Sign in again."); }
  },
  field(name, label, type = "text", auto = "off", extra = "") {
    return `<label class="f">${label}<input type="${type}" name="${name}" autocomplete="${auto}" ${extra}><span class="ferr" data-for="${name}"></span></label>`;
  },
  pw(name, label, auto) {
    return `<label class="f">${label}<span class="pw"><input type="password" name="${name}" autocomplete="${auto}">
      <button type="button" class="pw-toggle" onclick="Auth.reveal(this)" aria-label="Show password">Show</button></span><span class="ferr" data-for="${name}"></span></label>`;
  },
  reveal(btn) {
    const inp = btn.previousElementSibling, show = inp.type === "password";
    inp.type = show ? "text" : "password";
    btn.textContent = show ? "Hide" : "Show";
    btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
  },
  hint() { return `<p class="sub small">At least ${this.cfg.min_password_length || 10} characters, with letters and numbers. Avoid your name and email.</p>`; },
  views() {
    const canSignup = this.cfg.signup !== "disabled";
    return {
      signin: { title: "Sign in", sub: "Welcome back. Sign in to your TCS DataTrustAI account.", button: "Sign in",
        body: this.field("email", "Work email", "email", "username") + this.pw("password", "Password", "current-password"),
        foot: (canSignup ? `<p>New here? <a href="#" onclick="Auth.show('signup');return false">Create an account</a></p>` : "<p class=\"sub\">Need access? Ask an administrator to create your account.</p>") +
          `<a class="auth-switch" href="#" onclick="Auth.show('admin');return false"><span>Administrator sign-in</span><span aria-hidden="true">→</span></a>` },
      admin: { title: "Administrator sign-in", badge: true, sub: "Manage users, roles and access to TCS DataTrustAI.", button: "Sign in as administrator",
        body: this.field("email", "Administrator email", "email", "username") + this.pw("password", "Password", "current-password"),
        foot: `<p><a href="#" onclick="Auth.show('signin');return false">← Back to sign in</a></p>` },
      signup: { title: "Create your account", sub: this.cfg.signup === "open" ? "Get started with TCS DataTrustAI."
          : "An administrator approves new accounts before the first sign-in.", button: "Create account",
        body: this.field("name", "Full name", "text", "name") + this.field("email", "Work email", "email", "email") +
          this.pw("password", "Password", "new-password") + this.pw("confirm", "Confirm password", "new-password") + this.hint(),
        foot: `<p>Already have an account? <a href="#" onclick="Auth.show('signin');return false">Sign in</a></p>` },
      setup: { title: "Set up TCS DataTrustAI", badge: true, sub: "Create the administrator account. You'll use it to approve users and manage access.",
        button: "Create administrator",
        body: this.field("name", "Full name", "text", "name") + this.field("email", "Work email", "email", "email") +
          this.pw("password", "Password", "new-password") + this.pw("confirm", "Confirm password", "new-password") + this.hint(), foot: "" },
      change: { title: "Choose a new password", sub: "Your password was reset by an administrator. Choose a new one to continue.", button: "Save and continue",
        body: this.pw("current", "Temporary password", "current-password") + this.pw("password", "New password", "new-password") +
          this.pw("confirm", "Confirm new password", "new-password") + this.hint(),
        foot: `<p><a href="#" onclick="Account.signOut();return false">Sign out</a></p>` },
      pending: { title: "Request sent", sub: "", button: null,
        body: `<div class="callout ok">Your account was created and is waiting for an administrator to approve it. You'll be able to sign in once it's approved.</div>`,
        foot: `<p><a href="#" onclick="Auth.show('signin');return false">Back to sign in</a></p>` },
      sso: { title: "Single sign-on", sub: "", button: null,
        body: `<div class="callout bad">${esc(this._msg || "No single sign-on identity was received.")}</div>
          <p class="sub">This deployment signs users in through the platform (for example Databricks workspace SSO). Open the app from your workspace, or ask an administrator.</p>`,
        foot: "" },
    };
  },
  show(view, msg) {
    State.user = null;
    this._msg = msg;
    $("#app").hidden = true;
    $("#fab").hidden = true;
    const v = this.views()[view] || this.views().signin;
    const plats = ["databricks", "snowflake", "azure_purview", "aws_glue", "cognite"].map((p) => plat(p, { azure_purview: "Azure", aws_glue: "AWS" }[p])).join(" ");
    const a = $("#auth");
    a.hidden = false;
    a.innerHTML = `<div class="auth-wrap ${v.badge ? "is-admin" : ""}">
      <section class="auth-brand">
        <div class="brand"><div class="mark" aria-hidden="true">DT</div><div class="name">TCS DataTrustAI<small>Data quality and governance</small></div></div>
        <h2>Trusted data, explained.</h2>
        <ul><li>Quality checks that run inside Databricks, Snowflake, Azure and AWS</li>
          <li>Every failure traced to the table where it started</li>
          <li>Governance with a full audit trail</li>
          <li>An AI agent that answers from real check results</li></ul>
        <div class="auth-plats">${plats}</div>
      </section>
      <section class="auth-form">
        ${v.badge ? `<div class="auth-badge"><svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true" style="fill:none;stroke:currentColor;stroke-width:2"><path d="M12 3 4.5 6v6c0 4.8 3.3 8 7.5 9 4.2-1 7.5-4.2 7.5-9V6L12 3z"/></svg>Administrator</div>` : ""}
        <h1>${esc(v.title)}</h1>${v.sub ? `<p class="sub">${esc(v.sub)}</p>` : ""}
        <div id="auth-msg">${msg && view !== "sso" ? `<div class="callout">${esc(msg)}</div>` : ""}</div>
        <form onsubmit="Auth.submit(event, '${view}')" novalidate>${v.body}
          ${v.button ? `<button type="submit" class="btn primary auth-submit">${esc(v.button)}</button>` : ""}</form>
        <div class="auth-foot">${v.foot}</div>
      </section></div>
      <p class="auth-legal">TCS DataTrustAI v${esc(this.cfg.version || "")} · Sessions are protected with secure, HttpOnly cookies. Every sign-in is audited.</p>`;
    const first = a.querySelector("input");
    if (first) first.focus();
  },
  validate(view, d) {
    const e = {}, n = this.cfg.min_password_length || 10;
    if ("email" in d && !EMAIL_RE.test((d.email || "").trim())) e.email = "Enter a valid email address.";
    if ("name" in d && !(d.name || "").trim()) e.name = "Enter your name.";
    if ("current" in d && !d.current) e.current = "Enter your temporary password.";
    if (!d.password) e.password = "Enter a password.";
    else if (["signup", "setup", "change"].includes(view)) {
      if (d.password.length < n) e.password = `Use at least ${n} characters.`;
      else if (!/[A-Za-z]/.test(d.password) || !/\d/.test(d.password)) e.password = "Use both letters and numbers.";
      if (d.confirm !== d.password) e.confirm = "Passwords don't match.";
    }
    return e;
  },
  async submit(ev, view) {
    ev.preventDefault();
    const f = ev.target, d = Object.fromEntries(new FormData(f));
    f.querySelectorAll(".ferr").forEach((x) => (x.textContent = ""));
    f.querySelectorAll(".invalid").forEach((x) => x.classList.remove("invalid"));
    $("#auth-msg").innerHTML = "";
    const errs = this.validate(view, d);
    if (Object.keys(errs).length) {
      for (const [k, v] of Object.entries(errs)) {
        const el = f.querySelector(`.ferr[data-for="${k}"]`);
        if (el) el.textContent = v;
        const inp = f.querySelector(`[name="${k}"]`);
        if (inp) inp.classList.add("invalid");
      }
      f.querySelector(`[name="${Object.keys(errs)[0]}"]`).focus();
      return;
    }
    const btn = f.querySelector("button[type=submit]");
    btn.disabled = true;
    try {
      if (view === "signin" || view === "admin") {
        const u = await post("/auth/login", { email: d.email.trim(), password: d.password, admin: view === "admin" });
        return this.after(u, view === "admin");
      }
      if (view === "signup") {
        const r = await post("/auth/signup", { name: d.name.trim(), email: d.email.trim(), password: d.password });
        return r.status === "pending" ? this.show("pending") : this.after(r.user);
      }
      if (view === "setup") {
        const u = await post("/auth/setup", { name: d.name.trim(), email: d.email.trim(), password: d.password });
        return this.after(u, true);
      }
      if (view === "change") {
        const u = await post("/auth/password", { current: d.current, new: d.password });
        return this.after(u);
      }
    } catch (err) {
      $("#auth-msg").innerHTML = `<div class="callout bad" role="alert">${esc(err.message)}</div>`;
      const pw = f.querySelector('[name="password"]');
      if (pw && (view === "signin" || view === "admin")) { pw.value = ""; pw.focus(); }
    } finally {
      btn.disabled = false;
    }
  },
  after(u, toAdmin) {
    if (u.must_change_password) return this.show("change");
    if (toAdmin && u.role === "admin") location.hash = "#/admin";
    else if (location.hash.startsWith("#/admin") && u.role !== "admin") location.hash = "#/overview";
    App.enter(u);
  },
};

const Account = {
  toggle(e) {
    e.stopPropagation();
    const m = $("#acct-menu"), open = m.hidden;
    m.hidden = !open;
    $("#avatar").setAttribute("aria-expanded", String(open));
    if (!open) return;
    const u = State.user || {};
    m.innerHTML = `<div class="acct-head"><div class="acct-name">${esc(u.name || "")}</div><div class="sub">${esc(u.email || "")}</div>
        <div style="margin-top:6px">${pill(u.role === "admin" ? "info" : u.role === "viewer" ? "muted" : "ok", u.role)}</div></div>
      <a href="#/account" role="menuitem">Your account</a>
      ${u.role === "admin" ? '<a href="#/admin" role="menuitem">Admin console</a>' : ""}
      <a href="#/guide" role="menuitem">Guide and docs</a>
      ${u.auth_source === "local" ? '<button type="button" class="menu-btn" role="menuitem" onclick="Account.signOut()">Sign out</button>'
        : `<div class="sub" style="padding:8px 14px">${u.auth_source === "sso" ? "Signed in with workspace SSO" : "Sign-in is turned off"}</div>`}`;
  },
  async signOut() {
    try { await post("/auth/logout"); } catch (e) { /* already signed out */ }
    State.user = null;
    $("#acct-menu").hidden = true;
    Auth.show("signin", "You've signed out.");
  },
  async changePw(ev) {
    ev.preventDefault();
    const f = ev.target, d = Object.fromEntries(new FormData(f)), out = $("#pw-msg");
    f.querySelectorAll(".ferr").forEach((x) => (x.textContent = ""));
    const errs = Auth.validate("change", d);
    if (errs.current) errs.current = "Enter your current password.";
    if (Object.keys(errs).length) {
      for (const [k, v] of Object.entries(errs)) { const el = f.querySelector(`.ferr[data-for="${k}"]`); if (el) el.textContent = v; }
      return;
    }
    try {
      await post("/auth/password", { current: d.current, new: d.password });
      f.reset();
      out.innerHTML = '<div class="callout ok" style="margin-top:10px">Password changed.</div>';
    } catch (e) { out.innerHTML = `<div class="callout bad" style="margin-top:10px">${esc(e.message)}</div>`; }
  },
};
document.addEventListener("click", (e) => {
  const m = $("#acct-menu");
  if (m && !m.hidden && !e.target.closest(".acct")) m.hidden = true;
});

Pages.account = async () => {
  const u = await api("/auth/me");
  const src = { sso: "Workspace single sign-on", none: "Sign-in is turned off", local: "TCS DataTrustAI account" }[u.auth_source] || u.auth_source;
  return `<div class="page-head"><h1>Your account</h1></div>
  <div class="grid g2">
    <div class="card"><h2>Profile</h2><div class="kv"><div>Name</div><div>${esc(u.name)}</div><div>Email</div><div>${esc(u.email)}</div>
      <div>Role</div><div>${pill(u.role === "admin" ? "info" : u.role === "viewer" ? "muted" : "ok", u.role)}</div>
      <div>Signs in with</div><div>${esc(src)}</div><div>Last sign-in</div><div>${ts(u.last_login) || "-"}</div></div>
      <p class="sub" style="margin-top:12px"><strong>What your role can do:</strong> ${esc(ROLE_DESC[u.role] || "")}</p></div>
    ${u.auth_source === "local" ? `<div class="card"><h2>Change password</h2><form onsubmit="Account.changePw(event)" novalidate class="grid" style="gap:10px">
      ${Auth.pw("current", "Current password", "current-password")}${Auth.pw("password", "New password", "new-password")}
      ${Auth.pw("confirm", "Confirm new password", "new-password")}${Auth.hint()}
      <div><button class="btn primary" type="submit">Save password</button></div></form><div id="pw-msg"></div></div>` : ""}
  </div>`;
};

/* ------------------------------------------------------------------ admin console */
const Admin = {
  async update(id, changes, el) {
    if (el) el.disabled = true;
    try { await patch(`/admin/users/${id}`, changes); toast("Saved"); } catch (e) { toastError(e.message); }
    await render(true);
  },
  approve(id) { return this.update(id, { status: "active", role: $(`#appr-role-${id}`).value }); },
  async showTemp(title, email, pw) {
    await render(true);
    $("#admin-msg").innerHTML = `<div class="callout ok" style="margin:10px 0"><strong>${esc(title)}</strong> for ${esc(email)}.
      Temporary password (shown once): <code id="temp-pw">${esc(pw)}</code>
      <button class="btn sm" onclick="copyText($('#temp-pw').innerText)">Copy</button>
      <div class="sub">Share it privately. They must choose a new password at first sign-in.</div></div>`;
  },
  async reset(id, email, btn) {
    if (!confirm(`Reset the password for ${email}? They'll be signed out and must choose a new password at next sign-in.`)) return;
    btn.disabled = true;
    try { const r = await post(`/admin/users/${id}/reset-password`); await this.showTemp("Password reset", email, r.temporary_password); }
    catch (e) { toastError(e.message); btn.disabled = false; }
  },
  async unlock(id, btn) {
    btn.disabled = true;
    try { await post(`/admin/users/${id}/unlock`); toast("Unlocked"); } catch (e) { toastError(e.message); }
    await render(true);
  },
  async remove(id, email, btn) {
    if (!confirm(`Delete ${email}? This removes the account and can't be undone.`)) return;
    btn.disabled = true;
    try { await api(`/admin/users/${id}`, { method: "DELETE" }); toast("Deleted"); } catch (e) { toastError(e.message); }
    await render(true);
  },
  toggleAdd() { const f = $("#add-user"); f.hidden = !f.hidden; if (!f.hidden) f.querySelector("input").focus(); },
  async add(ev) {
    ev.preventDefault();
    const f = ev.target, d = Object.fromEntries(new FormData(f));
    f.querySelectorAll(".ferr").forEach((x) => (x.textContent = ""));
    const errs = {};
    if (!(d.name || "").trim()) errs.name = "Enter a name.";
    if (!EMAIL_RE.test((d.email || "").trim())) errs.email = "Enter a valid email address.";
    if (Object.keys(errs).length) {
      for (const [k, v] of Object.entries(errs)) f.querySelector(`.ferr[data-for="${k}"]`).textContent = v;
      return;
    }
    try {
      const r = await post("/admin/users", { name: d.name.trim(), email: d.email.trim(), role: d.role });
      await this.showTemp("Account created", r.user.email, r.temporary_password);
    } catch (e) { $("#admin-msg").innerHTML = `<div class="callout bad" style="margin:10px 0">${esc(e.message)}</div>`; }
  },
};

Pages.admin = async () => {
  if (!State.user || State.user.role !== "admin") return '<div class="callout bad">Only administrators can open the Admin console.</div>';
  const [s, users] = await Promise.all([api("/admin/summary"), api("/admin/users")]);
  const st = s.settings, me = State.user.id, local = st.mode === "local";
  const pending = users.filter((u) => u.status === "pending"), others = users.filter((u) => u.status !== "pending");
  const roleSel = (attrs, current) => `<select ${attrs}>${["admin", "steward", "viewer"].map((r) => `<option ${r === current ? "selected" : ""}>${r}</option>`).join("")}</select>`;
  return `<div class="page-head"><h1>Admin console</h1><span class="sub">Users, roles and access</span></div>
  ${!local ? `<div class="callout">Sign-in mode is <strong>${esc(st.mode)}</strong>. ${st.mode === "sso"
    ? "Users sign in with workspace single sign-on and appear here on their first visit. Manage their roles and access below."
    : "Sign-in is turned off, so everyone has full access. Set <code>auth.mode: local</code> to require sign-in."}</div><div class="sp"></div>` : ""}
  <div class="grid g4">
    <div class="card kpi info"><div class="label">Users</div><div class="value">${s.users}</div><div class="hint">${s.disabled} disabled</div></div>
    <div class="card kpi ${s.pending ? "warn" : "ok"}"><div class="label">Waiting for approval</div><div class="value">${s.pending}</div><div class="hint">new sign-ups</div></div>
    <div class="card kpi info"><div class="label">Administrators</div><div class="value">${s.admins}</div><div class="hint">active</div></div>
    <div class="card kpi info"><div class="label">Active sessions</div><div class="value">${s.sessions}</div><div class="hint">signed in now</div></div></div><div class="sp"></div>
  ${pending.length ? `<div class="card wrap"><h2>Sign-up requests (${pending.length})</h2><table class="t">
    <tr><th>Name</th><th>Email</th><th>Requested</th><th>Role</th><th></th></tr>
    ${pending.map((u) => `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${ts(u.created)}</td>
      <td>${roleSel(`id="appr-role-${u.id}"`, st.default_role)}</td>
      <td class="btns"><button class="btn sm primary" onclick="Admin.approve(${u.id})">Approve</button>
        <button class="btn sm" onclick="Admin.update(${u.id}, {status:'disabled'}, this)">Reject</button></td></tr>`).join("")}</table></div><div class="sp"></div>` : ""}
  <div class="card wrap"><div class="row"><h2 style="margin:0">Users</h2><span style="flex:1"></span>
      ${local ? '<button class="btn primary" onclick="Admin.toggleAdd()">Add user</button>' : ""}</div>
    <form id="add-user" hidden onsubmit="Admin.add(event)" novalidate class="xbar">
      ${Auth.field("name", "Name", "text", "off")}${Auth.field("email", "Email", "email", "off")}
      <label class="f">Role${roleSel('name="role"', st.default_role)}</label>
      <div class="btns" style="padding-bottom:18px"><button class="btn primary" type="submit">Create with temporary password</button></div></form>
    <div id="admin-msg"></div>
    <table class="t" style="margin-top:8px"><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Signs in with</th><th>Last sign-in</th><th></th></tr>
    ${others.map((u) => `<tr><td>${esc(u.name)}${u.id === me ? ' <span class="pill info">you</span>' : ""}</td><td>${esc(u.email)}</td>
      <td>${roleSel(`onchange="Admin.update(${u.id}, {role: this.value}, this)" aria-label="Role for ${esc(u.email)}"`, u.role)}</td>
      <td>${pill(u.status === "active" ? "ok" : "muted", u.status)}${u.locked ? " " + pill("bad", "locked") : ""}${u.sessions ? ` <span class="sub">${u.sessions} session(s)</span>` : ""}</td>
      <td class="sub">${u.auth_source === "sso" ? "Workspace SSO" : "Password"}${u.must_change_password ? " · must set new password" : ""}</td>
      <td>${ts(u.last_login) || '<span class="muted">never</span>'}</td>
      <td class="btns">${u.id === me ? "" : u.status === "active"
        ? `<button class="btn sm" onclick="Admin.update(${u.id}, {status:'disabled'}, this)">Disable</button>`
        : `<button class="btn sm" onclick="Admin.update(${u.id}, {status:'active'}, this)">Enable</button>`}
        ${u.auth_source === "local" && local ? `<button class="btn sm" onclick="Admin.reset(${u.id}, ${jsq(u.email)}, this)">Reset password</button>` : ""}
        ${u.locked ? `<button class="btn sm" onclick="Admin.unlock(${u.id}, this)">Unlock</button>` : ""}
        ${u.id !== me ? `<button class="btn sm danger" onclick="Admin.remove(${u.id}, ${jsq(u.email)}, this)">Delete</button>` : ""}</td></tr>`).join("")
      || '<tr><td colspan="7" class="empty">No users yet</td></tr>'}</table></div><div class="sp"></div>
  <div class="grid g2">
    <div class="card"><h2>Roles</h2><div class="kv">${Object.entries(ROLE_DESC).map(([r, d]) => `<div>${pill(r === "admin" ? "info" : r === "viewer" ? "muted" : "ok", r)}</div><div class="sub">${esc(d)}</div>`).join("")}</div></div>
    <div class="card"><h2>Access settings</h2><div class="kv">
      <div>Sign-in mode</div><div><code>${esc(st.mode)}</code></div><div>Sign-up</div><div><code>${esc(st.signup)}</code></div>
      <div>New users get</div><div><code>${esc(st.default_role)}</code></div><div>Session length</div><div>${esc(String(st.session_hours))} hours</div>
      <div>Lockout</div><div>${esc(String(st.max_failed_logins))} failed attempts → ${esc(String(st.lockout_minutes))} minutes</div>
      <div>Password length</div><div>at least ${esc(String(st.min_password_length))}</div></div>
      <p class="sub" style="margin-top:10px">Change these under <code>auth</code> in config.yaml, or with environment variables such as <code>DQGA__AUTH__SIGNUP=open</code>. Restart to apply.</p></div>
  </div>`;
};

/* ------------------------------------------------------------------ agent drawer */
function md(text) {
  const blocks = String(text || "").split(/```/);
  return blocks.map((b, i) => {
    if (i % 2) return `<pre>${esc(b.replace(/^[a-z]*\n/, ""))}</pre>`;
    const lines = esc(b).split("\n");
    let html = "", inList = false;
    for (const raw of lines) {
      let l = raw.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/`([^`]+)`/g, "<code>$1</code>").replace(/(^|\s)_(.+?)_(\s|$)/g, "$1<em>$2</em>$3");
      if (/^\s*- /.test(l)) { if (!inList) { html += "<ul>"; inList = true; } html += `<li>${l.replace(/^\s*- /, "")}</li>`; }
      else { if (inList) { html += "</ul>"; inList = false; } if (l.trim()) html += `<p>${l}</p>`; }
    }
    return html + (inList ? "</ul>" : "");
  }).join("");
}

const Agent = {
  session: (() => { try { return localStorage.getItem("dq-session") || Agent_newId(); } catch (e) { return Agent_newId(); } })(),
  toggle(open) {
    $("#drawer").classList.toggle("open", open);
    $("#fab").hidden = open;
    if (open) { this.updateCtx(); setTimeout(() => $("#agent-input").focus(), 50); if (!$("#msgs").children.length) this.greet(); }
  },
  greet() {
    this.add("bot", "Hi, I'm the **TCS DataTrustAI** agent. Ask me why something failed, to profile or suggest rules for a dataset, to write a rule in plain English, to export rules (DQX, SQL, Soda, dbt, Great Expectations), or for a GDPR / SOX / NERC CIP report. I suggest changes for you to apply, and new rules are saved as drafts for review.");
  },
  reset() { this.session = Agent_newId(); try { localStorage.setItem("dq-session", this.session); } catch (e) {} $("#msgs").innerHTML = ""; this.greet(); },
  updateCtx() { $("#agent-ctx").textContent = State.ctx.label ? "· " + State.ctx.label : ""; $("#agent-input").placeholder = State.ctx.label ? `Ask about ${State.ctx.label}` : "Ask about your data"; },
  add(role, html, extra = "") {
    const d = document.createElement("div");
    d.className = "msg " + role;
    d.innerHTML = (role === "bot" ? extra + md(html) : esc(html));
    $("#msgs").appendChild(d);
    $("#msgs").scrollTop = 1e9;
    return d;
  },
  ask(text) { this.toggle(true); $("#agent-input").value = text; this.send(); },
  async send(e) {
    if (e) e.preventDefault();
    const inp = $("#agent-input"), text = inp.value.trim();
    if (!text) return;
    inp.value = "";
    this.add("user", text);
    const wait = this.add("bot", "_Working…_");
    try {
      const ctx = { ...State.ctx };
      delete ctx.label;
      const r = await post("/agent/chat", { message: text, session_id: this.session, context: ctx });
      const trace = r.trace.length ? `<div class="trace">${r.trace.map((t) => `<div class="${t.ok ? "" : "bad"}">${t.ok ? "✓" : "✗"} ${esc(t.tool)}(${esc(Object.entries(t.args || {}).map(([k, v]) => k + "=" + JSON.stringify(v)).join(", "))}) ${t.ms}ms</div>`).join("")}</div>` : "";
      wait.innerHTML = trace + md(r.answer) + r.actions.map((a) => `<div class="approval"><div class="t1">${a.status === "approved" ? "Done" : "Failed"} · ${esc(a.kind)}</div><strong>${esc(a.title)}</strong>${a.error ? `<div class="sub">${esc(a.error)}</div>` : ""}</div>`).join("")
        + `<div class="sub muted" style="font-size:11px;margin-top:4px">${esc(r.provider.provider)}${r.provider.model ? " · " + esc(r.provider.model) : ""}</div>`;
      refreshCounts();
    } catch (err) { wait.innerHTML = `<div class="callout bad">${esc(err.message)}</div>`; }
    $("#msgs").scrollTop = 1e9;
  },
};
function Agent_newId() { return "s-" + Math.random().toString(36).slice(2, 10); }

/* ------------------------------------------------------------------ boot */
const App = {
  async enter(user) {
    State.user = user;
    const a = $("#auth");
    a.hidden = true;
    a.innerHTML = "";
    $("#app").hidden = false;
    $("#fab").hidden = false;
    $("#nav-admin").hidden = user.role !== "admin";
    $("#avatar").textContent = initials(user.name || user.email);
    $("#avatar").title = `${user.name || ""} (${user.email})`;
    try {
      const m = (State.meta = await api("/meta"));
      document.title = m.app || "TCS DataTrustAI";
      $("#nav-meta").textContent = `${m.app || "TCS DataTrustAI"} v${m.version}`;
      const dbx = m.runtime.platform === "databricks_apps";
      $("#chip-runtime").innerHTML = `<span class="dot" style="background:${dbx ? "var(--p-databricks)" : "var(--ok)"}"></span>${esc(m.runtime.label)}`;
      $("#chip-llm").textContent = `Agent: ${m.llm.provider}${m.llm.model ? " · " + m.llm.model : ""}`;
    } catch (e) { /* render shows the error */ }
    render();
  },
};

(async function boot() { await Auth.start(); })();
