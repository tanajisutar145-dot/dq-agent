"""Learning from steward feedback.

- false_positive: anomaly rules get less sensitive (+0.5, max 6); threshold
  rules get a proposed new threshold just under the observed pass rate;
  after 3 false positives with no true positives, disabling is proposed.
- true_positive: anomaly rules get slightly more sensitive (-0.25, min 2).
- expected_change: the anomaly baseline restarts from now (e.g. after a
  planned migration), so the old pattern stops triggering alerts.
Threshold and disable changes are only suggested (shown in the effect and in Insights); a person edits the rule.
"""
from __future__ import annotations

from sqlalchemy import select

from ..models import CheckResult, Feedback, Incident, Rule, utcnow


def _latest(db, rule_id):
    return db.scalars(select(CheckResult).where(CheckResult.rule_id == rule_id)
                      .order_by(CheckResult.ts.desc(), CheckResult.id.desc()).limit(1)).first()


def apply(db, rule: Rule, verdict: str, actor: str) -> str:
    effects = []
    p = dict(rule.params or {})
    if verdict == "false_positive":
        rule.fp_count = (rule.fp_count or 0) + 1
        if rule.type == "anomaly":
            old = float(p.get("sensitivity", 3.0))
            p["sensitivity"] = min(old + 0.5, 6.0)
            effects.append(f"sensitivity {old} -> {p['sensitivity']}")
        elif rule.type in ("not_null", "regex", "range", "accepted_values", "length", "custom_sql", "referential"):
            res = _latest(db, rule.id)
            if res and res.pass_rate < rule.threshold:
                new_thr = max(0.0, int(res.pass_rate * 1000) / 1000 - 0.001)
                effects.append(f"suggest lowering the threshold to {new_thr:.3f} (pass rate was {res.pass_rate:.3f})")
        if rule.fp_count >= 3 and not rule.tp_count:
            effects.append("suggest disabling (noisy: no confirmed issues)")
    elif verdict == "true_positive":
        rule.tp_count = (rule.tp_count or 0) + 1
        if rule.type == "anomaly":
            old = float(p.get("sensitivity", 3.0))
            p["sensitivity"] = max(old - 0.25, 2.0)
            effects.append(f"sensitivity {old} -> {p['sensitivity']}")
    elif verdict == "expected_change":
        if rule.type == "anomaly":
            p["baseline_from"] = utcnow().isoformat(timespec="seconds")
            p.pop("baseline", None)
            effects.append("baseline reset")
    else:
        raise ValueError("verdict must be false_positive, true_positive or expected_change")
    rule.params = p
    return "; ".join(effects) or "recorded"


def record(db, verdict: str, actor: str, rule_id: int | None = None, incident_id: int | None = None,
           note: str | None = None) -> dict:
    rule_ids = [rule_id] if rule_id else []
    if incident_id and not rule_ids:
        inc = db.get(Incident, incident_id)
        rule_ids = list(inc.rule_ids) if inc else []
    effects = {}
    for rid in rule_ids:
        rule = db.get(Rule, rid)
        if rule:
            effects[rid] = apply(db, rule, verdict, actor)
    db.add(Feedback(rule_id=rule_id, incident_id=incident_id, verdict=verdict, note=note, actor=actor,
                    effect="; ".join(f"#{k}: {v}" for k, v in effects.items())))
    db.flush()
    return {"verdict": verdict, "effects": effects}


def precision(db) -> list[dict]:
    out = []
    for r in db.scalars(select(Rule).where((Rule.fp_count > 0) | (Rule.tp_count > 0))):
        tot = (r.fp_count or 0) + (r.tp_count or 0)
        out.append({"rule_id": r.id, "name": r.name, "fp": r.fp_count, "tp": r.tp_count,
                    "precision": round((r.tp_count or 0) / tot, 2) if tot else None})
    return out
