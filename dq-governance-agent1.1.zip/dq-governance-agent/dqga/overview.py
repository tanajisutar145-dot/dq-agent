"""Overview data under one shared filter set: platform, domain, dataset, severity, rule set and time window.

Dataset filters (platform, domain, dataset) narrow everything. Severity and rule set
narrow rules, check results, incidents and SLA breaches; DQ scores always cover all of
a dataset's rules, so they are only narrowed by the dataset filters.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import timedelta

from sqlalchemy import func, select

from .dq import scoring
from .dq.categories import CATEGORIES
from .dq.rules import DIMENSIONS, SEVERITIES
from .models import Asset, CheckResult, Incident, MetricPoint, Rule, utcnow

SOURCE_LABELS = {"discovery": "AI rule generation", "nl": "Plain-English rule", "manual": "Manual rule builder",
                 "suggested": "Suggested from profile", "contract": "Data contract", "llm": "Model suggestion",
                 "agent": "Agent", "monitor": "Anomaly monitor"}
AGE_BUCKETS = [("< 1 day", 1), ("1-3 days", 3), ("3-7 days", 7), ("1-4 weeks", 30), ("> 4 weeks", None)]


@dataclass
class OvFilter:
    platform: str | None = None
    domain: str | None = None
    asset_id: int | None = None
    severity: str | None = None
    category: str | None = None
    days: int = 30

    @classmethod
    def of(cls, platform=None, domain=None, asset_id=None, severity=None, category=None, days=30):
        days = int(days or 30)
        if days not in (7, 30, 90):
            days = 30
        return cls(platform or None, domain or None, int(asset_id) if asset_id else None,
                   severity if severity in SEVERITIES else None, category if category in CATEGORIES else None, days)

    @property
    def by_dataset(self) -> bool:
        return bool(self.platform or self.domain or self.asset_id)

    def since(self):
        return utcnow() - timedelta(days=self.days)

    def as_dict(self) -> dict:
        return {"platform": self.platform, "domain": self.domain, "asset_id": self.asset_id, "severity": self.severity,
                "category": self.category, "days": self.days}


def assets_for(db, f: OvFilter) -> list[Asset]:
    q = select(Asset)
    if f.platform:
        q = q.where(Asset.platform == f.platform)
    if f.domain:
        q = q.where(Asset.domain.is_(None) if f.domain == "unassigned" else Asset.domain == f.domain)
    if f.asset_id:
        q = q.where(Asset.id == f.asset_id)
    return list(db.scalars(q.order_by(Asset.fqn)))


def _rules(db, f: OvFilter, ids: set[int]) -> list[Rule]:
    q = select(Rule)
    if f.by_dataset:
        q = q.where(Rule.asset_id.in_(ids or [-1]))
    if f.severity:
        q = q.where(Rule.severity == f.severity)
    if f.category:
        q = q.where(Rule.category == f.category)
    return list(db.scalars(q))


def _incidents(db, f: OvFilter, fqns: set[str], statuses: list[str] | None = None) -> list[Incident]:
    q = select(Incident)
    if statuses:
        q = q.where(Incident.status.in_(statuses))
    if f.severity:
        q = q.where(Incident.severity == f.severity)
    incs = list(db.scalars(q))
    if f.by_dataset:
        incs = [i for i in incs if i.root_fqn in fqns or any(x in fqns for x in (i.assets or []))]
    if f.category:
        cats = {r.id: r.category for r in db.scalars(select(Rule))}
        incs = [i for i in incs if any(cats.get(rid) == f.category for rid in (i.rule_ids or []))]
    return incs


def _hours(td) -> float:
    return td.total_seconds() / 3600


def options(db) -> dict:
    assets = list(db.scalars(select(Asset).order_by(Asset.fqn)))
    return {"platforms": sorted({a.platform for a in assets if a.platform}),
            "domains": sorted({a.domain or "unassigned" for a in assets}),
            "datasets": [{"id": a.id, "fqn": a.fqn, "platform": a.platform, "domain": a.domain} for a in assets],
            "severities": SEVERITIES, "categories": {k: v["label"] for k, v in CATEGORIES.items()},
            "dimensions": DIMENSIONS, "windows": [7, 30, 90]}


# ---------------------------------------------------------------------------- Summary tab
def summary(db, f: OvFilter) -> dict:
    from .governance import policies
    assets = assets_for(db, f)
    ids, fqns = {a.id for a in assets}, {a.fqn for a in assets}
    ov = scoring.overview(db, assets=assets, days=f.days)
    incs = _incidents(db, f, fqns, ["open", "ack"])
    sev = {s: 0 for s in SEVERITIES}
    for i in incs:
        sev[i.severity] = sev.get(i.severity, 0) + 1
    breaches = [r for r in _rules(db, f, ids) if r.type == "freshness" and r.status == "active" and r.last_status == "fail"]
    by_id = {a.id: a for a in db.scalars(select(Asset))}
    viol = [v for v in policies.evaluate(db) if (not f.by_dataset or v["asset_id"] in ids) and (not f.severity or v["severity"] == f.severity)]
    resolved = [i for i in _incidents(db, f, fqns, ["resolved"]) if i.resolved_at and i.resolved_at >= f.since()]
    mttr = round(sum(_hours(i.resolved_at - i.created) for i in resolved) / len(resolved), 2) if resolved else None
    ov.update({"incidents_by_severity": sev, "open_incidents": len(incs),
               "sla_breaches": [{"rule_id": r.id, "asset_id": r.asset_id, "asset": by_id[r.asset_id].fqn if r.asset_id in by_id else "", "name": r.name}
                                for r in breaches],
               "policy_violations": len(viol), "mttr_hours": mttr,
               "filters": f.as_dict()})
    return ov


# ---------------------------------------------------------------------------- Rules tab
def rules_view(db, f: OvFilter) -> dict:
    assets = assets_for(db, f)
    ids = {a.id for a in assets}
    by_id = {a.id: a for a in assets} if f.by_dataset else {a.id: a for a in db.scalars(select(Asset))}
    rules = _rules(db, f, ids)
    group = {"proposed": "proposed", "rejected": "proposed", "review": "review", "approved": "review"}  # drafts / waiting for an administrator
    st = Counter(group.get(r.status, r.status) for r in rules)
    tiles = {"total": len(rules), "active": st.get("active", 0), "saved": st.get("proposed", 0), "in_review": st.get("review", 0),
             "disabled": st.get("disabled", 0),
             "failing": sum(1 for r in rules if r.status == "active" and r.last_status == "fail")}
    set_sev = {k: {s: 0 for s in SEVERITIES} for k in CATEGORIES}
    for r in rules:
        if r.status != "disabled":
            row = set_sev.setdefault(r.category or "core", {s: 0 for s in SEVERITIES})
            row[r.severity] = row.get(r.severity, 0) + 1
    src: dict[str, Counter] = defaultdict(Counter)
    for r in rules:
        src[r.source or "manual"][group.get(r.status, r.status)] += 1
    rule_ids = {r.id: r for r in rules}
    fail_by_asset, dim = Counter(), defaultdict(Counter)
    if rule_ids:
        q = (select(CheckResult.rule_id, CheckResult.asset_id, CheckResult.status, func.count())
             .where(CheckResult.ts >= f.since(), CheckResult.rule_id.in_(list(rule_ids)))
             .group_by(CheckResult.rule_id, CheckResult.asset_id, CheckResult.status))
        for rid, aid, status, n in db.execute(q):
            if status == "fail":
                fail_by_asset[aid] += n
            if status in ("pass", "warn", "fail"):
                dim[rule_ids[rid].dimension]["ok" if status != "fail" else "fail"] += n
    return {"filters": f.as_dict(), "tiles": tiles,
            "set_severity": [{"key": k, "label": CATEGORIES[k]["label"] if k in CATEGORIES else k, "values": v}
                             for k, v in set_sev.items()],
            "failing_by_dataset": [{"key": aid, "label": by_id[aid].fqn if aid in by_id else str(aid), "value": n}
                                   for aid, n in fail_by_asset.items()],
            "pass_rate_by_dimension": [{"key": d, "label": d, "value": round(c["ok"] / (c["ok"] + c["fail"]) * 100, 1),
                                        "checks": c["ok"] + c["fail"]} for d, c in dim.items() if c["ok"] + c["fail"]],
            "source_status": [{"key": s, "label": SOURCE_LABELS.get(s, s), "values": {k: c.get(k, 0) for k in ("active", "proposed", "review", "disabled")}}
                              for s, c in src.items()]}


# ---------------------------------------------------------------------------- Incidents tab
def incidents_view(db, f: OvFilter) -> dict:
    assets = assets_for(db, f)
    fqns = {a.fqn for a in assets}
    all_assets = {a.fqn: a for a in db.scalars(select(Asset))}
    incs = _incidents(db, f, fqns)
    now, since = utcnow(), f.since()
    open_ = [i for i in incs if i.status in ("open", "ack")]
    in_window = [i for i in incs if i.created >= since]
    resolved = [i for i in incs if i.status == "resolved" and i.resolved_at and i.resolved_at >= since]
    days = [(since + timedelta(days=d + 1)).date() for d in range(f.days)]
    opened_by_day, resolved_by_day = Counter(i.created.date() for i in in_window), Counter(i.resolved_at.date() for i in resolved)
    ages = Counter()
    for i in open_:
        age_d = (now - i.created).total_seconds() / 86400
        ages[next(lbl for lbl, lim in AGE_BUCKETS if lim is None or age_d < lim)] += 1
    by_ds, by_dom = Counter(), Counter()
    for i in in_window + [i for i in open_ if i.created < since]:
        a = all_assets.get(i.root_fqn)
        by_ds[(a.id if a else None, i.root_fqn)] += 1
        by_dom[(a.domain if a else None) or "unassigned"] += 1
    ttr_week: dict = defaultdict(list)
    for i in resolved:
        week = i.resolved_at.date() - timedelta(days=i.resolved_at.weekday())
        ttr_week[week].append(_hours(i.resolved_at - i.created))
    mttr = round(sum(_hours(i.resolved_at - i.created) for i in resolved) / len(resolved), 1) if resolved else None
    oldest = max(((now - i.created).total_seconds() / 3600 for i in open_), default=None)
    return {"filters": f.as_dict(),
            "tiles": {"open": len(open_), "opened": len(in_window), "resolved": len(resolved), "mttr_hours": mttr,
                      "oldest_open_hours": round(oldest, 1) if oldest is not None else None},
            "open_by_severity": [{"key": s, "label": s, "value": sum(1 for i in open_ if i.severity == s)} for s in SEVERITIES],
            "opened_vs_resolved": [{"date": d.isoformat(), "opened": opened_by_day.get(d, 0), "resolved": resolved_by_day.get(d, 0)} for d in days],
            "by_dataset": [{"key": aid, "label": fqn, "value": n} for (aid, fqn), n in by_ds.items()],
            "by_domain": [{"key": dom, "label": dom, "value": n} for dom, n in by_dom.items()],
            "age_buckets": [{"key": lbl, "label": lbl, "value": ages.get(lbl, 0)} for lbl, _ in AGE_BUCKETS],
            "ttr_by_week": [{"date": w.isoformat(), "value": round(sum(v) / len(v), 1), "count": len(v)} for w, v in sorted(ttr_week.items())]}
