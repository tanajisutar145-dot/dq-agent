"""Pluggable LLM providers with one neutral message format.

Neutral messages:
    {"role": "user", "content": str}
    {"role": "assistant", "content": str, "tool_calls": [{"id", "name", "args"}]}
    {"role": "tool", "tool_call_id": str, "name": str, "content": str}

Providers: ollama (local, default for offline work), anthropic,
anthropic_bedrock (AWS), openai_compatible (Azure OpenAI / AI Foundry, vLLM, ...),
databricks (Model Serving endpoints, OAuth via the app's service principal).
provider "rules" means no LLM: the agent falls back to its deterministic router.
"""
from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass, field

import httpx

from ..config import resolve_env


@dataclass
class LLMResponse:
    text: str = ""
    tool_calls: list[dict] = field(default_factory=list)


def content_text(content) -> str:
    """A reply's text. Some models (reasoning models on Databricks, Gemini) return a list of blocks instead of a string."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for b in content:
            if isinstance(b, str):
                parts.append(b)
            elif isinstance(b, dict) and b.get("type") in (None, "text", "output_text"):
                parts.append(str(b.get("text") or ""))
        return "".join(parts)
    return str(content)


RETRY_STATUS = (429, 500, 502, 503, 504)  # rate limited or overloaded: usually gone a few seconds later


def post_with_retry(url, *, json, headers, timeout, tries: int = 4):
    """POST that waits and retries when a provider says it is busy (HTTP 429/5xx or a dropped connection)."""
    import time
    delay = 1.5
    for attempt in range(tries):
        try:
            r = httpx.post(url, json=json, headers=headers, timeout=timeout)
        except (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError):
            if attempt == tries - 1:
                raise
        else:
            if r.status_code not in RETRY_STATUS or attempt == tries - 1:
                return r
            retry_after = r.headers.get("retry-after")
            if retry_after and retry_after.isdigit():
                delay = min(float(retry_after), 20.0)
        time.sleep(delay)
        delay = min(delay * 2, 12.0)
    return r


def _extract_json(text: str):
    if not text:
        return None
    t = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(t)
    except Exception:
        m = re.search(r"\{.*\}|\[.*\]", t, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                return None
    return None


class LLM:
    name = "base"

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.model = cfg.get("model")
        self.timeout = float(cfg.get("timeout_s", 120))

    def chat(self, system: str, messages: list[dict], tools: list[dict]) -> LLMResponse:
        raise NotImplementedError

    def complete_json(self, system: str, prompt: str):
        resp = self.chat(system + "\nRespond with a single JSON object only.", [{"role": "user", "content": prompt}], [])
        return _extract_json(resp.text)

    def describe(self) -> dict:
        return {"provider": self.name, "model": self.model}


class OllamaLLM(LLM):
    name = "ollama"

    def _convert(self, system, messages):
        out = [{"role": "system", "content": system}]
        for m in messages:
            if m["role"] == "assistant":
                msg = {"role": "assistant", "content": m.get("content") or ""}
                if m.get("tool_calls"):
                    msg["tool_calls"] = [{"function": {"name": t["name"], "arguments": t["args"]}} for t in m["tool_calls"]]
                out.append(msg)
            elif m["role"] == "tool":
                out.append({"role": "tool", "content": m["content"], "tool_name": m.get("name")})
            else:
                out.append({"role": "user", "content": m["content"]})
        return out

    def _post(self, body):
        base = self.cfg.get("base_url", "http://localhost:11434").rstrip("/")
        r = httpx.post(f"{base}/api/chat", json=body, timeout=self.timeout)
        r.raise_for_status()
        return r.json()["message"]

    def chat(self, system, messages, tools):
        body = {"model": self.model, "messages": self._convert(system, messages), "stream": False,
                "options": {"temperature": 0}}
        if tools:
            body["tools"] = [{"type": "function", "function": t} for t in tools]
        msg = self._post(body)
        calls = [{"id": str(uuid.uuid4())[:8], "name": c["function"]["name"],
                  "args": c["function"].get("arguments") or {}} for c in msg.get("tool_calls") or []]
        for c in calls:
            if isinstance(c["args"], str):
                c["args"] = _extract_json(c["args"]) or {}
        return LLMResponse(content_text(msg.get("content")), calls)

    def complete_json(self, system, prompt):
        body = {"model": self.model, "stream": False, "format": "json", "options": {"temperature": 0},
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}]}
        return _extract_json(self._post(body).get("content", ""))


class AnthropicLLM(LLM):
    name = "anthropic"

    def __init__(self, cfg):
        super().__init__(cfg)
        self.client = None
        if cfg.get("provider") == "anthropic_bedrock":  # AWS signing needs the SDK
            import anthropic

            self.name = "anthropic_bedrock"
            self.client = anthropic.AnthropicBedrock(aws_region=resolve_env(cfg, "aws_region"))
        else:  # the Anthropic API is called over HTTP, so no extra package is needed
            self.api_key = resolve_env(cfg, "api_key")
            self.base = (cfg.get("base_url") or "https://api.anthropic.com").rstrip("/")
            if "localhost:11434" in self.base:  # the Ollama default from config.yaml is not an Anthropic URL
                self.base = "https://api.anthropic.com"
        if not self.model or not ("claude" in self.model or "anthropic" in self.model):
            self.model = "claude-sonnet-5-5"

    def _convert(self, messages):
        out: list[dict] = []
        for m in messages:
            if m["role"] == "assistant":
                blocks = []
                if m.get("content"):
                    blocks.append({"type": "text", "text": m["content"]})
                for t in m.get("tool_calls") or []:
                    blocks.append({"type": "tool_use", "id": t["id"], "name": t["name"], "input": t["args"]})
                out.append({"role": "assistant", "content": blocks or [{"type": "text", "text": ""}]})
            elif m["role"] == "tool":
                block = {"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m["content"]}
                if out and out[-1]["role"] == "user" and isinstance(out[-1]["content"], list) \
                        and out[-1]["content"] and out[-1]["content"][0].get("type") == "tool_result":
                    out[-1]["content"].append(block)
                else:
                    out.append({"role": "user", "content": [block]})
            else:
                out.append({"role": "user", "content": m["content"]})
        return out

    def chat(self, system, messages, tools):
        kwargs = {"model": self.model, "max_tokens": int(self.cfg.get("max_tokens", 4096)), "system": system,
                  "messages": self._convert(messages)}
        if tools:
            kwargs["tools"] = [{"name": t["name"], "description": t["description"], "input_schema": t["parameters"]}
                               for t in tools]
        if self.client is None:
            r = post_with_retry(f"{self.base}/v1/messages", json=kwargs, timeout=self.timeout,
                           headers={"x-api-key": self.api_key or "", "anthropic-version": "2023-06-01"})
            r.raise_for_status()
            blocks = r.json().get("content") or []
            text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
            calls = [{"id": b["id"], "name": b["name"], "args": b.get("input") or {}} for b in blocks if b.get("type") == "tool_use"]
            return LLMResponse(text, calls)
        resp = self.client.messages.create(**kwargs)
        text = "".join(b.text for b in resp.content if b.type == "text")
        calls = [{"id": b.id, "name": b.name, "args": b.input or {}} for b in resp.content if b.type == "tool_use"]
        return LLMResponse(text, calls)


class OpenAICompatibleLLM(LLM):
    name = "openai_compatible"

    def _convert(self, system, messages):
        out = [{"role": "system", "content": system}]
        for m in messages:
            if m["role"] == "assistant":
                msg = {"role": "assistant", "content": m.get("content") or ""}
                if m.get("tool_calls"):
                    msg["tool_calls"] = [{"id": t["id"], "type": "function",
                                          "function": {"name": t["name"], "arguments": json.dumps(t["args"])}}
                                         for t in m["tool_calls"]]
                out.append(msg)
            elif m["role"] == "tool":
                out.append({"role": "tool", "tool_call_id": m["tool_call_id"], "content": m["content"]})
            else:
                out.append({"role": "user", "content": m["content"]})
        return out

    def _endpoint(self) -> tuple[str, dict]:
        base = self.cfg["base_url"].rstrip("/")
        url = f"{base}/chat/completions"
        if self.cfg.get("api_version"):
            url += f"?api-version={self.cfg['api_version']}"
        key = resolve_env(self.cfg, "api_key")
        headers = {"api-key": key} if self.cfg.get("azure") else ({"Authorization": f"Bearer {key}"} if key else {})
        return url, headers

    def chat(self, system, messages, tools):
        url, headers = self._endpoint()
        body = {"model": self.model, "messages": self._convert(system, messages), "temperature": 0}
        if tools:
            body["tools"] = [{"type": "function", "function": t} for t in tools]
        r = post_with_retry(url, json=body, headers=headers, timeout=self.timeout)
        r.raise_for_status()
        msg = r.json()["choices"][0]["message"]
        calls = [{"id": c["id"], "name": c["function"]["name"],
                  "args": _extract_json(c["function"].get("arguments") or "{}") or {}} for c in msg.get("tool_calls") or []]
        return LLMResponse(content_text(msg.get("content")), calls)


class DatabricksServingLLM(OpenAICompatibleLLM):
    """Databricks Model Serving (OpenAI-compatible chat API).

    Auth comes from Databricks unified auth: inside a Databricks App that is the
    app's service principal (OAuth, refreshed automatically); locally a CLI
    profile or DATABRICKS_HOST/DATABRICKS_TOKEN. `model` is the serving endpoint name.
    """
    name = "databricks"

    def __init__(self, cfg):
        super().__init__(cfg)
        from databricks.sdk.core import Config

        self._db = Config(host=resolve_env(cfg, "host"), profile=cfg.get("profile"))

    def _endpoint(self) -> tuple[str, dict]:
        # The documented per-endpoint route: the endpoint name is in the path, so the gateway needs no model lookup.
        host = (self._db.host or "").rstrip("/")
        if host and not host.startswith("http"):
            host = "https://" + host
        return f"{host}/serving-endpoints/{self.model}/invocations", self._db.authenticate()

    def chat(self, system, messages, tools):
        if self.model and "." in self.model and "/" not in self.model:
            raise ValueError(f"'{self.model}' looks like a Unity Catalog model name. Use the serving endpoint name from "
                             "Databricks > Serving instead (for example databricks-meta-llama-3-3-70b-instruct).")
        url, headers = self._endpoint()
        body = {"messages": self._convert(system, messages), "temperature": 0}
        if tools:
            body["tools"] = [{"type": "function", "function": t} for t in tools]
        r = post_with_retry(url, json=body, headers=headers, timeout=self.timeout)
        r.raise_for_status()
        msg = r.json()["choices"][0]["message"]
        calls = [{"id": c["id"], "name": c["function"]["name"],
                  "args": _extract_json(c["function"].get("arguments") or "{}") or {}} for c in msg.get("tool_calls") or []]
        return LLMResponse(content_text(msg.get("content")), calls)


class GeminiLLM(OpenAICompatibleLLM):
    """Google Gemini through Google's OpenAI-compatible endpoint (a Gemini API key from Google AI Studio)."""
    name = "gemini"
    DEFAULT_BASE = "https://generativelanguage.googleapis.com/v1beta/openai"

    def __init__(self, cfg):
        cfg = {**cfg, "base_url": cfg.get("base_url") or self.DEFAULT_BASE, "azure": False}
        super().__init__(cfg)
        self.model = self.model or "gemini-2.5-flash"


def build_llm(cfg: dict) -> LLM | None:
    p = (cfg or {}).get("provider", "rules")
    if p in (None, "", "rules", "none"):
        return None
    if p == "ollama":
        return OllamaLLM(cfg)
    if p in ("anthropic", "anthropic_bedrock"):
        return AnthropicLLM(cfg)
    if p == "openai_compatible":
        return OpenAICompatibleLLM(cfg)
    if p == "gemini":
        return GeminiLLM(cfg)
    if p == "databricks":
        return DatabricksServingLLM(cfg)
    raise ValueError(f"Unknown LLM provider {p}")
