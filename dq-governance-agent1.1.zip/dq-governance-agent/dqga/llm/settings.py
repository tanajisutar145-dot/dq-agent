"""The LLM the whole app uses, configurable in Settings > LLM.

Precedence: what an administrator saves in the app (stored in the app database, API key encrypted),
then environment variables (DQGA_LLM_*), then the `llm:` section of config.yaml. Every part of the
app asks services.get_llm(), so one choice here applies to the agent, rule discovery, Describe a
rule and rule suggestions.
"""
from __future__ import annotations

import time

import httpx
from sqlalchemy import select

from .. import secretbox
from ..config import get_settings, resolve_env
from ..models import AppSetting, audit, utcnow

KEY = "llm"

# What each provider needs. The UI builds its form from this, so a new provider is one entry here plus a class in llm/__init__.py.
PROVIDERS: dict[str, dict] = {
    "rules": {"label": "None (built-in rules only)", "fields": [], "key": False,
              "help": "No model. The agent uses its built-in router and rules are drafted by the built-in parser. AI rule generation needs a model."},
    "anthropic": {"label": "Anthropic (Claude API)", "fields": ["model", "api_key", "base_url"], "key": True,
                  "defaults": {"model": "claude-sonnet-5-5"}, "key_env": "ANTHROPIC_API_KEY",
                  "models": ["claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5", "claude-fable-5-2"],
                  "help": "Claude models through the Anthropic API."},
    "gemini": {"label": "Google Gemini", "fields": ["model", "api_key"], "key": True, "key_env": "GEMINI_API_KEY",
               "defaults": {"model": "gemini-2.5-flash"}, "models": ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash"],
               "help": "Gemini models with an API key from Google AI Studio, through Google's OpenAI-compatible endpoint."},
    "anthropic_bedrock": {"label": "Anthropic on AWS Bedrock", "fields": ["model", "aws_region"], "key": False,
                          "defaults": {"model": "anthropic.claude-sonnet-5-5-v1:0"},
                          "help": "AWS credentials come from the environment or the instance role, not from this page."},
    "openai_compatible": {"label": "OpenAI, Azure OpenAI or compatible", "fields": ["base_url", "model", "api_key", "azure", "api_version"], "key": True,
                          "defaults": {"base_url": "https://api.openai.com/v1"}, "key_env": "OPENAI_API_KEY",
                          "help": "Any endpoint that speaks the OpenAI chat API: OpenAI, Azure OpenAI / AI Foundry, vLLM, LiteLLM. "
                                  "For Azure, use https://<resource>.openai.azure.com/openai/deployments/<deployment>, tick Azure and set the API version; the model is the deployment name."},
    "databricks": {"label": "Databricks Model Serving", "fields": ["model", "host"], "key": False,
                   "help": "The model is the serving endpoint name. Sign-in comes from Databricks: the app's service principal on Databricks Apps, "
                           "or DATABRICKS_HOST and DATABRICKS_TOKEN (or a CLI profile) elsewhere."},
    "ollama": {"label": "Ollama (local)", "fields": ["base_url", "model"], "key": False,
               "defaults": {"base_url": "http://localhost:11434", "model": "qwen2.5:7b"},
               "help": "A model running on this machine or your network. No key needed."},
}
FIELD_LABELS = {"model": "Model", "api_key": "API key", "base_url": "Base URL", "aws_region": "AWS region", "azure": "Azure OpenAI style (api-key header)",
                "api_version": "API version", "host": "Workspace URL (optional)"}
KEPT = ("provider", "model", "base_url", "aws_region", "azure", "api_version", "host", "timeout_s", "max_steps", "api_key_env")


def _base() -> dict:
    return dict(get_settings().section("llm") or {})


def _state(db) -> dict:
    """{"active": id or None, "items": {id: config}}. A single config saved by an earlier version becomes the first connection."""
    row = db.get(AppSetting, KEY)
    v = dict(row.value) if row and row.value else {}
    if v.get("provider"):  # older flat format
        v = {"active": "c1", "items": {"c1": {**v, "name": _default_name(v)}}}
    return {"active": v.get("active"), "items": dict(v.get("items") or {})}


def _write(db, st: dict, actor: str) -> None:
    row = db.get(AppSetting, KEY)
    if row:
        row.value, row.updated, row.updated_by = st, utcnow(), actor
    else:
        db.add(AppSetting(key=KEY, value=st, updated=utcnow(), updated_by=actor))
    db.flush()


def _default_name(cfg: dict) -> str:
    label = PROVIDERS.get(cfg.get("provider"), {}).get("label", cfg.get("provider") or "LLM")
    return f"{label} · {cfg['model']}" if cfg.get("model") else label


def stored(db) -> dict | None:
    """The active saved connection, or None when config.yaml / environment variables are in charge."""
    st = _state(db)
    item = st["items"].get(st["active"]) if st["active"] else None
    return dict(item) if item and item.get("provider") else None


def effective(db) -> tuple[dict, str]:
    """(config for build_llm, where it came from: 'app' or 'config')."""
    base = _base()
    st = stored(db)
    if not st:
        return base, "config"
    return _build_cfg(st, base), "app"


def _build_cfg(st: dict, base: dict) -> dict:
    cfg = {k: v for k, v in st.items() if k in KEPT and v not in (None, "")}
    for k in ("timeout_s", "max_steps"):
        cfg.setdefault(k, base.get(k))
    key = secretbox.decrypt(st.get("api_key_enc"))
    if key:
        cfg["api_key"] = key
    spec = PROVIDERS.get(cfg.get("provider"), {})
    if spec.get("key") and not key and not cfg.get("api_key_env"):
        cfg["api_key_env"] = spec.get("key_env") or base.get("api_key_env")  # no saved key: fall back to the usual environment variable
    return cfg


def effective_now() -> tuple[dict, str]:
    """Same, from a fresh session (for code that has no db handle)."""
    try:
        from ..db import session_scope
        with session_scope() as db:
            return effective(db)
    except Exception:
        return _base(), "config"


def key_state(cfg: dict) -> dict:
    """Where the API key comes from, without revealing it."""
    p = PROVIDERS.get(cfg.get("provider") or "rules", {})
    if not p.get("key"):
        return {"needed": False, "set": False}
    if cfg.get("api_key"):
        return {"needed": True, "set": True, "source": "saved", "hint": secretbox.hint(cfg["api_key"])}
    env = cfg.get("api_key_env") or p.get("key_env")
    val = resolve_env({**cfg, "api_key_env": env}, "api_key") if env else None
    if val:
        return {"needed": True, "set": True, "source": "env", "env": env, "hint": secretbox.hint(val)}
    return {"needed": True, "set": False, "env": env}


def view(db) -> dict:
    cfg, source = effective(db)
    st = stored(db)
    drop_key = bool(st and st.get("api_key_enc") and not cfg.get("api_key"))  # saved key that this installation can't decrypt
    current = {k: cfg.get(k) for k in ("provider", "model", "base_url", "aws_region", "azure", "api_version", "host", "timeout_s", "api_key_env")}
    current["provider"] = current["provider"] or "rules"
    return {"providers": {k: {kk: vv for kk, vv in v.items()} for k, v in PROVIDERS.items()}, "field_labels": FIELD_LABELS,
            "current": current, "source": source, "key": key_state(cfg), "key_unreadable": drop_key,
            "secret_key_from": secretbox.key_source(), "updated": _updated(db),
            "profiles": profiles(db), "active_id": _state(db)["active"]}


def profiles(db) -> list[dict]:
    """Saved connections for the list in Settings. Keys are never included."""
    st, base = _state(db), _base()
    out = []
    for pid, item in st["items"].items():
        cfg = _build_cfg(item, base)
        out.append({"id": pid, "name": item.get("name") or _default_name(item), "provider": item.get("provider"),
                    "provider_label": PROVIDERS.get(item.get("provider"), {}).get("label", item.get("provider")),
                    "model": item.get("model"), "base_url": item.get("base_url"), "active": pid == st["active"],
                    "key": key_state(cfg), "key_unreadable": bool(item.get("api_key_enc") and not cfg.get("api_key")),
                    "form": {k: item.get(k) for k in ("provider", "model", "base_url", "aws_region", "azure", "api_version", "host", "api_key_env")}})
    return sorted(out, key=lambda x: (not x["active"], x["name"].lower()))


def _updated(db) -> dict | None:
    row = db.get(AppSetting, KEY)
    return {"at": row.updated.isoformat(timespec="seconds"), "by": row.updated_by} if row else None


def _clean(body: dict) -> dict:
    p = body.get("provider") or "rules"
    if p not in PROVIDERS:
        raise ValueError(f"Unknown provider {p!r}. Choose one of: {', '.join(PROVIDERS)}")
    spec = PROVIDERS[p]
    out = {"provider": p}
    for f in spec["fields"]:
        if f == "api_key":
            continue
        v = body.get(f)
        v = v.strip() if isinstance(v, str) else v
        out[f] = v if v not in ("", None) else spec.get("defaults", {}).get(f)
    if "azure" in spec["fields"]:
        out["azure"] = bool(body.get("azure"))
    if p != "rules" and "model" in spec["fields"] and not out.get("model"):
        raise ValueError("Enter the model name" + (" (the serving endpoint)" if p == "databricks" else ""))
    if p == "openai_compatible" and not out.get("base_url"):
        raise ValueError("Enter the base URL of the endpoint")
    if p == "openai_compatible" and out.get("azure") and not out.get("api_version"):
        raise ValueError("Azure OpenAI needs an API version, for example 2024-10-21")
    if spec.get("key"):
        env = (body.get("api_key_env") or "").strip()
        if env:
            out["api_key_env"] = env
    if body.get("timeout_s"):
        out["timeout_s"] = max(5, min(int(body["timeout_s"]), 600))
    return out


def save(db, body: dict, actor: str) -> dict:
    """Save a connection. `profile_id` updates that one, otherwise a new one is added. `api_key` set = replace the key;
    `clear_key` = remove it; neither = keep the stored key. The saved connection becomes the one in use unless `activate` is false."""
    cfg = _clean(body)
    st = _state(db)
    pid = body.get("profile_id")
    if pid and pid not in st["items"]:
        raise ValueError("That saved connection no longer exists")
    if not pid:
        n = 1
        while f"c{n}" in st["items"]:
            n += 1
        pid = f"c{n}"
    prev = st["items"].get(pid) or {}
    prev_enc = prev.get("api_key_enc")
    spec = PROVIDERS[cfg["provider"]]
    new_key = (body.get("api_key") or "").strip()
    if spec.get("key"):
        if new_key:
            cfg["api_key_enc"] = secretbox.encrypt(new_key)
        elif prev_enc and not body.get("clear_key") and prev.get("provider") == cfg["provider"]:
            cfg["api_key_enc"] = prev_enc
    cfg["name"] = (body.get("name") or "").strip()[:80] or _default_name(cfg)
    if any(i.get("name") == cfg["name"] for k, i in st["items"].items() if k != pid):
        raise ValueError(f"A saved connection is already called '{cfg['name']}'. Give this one another name.")
    st["items"][pid] = cfg
    if body.get("activate", True):
        st["active"] = pid
    _write(db, st, actor)
    audit(db, actor, "llm.configured", cfg["provider"], name=cfg["name"], model=cfg.get("model"), key_changed=bool(new_key),
          key_cleared=bool(body.get("clear_key")), active=st["active"] == pid)
    return cfg


def activate(db, pid: str, actor: str) -> None:
    st = _state(db)
    if pid not in st["items"]:
        raise ValueError("That saved connection no longer exists")
    st["active"] = pid
    _write(db, st, actor)
    audit(db, actor, "llm.activated", st["items"][pid].get("name"))


def delete(db, pid: str, actor: str) -> None:
    st = _state(db)
    if pid not in st["items"]:
        raise ValueError("That saved connection no longer exists")
    name = st["items"].pop(pid).get("name")
    if st["active"] == pid:
        st["active"] = None  # falls back to config.yaml / environment variables
    _write(db, st, actor)
    audit(db, actor, "llm.deleted", name)


def clear(db, actor: str) -> None:
    """Stop using a saved connection (they stay in the list); config.yaml and environment variables take over."""
    st = _state(db)
    st["active"] = None
    _write(db, st, actor)
    audit(db, actor, "llm.reset_to_config", None)


def test(db, body: dict) -> dict:
    """Try the settings in the form (not yet saved) with one tiny request. A blank API key uses the saved one."""
    from . import build_llm
    t0 = time.perf_counter()
    try:
        cfg = _clean(body)
    except ValueError as e:
        return {"ok": False, "error": str(e)}
    if cfg["provider"] == "rules":
        return {"ok": False, "error": "No model is selected. Choose a provider to test."}
    spec = PROVIDERS[cfg["provider"]]
    if spec.get("key"):
        key = (body.get("api_key") or "").strip()
        if not key:
            item = _state(db)["items"].get(body.get("profile_id") or "") or stored(db) or {}
            key = secretbox.decrypt(item.get("api_key_enc")) if item.get("provider") == cfg["provider"] else None
        if key:
            cfg["api_key"] = key
        elif body.get("api_key_env"):
            cfg["api_key_env"] = body["api_key_env"]
        else:
            cfg["api_key_env"] = spec.get("key_env")
        if not key and not resolve_env(cfg, "api_key"):
            env = cfg.get("api_key_env")
            return {"ok": False, "error": "No API key. Paste one" + (f" or set the {env} environment variable" if env else "") + "."}
    cfg["timeout_s"] = min(int(cfg.get("timeout_s") or 30), 45)
    try:
        llm = build_llm(cfg)
        resp = llm.chat("You are a connection test. Answer with one word.", [{"role": "user", "content": "Reply with the single word OK."}], [])
    except httpx.HTTPStatusError as e:
        body_text = (e.response.text or "")[:240].replace("\n", " ")
        hint = {401: " The key was rejected.", 403: " The key has no access to this model.", 404: " The model or URL wasn't found."}.get(e.response.status_code, "")
        return {"ok": False, "error": f"HTTP {e.response.status_code} from the provider.{hint} {body_text}".strip()}
    except httpx.ConnectError:
        return {"ok": False, "error": f"Could not connect to {cfg.get('base_url') or 'the provider'}. Check the URL and that the service is running."}
    except httpx.TimeoutException:
        return {"ok": False, "error": f"No answer within {cfg['timeout_s']} seconds."}
    except ImportError as e:
        return {"ok": False, "error": f"A library for this provider isn't installed: {e}. Install the matching extra, for example pip install 'tcs-datatrustai[anthropic]'."}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"[:400]}
    from . import content_text
    try:
        reply = content_text(resp.text).strip()[:120]
    except Exception:
        reply = ""
    return {"ok": True, "provider": cfg["provider"], "model": getattr(llm, "model", cfg.get("model")),
            "latency_s": round(time.perf_counter() - t0, 2), "reply": reply}
