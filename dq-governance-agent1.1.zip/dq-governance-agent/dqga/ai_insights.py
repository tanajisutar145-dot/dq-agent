"""AI-written Patterns and Insights: the app computes the facts, a fixed guidance tells the model how to write them up.

What makes the result steady whichever model is configured:
  1. The facts are computed in code (dqga/insights.py), numbered, rounded and sorted the same way every time.
  2. The guidance below is built in and versioned; a model never sees different instructions.
  3. The model must return JSON in a fixed shape, at temperature 0.
  4. Every statement must cite facts, and may only contain numbers that appear in those facts. Anything else is dropped.
  5. The result is saved against a fingerprint of (facts, guidance version, scope). While the facts are unchanged, the
     saved text is shown and the model is not called again, so switching models does not reword the page.

The model sees counts, percentages, weekdays, causes and dataset names. It never sees rows, column values or personal data.
"""
from __future__ import annotations

import hashlib
import json
import re

from sqlalchemy import select

from .config import feature_on
from .insights import compute
from .models import Asset, AppSetting, audit, utcnow

GUIDANCE_VERSION = 2
KEY_PREFIX = "ai_insights:"
LIMITS = {"insights": 6, "learnings": 4, "recommendations": 5}
MAX_CHARS = 320
ACTIONS = ("dataset", "rule_studio", "review_queue", "incidents", "none")

GUIDANCE = (
    "You are a senior data quality analyst writing the Patterns and Insights page of a data quality product. "
    "You receive FACTS about the last period as JSON: each fact has an id (F1, F2, ...), a type and data. "
    "Write for data engineers and stewards in plain, direct English.\n"
    "Return ONE JSON object and nothing else, exactly in this shape:\n"
    '{"insights": [{"text": str, "facts": [ids], "severity": "high"|"medium"|"low"}],\n'
    ' "learnings": [{"text": str, "facts": [ids]}],\n'
    ' "recommendations": [{"text": str, "facts": [ids], "action": {"type": "dataset"|"rule_studio"|"review_queue"|"incidents"|"none", "dataset": str|null}}]}\n'
    "Rules:\n"
    "- Use ONLY the facts. Every item must list the ids of the facts it relies on in \"facts\".\n"
    "- Every number you write must appear in those facts (counts, percentages, hours). Do not add, estimate or round differently, "
    "and do not write times of day, thresholds, dates or any number that is not in a fact.\n"
    "- Name datasets exactly as in the facts. Never invent datasets, causes, rules or people.\n"
    f"- At most {LIMITS['insights']} insights (what is happening, most important first), {LIMITS['learnings']} learnings "
    f"(what the system has learned from feedback and rule tuning; skip if the facts hold nothing about it) and "
    f"{LIMITS['recommendations']} recommendations (concrete next steps a person or this product can take).\n"
    f"- Each text is one or two sentences, under {MAX_CHARS} characters, with no markdown and no fact ids inside the text.\n"
    "- A recommendation's action type says where the product should send the reader: dataset (set \"dataset\" to that dataset's name), "
    "rule_studio (add or change rules), review_queue (rules waiting for approval), incidents (open incidents), or none.\n"
    "- Severity: high when incidents recur or reach downstream datasets, medium for notable patterns, low for context.\n"
    "- If the facts hold little, return fewer items. Empty lists are fine."
)


# ---------------------------------------------------------------------------- facts
def build_facts(db, days: int = 30, platform: str | None = None) -> list[dict]:
    r = compute(db, days, platform)
    out: list[dict] = []

    def add(kind: str, **data):
        out.append({"id": f"F{len(out) + 1}", "type": kind, "data": data})

    t = r["totals"]
    add("period", days=r["days"], failed_checks=t["failures"], checks=t["checks"], incidents=t["incidents"])
    for x in sorted(r["recurring"], key=lambda x: (-x["count"], x["root"]))[:5]:
        cause = x["hypotheses"][0][0] if x["hypotheses"] else None
        add("recurring_incidents", dataset=x["root"], incidents=x["count"], usual_weekday=x["common_day"], usual_cause=cause,
            avg_hours_to_fix=x["mttr_hours"], downstream_datasets_hit=x["downstream"])
    days_n = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    if t["failures"]:
        d = max(range(7), key=lambda i: (r["by_day"][i], -i))
        add("failure_timing_weekday", weekday=days_n[d], failures=r["by_day"][d], share_percent=round(100 * r["by_day"][d] / t["failures"]))
        h = max(range(24), key=lambda i: (r["by_hour"][i], -i))
        add("failure_timing_hour", hour_utc=h, failures=r["by_hour"][h], share_percent=round(100 * r["by_hour"][h] / t["failures"]))
    for dim, n in sorted(r["dimensions"].items(), key=lambda kv: (-kv[1], kv[0]))[:3]:
        add("failures_by_dimension", dimension=dim, failures=n)
    for s in r["sources"][:3]:
        add("source_reach", dataset=s["root"], incidents=s["incidents"], downstream_datasets_hit=s["downstream_hit"])
    for h in r["hotspots"][:4]:
        add("hotspot", dataset=h["fqn"], failed_checks=h["fails"], fail_rate_percent=round(100 * h["fail_rate"], 1))
    for f in r["flaky"][:3]:
        add("flaky_rule", rule=f["name"], dataset=f["asset"], flips=f["flips"], runs=f["runs"])
    L = r["learnings"]
    if L["precision"] is not None:
        add("alert_precision", precision_percent=round(100 * L["precision"]), feedback=dict(sorted(L["feedback"].items())))
    for n in L["noisy_rules"][:3]:
        add("noisy_rule", rule=n["name"], dataset=n["asset"], false_positives=n["fp"])
    fixes = feature_on("fixes_and_quarantine")
    if fixes and (L["auto_corrections"] or L["manual_corrections"] or L["rows_corrected"]):
        add("corrections", automatic=L["auto_corrections"], manual=L["manual_corrections"], rows_corrected=L["rows_corrected"], undone=L["undone"])
    if fixes and L["rows_quarantined"]:
        add("quarantine", rows_quarantined=L["rows_quarantined"], rows_released=L["rows_released"])
    if L["tuned"]:
        add("feedback_tuning", changes=len(L["tuned"]), examples=[x["effect"] for x in L["tuned"][:3]])
    rs = dict(sorted(L["rules_by_source"].items()))
    if rs:
        add("rules_by_origin", **rs)
    return out


def fingerprint(facts: list[dict], scope: str) -> str:
    blob = json.dumps({"v": GUIDANCE_VERSION, "scope": scope, "facts": facts}, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


# ---------------------------------------------------------------------------- checking the model's answer
NUM_RE = re.compile(r"\d+(?:[.,]\d+)?")


def _numbers_in(value) -> set[str]:
    nums: set[str] = set()
    if isinstance(value, bool) or value is None:
        return nums
    if isinstance(value, (int, float)):
        v = float(value)  # the exact value and its rounding to 0, 1 and 2 decimals may be written
        return {_clean_number(f"{v:.0f}"), _clean_number(f"{v:.1f}"), _clean_number(f"{v:.2f}")}
    if isinstance(value, str):
        return {m.replace(",", ".") for m in NUM_RE.findall(value)}
    if isinstance(value, dict):
        for v in value.values():
            nums |= _numbers_in(v)
    elif isinstance(value, (list, tuple)):
        for v in value:
            nums |= _numbers_in(v)
    return nums


def _clean_number(s: str) -> str:
    s = s.replace(",", ".")
    return s.rstrip("0").rstrip(".") if "." in s else s


def validate(answer, facts: list[dict]) -> tuple[dict, int]:
    """Keep only statements that cite known facts and contain no number outside them. Returns (clean, dropped)."""
    ids = {f["id"]: f for f in facts}
    datasets = {str(v) for f in facts for k, v in f["data"].items() if k == "dataset"}
    dropped = 0
    out = {"insights": [], "learnings": [], "recommendations": []}
    if not isinstance(answer, dict):
        return out, 0
    for section, limit in LIMITS.items():
        items = answer.get(section)
        if not isinstance(items, list):
            continue
        for it in items:
            if len(out[section]) >= limit:
                break
            if not isinstance(it, dict) or not isinstance(it.get("text"), str):
                dropped += 1
                continue
            text = " ".join(it["text"].split())
            cited = [c for c in (it.get("facts") or []) if c in ids] if isinstance(it.get("facts"), list) else []
            if not text or len(text) > MAX_CHARS or not cited:
                dropped += 1
                continue
            allowed = {_clean_number(n) for c in cited for n in _numbers_in(ids[c]["data"])}
            allowed |= {_clean_number(n) for n in _numbers_in(facts[0]["data"])}  # the period (days, totals) is always citable
            if any(_clean_number(n) not in allowed for n in NUM_RE.findall(text)):
                dropped += 1
                continue
            item = {"text": text, "facts": cited}
            if section == "insights":
                item["severity"] = it.get("severity") if it.get("severity") in ("high", "medium", "low") else "medium"
            if section == "recommendations":
                act = it.get("action") if isinstance(it.get("action"), dict) else {}
                typ = act.get("type") if act.get("type") in ACTIONS else "none"
                ds = act.get("dataset") if isinstance(act.get("dataset"), str) else None
                if typ == "dataset" and ds not in datasets:
                    typ, ds = "none", None
                item["action"] = {"type": typ, "dataset": ds if typ == "dataset" else None}
            out[section].append(item)
    return out, dropped


# ---------------------------------------------------------------------------- saved result
def scope_key(platform: str | None) -> str:
    return KEY_PREFIX + (platform or "all")


def saved(db, platform: str | None) -> dict | None:
    row = db.get(AppSetting, scope_key(platform))
    return dict(row.value) if row and row.value else None


def state(db, platform: str | None = None, days: int = 30) -> dict:
    """What the page needs: the saved write-up, and whether the facts have changed since it was made."""
    facts = build_facts(db, days, platform)
    fp = fingerprint(facts, platform or "all")
    rep = saved(db, platform)
    return {"report": rep, "fingerprint": fp, "fresh": bool(rep and rep.get("fingerprint") == fp), "facts": len(facts)}


class AIInsightsError(RuntimeError):
    pass


def generate(db, llm, actor: str, platform: str | None = None, days: int = 30, force: bool = False) -> dict:
    """Write up the current facts with the configured model. With unchanged facts the saved text is returned and the model is not called."""
    if llm is None:
        raise AIInsightsError("No LLM is configured. Choose a provider and add its API key in Settings > LLM.")
    facts = build_facts(db, days, platform)
    fp = fingerprint(facts, platform or "all")
    rep = saved(db, platform)
    if rep and rep.get("fingerprint") == fp and not force:
        return {**rep, "reused": True}
    prompt = json.dumps({"scope": platform or "all platforms", "facts": facts}, sort_keys=True, default=str)
    try:
        answer = llm.complete_json(GUIDANCE, prompt)
    except Exception as e:
        raise AIInsightsError(f"The model could not be reached ({type(e).__name__}: {str(e)[:200]}). Check it in Settings > LLM with Test connection.") from e
    clean, dropped = validate(answer, facts)
    if not any(clean.values()):
        raise AIInsightsError("The model's answer had nothing that could be checked against the facts. Try again, or use a more capable model in Settings > LLM.")
    desc = llm.describe() if hasattr(llm, "describe") else {}
    rep = {**clean, "fingerprint": fp, "guidance_version": GUIDANCE_VERSION, "scope": platform or "all", "days": days, "facts": len(facts),
           "dropped": dropped, "provider": desc.get("provider"), "model": desc.get("model"), "generated_at": utcnow().isoformat(timespec="seconds"),
           "generated_by": actor}
    row = db.get(AppSetting, scope_key(platform))
    if row:
        row.value, row.updated, row.updated_by = rep, utcnow(), actor
    else:
        db.add(AppSetting(key=scope_key(platform), value=rep, updated=utcnow(), updated_by=actor))
    audit(db, actor, "ai_insights.generated", platform or "all", model=rep["model"], items=sum(len(clean[k]) for k in clean), dropped=dropped)
    db.flush()
    return {**rep, "reused": False}


def with_links(db, rep: dict | None) -> dict | None:
    """Resolve each recommendation's dataset name to the app address it should open."""
    if not rep:
        return rep
    by = {a.fqn: a.id for a in db.scalars(select(Asset))}
    links = {"rule_studio": "#/rules/generation", "review_queue": "#/rules/review", "incidents": "#/explore/incidents"}
    out = {**rep, "recommendations": []}
    for r in rep.get("recommendations", []):
        act = r.get("action") or {"type": "none"}
        href = f"#/asset/{by[act['dataset']]}" if act.get("type") == "dataset" and act.get("dataset") in by else links.get(act.get("type"))
        out["recommendations"].append({**r, "href": href})
    return out
