"""How datasets are grouped (what the app used to call the "domain").

The group is stored on each dataset. It comes from, in order:
  1. a value someone typed on the dataset page (locked: sync never overwrites it),
  2. a group the connector reports (for example the Cognite connection's own `domain` setting),
  3. the configured source: a tag on the table, the catalog, the schema, the connection, or the owner.

config.yaml:
    grouping:
      label: Domain          # what the UI calls it: Domain, Business unit, Data product ...
      source: tag            # tag | catalog | schema | connection | owner
      tag: domain            # tag name when source is tag
      critical: []           # group values that count as business-critical in impact analysis
      financial: []          # group values treated as financial data by governance rules and compliance
      hints: {}              # {group value: sentence}, used by AI rule discovery as business context

Nothing here is specific to one industry: leave the lists empty and nothing assumes a group name.
"""
from __future__ import annotations

from .config import get_settings

SOURCES = {"tag": "a tag on the table", "catalog": "the catalog", "schema": "the schema",
           "connection": "the connection name", "owner": "the dataset owner"}


def config() -> dict:
    g = dict(get_settings().section("grouping") or {})
    src = str(g.get("source") or "tag").lower()
    g["source"] = src if src in SOURCES else "tag"
    g["label"] = str(g.get("label") or "Domain").strip() or "Domain"
    g["tag"] = str(g.get("tag") or "domain")
    for k in ("critical", "financial"):
        g[k] = [str(x).lower() for x in (g.get(k) or [])]
    g["hints"] = {str(k).lower(): str(v) for k, v in (g.get("hints") or {}).items()}
    return g


def _tag(tags: dict | None, name: str) -> str | None:
    for k, v in (tags or {}).items():
        if str(k).lower() == name.lower() and v not in (None, ""):
            return str(v)
    return None


def derive(fqn: str, connection: str, owner: str | None, tags: dict | None, reported: str | None = None) -> str | None:
    """The group for a dataset from what a sync knows about it (None = unassigned)."""
    if reported:
        return reported
    g = config()
    src = g["source"]
    parts = fqn.split(".")
    if src == "tag":
        return _tag(tags, g["tag"])
    if src == "catalog":
        return parts[0] if len(parts) >= 3 else None
    if src == "schema":
        return parts[-2] if len(parts) >= 2 else None
    if src == "connection":
        return connection or None
    if src == "owner":
        return owner or _tag(tags, "owner")
    return None


def apply_on_sync(asset, reported: str | None) -> None:
    """Set the group while syncing. Locked values (typed by a person) stay; datasets from before
    locking existed keep whatever value they already have."""
    if asset.domain_locked is None:
        asset.domain_locked = bool(asset.domain)
    if asset.domain_locked:
        return
    asset.domain = derive(asset.fqn, asset.connection, asset.owner, asset.tags, reported)


def regroup_all(db) -> dict:
    """Unlock every dataset and recompute its group from the connectors' last-synced tags and the configured source."""
    from sqlalchemy import select

    from .models import Asset
    changed = 0
    for a in db.scalars(select(Asset)):
        before = a.domain
        a.domain_locked = False
        a.domain = derive(a.fqn, a.connection, a.owner, a.tags)
        changed += before != a.domain
    db.flush()
    return {"datasets": db.query(Asset).count(), "changed": changed}


def is_critical(domain: str | None) -> bool:
    return (domain or "").lower() in config()["critical"]


def is_financial(domain: str | None) -> bool:
    return (domain or "").lower() in config()["financial"]


def hint_for(domain: str | None) -> str | None:
    return config()["hints"].get((domain or "").lower())


def public() -> dict:
    g = config()
    return {"label": g["label"], "source": g["source"], "source_text": SOURCES[g["source"]], "tag": g["tag"],
            "critical": g["critical"], "financial": g["financial"]}
