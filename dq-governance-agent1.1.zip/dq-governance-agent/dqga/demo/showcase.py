"""Fills the parts of the demo that the core seed leaves empty, so every screen has something to show:

  reference documents and a glossary file, rules in every review state, rule schedules, two weeks of run
  history, custom Overview metrics with trends, pending and decided approvals, applied / undone corrections
  with more suggested, a quarantine batch, and an insights refresh record.

Everything is real data produced by the app's own code (rules validated, fixes applied with snapshots,
quarantine copied on the platform); only the timestamps of the run history are backdated.
"""
from __future__ import annotations

import random
from datetime import timedelta

from sqlalchemy import select

from .. import services as S
from ..dq import custom_metrics as CM
from ..dq import review
from ..dq import schedules as SCH
from ..config import feature_on
from ..models import (Approval, Asset, CheckResult, Classification, CustomMetric, CustomMetricValue, Incident, MetricPoint, Rule,
                      RuleSchedule, Run, audit, utcnow)

UTILITY_RULES_DOC = """Meter data business rules (sample document)

Every meter reading must have a meter_id.
kwh must not be negative.
voltage must be between 200 and 260.
Meter readings must be refreshed every 3 hours.
A meter status must be one of ACTIVE, INACTIVE, FAULTY.
customer_id must exist in customers.customer_id.
Billing amounts must never be negative.
Personal data such as email and phone must be masked for non-privileged users.
"""

UTILITY_GLOSSARY = """term,definition,maps_to,domain
Consumption,Energy used by a customer in kilowatt hours,ami_raw.kwh,metering
Reading Time,When the smart meter recorded the reading,ami_raw.reading_ts,metering
Contact Email,The customer's email address for notices,customers.email,customer
"""


def _log(log, msg):
    if log:
        log(msg)


def seed_showcase(db, assets: dict[str, Asset], cat: str, log=None) -> dict:
    rng = random.Random(11)
    now = utcnow().replace(minute=0, second=0, microsecond=0)
    out: dict = {}
    ids = [a.id for a in assets.values()]  # everything below is limited to these datasets, so existing data is never touched
    fqns = {a.fqn for a in assets.values()}

    # ------------------------------------------------------------------ reference library
    from .. import reference as REF
    try:
        REF.ingest(db, "utility_meter_rules.txt", UTILITY_RULES_DOC.encode(), "demo-steward", description="Business rules for meter data")
        REF.ingest(db, "utility_glossary.csv", UTILITY_GLOSSARY.encode(), "demo-steward", description="Business terms mapped to columns")
        out["reference_files"] = 2
    except Exception as e:  # never block the demo on an optional part
        _log(log, f"  reference files skipped: {e}")

    # ------------------------------------------------------------------ more rules: governance and business sets, and a late dataset
    try:
        from ..dq.discovery import accept, discover
        from ..dq.runner import run_asset
        touched = set()
        for key, want in (("silver.customers", ("governance", "business")), ("gold.billing_mart", ("governance",)), ("silver.meters", ("business",))):
            a = assets[key]
            found = discover(db, a, use_llm=False, llm=None)
            picked = [c for c in found["candidates"] if c.get("rule_category") in want and (c.get("dry_run") or {}).get("status") == "pass"][:4]
            for r in accept(db, a, picked, "demo-steward"):
                S.update_rule(db, r, {"status": "active"}, "demo-admin", "approved in review")
                touched.add(key)
        gold = assets["gold.meter_readings_daily"]
        S.create_rule(db, gold, {"type": "freshness", "column": "reading_date", "params": {"max_age_hours": 2}, "severity": "medium",
                                 "name": "daily summary refreshed within 2h of day end", "source": "manual"}, "demo-steward", status="active")
        touched.add("gold.meter_readings_daily")
        for key in touched:
            run_asset(db, assets[key], trigger="demo", allow_autofix=False)
        out["extra_rules"] = len(touched)
    except Exception as e:
        _log(log, f"  extra rules skipped: {e}")

    # ------------------------------------------------------------------ rules in every review state
    drafts = list(db.scalars(select(Rule).where(Rule.status == "proposed", Rule.asset_id.in_(ids)).order_by(Rule.id)))
    for r, src in zip(drafts[:9], ("discovery", "nl", "discovery", "llm", "nl", "discovery", "contract", "discovery", "nl")):
        r.source = src
    if len(drafts) >= 8:
        try:
            review.submit(db, [drafts[0].id, drafts[1].id, drafts[2].id], "demo-steward", "Found by discovery; ranges match the meter spec")
            review.submit(db, [drafts[3].id], "grid-analytics@utility.example", "Please check the threshold")
            review.submit(db, [drafts[4].id, drafts[5].id], "demo-steward", "Ready to go live")
            review.decide(db, [drafts[4].id], "approve", "demo-admin", "Approved; activate after the next load")
            review.decide(db, [drafts[5].id], "reject", "demo-admin", "Too strict for night loads: allow 1% nulls, then send again")
            out["review"] = {"waiting": 4, "approved": 1, "rejected": 1}
        except Exception as e:
            _log(log, f"  review states skipped: {e}")
    disabled = [r for r in db.scalars(select(Rule).where(Rule.status == "active", Rule.severity == "low", Rule.asset_id.in_(ids)).limit(2))]
    for r in disabled:
        S.update_rule(db, r, {"status": "disabled"}, "demo-admin", "switched off: too noisy for now")
    db.flush()

    # ------------------------------------------------------------------ schedules
    specs = [("Core checks every hour", "interval", 60, None, [], {"category": "core"}, True),
             ("Business rules on weekday mornings", "daily", None, "06:30", [0, 1, 2, 3, 4], {"category": "business"}, True),
             ("Critical rules every 15 minutes", "interval", 15, None, [], {"severity": "critical"}, True),
             ("Governance checks nightly", "daily", None, "01:00", [], {"category": "governance"}, False)]
    sched = []
    for name, cad, every, at, days, scope, on in specs:
        s = RuleSchedule(name=name, cadence=cad, every_minutes=every, at_time=at, weekdays=days, scope=SCH.clean_scope(scope), enabled=on,
                         created_by="demo-admin")
        db.add(s)
        db.flush()
        s.next_run = SCH.next_after(s, now) if on else None
        sched.append(s)
    out["schedules"] = len(sched)

    # ------------------------------------------------------------------ run history (14 days)
    runs = 0
    latest = {}
    for cr in db.scalars(select(CheckResult).where(CheckResult.run_id.in_(select(Run.id).where(Run.trigger == "demo", Run.asset_id.in_(ids))))):
        latest[cr.rule_id] = cr
    keys = ("schedule", "schedule", "schedule", "schedule", "manual", "agent", "refresh")
    for back in range(14, 0, -1):
        for hour in (2, 8, 14, 20)[: 2 + back % 3]:
            at = (now - timedelta(days=back)).replace(hour=hour)
            for a in assets.values():
                rules = [r for r in db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status.in_(("active", "disabled"))))]
                rules = [r for r in rules if r.id in latest]
                if not rules or rng.random() < 0.45:
                    continue
                trig = rng.choice(keys)
                sid = rng.choice(sched[:3]).id if trig == "schedule" else None
                run = Run(asset_id=a.id, ts=at, trigger=trig, duration_s=round(rng.uniform(0.05, 1.8), 2), schedule_id=sid,
                          actor="demo-steward" if trig == "manual" else "grid-analytics@utility.example" if trig == "agent" else None)
                db.add(run)
                db.flush()
                failed = errors = 0
                for r in rules:
                    src = latest[r.id]
                    st = src.status
                    if st == "pass" and rng.random() < 0.03 and r.type not in ("unique", "freshness"):
                        st = "fail"            # the odd transient failure
                    elif st == "fail" and rng.random() < 0.25:
                        st = "pass"            # and the odd recovery
                    pr = src.pass_rate if st == src.status else (1.0 if st == "pass" else round(rng.uniform(0.9, 0.995), 4))
                    db.add(CheckResult(run_id=run.id, rule_id=r.id, asset_id=a.id, ts=at, status=st, total=src.total,
                                       failed=0 if st == "pass" else max(1, src.failed or 1), pass_rate=pr, message=src.message,
                                       duration_s=round(rng.uniform(0.001, 0.05), 4)))
                    failed += st == "fail"
                run.checks, run.failed, run.errors = len(rules), failed, errors
                run.status = "ok"
                runs += 1
    for s in sched[:3]:
        last = db.scalars(select(Run).where(Run.schedule_id == s.id).order_by(Run.ts.desc())).first()
        if last:
            s.last_run, s.last_status = last.ts, "failures" if last.failed else "ok"
            s.last_summary = {"rules": last.checks, "datasets": 1, "checks": last.checks, "failed": last.failed, "errors": 0,
                              "duration_s": last.duration_s, "incidents": 0, "skipped": [], "failures": [], "manual": False}
    out["history_runs"] = runs
    audit(db, "demo-steward", "insights.refreshed", "due", sync={"datasets": len(assets), "new": 0, "errors": {}},
          checks={"datasets": len(assets), "checks": 96, "failed": 11, "schedules": 2, "skipped": 0, "deferred": 0, "errors": []},
          datasets_without_rules=0, duration_s=3.4)

    # ------------------------------------------------------------------ custom Overview metrics, with a trend
    metrics = [
        ("Metering average score", "Mean DQ score of metering datasets", "avg_score", {"domain": "metering"}, 95, 85),
        ("Completeness score", "Mean completeness across all datasets", "dimension_score", {"dimension": "completeness"}, 98, 92),
        ("Check pass rate, 7 days", "Share of checks that passed this week", "pass_rate", {"window_days": 7}, 97, 92),
        ("Failed checks, 7 days", "How many checks failed this week", "failed_checks", {"window_days": 7}, 5, 15),
        ("Billing average score", "Mean DQ score of billing datasets", "avg_score", {"domain": "billing"}, 95, 85),
        ("Customers in the master table", "Row count from the platform (a SQL metric)", "sql",
         {"connection": "demo", "sql": f"SELECT COUNT(*) FROM {cat}.silver.customers"}, None, None)]
    for pos, (name, desc, measure, params, target, warn) in enumerate(metrics, 1):
        try:
            vals = CM.normalize({"name": name, "description": desc, "measure": measure, "params": params, "target": target, "warn_at": warn,
                                 "show_on_overview": True})
            m = CustomMetric(**vals, position=pos, created_by="demo-admin")
            db.add(m)
            db.flush()
            now_v = CM.evaluate(db, m)
            base = now_v if now_v is not None else 50.0
            for d in range(7, 0, -1):
                drift = base * (1 + rng.uniform(-0.06, 0.06)) if measure != "failed_checks" else max(0.0, base + rng.uniform(-6, 8))
                db.add(CustomMetricValue(metric_id=m.id, ts=now - timedelta(days=d), value=round(drift, 2)))
        except Exception as e:
            _log(log, f"  metric {name!r} skipped: {e}")
    out["metrics"] = len(metrics)

    # ------------------------------------------------------------------ corrections: applied, undone, and more suggested
    cust = assets["silver.customers"]
    fixes_on = feature_on("fixes_and_quarantine")
    try:
        if not fixes_on:
            raise StopIteration  # corrections are not offered in this version
        from ..dq.runner import run_asset
        from ..incidents import autofix
        fixes = sorted(autofix.analyze_asset(db, cust), key=lambda f: f.get("kind") == "dedupe_exact")  # undo is shown on the last one
        applied = 0
        for f in fixes:
            if f["risk"] != "low":
                continue
            fr = autofix.apply(db, f["id"], "demo-steward" if applied else "auto-correct", auto=not applied)
            applied += 1
            if f.get("kind") == "dedupe_exact":        # show the undo: applied, then taken back
                autofix.undo(db, fr, "demo-steward")
        run_asset(db, cust, trigger="correction", allow_autofix=False)
        out["corrections"] = applied
    except StopIteration:
        pass
    except Exception as e:
        _log(log, f"  corrections skipped: {e}")

    # ------------------------------------------------------------------ quarantine: a copied batch of bad readings
    try:
        if not fixes_on:
            raise StopIteration
        from ..incidents import quarantine as Q
        ami = assets["bronze.ami_raw"]
        bad = next((r for r in db.scalars(select(Rule).where(Rule.asset_id == ami.id, Rule.status == "active", Rule.last_status == "fail"))
                    if Q.can_quarantine(r) and r.type in ("range", "not_null", "accepted_values")), None)
        if bad:
            Q.quarantine(db, ami, bad, "demo-steward", mode="copy", note="Kept for the meter firmware investigation")
            out["quarantine_batches"] = 1
    except StopIteration:
        pass
    except Exception as e:
        _log(log, f"  quarantine skipped: {e}")

    db.flush()
    _log(log, "Showcase data: " + ", ".join(f"{k} {v}" for k, v in out.items()))
    return out
