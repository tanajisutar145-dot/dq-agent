"""Demo: a utility (power distribution) lakehouse in DuckDB with planted issues.

Planted issues the product should find on its own:
  1. AMI extractor outage: substation SUB-07 meters send empty kwh for the last
     12 hours (bronze.ami_raw), which propagates to gold.meter_readings_daily.
     Bronze volume is ~17% under its 28-day baseline. Expect ONE incident
     rooted at bronze.ami_raw, with gold grouped under it.
  2. Orphan meters: silver.meters has customer_ids missing from customers.
  3. OT sensors: TX-03 flatlined for 8h, TX-07 spikes, TX-11 has a 3h gap.
  4. Finance: duplicate journal entry ids in finance.gl_revenue.
  5. PII in silver.customers (names, emails, phones, addresses) -> masking policy.
"""
from __future__ import annotations

import random
from datetime import timedelta
from pathlib import Path

import duckdb
from sqlalchemy import select

from .. import services as S
from ..config import Settings
from ..db import session_scope
from ..dq.runner import run_asset
from ..governance import contracts
from ..models import Asset, GlossaryLink, GlossaryTerm, MetricPoint, Rule, utcnow


def build_warehouse(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    for p in (path, path.with_suffix(".duckdb.wal")):
        if p.exists():
            p.unlink()
    now = utcnow().replace(minute=0, second=0, microsecond=0)
    t0 = (now - timedelta(hours=49)).isoformat(sep=" ")
    cut = (now - timedelta(hours=12)).isoformat(sep=" ")
    con = duckdb.connect(str(path))
    cat = path.stem
    con.execute("SELECT setseed(0.42)")
    for s in ("bronze", "silver", "gold", "ot", "finance"):
        con.execute(f"CREATE SCHEMA {cat}.{s}")
    first = ["Asha", "Ravi", "Maria", "John", "Wei", "Fatima", "Lukas", "Sofia", "Omar", "Priya", "Kenji", "Elena"]
    last = ["Patel", "Smith", "Garcia", "Chen", "Khan", "Muller", "Rossi", "Sato", "Silva", "Nair", "Brown", "Novak"]
    rng = random.Random(7)
    rows = []
    for i in range(1, 2001):
        fn, ln = rng.choice(first), rng.choice(last)
        email = f"{fn}.{ln}{i}@example.com".lower() if i % 250 else f"{fn}{ln}{i}.example.com"
        rows.append((i, f"{fn} {ln}", email, f"+44 20 {7000 + i:04d} {1000 + i % 9000:04d}",
                     f"{i} {rng.choice(['High St', 'Mill Rd', 'Park Ave', 'Station Rd'])}, {rng.choice(['Leeds', 'York', 'Hull'])}",
                     rng.choice(["residential", "residential", "residential", "commercial", "industrial"]),
                     (now - timedelta(days=rng.randint(0, 900), hours=rng.randint(0, 23))).isoformat(sep=" ")))
    # planted for auto-correct: inconsistent spelling of segments, and exact duplicate rows
    for i, r in enumerate(rows):
        seg = r[5]
        if i % 97 == 5:
            seg = seg.capitalize()            # 'Residential'
        elif i % 131 == 7:
            seg = seg + " "                   # trailing space
        elif i % 173 == 11 and seg == "commercial":
            seg = "comercial"                 # misspelling
        rows[i] = r[:5] + (seg,) + r[6:]
    rows += [rows[10], rows[11], rows[12], rows[13]]
    con.execute(f"CREATE TABLE {cat}.silver.customers (customer_id INTEGER, full_name VARCHAR, email VARCHAR, phone VARCHAR, "
                "address VARCHAR, segment VARCHAR, created_at TIMESTAMP)")
    con.executemany(f"INSERT INTO {cat}.silver.customers VALUES (?, ?, ?, ?, ?, ?, ?)", rows)

    con.execute(f"""CREATE TABLE {cat}.silver.meters AS
        SELECT printf('MTR-%06d', i) AS meter_id,
               CASE WHEN i % 200 = 0 THEN 90000 + i ELSE 1 + (i % 2000) END AS customer_id,
               printf('SUB-%02d', 1 + (i % 12)) AS substation,
               CASE WHEN i % 10 < 7 THEN 'smart' WHEN i % 10 < 9 THEN 'legacy' ELSE 'prepaid' END AS meter_type,
               DATE '2018-01-01' + CAST(i % 2000 AS INTEGER) AS install_date,
               CASE WHEN i % 97 = 0 THEN 'inactive' ELSE 'active' END AS status
        FROM range(1, 3001) t(i)""")

    con.execute(f"""CREATE TABLE {cat}.bronze.ami_raw AS
        SELECT m.meter_id, ts AS reading_ts,
               CASE WHEN m.substation = 'SUB-07' AND ts > TIMESTAMP '{cut}' THEN NULL
                    WHEN m.meter_id = 'MTR-000777' AND h = 30 THEN -4.2
                    ELSE round(0.15 + random() * 2.4 + (CASE WHEN hour(ts) BETWEEN 17 AND 21 THEN 0.8 ELSE 0 END), 3) END AS kwh,
               round(229 + random() * 4, 1) AS voltage, m.substation,
               ts + INTERVAL 15 MINUTE AS ingested_at
        FROM {cat}.silver.meters m
        CROSS JOIN (SELECT TIMESTAMP '{t0}' + INTERVAL (h) HOUR AS ts, h FROM range(1, 48) r(h))""")

    con.execute(f"""CREATE TABLE {cat}.gold.meter_readings_daily AS
        SELECT meter_id, CAST(reading_ts AS DATE) AS reading_date,
               CASE WHEN COUNT(kwh) < COUNT(*) THEN NULL ELSE round(SUM(kwh), 3) END AS kwh_total,
               COUNT(*) AS readings
        FROM {cat}.bronze.ami_raw GROUP BY 1, 2""")

    con.execute(f"""CREATE TABLE {cat}.gold.billing_mart AS
        SELECT m.customer_id, date_trunc('month', d.reading_date) AS bill_month,
               round(SUM(d.kwh_total), 2) AS kwh, round(SUM(d.kwh_total) * 0.28, 2) AS amount
        FROM {cat}.gold.meter_readings_daily d JOIN {cat}.silver.meters m USING (meter_id)
        GROUP BY 1, 2""")

    con.execute(f"""CREATE TABLE {cat}.finance.gl_revenue AS
        SELECT CASE WHEN i % 150 = 0 THEN i - 1 ELSE i END AS entry_id,
               DATE '{now.date().isoformat()}' - CAST(i % 30 AS INTEGER) AS posting_date,
               CASE WHEN i % 3 = 0 THEN '4000-ENERGY' WHEN i % 3 = 1 THEN '4100-STANDING' ELSE '4200-OTHER' END AS account,
               round(20 + random() * 400, 2) AS amount, 1 + (i % 2000) AS customer_id
        FROM range(1, 4501) t(i)""")

    s_start = now - timedelta(hours=48)
    sensors = []
    srng = random.Random(11)
    for k in range(1, 21):
        sid = f"TX-{k:02d}"
        base = 60 + k
        for step in range(0, 48 * 12):
            t = s_start + timedelta(minutes=5 * step)
            if sid == "TX-11" and timedelta(hours=20) <= t - s_start < timedelta(hours=23):
                continue
            v = round(base + 5 * srng.random() + 3 * ((step % 288) / 288), 2)
            if sid == "TX-03" and t > now - timedelta(hours=8):
                v = 71.4
            if sid == "TX-07" and step in (300, 301, 450):
                v = 640.0
            sensors.append((sid, t.isoformat(sep=" "), v, "degC"))
    con.execute(f"CREATE TABLE {cat}.ot.sensor_timeseries (sensor_id VARCHAR, ts TIMESTAMP, value DOUBLE, unit VARCHAR)")
    con.executemany(f"INSERT INTO {cat}.ot.sensor_timeseries VALUES (?, ?, ?, ?)", sensors)

    con.execute("CREATE SCHEMA IF NOT EXISTS dq_meta")
    con.execute("CREATE TABLE dq_meta.lineage (source VARCHAR, target VARCHAR)")
    con.execute("CREATE TABLE dq_meta.tags (fqn VARCHAR, column_name VARCHAR, key VARCHAR, value VARCHAR)")
    edges = [("cdf:demo:ts:ami_feed", "bronze.ami_raw"), ("bronze.ami_raw", "gold.meter_readings_daily"),
             ("silver.meters", "gold.meter_readings_daily"), ("gold.meter_readings_daily", "gold.billing_mart"),
             ("silver.meters", "gold.billing_mart"), ("silver.customers", "gold.billing_mart"),
             ("gold.billing_mart", "finance.gl_revenue"), ("cdf:demo:ts:substation_sensors", "ot.sensor_timeseries")]
    for s, t in edges:
        s = s if s.startswith("cdf:") else f"{cat}.{s}"
        con.execute("INSERT INTO dq_meta.lineage VALUES (?, ?)", [s, f"{cat}.{t}"])
    con.close()


META = {
    "bronze.ami_raw": ("metering", "ami-platform@utility.example", "Grid analytics", False, "Raw hourly smart meter reads from the AMI head-end via CDF"),
    "silver.meters": ("metering", "asset-data@utility.example", "Grid analytics", False, "Meter master data"),
    "silver.customers": ("customer", "crm-team@utility.example", None, False, "Customer master (contains personal data)"),
    "gold.meter_readings_daily": ("metering", "grid-analytics@utility.example", "Grid analytics", True, "Daily consumption per meter"),
    "gold.billing_mart": ("billing", "billing@utility.example", "Revenue assurance", True, "Monthly billed energy per customer"),
    "finance.gl_revenue": ("finance", "finance-data@utility.example", "Financial control", True, "General ledger revenue lines"),
    "ot.sensor_timeseries": ("operations", "ot-engineering@utility.example", "OT reliability", False, "Transformer temperature sensors (5-minute)"),
}

GLOSSARY = [
    ("Meter reading", "A cumulative or interval energy measurement reported by a meter.", "metering", ["kwh", "read"], ["bronze.ami_raw", "gold.meter_readings_daily"]),
    ("Billed energy", "Energy (kWh) invoiced to a customer for a billing period.", "billing", ["billed kwh"], ["gold.billing_mart"]),
    ("Customer", "A party with a supply agreement; personal data under GDPR.", "customer", ["account holder"], ["silver.customers"]),
    ("Substation", "Grid node that steps voltage down for distribution; meters roll up to one.", "operations", ["sub"], ["silver.meters"]),
    ("Revenue", "Recognized income from energy and standing charges.", "finance", ["GL revenue"], ["finance.gl_revenue"]),
]


def explicit_rules(cat: str) -> dict[str, list[dict]]:
    return {
        "bronze.ami_raw": [
            {"type": "not_null", "column": "kwh", "threshold": 0.99, "severity": "high", "name": "kwh populated >= 99%"},
            {"type": "range", "column": "kwh", "params": {"min": 0, "max": 50}, "severity": "medium", "threshold": 0.9999},
            {"type": "freshness", "column": "ingested_at", "params": {"max_age_hours": 3}, "severity": "high"},
            {"type": "anomaly", "params": {"metric": "row_count", "sensitivity": 3}, "severity": "high", "name": "row volume vs baseline"},
        ],
        "gold.meter_readings_daily": [
            {"type": "not_null", "column": "kwh_total", "threshold": 0.99, "severity": "high"},
            {"type": "unique", "params": {"columns": ["meter_id", "reading_date"]}, "severity": "high"},
            {"type": "anomaly", "params": {"metric": "row_count", "sensitivity": 3}, "severity": "medium"},
        ],
        "silver.customers": [
            {"type": "unique", "params": {"columns": ["customer_id"]}, "severity": "high"},
            {"type": "accepted_values", "column": "segment", "params": {"values": ["residential", "commercial", "industrial"]},
             "severity": "medium"},
        ],
        "silver.meters": [
            {"type": "referential", "column": "customer_id", "params": {"ref_table": f"{cat}.silver.customers", "ref_column": "customer_id"}, "severity": "high"},
            {"type": "unique", "params": {"columns": ["meter_id"]}, "severity": "critical"},
        ],
        "gold.billing_mart": [
            {"type": "range", "column": "amount", "params": {"min": 0}, "severity": "high"},
            {"type": "reconciliation", "params": {"expression": "SUM(kwh)", "ref_table": f"{cat}.gold.meter_readings_daily",
                                                  "ref_expression": "SUM(kwh_total)", "tolerance_pct": 0.5}, "severity": "high",
             "name": "billed kWh reconciles to daily reads"},
        ],
        "finance.gl_revenue": [
            {"type": "unique", "params": {"columns": ["entry_id"]}, "severity": "critical"},
            {"type": "accepted_values", "column": "account", "params": {"values": ["4000-ENERGY", "4100-STANDING", "4200-OTHER"]}, "severity": "high"},
        ],
        "ot.sensor_timeseries": [
            {"type": "timeseries", "params": {"check": "flatline", "id_column": "sensor_id", "ts_column": "ts", "value_column": "value",
                                              "flatline_s": 6 * 3600, "entity_label": "sensors"}, "severity": "high", "name": "sensor flatline < 6h"},
            {"type": "timeseries", "params": {"check": "spikes", "id_column": "sensor_id", "ts_column": "ts", "value_column": "value",
                                              "spike_z": 12, "entity_label": "sensors"}, "severity": "medium", "name": "sensor spikes"},
            {"type": "timeseries", "params": {"check": "gaps", "id_column": "sensor_id", "ts_column": "ts", "value_column": "value",
                                              "expected_interval_s": 300, "tolerance": 3, "entity_label": "sensors"}, "severity": "medium", "name": "sensor data gaps"},
            {"type": "timeseries", "params": {"check": "bounds", "id_column": "sensor_id", "ts_column": "ts", "value_column": "value",
                                              "min": -40, "max": 150, "entity_label": "sensors"}, "severity": "high", "name": "temperature within physical bounds"},
        ],
    }


def seed_history(db, asset: Asset, current_rows: int, factor: float, shift_days: int = 0) -> None:
    rng = random.Random(asset.id)
    now = utcnow()
    season_now = 1.03 if now.weekday() < 5 else 0.96
    for d in range(28, 0, -1):
        t = now - timedelta(days=d)
        season = 1.03 if t.weekday() < 5 else 0.96
        f = factor if not shift_days or d <= shift_days else factor * 0.7   # planted level shift in the last days
        db.add(MetricPoint(asset_id=asset.id, metric="row_count", ts=t,
                           value=round(current_rows * f * season / season_now * (1 + rng.uniform(-0.01, 0.01)))))
        db.add(MetricPoint(asset_id=asset.id, metric="dq_score", ts=t, value=round(min(100, 96 + rng.uniform(-2, 3)), 1)))


def seed_null_history(db, asset: Asset, column: str, base: float) -> None:
    rng = random.Random(asset.id * 7)
    now = utcnow()
    for d in range(28, 0, -1):
        db.add(MetricPoint(asset_id=asset.id, metric="null_rate", column=column, ts=now - timedelta(days=d),
                           value=round(max(0.0, base * (1 + rng.uniform(-0.3, 0.3))), 6)))


def seed_past(db, assets: dict[str, Asset]) -> None:
    """30 days of history so Insights has patterns: Monday load failures, sensor faults, feedback."""
    from ..models import CheckResult, Feedback, Incident, IncidentEvent, Run
    now = utcnow().replace(minute=0, second=0, microsecond=0)
    rng = random.Random(3)

    def rule_of(key, rtype):
        return next((r for r in db.scalars(select(Rule).where(Rule.asset_id == assets[key].id, Rule.type == rtype))), None)

    plan = []
    for back in range(3, 31):
        day = now - timedelta(days=back)
        if day.weekday() == 0:                                    # Mondays: AMI load is late
            plan.append(("bronze.ami_raw", "freshness", day.replace(hour=6), "Late or failed load upstream (freshness breach at the root)",
                         ["utility.gold.meter_readings_daily", "utility.gold.billing_mart", "utility.finance.gl_revenue"], 4))
        if back in (5, 12, 19):
            plan.append(("ot.sensor_timeseries", "timeseries", day.replace(hour=2), "Sensor / extractor problem in the source system", [], 9))
        if back in (9, 23):
            plan.append(("silver.customers", "accepted_values", day.replace(hour=7), "Data defect in the root asset",
                         ["utility.gold.billing_mart"], 26))
        if back == 16:
            plan.append(("finance.gl_revenue", "unique", day.replace(hour=6), "Duplicate load or broken merge key", [], 6))
    for key, rtype, at, hyp, down, hours in plan:
        a, r = assets[key], rule_of(key, rtype)
        if not r:
            continue
        run = Run(asset_id=a.id, ts=at, trigger="schedule", duration_s=round(rng.uniform(0.2, 2.0), 2), checks=1, failed=1)
        db.add(run)
        db.flush()
        db.add(CheckResult(run_id=run.id, rule_id=r.id, asset_id=a.id, ts=at, status="fail", total=1, failed=1, pass_rate=0.0,
                           message=f"historical failure of {r.name}"))
        for h in (1, 2):
            db.add(CheckResult(run_id=run.id, rule_id=r.id, asset_id=a.id, ts=at + timedelta(hours=hours + h), status="pass",
                               total=1, failed=0, pass_rate=1.0, message="passing again"))
        inc = Incident(key=f"{a.fqn}|{at.date().isoformat()}", title=f"{a.fqn}: {r.name}", status="resolved", severity=r.severity,
                       root_fqn=a.fqn, assets=[a.fqn], rule_ids=[r.id], downstream=down, summary=hyp, assignee=a.owner,
                       rca={"root": a.fqn, "hypothesis": hyp, "evidence": [], "downstream": down, "narrative": hyp},
                       created=at, updated=at + timedelta(hours=hours), resolved_at=at + timedelta(hours=hours))
        db.add(inc)
        db.flush()
        db.add(IncidentEvent(incident_id=inc.id, ts=at, kind="opened", text=r.name))
        db.add(IncidentEvent(incident_id=inc.id, ts=at + timedelta(hours=hours), kind="auto_resolved", text="All checks passing again"))
    gold = rule_of("gold.meter_readings_daily", "anomaly")
    kwh = next((r for r in db.scalars(select(Rule).where(Rule.asset_id == assets["bronze.ami_raw"].id, Rule.type == "not_null"))), None)
    fresh = rule_of("bronze.ami_raw", "freshness")
    for rule, verdict, effect, back in ((gold, "false_positive", "sensitivity 3.0 -> 3.5", 20), (gold, "false_positive", "sensitivity 3.5 -> 4.0", 13),
                                        (kwh, "true_positive", "recorded", 8), (fresh, "true_positive", "recorded", 7),
                                        (fresh, "true_positive", "recorded", 14), (gold, "expected_change", "baseline reset", 10)):
        if rule:
            db.add(Feedback(rule_id=rule.id, verdict=verdict, actor="grid-analytics@utility.example", effect=effect,
                            ts=now - timedelta(days=back)))
    if gold:
        gold.fp_count = 2
    for r, n in ((kwh, 1), (fresh, 2)):
        if r:
            r.tp_count = n


DEMO_CONNECTION = {"name": "demo", "type": "duckdb", "path": "data/utility.duckdb", "catalogs": ["utility"]}


def run(settings: Settings, verbose: bool = True, showcase: bool = True, additive: bool = False, rebootstrap: bool = True) -> dict:
    """Build the demo warehouse and seed the app database.

    additive=False (the `demo` command): recreates the app database from scratch.
    additive=True  (`demo --add`, Settings > Maintenance > Load demo data): keeps everything already in the app
    database and adds the demo connection and its datasets next to it. Only the demo datasets are touched.
    """
    log = print if verbose else (lambda *a, **k: None)
    if additive:  # always the demo's own connection and file, never a DuckDB connection that is yours
        conn_cfg = dict(DEMO_CONNECTION)
    else:
        conn_cfg = next((c for c in settings.data.get("connections", []) if c["type"] == "duckdb"), None)
        if conn_cfg is None:
            raise StopIteration("config has no duckdb connection; use `demo --add`, or --config config.demo.yaml")
    conn_name = conn_cfg["name"]
    wh = settings.abspath(conn_cfg["path"])
    cat = wh.stem
    if additive:  # refuse before touching the warehouse file: a loaded demo has it open
        if rebootstrap:
            S.bootstrap(settings)
        with session_scope() as db:
            if db.scalars(select(Asset).where(Asset.connection == conn_name).limit(1)).first():
                raise ValueError("The demo data is already loaded. Delete the 'demo' connection (Settings > Connections) first to load it again.")
    log(f"Building demo warehouse at {wh}")
    build_warehouse(wh)

    url = settings.section("app")["database_url"]
    if additive:
        if rebootstrap:  # a running app keeps its database connection; only the command line starts one
            S.bootstrap(settings)
        with session_scope() as db:
            from ..connectors import build_connector, register
            from ..models import Connection
            row = db.scalars(select(Connection).where(Connection.name == conn_name)).first()
            if row and row.type != "duckdb":
                raise ValueError(f"A connection named '{conn_name}' already exists and is not DuckDB; rename it first")
            cfg = {**conn_cfg, "path": str(wh), "name": conn_name, "type": "duckdb"}
            row = row or Connection(name=conn_name)
            row.type, row.config, row.enabled, row.status = "duckdb", cfg, True, "registered"
            db.add(row)
            register(build_connector(conn_name, "duckdb", cfg))
    else:
        if url.startswith("sqlite:///"):
            db_path = settings.abspath(url[len("sqlite:///"):])
            if db_path.exists():
                db_path.unlink()
        S.bootstrap(settings)
    summary: dict = {}
    with session_scope() as db:
        res = S.sync_catalog(db, conn_name if additive else None)
        log(f"Catalog: {res['assets']} datasets, lineage +{res['lineage']['added']} edges")
        assets = {a.fqn.split(".", 1)[1]: a for a in db.scalars(select(Asset).where(Asset.connection == conn_name))}
        if additive and any(r for r in db.scalars(select(Rule).where(Rule.asset_id.in_([a.id for a in assets.values()])).limit(1))):
            raise ValueError("The demo data is already loaded. Delete the 'demo' connection (Settings > Connections) first to load it again.")
        for key, (domain, owner, steward, cert, desc) in META.items():
            a = assets[key]
            a.domain, a.owner, a.steward, a.certified, a.description = domain, owner, steward, cert, desc
            a.domain_locked = True
        for name, definition, domain, syn, refs in GLOSSARY:
            if db.scalars(select(GlossaryTerm).where(GlossaryTerm.name == name)).first():
                continue  # already there (loading the demo next to existing data)
            t = GlossaryTerm(name=name, definition=definition, domain=domain, synonyms=syn, owner=None)
            db.add(t)
            db.flush()
            for r in refs:
                db.add(GlossaryLink(term_id=t.id, target_type="asset", target_ref=f"{cat}.{r}"))
        counts = {k: a for k, a in assets.items()}
        from ..connectors import get_connector
        conn = get_connector(assets["bronze.ami_raw"].connection)
        for key, a in counts.items():
            n = conn.query(f"SELECT COUNT(*) AS n FROM {a.fqn}")[0]["n"]
            seed_history(db, a, n, 1 / 0.83 if key == "bronze.ami_raw" else 1.0, shift_days=6 if key == "finance.gl_revenue" else 0)
        seed_null_history(db, assets["bronze.ami_raw"], "kwh", 0.0006)
        db.flush()

        for key, rules in explicit_rules(cat).items():
            for r in rules:
                S.create_rule(db, assets[key], {**r, "source": "manual"}, "demo-seed", status="active")
        log("Explicit rules created")

        activated = proposed = 0
        for key, a in assets.items():
            S.profile_asset(db, a)
            for r in S.suggest_rules(db, a, use_llm=False, actor="demo-seed"):
                try:
                    dr = S.dry_run_rule(db, a, {k: getattr(r, k) for k in ("type", "column", "params", "severity", "threshold", "name")})
                except Exception:
                    dr = {"status": "error"}
                if dr["status"] == "pass" and r.type != "freshness":
                    S.update_rule(db, r, {"status": "active"}, "demo-steward", "accepted after dry run")
                    activated += 1
                else:
                    proposed += 1
        log(f"Suggestions: {activated} activated after a passing dry run, {proposed} left for review")

        order = ["silver.customers", "silver.meters", "bronze.ami_raw", "gold.meter_readings_daily",
                 "gold.billing_mart", "finance.gl_revenue", "ot.sensor_timeseries"]
        for key in order:
            r = run_asset(db, assets[key], trigger="demo", allow_autofix=False)
            log(f"  {key:28s} score {r['score']!s:>6}  checks {r['checks']:>2}  failed {r['failed']}")
        seed_past(db, assets)

        bm = assets["gold.billing_mart"]
        spec = contracts.export_contract(bm, db.scalars(select(Rule).where(Rule.asset_id == bm.id, Rule.status == "active")).all())
        from ..models import Contract
        db.add(Contract(asset_id=bm.id, name=spec["name"], version=spec["version"], spec=spec,
                        last_validation=contracts.validate_against_schema(spec, bm.columns)))
        from .showcase import seed_showcase
        if showcase:  # the extra screens' data: approvals, schedules, run history, corrections, quarantine, metrics...
            seed_showcase(db, assets, cat, log)
        from ..models import Incident
        demo_fqns = {a.fqn for a in assets.values()}
        incs = [i for i in db.scalars(select(Incident)) if i.status != "resolved" and i.root_fqn in demo_fqns]
        summary = {"assets": len(assets), "incidents": [(i.id, i.severity, i.title) for i in incs]}
        log("Open incidents (plus 30 days of resolved history for Insights):")
        for i in incs:
            log(f"  #{i.id} [{i.severity}] {i.title}  (root {i.root_fqn}, {len(i.assets)} assets)")
    return summary
