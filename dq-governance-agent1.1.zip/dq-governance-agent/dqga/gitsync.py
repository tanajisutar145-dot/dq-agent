"""Optional GitHub sync for rule files (see rulefiles.py). Off unless `features: git_sync: true` and a repository is configured.

Uses the GitHub REST API over HTTPS (no git program and no clone). Export writes the rule files in one commit:
  mode "pr"      a new branch from the base branch and a pull request (the default)
  mode "commit"  a commit straight onto the base branch (never forced)
Existing files in the repository are only added to or updated, never deleted.

The access token is stored encrypted (secretbox.py) and never returned by the API.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from urllib.parse import urlparse

import httpx

from . import rulefiles as RF
from . import secretbox
from .models import AppSetting, audit, utcnow

KEY = "git_sync"
DEFAULT_API = "https://api.github.com"
MODES = ("pr", "commit")
_transport: httpx.BaseTransport | None = None  # tests put a fake GitHub here


class GitError(ValueError):
    """Something the person can act on (bad token, no access, repository not found)."""


# ----------------------------------------------------------------------------------------------------------- settings
def parse_repo(text: str) -> tuple[str, str]:
    t = (text or "").strip()
    m = re.match(r"^(?:https?://[^/]+/|git@[^:]+:)?([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+?)(?:\.git)?/?$", t)
    if not m:
        raise GitError("Give the repository as owner/name or its GitHub URL, e.g. my-org/data-rules")
    return m.group(1), m.group(2)


def _safe_folder(folder: str) -> str:
    f = (folder or "dq-rules").strip().strip("/")
    if not re.match(r"^[A-Za-z0-9_./-]+$", f) or ".." in f.split("/"):
        raise GitError("The rules folder may contain letters, digits, - _ . and /, and must stay inside the repository")
    return f


def _clean_api(url: str | None) -> str:
    u = (url or DEFAULT_API).strip().rstrip("/")
    p = urlparse(u)
    if p.scheme != "https" or not p.netloc:
        raise GitError("The API address must start with https:// (GitHub Enterprise: https://HOST/api/v3)")
    return u


def get(db) -> dict:
    row = db.get(AppSetting, KEY)
    return dict(row.value) if row and row.value else {}


def view(db) -> dict:
    """The saved settings without the token."""
    c = get(db)
    return {"configured": bool(c.get("repo")), "repo": c.get("repo"), "branch": c.get("branch", "main"), "folder": c.get("folder", "dq-rules"),
            "mode": c.get("mode", "pr"), "api_url": c.get("api_url", DEFAULT_API), "token_set": bool(secretbox.decrypt(c.get("token"))) if c.get("token") else False,
            "last": c.get("last")}


def save(db, body: dict, actor: str) -> dict:
    cur = get(db)
    owner, repo = parse_repo(body.get("repo") or cur.get("repo") or "")
    mode = body.get("mode") or cur.get("mode") or "pr"
    if mode not in MODES:
        raise GitError("Mode must be pr (pull request) or commit")
    branch = (body.get("branch") or cur.get("branch") or "main").strip()
    if not re.match(r"^[A-Za-z0-9_./-]+$", branch):
        raise GitError("That branch name is not valid")
    new = {**cur, "repo": f"{owner}/{repo}", "branch": branch, "folder": _safe_folder(body.get("folder") or cur.get("folder") or "dq-rules"),
           "mode": mode, "api_url": _clean_api(body.get("api_url") or cur.get("api_url"))}
    token = (body.get("token") or "").strip()
    if token:
        new["token"] = secretbox.encrypt(token)
    if not new.get("token"):
        raise GitError("Enter an access token. It needs read and write access to the repository's contents and pull requests")
    _store(db, new, actor)
    audit(db, actor, "git.configured", None, repo=new["repo"], branch=branch, mode=mode, token_changed=bool(token))
    return view(db)


def clear(db, actor: str) -> None:
    row = db.get(AppSetting, KEY)
    if row:
        db.delete(row)
    audit(db, actor, "git.removed", None)


def _store(db, value: dict, actor: str) -> None:
    row = db.get(AppSetting, KEY)
    if row:
        row.value, row.updated, row.updated_by = value, utcnow(), actor
    else:
        db.add(AppSetting(key=KEY, value=value, updated=utcnow(), updated_by=actor))


# ----------------------------------------------------------------------------------------------------------- GitHub calls
class _Hub:
    def __init__(self, cfg: dict):
        token = secretbox.decrypt(cfg.get("token"))
        if not token:
            raise GitError("The saved token cannot be read (the app's secret key changed). Enter the token again in Settings > Git")
        self.owner, self.repo = parse_repo(cfg["repo"])
        self.base = cfg.get("branch", "main")
        self.api = _clean_api(cfg.get("api_url"))
        self.c = httpx.Client(base_url=self.api, timeout=30, transport=_transport, headers={
            "Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "TCS-DataTrustAI"})

    def call(self, method: str, path: str, **kw) -> dict:
        try:
            r = self.c.request(method, f"/repos/{self.owner}/{self.repo}{path}", **kw)
        except httpx.HTTPError as e:
            raise GitError(f"Could not reach GitHub at {self.api}: {type(e).__name__}") from None
        if r.status_code >= 400:
            raise GitError(_explain(r, self.owner, self.repo, self.base))
        return r.json() if r.content else {}

    def close(self):
        self.c.close()


def _explain(r: httpx.Response, owner: str, repo: str, branch: str) -> str:
    try:
        msg = (r.json() or {}).get("message", "")
    except Exception:
        msg = ""
    s = r.status_code
    if s == 401:
        return "GitHub rejected the token (it is wrong, expired or revoked)."
    if s == 403:
        return "GitHub refused the request: the token lacks permission (it needs contents and pull requests access), or the rate limit was hit. " + msg[:120]
    if s == 404:
        return f"GitHub could not find {owner}/{repo} or branch {branch}, or the token cannot see it."
    if s in (409, 422):
        return f"GitHub could not accept the change: {msg[:160]}"
    return f"GitHub returned {s}: {msg[:160]}"


def test(db, actor: str) -> dict:
    cfg = get(db)
    if not cfg.get("repo"):
        raise GitError("No repository is configured")
    hub = _Hub(cfg)
    try:
        info = hub.call("GET", "")
        br = hub.call("GET", f"/branches/{hub.base}")
        perms = info.get("permissions") or {}
        can_push = bool(perms.get("push") or perms.get("admin"))
        detail = (f"Connected to {info.get('full_name')}; branch {hub.base} exists" + ("" if can_push else ". The token can read but not write: export will fail"))
        return {"ok": can_push, "detail": detail, "default_branch": info.get("default_branch"), "can_push": can_push, "private": bool(info.get("private")),
                "head": (br.get("commit") or {}).get("sha", "")[:7]}
    finally:
        hub.close()


# ----------------------------------------------------------------------------------------------------------- export
def export(db, actor: str, asset_ids: list[int] | None = None, include_drafts: bool = False, message: str | None = None) -> dict:
    """Write the rule files to the repository in one commit. Returns what happened; raises GitError for problems."""
    cfg = get(db)
    if not cfg.get("repo"):
        raise GitError("No repository is configured")
    files = RF.export_files(db, asset_ids, include_drafts)
    if not files:
        raise GitError("No rules to export. Only active and disabled rules are exported unless you include drafts.")
    folder = cfg.get("folder", "dq-rules")
    mode = cfg.get("mode", "pr")
    hub = _Hub(cfg)
    try:
        head = hub.call("GET", f"/git/ref/heads/{hub.base}")["object"]["sha"]
        base_commit = hub.call("GET", f"/git/commits/{head}")
        base_tree = base_commit["tree"]["sha"]
        tree = hub.call("POST", "/git/trees", json={"base_tree": base_tree, "tree": [
            {"path": f"{folder}/{p}", "mode": "100644", "type": "blob", "content": t} for p, t in files]})
        if tree["sha"] == base_tree:
            res = {"status": "unchanged", "files": len(files), "detail": "The repository already has these rules. Nothing to commit."}
            _last(db, cfg, actor, res)
            return res
        msg = (message or "").strip() or f"Update DQ rules ({len(files)} dataset{'s' if len(files) != 1 else ''})"
        commit = hub.call("POST", "/git/commits", json={"message": msg, "tree": tree["sha"], "parents": [head]})
        res = {"status": "committed", "files": len(files), "commit": commit["sha"][:7], "mode": mode}
        if mode == "commit":
            hub.call("PATCH", f"/git/refs/heads/{hub.base}", json={"sha": commit["sha"], "force": False})
            res["branch"] = hub.base
            res["url"] = f"https://github.com/{hub.owner}/{hub.repo}/commit/{commit['sha']}" if hub.api == DEFAULT_API else None
        else:
            branch = "datatrustai/rules-" + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            hub.call("POST", "/git/refs", json={"ref": f"refs/heads/{branch}", "sha": commit["sha"]})
            pr = hub.call("POST", "/pulls", json={"title": msg, "head": branch, "base": hub.base, "body": _pr_body(files, actor, include_drafts)})
            res.update({"branch": branch, "url": pr.get("html_url"), "pr_number": pr.get("number")})
        _last(db, cfg, actor, res)
        audit(db, actor, "rules.git_exported", None, repo=cfg["repo"], mode=mode, files=len(files), commit=res["commit"], branch=res.get("branch"))
        return res
    finally:
        hub.close()


def _pr_body(files: list[tuple[str, str]], actor: str, drafts: bool) -> str:
    names = "\n".join(f"- `{p}`" for p, _ in files[:30]) + ("\n- ..." if len(files) > 30 else "")
    return (f"Rule files exported from TCS DataTrustAI by {actor}.\n\n{len(files)} dataset file(s)"
            + (", including saved drafts" if drafts else ", active and disabled rules") + f":\n\n{names}\n\n"
            "Review the changes, then merge. Importing the merged files back creates drafts for review; nothing goes live without approval.")


def _last(db, cfg: dict, actor: str, res: dict) -> None:
    row = db.get(AppSetting, KEY)
    value = dict(row.value)
    value["last"] = {"ts": utcnow().isoformat(timespec="seconds"), "actor": actor, **{k: res.get(k) for k in ("status", "files", "commit", "branch", "url", "mode")}}
    row.value, row.updated = value, utcnow()
