"""Rules as files: one YAML file per dataset, exported from and imported back into the app.

This is the transport-independent part of "rules as code". The same files can be downloaded and uploaded by hand, used by the
command line and in CI, and (later) synced with a git repository.

Format (version 1), one file per dataset, e.g. dq-rules/utility/silver/customers.yaml:

    format: datatrustai-rules/1
    dataset: utility.silver.customers
    rules:
      - key: not_null:email:email-populated      # identity: type, column and name. Renaming a rule makes it a new rule
        name: email populated
        type: not_null
        column: email
        params: {}
        dimension: completeness
        severity: high
        threshold: 0.99
        category: core
        description: ...
        schedule_minutes: 60

Files never hold data values, only names, thresholds and descriptions.

Importing never changes a live rule and never deletes anything. File rules become drafts, which then go through the review queue:
  new                      saved as a draft
  changed, rule is a draft  the draft is updated
  changed, rule is live     saved as a new draft that proposes the change
  unchanged                 nothing happens
Rules that are in the app but not in the file are only reported.
"""
from __future__ import annotations

import io
import json
import re
import zipfile
from typing import Any

import yaml
from sqlalchemy import select

from .dq import rules as R
from .models import Asset, Rule, audit

FORMAT = "datatrustai-rules/1"
FIELDS = ("name", "type", "column", "params", "dimension", "severity", "threshold", "category", "description", "schedule_minutes")
DRAFT = ("proposed", "rejected")


# ----------------------------------------------------------------------------------------------------------- identity
def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")[:80] or "rule"


def rule_key(rule: dict) -> str:
    return f"{rule.get('type')}:{rule.get('column') or '*'}:{slug(rule.get('name'))}"


def _norm(rule: dict) -> dict:
    """The fields that decide whether two rules are the same, in a comparable form."""
    out = {}
    for f in FIELDS:
        v = rule.get(f)
        if f == "threshold":
            v = round(float(v if v is not None else 1.0), 6)
        elif f == "params":
            v = json.loads(json.dumps(v or {}, sort_keys=True, default=str))
        elif f == "schedule_minutes":
            v = int(v) if v else None
        elif f in ("column", "description", "category"):
            v = v or None
        out[f] = v
    return out


def file_path(fqn: str) -> str:
    return "/".join(re.sub(r"[^A-Za-z0-9_.-]+", "_", part) for part in fqn.split(".")) + ".yaml"


# ----------------------------------------------------------------------------------------------------------- export
def to_doc(fqn: str, rules: list[Rule | dict]) -> dict:
    seen: dict[str, int] = {}
    items = []
    for r in rules:
        d = r if isinstance(r, dict) else r.to_dict()
        n = _norm(d)
        key = rule_key(n)
        seen[key] = seen.get(key, 0) + 1
        if seen[key] > 1:
            key = f"{key}-{seen[key]}"
        item = {"key": key, **{k: v for k, v in n.items() if v is not None and v != {}}}
        item.setdefault("params", {})
        items.append(item)
    return {"format": FORMAT, "dataset": fqn, "rules": items}


def dump(doc: dict) -> str:
    return ("# DQ rules for " + doc["dataset"] + ". Edit and import to propose changes; imports become drafts for review.\n"
            + yaml.safe_dump(doc, sort_keys=False, allow_unicode=True, default_flow_style=False, width=120))


def export_files(db, asset_ids: list[int] | None = None, include_drafts: bool = False) -> list[tuple[str, str]]:
    """[(path, yaml text)] for the datasets that have rules to export. Active and disabled rules; drafts only when asked."""
    statuses = ["active", "disabled"] + (["proposed"] if include_drafts else [])
    q = select(Asset).order_by(Asset.fqn)
    if asset_ids:
        q = q.where(Asset.id.in_(asset_ids))
    out = []
    for a in db.scalars(q):
        rs = db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status.in_(statuses)).order_by(Rule.id)).all()
        if rs:
            out.append((file_path(a.fqn), dump(to_doc(a.fqn, rs))))
    return out


def zip_files(files: list[tuple[str, str]]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for path, text in files:
            z.writestr(path, text)
    return buf.getvalue()


# ----------------------------------------------------------------------------------------------------------- parse
class RuleFileError(ValueError):
    pass


def parse(text: str, name: str = "file") -> dict:
    try:
        doc = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise RuleFileError(f"{name}: not valid YAML ({str(e).splitlines()[0]})") from None
    if not isinstance(doc, dict):
        raise RuleFileError(f"{name}: expected a mapping with 'format', 'dataset' and 'rules'")
    fmt = str(doc.get("format") or "")
    if fmt.split("/")[0] != FORMAT.split("/")[0]:
        raise RuleFileError(f"{name}: not a DataTrustAI rule file (format is {fmt!r}, expected {FORMAT})")
    if fmt != FORMAT:
        raise RuleFileError(f"{name}: format {fmt} is not supported by this version (it reads {FORMAT})")
    if not str(doc.get("dataset") or "").strip():
        raise RuleFileError(f"{name}: 'dataset' is missing")
    rules = doc.get("rules")
    if not isinstance(rules, list):
        raise RuleFileError(f"{name}: 'rules' must be a list")
    for i, r in enumerate(rules, 1):
        if not isinstance(r, dict) or not r.get("type"):
            raise RuleFileError(f"{name}: rule {i} needs a 'type'")
    return {"dataset": str(doc["dataset"]).strip(), "rules": rules, "name": name}


def _asset(db, fqn: str) -> Asset | None:
    exact = db.scalars(select(Asset).where(Asset.fqn == fqn)).first()
    if exact:
        return exact
    low = fqn.lower()
    ci = [a for a in db.scalars(select(Asset)) if a.fqn.lower() == low]
    return ci[0] if len(ci) == 1 else None


# ----------------------------------------------------------------------------------------------------------- compare
def plan(db, texts: list[tuple[str, str]]) -> dict:
    """Compare uploaded files with the rules in the app. Nothing is saved."""
    datasets, errors = [], []
    for name, text in texts:
        try:
            doc = parse(text, name)
        except RuleFileError as e:
            errors.append(str(e))
            continue
        a = _asset(db, doc["dataset"])
        if not a:
            errors.append(f"{name}: dataset {doc['dataset']} is not in the catalog (sync the connection first)")
            continue
        existing = db.scalars(select(Rule).where(Rule.asset_id == a.id).order_by(Rule.id)).all()
        by_key: dict[str, list[Rule]] = {}
        for r in existing:
            by_key.setdefault(rule_key(r.to_dict()), []).append(r)
        items, in_file = [], set()
        for raw in doc["rules"]:
            cand = {**raw}
            cand["name"] = cand.get("name") or cand.get("key") or ""
            key = rule_key(_norm({**cand, "name": cand["name"]}))
            if raw.get("key") and str(raw["key"]).strip():
                key = str(raw["key"]).strip()
            in_file.add(key)
            item: dict[str, Any] = {"key": key, "name": cand["name"], "type": raw.get("type"), "column": raw.get("column")}
            try:
                v = R.validate_rule({k: cand.get(k) for k in FIELDS if cand.get(k) is not None}, a.columns or [])
                from .dq.categories import infer
                v["category"] = cand.get("category") or infer(v)  # what saving the rule would store, so an unchanged rule compares equal
            except ValueError as e:
                items.append({**item, "action": "invalid", "detail": str(e)})
                continue
            wanted = _norm(v)
            match = by_key.get(key) or by_key.get(rule_key(wanted)) or []
            same = next((r for r in match if _norm(r.to_dict()) == wanted), None)
            draft = next((r for r in match if r.status in DRAFT), None)
            live = next((r for r in match if r.status not in DRAFT), None)
            if same:
                items.append({**item, "action": "unchanged", "rule_id": same.id, "status": same.status})
            elif draft:
                items.append({**item, "action": "update_draft", "rule_id": draft.id, "changes": _changes(_norm(draft.to_dict()), wanted), "spec": wanted})
            elif live:
                items.append({**item, "action": "propose_change", "rule_id": live.id, "status": live.status,
                              "changes": _changes(_norm(live.to_dict()), wanted), "spec": wanted})
            else:
                items.append({**item, "action": "new", "spec": wanted})
        missing = [{"key": k, "name": rs[0].name, "rule_id": rs[0].id, "status": rs[0].status} for k, rs in by_key.items()
                   if k not in in_file and rs[0].status in ("active", "disabled", "review", "approved")]
        datasets.append({"dataset": a.fqn, "asset_id": a.id, "file": name, "items": items, "not_in_file": missing,
                         "counts": _counts(items)})
    totals = {k: sum(d["counts"].get(k, 0) for d in datasets) for k in ("new", "update_draft", "propose_change", "unchanged", "invalid")}
    totals["datasets"], totals["not_in_file"] = len(datasets), sum(len(d["not_in_file"]) for d in datasets)
    return {"datasets": datasets, "errors": errors, "totals": totals,
            "will_save": totals["new"] + totals["update_draft"] + totals["propose_change"]}


def _counts(items: list[dict]) -> dict:
    out: dict[str, int] = {}
    for i in items:
        out[i["action"]] = out.get(i["action"], 0) + 1
    return out


def _changes(old: dict, new: dict) -> list[dict]:
    return [{"field": f, "from": old[f], "to": new[f]} for f in FIELDS if old[f] != new[f]]


# ----------------------------------------------------------------------------------------------------------- import
def apply(db, texts: list[tuple[str, str]], actor: str) -> dict:
    """Save what plan() found, as drafts. Live rules are never changed and nothing is deleted."""
    from . import services as S
    p = plan(db, texts)
    created, updated = [], []
    for d in p["datasets"]:
        a = db.get(Asset, d["asset_id"])
        for it in d["items"]:
            if it["action"] == "new":
                r = S.create_rule(db, a, {**it["spec"], "source": "file"}, actor, status="proposed")
                created.append(r.id)
            elif it["action"] == "propose_change":
                r = S.create_rule(db, a, {**it["spec"], "source": "file",
                                          "reason": f"Proposed change to rule #{it['rule_id']} from a rule file. Approve this one and disable the old rule."},
                                  actor, status="proposed")
                created.append(r.id)
            elif it["action"] == "update_draft":
                S.update_rule(db, db.get(Rule, it["rule_id"]), {k: it["spec"][k] for k in FIELDS if it["spec"][k] is not None}, actor, "updated from a rule file")
                updated.append(it["rule_id"])
    audit(db, actor, "rules.imported", None, files=len(texts), created=len(created), updated=len(updated), skipped=p["totals"]["invalid"])
    return {"created": created, "updated": updated, "invalid": p["totals"]["invalid"], "unchanged": p["totals"]["unchanged"],
            "errors": p["errors"], "plan": p}


def read_zip(raw: bytes) -> list[tuple[str, str]]:
    out = []
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        for n in sorted(z.namelist()):
            if n.lower().endswith((".yaml", ".yml")) and not n.endswith("/") and ".." not in n:
                out.append((n, z.read(n).decode("utf-8")))
    return out
