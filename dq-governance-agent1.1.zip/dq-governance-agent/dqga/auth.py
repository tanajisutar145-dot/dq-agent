"""Accounts, passwords, sessions and access modes.

Modes (auth.mode):
  local  Built-in accounts: sign-up, sign-in, administrator sign-in, Admin console.
  sso    Trust the identity header from the platform's SSO (Databricks Apps sets
         X-Forwarded-Email). Users are provisioned on first visit; no password screen.
  none   No authentication (tests, single-user demos).

Passwords: PBKDF2-HMAC-SHA256, 600,000 iterations, random 16-byte salt.
Sessions: random 256-bit tokens in an HttpOnly cookie; only their SHA-256 is stored.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets
from datetime import timedelta

from sqlalchemy import func, select

from .config import get_settings
from .models import AuthSession, User, audit, utcnow

ITERATIONS = 600_000
ROLES = ("admin", "steward", "viewer")
STATUSES = ("active", "pending", "disabled")
COOKIE = "dta_session"
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
COMMON = {"password", "password1", "password123", "1234567890", "qwerty1234", "letmein123", "welcome123", "admin12345"}
_DUMMY = None


class AuthError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def cfg() -> dict:
    return get_settings().section("auth")


def mode() -> str:
    return str(cfg().get("mode", "local")).lower()


# ---------------------------------------------------------------- passwords
def hash_password(password: str, iterations: int | None = None) -> str:
    it = iterations or ITERATIONS
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, it)
    return f"pbkdf2_sha256${it}${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str | None) -> bool:
    try:
        algo, it, salt, digest = (stored or "").split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), int(it))
        return hmac.compare_digest(dk.hex(), digest)
    except (ValueError, TypeError):
        return False


def password_problem(password: str, email: str = "", name: str = "") -> str | None:
    n = int(cfg().get("min_password_length", 10))
    if len(password or "") < n:
        return f"Use at least {n} characters."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "Use both letters and numbers."
    low = password.lower()
    local = (email or "").split("@")[0].lower()
    if low in COMMON or (local and len(local) >= 4 and local in low) or (name and name.lower().replace(" ", "") in low):
        return "That password is too easy to guess. Avoid your name, email and common passwords."
    return None


def temporary_password() -> str:
    while True:
        p = secrets.token_urlsafe(12)
        if re.search(r"[A-Za-z]", p) and re.search(r"\d", p):
            return p


def normalize_email(email: str) -> str:
    e = (email or "").strip().lower()
    if not EMAIL_RE.match(e) or len(e) > 320:
        raise AuthError("Enter a valid email address.")
    return e


# ---------------------------------------------------------------- users
def user_count(db) -> int:
    return db.scalar(select(func.count()).select_from(User)) or 0


def active_admins(db, exclude_id: int | None = None) -> int:
    q = select(func.count()).select_from(User).where(User.role == "admin", User.status == "active")
    if exclude_id:
        q = q.where(User.id != exclude_id)
    return db.scalar(q) or 0


def find_user(db, email: str) -> User | None:
    return db.scalars(select(User).where(User.email == email.strip().lower())).first()


def create_user(db, email: str, name: str, password: str | None, role: str = "steward", status: str = "active",
                must_change: bool = False, actor: str = "system", source: str = "local") -> User:
    email = normalize_email(email)
    name = (name or "").strip()[:200] or email.split("@")[0]
    if role not in ROLES:
        raise AuthError(f"Role must be one of {', '.join(ROLES)}.")
    if status not in STATUSES:
        raise AuthError(f"Status must be one of {', '.join(STATUSES)}.")
    if find_user(db, email):
        raise AuthError("An account with this email already exists.", 409)
    if password is not None:
        problem = password_problem(password, email, name)
        if problem:
            raise AuthError(problem)
    u = User(email=email, name=name, password_hash=hash_password(password) if password else None, role=role,
             status=status, must_change_password=must_change, auth_source=source)
    db.add(u)
    db.flush()
    audit(db, actor, "user.created", email, role=role, status=status, source=source)
    return u


def authenticate(db, email: str, password: str) -> User:
    global _DUMMY
    c = cfg()
    u = find_user(db, email or "")
    if u is None or not u.password_hash:
        if _DUMMY is None:
            _DUMMY = hash_password("timing-equalizer-1")
        verify_password(password or "", _DUMMY)  # same cost as a real check
        audit(db, (email or "")[:100], "auth.login_failed", None, reason="unknown account")
        raise AuthError("Incorrect email or password.", 401)
    now = utcnow()
    if u.locked_until and u.locked_until > now:
        mins = max(1, int((u.locked_until - now).total_seconds() // 60) + 1)
        raise AuthError(f"Too many failed attempts. Try again in {mins} minute(s), or ask an administrator.", 429)
    if not verify_password(password or "", u.password_hash):
        u.failed_logins = (u.failed_logins or 0) + 1
        if u.failed_logins >= int(c.get("max_failed_logins", 5)):
            u.locked_until = now + timedelta(minutes=int(c.get("lockout_minutes", 15)))
            u.failed_logins = 0
            audit(db, u.email, "auth.locked", u.email)
        audit(db, u.email, "auth.login_failed", u.email, reason="wrong password")
        raise AuthError("Incorrect email or password.", 401)
    if u.status == "pending":
        raise AuthError("Your account is waiting for administrator approval.", 403)
    if u.status == "disabled":
        raise AuthError("This account is disabled. Contact an administrator.", 403)
    u.failed_logins, u.locked_until, u.last_login = 0, None, now
    return u


def change_password(db, u: User, current: str, new: str) -> None:
    if not verify_password(current or "", u.password_hash):
        raise AuthError("Your current password is incorrect.", 400)
    if current == new:
        raise AuthError("Choose a password you haven't used here.")
    problem = password_problem(new, u.email, u.name)
    if problem:
        raise AuthError(problem)
    u.password_hash, u.must_change_password = hash_password(new), False
    audit(db, u.email, "auth.password_changed", u.email)


# ---------------------------------------------------------------- sessions
def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_session(db, u: User, ip: str | None = None, user_agent: str | None = None) -> str:
    token = secrets.token_urlsafe(32)
    hours = float(cfg().get("session_hours", 12))
    db.add(AuthSession(token_hash=_token_hash(token), user_id=u.id, expires=utcnow() + timedelta(hours=hours),
                       ip=(ip or "")[:64], user_agent=(user_agent or "")[:300]))
    db.flush()
    return token


def session_user(db, token: str | None) -> User | None:
    if not token:
        return None
    s = db.scalars(select(AuthSession).where(AuthSession.token_hash == _token_hash(token))).first()
    now = utcnow()
    if not s or s.expires < now:
        return None
    u = db.get(User, s.user_id)
    if not u or u.status != "active":
        return None
    if (now - s.last_seen).total_seconds() > 300:
        s.last_seen = now
    return u


def revoke_session(db, token: str | None) -> None:
    if token:
        for s in db.scalars(select(AuthSession).where(AuthSession.token_hash == _token_hash(token))):
            db.delete(s)


def revoke_user_sessions(db, user_id: int) -> int:
    rows = db.scalars(select(AuthSession).where(AuthSession.user_id == user_id)).all()
    for s in rows:
        db.delete(s)
    return len(rows)


def active_sessions(db) -> int:
    return db.scalar(select(func.count()).select_from(AuthSession).where(AuthSession.expires > utcnow())) or 0


# ---------------------------------------------------------------- SSO and bootstrap
def sso_user(db, email: str, name: str | None = None) -> User:
    email = normalize_email(email)
    u = find_user(db, email)
    if u:
        u.last_login = utcnow()
        return u
    admins = [a.lower() for a in (cfg().get("admins") or [])]
    role = "admin" if (email in admins or active_admins(db) == 0) else cfg().get("default_role", "steward")
    u = create_user(db, email, name or email.split("@")[0], None, role=role, status="active", source="sso")
    u.last_login = utcnow()
    return u


def bootstrap_admin_from_env(db) -> str | None:
    """Create an administrator from DQGA_ADMIN_EMAIL / DQGA_ADMIN_PASSWORD (headless installs)."""
    email, password = os.environ.get("DQGA_ADMIN_EMAIL"), os.environ.get("DQGA_ADMIN_PASSWORD")
    if not email or not password or find_user(db, email):
        return None
    create_user(db, email, os.environ.get("DQGA_ADMIN_NAME", "Administrator"), password, role="admin",
                actor="bootstrap")
    return email


def public_config(db) -> dict:
    c = cfg()
    return {"mode": mode(), "signup": c.get("signup", "approval"), "needs_setup": mode() == "local" and user_count(db) == 0,
            "min_password_length": int(c.get("min_password_length", 10)), "default_role": c.get("default_role", "steward")}
