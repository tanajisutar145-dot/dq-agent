"""Persistence model for runs, results, incidents, governance and audit.

SQLite by default; any SQLAlchemy URL (Postgres recommended in production) works.
All timestamps are naive UTC.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Integer, LargeBinary, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    def to_dict(self) -> dict[str, Any]:
        out = {}
        for col in self.__table__.columns:
            v = getattr(self, col.name)
            out[col.name] = v.isoformat() if isinstance(v, datetime) else v
        return out


class Connection(Base):
    __tablename__ = "connections"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)
    type: Mapped[str] = mapped_column(String(40))
    config: Mapped[dict] = mapped_column(JSON, default=dict)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_sync: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str | None] = mapped_column(String(200), nullable=True)
    # Last connection test and last sync outcome, kept so the Settings page can show them after a reload.
    last_test_ok: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    last_test_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_test_detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_sync_error: Mapped[str | None] = mapped_column(Text, nullable=True)


class Asset(Base):
    __tablename__ = "assets"
    __table_args__ = (UniqueConstraint("connection", "fqn"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    connection: Mapped[str] = mapped_column(String(100))
    platform: Mapped[str] = mapped_column(String(40))
    fqn: Mapped[str] = mapped_column(String(400), index=True)
    kind: Mapped[str] = mapped_column(String(40), default="table")
    domain: Mapped[str | None] = mapped_column(String(100), nullable=True)
    domain_locked: Mapped[bool | None] = mapped_column(Boolean, nullable=True)  # typed by a person: sync keeps it
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    owner: Mapped[str | None] = mapped_column(String(200), nullable=True)
    steward: Mapped[str | None] = mapped_column(String(200), nullable=True)
    certified: Mapped[bool] = mapped_column(Boolean, default=False)
    tags: Mapped[dict] = mapped_column(JSON, default=dict)
    columns: Mapped[list] = mapped_column(JSON, default=list)
    row_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    score: Mapped[float | None] = mapped_column(Float, nullable=True)
    dimension_scores: Mapped[dict] = mapped_column(JSON, default=dict)
    change_marker: Mapped[str | None] = mapped_column(String(200), nullable=True)
    last_checked_marker: Mapped[str | None] = mapped_column(String(200), nullable=True)
    last_profiled: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_run: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Profile(Base):
    __tablename__ = "profiles"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    data: Mapped[dict] = mapped_column(JSON, default=dict)


class Rule(Base):
    __tablename__ = "rules"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), index=True)
    name: Mapped[str] = mapped_column(String(300))
    type: Mapped[str] = mapped_column(String(40))
    column: Mapped[str | None] = mapped_column(String(200), nullable=True)
    params: Mapped[dict] = mapped_column(JSON, default=dict)
    dimension: Mapped[str] = mapped_column(String(40))
    severity: Mapped[str] = mapped_column(String(20), default="medium")
    threshold: Mapped[float] = mapped_column(Float, default=1.0)
    # proposed = saved draft | review = sent for approval | approved = approved, not live yet | rejected | active | disabled
    status: Mapped[str] = mapped_column(String(20), default="proposed")
    source: Mapped[str] = mapped_column(String(30), default="manual")  # manual|suggested|nl|contract|llm
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    schedule_minutes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    est_cost_s: Mapped[float] = mapped_column(Float, default=1.0)
    fp_count: Mapped[int] = mapped_column(Integer, default=0)
    tp_count: Mapped[int] = mapped_column(Integer, default=0)
    last_run: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_status: Mapped[str | None] = mapped_column(String(20), nullable=True)
    created: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    # core (nulls, types, formats, keys) | business (domain rules) | governance (privacy, security, regulatory)
    category: Mapped[str | None] = mapped_column(String(20), nullable=True)
    submitted_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    submitted_ts: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    submit_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    decided_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    decided_ts: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    decision_note: Mapped[str | None] = mapped_column(Text, nullable=True)


class RuleHistory(Base):
    __tablename__ = "rule_history"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rule_id: Mapped[int] = mapped_column(Integer, index=True)
    version: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    changed_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    change: Mapped[str | None] = mapped_column(String(300), nullable=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Run(Base):
    __tablename__ = "runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(Integer, index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    trigger: Mapped[str] = mapped_column(String(30), default="manual")
    duration_s: Mapped[float] = mapped_column(Float, default=0.0)
    status: Mapped[str] = mapped_column(String(20), default="ok")
    checks: Mapped[int] = mapped_column(Integer, default=0)
    failed: Mapped[int] = mapped_column(Integer, default=0)
    schedule_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)  # set when a rule schedule started it
    actor: Mapped[str | None] = mapped_column(String(100), nullable=True)
    errors: Mapped[int | None] = mapped_column(Integer, nullable=True)


class RuleSchedule(Base):
    """Run a set of active rules on a cadence: every N minutes, or at a time of day on chosen weekdays (UTC).

    scope: {"category": core|business|governance|None, "severity": minimum severity or None,
            "asset_ids": [..] or [], "platform": connection type or None, "rule_ids": [..] or []}
    """
    __tablename__ = "rule_schedules"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    scope: Mapped[dict] = mapped_column(JSON, default=dict)
    cadence: Mapped[str] = mapped_column(String(20), default="interval")  # interval | daily
    every_minutes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    at_time: Mapped[str | None] = mapped_column(String(5), nullable=True)  # "HH:MM" UTC for daily
    weekdays: Mapped[list] = mapped_column(JSON, default=list)  # 0=Mon..6=Sun; empty = every day
    next_run: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_run: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_status: Mapped[str | None] = mapped_column(String(20), nullable=True)  # ok | failures | error | empty
    last_summary: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    created: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class CheckResult(Base):
    __tablename__ = "check_results"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(Integer, index=True)
    rule_id: Mapped[int] = mapped_column(Integer, index=True)
    asset_id: Mapped[int] = mapped_column(Integer, index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    status: Mapped[str] = mapped_column(String(20))  # pass|fail|warn|error
    total: Mapped[int] = mapped_column(Integer, default=0)
    failed: Mapped[int] = mapped_column(Integer, default=0)
    pass_rate: Mapped[float] = mapped_column(Float, default=1.0)
    observed: Mapped[dict] = mapped_column(JSON, default=dict)
    message: Mapped[str | None] = mapped_column(Text, nullable=True)
    failing_sql: Mapped[str | None] = mapped_column(Text, nullable=True)
    duration_s: Mapped[float] = mapped_column(Float, default=0.0)


class MetricPoint(Base):
    __tablename__ = "metric_points"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(Integer, index=True)
    metric: Mapped[str] = mapped_column(String(60), index=True)
    column: Mapped[str | None] = mapped_column(String(200), nullable=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    value: Mapped[float] = mapped_column(Float)


class LineageEdge(Base):
    __tablename__ = "lineage_edges"
    __table_args__ = (UniqueConstraint("source", "target", "source_column", "target_column"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(400), index=True)
    target: Mapped[str] = mapped_column(String(400), index=True)
    source_column: Mapped[str] = mapped_column(String(200), default="")
    target_column: Mapped[str] = mapped_column(String(200), default="")
    origin: Mapped[str] = mapped_column(String(60), default="manual")
    updated: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Incident(Base):
    __tablename__ = "incidents"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    key: Mapped[str] = mapped_column(String(500), index=True)
    title: Mapped[str] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(20), default="open")  # open|ack|resolved|muted
    severity: Mapped[str] = mapped_column(String(20), default="medium")
    root_fqn: Mapped[str] = mapped_column(String(400))
    assets: Mapped[list] = mapped_column(JSON, default=list)
    rule_ids: Mapped[list] = mapped_column(JSON, default=list)
    downstream: Mapped[list] = mapped_column(JSON, default=list)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    rca: Mapped[dict] = mapped_column(JSON, default=dict)
    assignee: Mapped[str | None] = mapped_column(String(200), nullable=True)
    ticket: Mapped[dict] = mapped_column(JSON, default=dict)
    created: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class IncidentEvent(Base):
    __tablename__ = "incident_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    incident_id: Mapped[int] = mapped_column(Integer, index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    actor: Mapped[str] = mapped_column(String(100), default="system")
    kind: Mapped[str] = mapped_column(String(40))
    text: Mapped[str] = mapped_column(Text)


class Approval(Base):
    __tablename__ = "approvals"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    kind: Mapped[str] = mapped_column(String(40))
    title: Mapped[str] = mapped_column(String(500))
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending|approved|rejected|failed
    requested_by: Mapped[str] = mapped_column(String(100), default="agent")
    decided_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    result: Mapped[dict] = mapped_column(JSON, default=dict)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    decided_ts: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class Classification(Base):
    __tablename__ = "classifications"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(Integer, index=True)
    column: Mapped[str] = mapped_column(String(200))
    label: Mapped[str] = mapped_column(String(60))
    sensitivity: Mapped[str] = mapped_column(String(30))
    confidence: Mapped[float] = mapped_column(Float)
    method: Mapped[str] = mapped_column(String(60))
    status: Mapped[str] = mapped_column(String(20), default="suggested")  # suggested|confirmed|rejected
    applied: Mapped[bool] = mapped_column(Boolean, default=False)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Contract(Base):
    __tablename__ = "contracts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    name: Mapped[str] = mapped_column(String(300))
    version: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(30), default="active")
    spec: Mapped[dict] = mapped_column(JSON, default=dict)
    last_validation: Mapped[dict] = mapped_column(JSON, default=dict)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Policy(Base):
    __tablename__ = "policies"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    key: Mapped[str] = mapped_column(String(100), unique=True)
    type: Mapped[str] = mapped_column(String(40))
    spec: Mapped[dict] = mapped_column(JSON, default=dict)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    source: Mapped[str | None] = mapped_column(String(30), nullable=True)  # file | manual | nl | suggested | standard | upload
    updated_by: Mapped[str | None] = mapped_column(String(100), nullable=True)


class PolicyScan(Base):
    """One evaluation of every enabled policy, kept so violations can be tracked over time (new, resolved, trend)."""
    __tablename__ = "policy_scans"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    trigger: Mapped[str] = mapped_column(String(20), default="manual")  # manual | schedule
    actor: Mapped[str | None] = mapped_column(String(100), nullable=True)
    duration_s: Mapped[float] = mapped_column(Float, default=0.0)
    total: Mapped[int] = mapped_column(Integer, default=0)
    new_count: Mapped[int] = mapped_column(Integer, default=0)
    resolved_count: Mapped[int] = mapped_column(Integer, default=0)
    policies: Mapped[int] = mapped_column(Integer, default=0)
    datasets: Mapped[int] = mapped_column(Integer, default=0)
    by_severity: Mapped[dict] = mapped_column(JSON, default=dict)
    by_policy: Mapped[dict] = mapped_column(JSON, default=dict)
    violations: Mapped[list] = mapped_column(JSON, default=list)


class GlossaryTerm(Base):
    __tablename__ = "glossary_terms"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), unique=True)
    definition: Mapped[str] = mapped_column(Text, default="")
    domain: Mapped[str | None] = mapped_column(String(100), nullable=True)
    owner: Mapped[str | None] = mapped_column(String(200), nullable=True)
    synonyms: Mapped[list] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String(20), default="approved")


class GlossaryLink(Base):
    __tablename__ = "glossary_links"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    term_id: Mapped[int] = mapped_column(Integer, index=True)
    target_type: Mapped[str] = mapped_column(String(20))  # asset|column|rule
    target_ref: Mapped[str] = mapped_column(String(500))


class Feedback(Base):
    __tablename__ = "feedback"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rule_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    incident_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    verdict: Mapped[str] = mapped_column(String(30))  # false_positive|true_positive|expected_change
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    actor: Mapped[str] = mapped_column(String(100), default="steward")
    effect: Mapped[str | None] = mapped_column(Text, nullable=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Notification(Base):
    __tablename__ = "notifications"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    channel: Mapped[str] = mapped_column(String(30))
    title: Mapped[str] = mapped_column(String(500))
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(40))
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    actor: Mapped[str] = mapped_column(String(100))
    action: Mapped[str] = mapped_column(String(100))
    target: Mapped[str | None] = mapped_column(String(400), nullable=True)
    detail: Mapped[dict] = mapped_column(JSON, default=dict)


class ChatMessage(Base):
    __tablename__ = "chat_messages"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    session_id: Mapped[str] = mapped_column(String(100), index=True)
    role: Mapped[str] = mapped_column(String(20))
    content: Mapped[dict] = mapped_column(JSON, default=dict)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class FixRun(Base):
    """An applied data correction, with what's needed to undo it."""
    __tablename__ = "fix_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(Integer, index=True)
    rule_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    incident_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    kind: Mapped[str] = mapped_column(String(40))
    title: Mapped[str] = mapped_column(String(500))
    risk: Mapped[str] = mapped_column(String(20))
    rows: Mapped[int] = mapped_column(Integer, default=0)
    statements: Mapped[list] = mapped_column(JSON, default=list)
    snapshot: Mapped[str | None] = mapped_column(String(400), nullable=True)  # snapshot table, or "delta_version:<n>"
    marker_after: Mapped[str | None] = mapped_column(String(200), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="applied")  # applied|undone|failed
    auto: Mapped[bool] = mapped_column(Boolean, default=False)
    actor: Mapped[str] = mapped_column(String(100), default="system")
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    undone_ts: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class QuarantineBatch(Base):
    """Rows set aside by one quarantine action."""
    __tablename__ = "quarantine_batches"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    batch_key: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    asset_id: Mapped[int] = mapped_column(Integer, index=True)
    rule_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    incident_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    mode: Mapped[str] = mapped_column(String(10))  # move|copy|split
    target_table: Mapped[str] = mapped_column(String(400))
    clean_table: Mapped[str | None] = mapped_column(String(400), nullable=True)
    condition: Mapped[str] = mapped_column(Text)
    rows: Mapped[int] = mapped_column(Integer, default=0)
    released: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(20), default="quarantined")  # quarantined|partially_released|released|purged
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    actor: Mapped[str] = mapped_column(String(100), default="system")
    created: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    history: Mapped[list] = mapped_column(JSON, default=list)


class ReferenceDoc(Base):
    """An uploaded reference file (model, ontology, glossary, master data, policy...) that AI Rule Studio uses as context."""
    __tablename__ = "reference_docs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(300))
    kind: Mapped[str] = mapped_column(String(30))  # see reference.KINDS
    domain: Mapped[str | None] = mapped_column(String(100), nullable=True)  # business domain it applies to; None = all
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    content_type: Mapped[str | None] = mapped_column(String(100), nullable=True)
    size: Mapped[int] = mapped_column(Integer, default=0)
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    content: Mapped[bytes] = mapped_column(LargeBinary, deferred=True)
    text: Mapped[str | None] = mapped_column(Text, nullable=True, deferred=True)  # extracted text for model context
    summary: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="parsed")  # parsed|stored|error
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)  # used by AI Rule Studio unless deselected
    uploaded_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    created: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    def public(self) -> dict[str, Any]:
        return {k: (v.isoformat() if isinstance(v, datetime) else v) for k, v in (
            ("id", self.id), ("name", self.name), ("kind", self.kind), ("domain", self.domain),
            ("description", self.description), ("content_type", self.content_type), ("size", self.size),
            ("sha256", self.sha256), ("summary", self.summary or {}), ("status", self.status), ("error", self.error),
            ("enabled", self.enabled), ("uploaded_by", self.uploaded_by), ("created", self.created))}


class ReferenceFact(Base):
    """One thing a reference file says about a table or column (not null, allowed values, pattern, term...)."""
    __tablename__ = "reference_facts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    doc_id: Mapped[int] = mapped_column(Integer, index=True)
    table_key: Mapped[str] = mapped_column(String(300), default="", index=True)  # normalized; "" = any table
    column_key: Mapped[str] = mapped_column(String(200), default="", index=True)  # normalized; "" = table level
    table: Mapped[str | None] = mapped_column(String(300), nullable=True)
    column: Mapped[str | None] = mapped_column(String(200), nullable=True)
    kind: Mapped[str] = mapped_column(String(30))
    value: Mapped[Any] = mapped_column(JSON, nullable=True)
    text: Mapped[str | None] = mapped_column(Text, nullable=True)


class CustomMetric(Base):
    """A user-defined DQ metric shown as a tile on the Overview page."""
    __tablename__ = "custom_metrics"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    measure: Mapped[str] = mapped_column(String(40))  # key in dq.custom_metrics.MEASURES
    params: Mapped[dict] = mapped_column(JSON, default=dict)  # filters, or connection + sql
    unit: Mapped[str | None] = mapped_column(String(20), nullable=True)
    direction: Mapped[str] = mapped_column(String(10), default="higher")  # higher|lower is better
    target: Mapped[float | None] = mapped_column(Float, nullable=True)
    warn_at: Mapped[float | None] = mapped_column(Float, nullable=True)
    show_on_overview: Mapped[bool] = mapped_column(Boolean, default=True)
    position: Mapped[int] = mapped_column(Integer, default=0)
    last_value: Mapped[float | None] = mapped_column(Float, nullable=True)
    last_evaluated: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    created: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class CustomMetricValue(Base):
    __tablename__ = "custom_metric_values"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    metric_id: Mapped[int] = mapped_column(Integer, index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    value: Mapped[float] = mapped_column(Float)


class AppSetting(Base):
    """Settings changed in the app (for example the LLM). Secrets inside are encrypted (see secretbox.py)."""
    __tablename__ = "app_settings"
    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON, default=dict)
    updated: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_by: Mapped[str | None] = mapped_column(String(100), nullable=True)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    password_hash: Mapped[str | None] = mapped_column(String(300), nullable=True)  # None for SSO-only users
    role: Mapped[str] = mapped_column(String(20), default="steward")  # admin|steward|viewer
    status: Mapped[str] = mapped_column(String(20), default="active")  # active|pending|disabled
    must_change_password: Mapped[bool] = mapped_column(Boolean, default=False)
    failed_logins: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    auth_source: Mapped[str] = mapped_column(String(20), default="local")  # local|sso
    created: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_login: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    def public(self) -> dict[str, Any]:
        return {"id": self.id, "email": self.email, "name": self.name, "role": self.role, "status": self.status,
                "must_change_password": self.must_change_password, "auth_source": self.auth_source,
                "created": self.created.isoformat() if self.created else None,
                "last_login": self.last_login.isoformat() if self.last_login else None,
                "locked": bool(self.locked_until and self.locked_until > utcnow())}


class AuthSession(Base):
    __tablename__ = "auth_sessions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    user_id: Mapped[int] = mapped_column(Integer, index=True)
    created: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires: Mapped[datetime] = mapped_column(DateTime)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(300), nullable=True)


def audit(db, actor: str, action: str, target: str | None = None, **detail: Any) -> None:
    db.add(AuditLog(actor=actor or "system", action=action, target=target, detail=detail))
