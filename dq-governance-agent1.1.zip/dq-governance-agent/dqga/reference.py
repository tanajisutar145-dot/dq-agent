"""Reference library: files that describe what the data should look like.

People upload models (SQL DDL, ontology / SHACL .ttl, XSD, UML), business
glossaries, master / reference data and business or policy documents. Each file
is parsed once into *facts* about tables and columns, for example "asset_tag is
mandatory", "capacity_unit is one of MW|MVA|kV", "email is personal data" or
"invoices must be retained for 7 years". AI Rule Studio turns the facts that match
a dataset into rule proposals, and sends a compact summary of them to the LLM
as context when one is configured.

No third-party parsers are needed: Turtle, SQL, XML (XSD, XMI), PlantUML, CSV,
JSON, Word (.docx) and text are read here; Excel uses openpyxl; PDF text is
extracted only when the optional pypdf package is installed.
"""
from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import re
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable
from xml.etree import ElementTree as ET

from sqlalchemy import delete, or_, select

from .models import Asset, ReferenceDoc, ReferenceFact, utcnow

KINDS: dict[str, dict] = {
    "sql_model": {"label": "SQL model (DDL)", "ext": [".sql", ".ddl"],
                  "help": "CREATE TABLE / ALTER TABLE: NOT NULL, keys, foreign keys, CHECK constraints, column comments"},
    "ontology": {"label": "Ontology or SHACL (.ttl)", "ext": [".ttl", ".n3", ".nt"],
                 "help": "OWL classes and properties, SHACL shapes: minCount, datatype, pattern, sh:in, ranges, sensitivity"},
    "uml": {"label": "UML diagram", "ext": [".puml", ".plantuml", ".pu", ".wsd", ".iuml", ".xmi", ".uml",
                                            ".png", ".jpg", ".jpeg", ".gif", ".svg", ".drawio"],
            "help": "PlantUML or XMI class diagrams: attributes, multiplicity, keys, enumerations. Images are stored for reference only"},
    "xml": {"label": "XML or XSD", "ext": [".xml", ".xsd"],
            "help": "XSD restrictions (minOccurs, enumeration, pattern, lengths, ranges) or XML reference lists"},
    "glossary": {"label": "Business glossary", "ext": [],
                 "help": "CSV, Excel or JSON with term and definition columns; optional column, synonyms, rule, allowed values, classification"},
    "master_data": {"label": "Master or reference data", "ext": [".csv", ".tsv", ".xlsx", ".xlsm", ".json"],
                    "help": "Lists of valid codes and values (CSV, Excel, JSON, XML). Each column becomes a list of allowed values"},
    "business_doc": {"label": "Business rules document", "ext": [".txt", ".md", ".markdown", ".docx", ".pdf", ".html", ".htm", ".rst"],
                     "help": "Requirements in plain English; sentences with must / never / only / between become rule proposals"},
    "policy": {"label": "Policy or regulation", "ext": [],
               "help": "Privacy, security, retention and compliance text; its rules go to the Data governance set"},
}
MAX_BYTES = 60 * 1024 * 1024
MAX_FACTS = 250_000
MAX_TEXT = 2_000_000
MAX_LIST = 5000

RULE_WORDS = re.compile(r"\b(must|shall|never|always|cannot|can not|required|mandatory|should|only|unique|not be|non-negative|"
                        r"positive|between|at least|at most|no more than|no less than|valid values|allowed values|one of|"
                        r"retain|retained|retention|mask|masked|encrypt|encrypted|consent)\b", re.I)
GOV_WORDS = re.compile(r"\b(personal data|personal information|pii|privacy|gdpr|ccpa|hipaa|pci|consent|opt[- ]?in|retention|retain|"
                       r"retained|purge|erase|erasure|right to be forgotten|anonymi[sz]|pseudonymi[sz]|mask|masked|encrypt|tokeni[sz]|"
                       r"confidential|restricted|sensitive|sox|sarbanes|nerc|cip|audit trail|segregation of duties|regulat\w*|"
                       r"complian\w*|access control|data protection|lawful basis|legal basis)\b", re.I)


# ---------------------------------------------------------------------------- keys
def tkey(name: str | None) -> str:
    """Normalized table key: the last two dotted parts, lower case, without quotes, underscores or spaces."""
    parts = [re.sub(r"[^a-z0-9]", "", p.lower()) for p in re.split(r"\.", re.sub(r"[`\"\[\]]", "", name or ""))]
    parts = [p for p in parts if p]
    return ".".join(parts[-2:])


def ckey(name: str | None) -> str:
    return re.sub(r"[^a-z0-9]", "", (name or "").lower())


def asset_table_keys(fqn: str) -> set[str]:
    parts = [re.sub(r"[^a-z0-9]", "", p.lower()) for p in re.sub(r"[`\"\[\]]", "", fqn).split(".")]
    parts = [p for p in parts if p]
    keys = {parts[-1]} if parts else set()
    if len(parts) >= 2:
        keys |= {f"{parts[-2]}.{parts[-1]}", parts[-2] + parts[-1]}
    return keys


def _local(term: str) -> str:
    t = term.strip().rstrip(";,.").strip("<>")
    return re.split(r"[#/:]", t)[-1]


class Facts:
    def __init__(self):
        self.items: list[dict] = []
        self.tables: set[str] = set()

    def add(self, kind: str, table: str | None = None, column: str | None = None, value: Any = None, text: str | None = None):
        if len(self.items) >= MAX_FACTS:
            return
        if table:
            self.tables.add(table)
        self.items.append({"kind": kind, "table": table or None, "column": column or None, "value": value,
                           "text": (text or "")[:1200] or None})


def _values(s: str) -> list[str]:
    vals = [v.strip().strip("'\"") for v in re.split(r"\s*\|\s*|\s*,\s*(?=['\"]?\w)", s.strip().strip(".")) if v.strip()]
    return [v for v in vals if v and len(v) <= 120][:MAX_LIST]


def _comment_facts(f: Facts, table: str | None, column: str, comment: str):
    """Constraints written into column comments: 'Valid values: a|b', 'Pattern: ^...$', plain-English rules."""
    if not comment:
        return
    f.add("description", table, column, text=comment)
    m = re.search(r"\b(?:valid|allowed|permitted|possible) values?\s*(?:are|:)\s*(.+?)(?:\.\s|\.$|;|$)", comment, re.I)
    if m and ("|" in m.group(1) or "," in m.group(1)):
        f.add("values", table, column, _values(m.group(1)), comment)
    m = re.search(r"\breference[- ]value candidates?\s*:\s*([^.;]+)", comment, re.I)
    if m:
        f.add("values", table, column, _values(m.group(1)), "candidate values: " + m.group(1)[:300])
    m = re.search(r"\bpattern\s*:\s*(\^\S+\$)", comment, re.I)
    if m:
        f.add("pattern", table, column, m.group(1).replace("\\\\", "\\"), comment)
    for sentence in re.split(r"(?<=[.;])\s+", comment):
        if RULE_WORDS.search(sentence) and not re.search(r"valid values|reference-value|pattern\s*:", sentence, re.I):
            f.add("rule_text", table, column, {"governance": bool(GOV_WORDS.search(sentence))}, sentence.strip())


# ---------------------------------------------------------------------------- Turtle / SHACL / OWL
_STR = r'"((?:[^"\\]|\\.)*)"'


def _unesc(s: str) -> str:
    return re.sub(r"\\(.)", lambda m: {"n": "\n", "t": "\t"}.get(m.group(1), m.group(1)), s)


def _ttl_statements(text: str) -> Iterable[str]:
    """Split Turtle into statements (a subject with its predicates), ignoring '.' inside strings and IRIs."""
    buf, in_str, in_iri, esc, depth = [], False, False, False, 0
    for ch in text:
        buf.append(ch)
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if in_iri:
            in_iri = ch != ">"
            continue
        if ch == '"':
            in_str = True
        elif ch == "<":
            in_iri = True
        elif ch in "[(":
            depth += 1
        elif ch in "])":
            depth -= 1
        elif ch == "." and depth <= 0 and (len(buf) < 2 or buf[-2] in " \t\n\"')>"):
            stmt = "".join(buf[:-1]).strip()
            buf = []
            if stmt and not stmt.startswith("@") and not stmt.lower().startswith("prefix"):
                yield stmt
    rest = "".join(buf).strip()
    if rest:
        yield rest


def _strip_ttl_comments(text: str) -> str:
    out = []
    for line in text.splitlines():
        if "#" in line:
            # drop comments that are not inside strings or IRIs
            in_str = in_iri = esc = False
            for i, ch in enumerate(line):
                if in_str:
                    if esc:
                        esc = False
                    elif ch == "\\":
                        esc = True
                    elif ch == '"':
                        in_str = False
                elif in_iri:
                    in_iri = ch != ">"
                elif ch == '"':
                    in_str = True
                elif ch == "<":
                    in_iri = True
                elif ch == "#":
                    line = line[:i]
                    break
        out.append(line)
    return "\n".join(out)


def _blocks(stmt: str, opener: str = "[", closer: str = "]") -> list[str]:
    """Top-level [ ... ] blocks, skipping brackets inside strings (patterns often contain [ ])."""
    out, depth, start, in_str, esc = [], 0, None, False, False
    for i, ch in enumerate(stmt):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == opener:
            if depth == 0:
                start = i + 1
            depth += 1
        elif ch == closer and depth:
            depth -= 1
            if depth == 0 and start is not None:
                out.append(stmt[start:i])
    return out


def _lits(stmt: str, pred: str) -> list[str]:
    return [_unesc(m.group(1)) for m in re.finditer(rf"{pred}\s+{_STR}", stmt)]


def _lit(stmt: str, pred: str) -> str | None:
    v = _lits(stmt, pred)
    return v[0] if v else None


def _num(stmt: str, pred: str) -> float | None:
    m = re.search(rf"{pred}\s+\"?(-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)\"?", stmt)
    return float(m.group(1)) if m else None


XSD_FAMILY = {"string": "string", "normalizedstring": "string", "token": "string", "anyuri": "string", "boolean": "boolean",
              "int": "numeric", "integer": "numeric", "long": "numeric", "short": "numeric", "decimal": "numeric",
              "double": "numeric", "float": "numeric", "nonnegativeinteger": "numeric", "positiveinteger": "numeric",
              "date": "temporal", "datetime": "temporal", "time": "temporal", "gyear": "temporal"}


def parse_turtle(text: str, f: Facts) -> dict:
    text = _strip_ttl_comments(text)
    stmts = list(_ttl_statements(text))
    class_table: dict[str, str] = {}
    n_shapes = n_props = n_classes = 0
    for s in stmts:
        head = s.split(";")[0]
        if "AnnotationProperty" in head:
            continue
        if "owl:Class" in head or re.search(r'\w+:physicalTable\s+"', s):
            cls = _local(s.split()[0])
            n_classes += 1
            table = _lit(s, r"\w*:physicalTable") or _lit(s, r"\w*:tableName")
            if table:
                class_table[cls] = table
            name = table or cls
            label = _lit(s, r"rdfs:label") or _lit(s, r"skos:prefLabel")
            comment = _lit(s, r"rdfs:comment") or _lit(s, r"skos:definition")
            if comment or label:
                f.add("table_description", name, None, {"class": cls, "label": label}, comment or label)
            if table and cls:
                f.add("table_alias", table, None, cls)
            for sens in _lits(s, r"\w*:(?:sensitivity|dataClassification|classification|piiCategory)"):
                f.add("classification", name, None, sens.lower())
    for s in stmts:
        head = s.split(";")[0]
        if "AnnotationProperty" in head:
            continue
        if "sh:property" in s or "sh:NodeShape" in head:
            n_shapes += 1
            target = re.search(r"sh:targetClass\s+(\S+)", s)
            tcls = _local(target.group(1)) if target else _local(s.split()[0]).removesuffix("Shape")
            for b in _blocks(s):
                if "sh:path" not in b:
                    continue
                path = _local(re.search(r"sh:path\s+(\S+)", b).group(1))
                cls, prop = (path.rsplit(".", 1) if "." in path else (tcls, path))
                table = class_table.get(cls, cls)
                mc = _num(b, "sh:minCount")
                if mc and mc >= 1:
                    f.add("not_null", table, prop, None, f"SHACL sh:minCount {mc:g} on {path}")
                dt = re.search(r"sh:datatype\s+(\S+)", b)
                if dt:
                    t = _local(dt.group(1)).rstrip(";")
                    f.add("datatype", table, prop, {"type": t, "family": XSD_FAMILY.get(t.lower())}, f"SHACL datatype {t}")
                pat = _lit(b, "sh:pattern")
                if pat:
                    f.add("pattern", table, prop, pat, f"SHACL sh:pattern on {path}")
                m = re.search(r"sh:in\s*\(([^)]*)\)", b)
                if m:
                    vals = [_unesc(v) for v in re.findall(_STR, m.group(1))] or m.group(1).split()
                    f.add("values", table, prop, vals[:MAX_LIST], f"SHACL sh:in on {path}")
                lo = _num(b, "sh:minInclusive")
                hi = _num(b, "sh:maxInclusive")
                if lo is None and (x := _num(b, "sh:minExclusive")) is not None:
                    lo = x
                if hi is None and (x := _num(b, "sh:maxExclusive")) is not None:
                    hi = x
                if lo is not None or hi is not None:
                    f.add("range", table, prop, {"min": lo, "max": hi}, f"SHACL range on {path}")
                for k, kind in (("sh:maxLength", "max_length"), ("sh:minLength", "min_length")):
                    v = _num(b, k)
                    if v is not None:
                        f.add(kind, table, prop, int(v), f"SHACL {k}")
                ref = re.search(r"sh:class\s+(\S+)", b)
                if ref:
                    rc = _local(ref.group(1)).rstrip(";")
                    f.add("fk", table, prop, {"ref_table": class_table.get(rc, rc), "ref_column": None}, f"SHACL sh:class {rc}")
                msg = _lit(b, "sh:message")
                if msg:
                    f.add("description", table, prop, None, msg)
        elif re.search(r"owl:(?:Datatype|Object)Property|rdf:Property", head) or re.search(r'\w+:physicalColumn\s+"', s):
            n_props += 1
            subj = _local(s.split()[0])
            dom = re.search(r"rdfs:domain\s+(\S+)", s)
            cls = _local(dom.group(1)) if dom else (subj.rsplit(".", 1)[0] if "." in subj else None)
            table = class_table.get(cls, cls) if cls else None
            column = _lit(s, r"\w*:physicalColumn") or _lit(s, r"\w*:columnName") or (subj.rsplit(".", 1)[-1] if subj else None)
            if not column:
                continue
            nullable = re.search(r"\w*:nullable\s+\"?(true|false)\"?", s)
            if nullable and nullable.group(1) == "false":
                f.add("not_null", table, column, None, "ontology: nullable false")
            if re.search(r"\w*:(?:required|mandatory)\s+\"?true", s):
                f.add("not_null", table, column, None, "ontology: required")
            sql_t = _lit(s, r"\w*:sqlDataType")
            rng = re.search(r"rdfs:range\s+xsd:(\w+)", s)
            if sql_t or rng:
                t = sql_t or rng.group(1)
                f.add("datatype", table, column, {"type": t, "family": _sql_family(t) if sql_t else XSD_FAMILY.get(rng.group(1).lower())},
                      f"ontology type {t}")
            pat = _lit(s, r"\w*:(?:valuePattern|pattern|regex)")
            if pat:
                f.add("pattern", table, column, pat, "ontology value pattern")
            vv = _lit(s, r"\w*:(?:validValues|allowedValues|enumeration)")
            if vv:
                f.add("values", table, column, _values(vv), f"ontology valid values: {vv[:300]}")
            term = _lit(s, r"\w*:businessTerm")
            if term:
                f.add("business_term", table, column, None, term)
            comment = _lit(s, r"rdfs:comment") or _lit(s, r"skos:definition")
            if comment:
                f.add("description", table, column, None, comment)
            for sens in _lits(s, r"\w*:(?:sensitivity|classification|piiCategory|dataClassification)"):
                f.add("classification", table, column, sens.lower(), f"ontology sensitivity {sens}")
            unit = _lit(s, r"\w*:unitSymbol")
            if unit:
                f.add("unit", table, column, unit)
    return {"statements": len(stmts), "classes": n_classes, "shapes": n_shapes, "properties": n_props}


# ---------------------------------------------------------------------------- SQL DDL
def _sql_family(t: str) -> str | None:
    t = (t or "").lower()
    if re.search(r"bool", t):
        return "boolean"
    if re.search(r"int|dec|num|double|float|real|money|number", t):
        return "numeric"
    if re.search(r"date|time", t):
        return "temporal"
    if re.search(r"char|string|text|varchar|clob|uuid", t):
        return "string"
    return None


def _sql_clean(sql: str) -> str:
    """Remove -- and /* */ comments outside string literals."""
    out, i, n, q = [], 0, len(sql), None
    while i < n:
        ch = sql[i]
        if q:
            out.append(ch)
            if ch == q:
                if i + 1 < n and sql[i + 1] == q:
                    out.append(sql[i + 1])
                    i += 1
                else:
                    q = None
            elif ch == "\\" and q == "'" and i + 1 < n:
                out.append(sql[i + 1])
                i += 1
        elif ch in "'\"`":
            q = ch
            out.append(ch)
        elif sql.startswith("--", i):
            j = sql.find("\n", i)
            i = n if j < 0 else j
            continue
        elif sql.startswith("/*", i):
            j = sql.find("*/", i + 2)
            i = n if j < 0 else j + 2
            continue
        else:
            out.append(ch)
        i += 1
    return "".join(out)


def _split_top(s: str, sep: str = ",") -> list[str]:
    """Split on sep outside quotes, parentheses and ARRAY<...>/MAP<...>/STRUCT<...> types (but not on < > comparisons)."""
    parts, depth, adepth, cur, q = [], 0, 0, [], None
    i = 0
    while i < len(s):
        ch = s[i]
        if q:
            cur.append(ch)
            if ch == "\\" and q == "'" and i + 1 < len(s):
                cur.append(s[i + 1])
                i += 1
            elif ch == q:
                q = None
        elif ch in "'\"`":
            q = ch
            cur.append(ch)
        elif ch in "([":
            depth += 1
            cur.append(ch)
        elif ch in ")]":
            depth -= 1
            cur.append(ch)
        elif ch == "<" and re.search(r"(ARRAY|MAP|STRUCT)\s*$", "".join(cur[-8:]), re.I):
            adepth += 1
            cur.append(ch)
        elif ch == ">" and adepth:
            adepth -= 1
            cur.append(ch)
        elif ch == sep and depth == 0 and adepth == 0:
            parts.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
        i += 1
    if "".join(cur).strip():
        parts.append("".join(cur).strip())
    return parts


def _ident(s: str) -> str:
    return re.sub(r"[`\"\[\]]", "", s.strip())


def _sql_string(s: str) -> str:
    return s[1:-1].replace("''", "'").replace("\\'", "'") if len(s) >= 2 else s


def _check_facts(f: Facts, table: str, expr: str, column: str | None = None):
    e = expr.strip()
    m = re.fullmatch(r"\(?\s*[`\"]?(\w+)[`\"]?\s+IN\s*\((.*)\)\s*\)?", e, re.I | re.S)
    if m:
        vals = [_sql_string(v.strip()) if v.strip()[:1] in "'\"" else v.strip() for v in _split_top(m.group(2))]
        f.add("values", table, m.group(1), vals[:MAX_LIST], f"CHECK ({e[:300]})")
        return
    m = re.fullmatch(r"\(?\s*[`\"]?(\w+)[`\"]?\s+BETWEEN\s+(-?[\d.]+)\s+AND\s+(-?[\d.]+)\s*\)?", e, re.I)
    if m:
        f.add("range", table, m.group(1), {"min": float(m.group(2)), "max": float(m.group(3))}, f"CHECK ({e[:300]})")
        return
    m = re.fullmatch(r"\(?\s*[`\"]?(\w+)[`\"]?\s*(>=|>|<=|<)\s*(-?[\d.]+)\s*\)?", e)
    if m:
        lim = float(m.group(3))
        f.add("range", table, m.group(1), {"min": lim} if m.group(2).startswith(">") else {"max": lim}, f"CHECK ({e[:300]})")
        return
    f.add("check", table, column, e.strip("() ")[:1000], f"CHECK ({e[:300]})")


_COL_KW = r"\b(NOT\s+NULL|NULL|DEFAULT|COMMENT|PRIMARY\s+KEY|REFERENCES|CHECK|UNIQUE|CONSTRAINT|GENERATED|COLLATE|MASK|AUTO_INCREMENT|IDENTITY)\b"


def parse_sql(sql: str, f: Facts) -> dict:
    sql = _sql_clean(sql)
    stmts = _split_top(sql, ";")
    n_tables = n_cols = n_fk = 0
    for st in stmts:
        m = re.match(r"\s*CREATE\s+(?:OR\s+REPLACE\s+)?(?:(?:GLOBAL\s+|LOCAL\s+)?TEMP(?:ORARY)?\s+)?(?:EXTERNAL\s+)?TABLE\s+"
                     r"(?:IF\s+NOT\s+EXISTS\s+)?([^\s(]+)\s*\(", st, re.I)
        if m:
            table = _ident(m.group(1))
            n_tables += 1
            body_start = m.end()
            depth, i = 1, body_start
            q = None
            while i < len(st) and depth:
                ch = st[i]
                if q:
                    if ch == q:
                        q = None
                elif ch in "'\"`":
                    q = ch
                elif ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                i += 1
            body, tail = st[body_start:i - 1], st[i:]
            tc = re.search(r"\bCOMMENT\s+('(?:[^']|'')*')", tail, re.I)
            if tc:
                f.add("table_description", table, None, None, _sql_string(tc.group(1)))
            for item in _split_top(body):
                up = item.upper()
                if re.match(r"(CONSTRAINT\s+\S+\s+)?PRIMARY\s+KEY", up):
                    cols = [_ident(c) for c in re.search(r"\((.*)\)", item, re.S).group(1).split(",")]
                    f.add("pk", table, cols[0] if len(cols) == 1 else None, cols, item[:300])
                    continue
                if re.match(r"(CONSTRAINT\s+\S+\s+)?UNIQUE", up):
                    cols = [_ident(c) for c in re.search(r"\((.*)\)", item, re.S).group(1).split(",")]
                    f.add("unique", table, cols[0] if len(cols) == 1 else None, cols, item[:300])
                    continue
                if re.match(r"(CONSTRAINT\s+\S+\s+)?FOREIGN\s+KEY", up):
                    fm = re.search(r"FOREIGN\s+KEY\s*\(([^)]*)\)\s*REFERENCES\s+([^\s(]+)\s*\(([^)]*)\)", item, re.I)
                    if fm:
                        n_fk += 1
                        f.add("fk", table, _ident(fm.group(1).split(",")[0]),
                              {"ref_table": _ident(fm.group(2)), "ref_column": _ident(fm.group(3).split(",")[0])}, item[:300])
                    continue
                if re.match(r"(CONSTRAINT\s+\S+\s+)?CHECK", up):
                    cm = re.search(r"CHECK\s*\((.*)\)", item, re.I | re.S)
                    if cm:
                        _check_facts(f, table, cm.group(1))
                    continue
                if re.match(r"(INDEX|KEY|PERIOD|LIKE)\b", up):
                    continue
                cm = re.match(r"(`[^`]+`|\"[^\"]+\"|\[[^\]]+\]|\w+)\s+(.*)$", item, re.S)
                if not cm:
                    continue
                col, full = _ident(cm.group(1)), cm.group(2)
                n_cols += 1
                com = re.search(r"\bCOMMENT\s+('(?:[^'\\]|''|\\.)*')", full, re.I | re.S)
                rest = full[:com.start()] + full[com.end():] if com else full  # never read constraints from comment text
                kw = re.search(_COL_KW, rest, re.I)
                ctype = (rest[:kw.start()] if kw else rest).strip()
                f.add("datatype", table, col, {"type": ctype, "family": _sql_family(ctype)}, f"{col} {ctype}")
                lm = re.match(r"(?:N?VAR)?CHAR(?:ACTER)?(?:\s+VARYING)?\s*\(\s*(\d+)\s*\)", ctype, re.I)
                if lm:
                    f.add("max_length", table, col, int(lm.group(1)), ctype)
                if re.search(r"\bNOT\s+NULL\b", rest, re.I):
                    f.add("not_null", table, col, None, f"{col} {ctype} NOT NULL")
                if re.search(r"\bPRIMARY\s+KEY\b", rest, re.I):
                    f.add("pk", table, col, [col], f"{col} PRIMARY KEY")
                elif re.search(r"\bUNIQUE\b", rest, re.I):
                    f.add("unique", table, col, [col], f"{col} UNIQUE")
                rm = re.search(r"REFERENCES\s+([^\s(]+)\s*\(([^)]*)\)", rest, re.I)
                if rm:
                    n_fk += 1
                    f.add("fk", table, col, {"ref_table": _ident(rm.group(1)), "ref_column": _ident(rm.group(2))}, rest[:300])
                ck = re.search(r"CHECK\s*\((.*)\)", rest, re.I | re.S)
                if ck:
                    _check_facts(f, table, ck.group(1), col)
                if com:
                    _comment_facts(f, table, col, _sql_string(com.group(1)).replace("\\'", "'"))
            continue
        m = re.match(r"\s*ALTER\s+TABLE\s+(?:IF\s+EXISTS\s+)?([^\s]+)\s+(.*)$", st, re.I | re.S)
        if m:
            table, rest = _ident(m.group(1)), m.group(2)
            fm = re.search(r"FOREIGN\s+KEY\s*\(([^)]*)\)\s*REFERENCES\s+([^\s(]+)\s*\(([^)]*)\)", rest, re.I)
            if fm and re.match(r"ADD\b", rest.strip(), re.I):
                n_fk += 1
                f.add("fk", table, _ident(fm.group(1).split(",")[0]),
                      {"ref_table": _ident(fm.group(2)), "ref_column": _ident(fm.group(3).split(",")[0])}, st.strip()[:300])
            pm = re.search(r"ADD\s+(?:CONSTRAINT\s+\S+\s+)?PRIMARY\s+KEY\s*\(([^)]*)\)", rest, re.I)
            if pm:
                cols = [_ident(c) for c in pm.group(1).split(",")]
                f.add("pk", table, cols[0] if len(cols) == 1 else None, cols, st.strip()[:300])
            nm = re.search(r"ALTER\s+(?:COLUMN\s+)?([`\"\w]+)\s+SET\s+NOT\s+NULL", rest, re.I)
            if nm:
                f.add("not_null", table, _ident(nm.group(1)), None, st.strip()[:300])
            ck = re.search(r"ADD\s+(?:CONSTRAINT\s+\S+\s+)?CHECK\s*\((.*)\)", rest, re.I | re.S)
            if ck:
                _check_facts(f, table, ck.group(1))
            continue
        m = re.match(r"\s*COMMENT\s+ON\s+COLUMN\s+([^\s]+)\s+IS\s+('(?:[^']|'')*')", st, re.I)
        if m:
            parts = _ident(m.group(1)).rsplit(".", 1)
            if len(parts) == 2:
                _comment_facts(f, parts[0], parts[1], _sql_string(m.group(2)))
    return {"statements": len(stmts), "tables": n_tables, "columns": n_cols, "foreign_keys": n_fk}


# ---------------------------------------------------------------------------- XML: XSD, XMI (UML), data
def _tag(e) -> str:
    return e.tag.split("}")[-1] if isinstance(e.tag, str) else ""


def _safe_xml(raw: bytes):
    head = raw[:20000].decode("utf-8", "ignore")
    if "<!ENTITY" in head.upper():
        raise ValueError("XML with entity declarations is not accepted")
    return ET.fromstring(raw)


def _restrictions(node) -> dict:
    r: dict[str, Any] = {}
    for x in node.iter():
        t, v = _tag(x), x.get("value")
        if t == "restriction" and x.get("base"):
            r["base"] = x.get("base").split(":")[-1]
        elif t == "enumeration" and v is not None:
            r.setdefault("values", []).append(v)
        elif t == "pattern" and v:
            r["pattern"] = v
        elif t in ("maxLength", "length") and v:
            r["max_length"] = int(v)
        elif t == "minLength" and v:
            r["min_length"] = int(v)
        elif t in ("minInclusive", "minExclusive") and v:
            r["min"] = float(v)
        elif t in ("maxInclusive", "maxExclusive") and v:
            r["max"] = float(v)
    return r


def _apply_restr(f: Facts, table, col, r: dict, src: str):
    if r.get("values"):
        f.add("values", table, col, r["values"][:MAX_LIST], src)
    if r.get("pattern"):
        f.add("pattern", table, col, r["pattern"], src)
    if r.get("max_length"):
        f.add("max_length", table, col, r["max_length"], src)
    if r.get("min_length"):
        f.add("min_length", table, col, r["min_length"], src)
    if r.get("min") is not None or r.get("max") is not None:
        f.add("range", table, col, {"min": r.get("min"), "max": r.get("max")}, src)
    if r.get("base"):
        f.add("datatype", table, col, {"type": r["base"], "family": XSD_FAMILY.get(r["base"].lower())}, src)


def parse_xsd(root, f: Facts) -> dict:
    simple = {st.get("name"): _restrictions(st) for st in root.iter() if _tag(st) == "simpleType" and st.get("name")}
    # <xs:element name="customer" type="CustomerType"/> -> facts of CustomerType belong to table "customer"
    alias = {(ch.get("type") or "").split(":")[-1]: ch.get("name") for ch in root if _tag(ch) == "element" and ch.get("type")}
    n = 0

    def walk(node, table):
        nonlocal n
        for ch in node:
            t = _tag(ch)
            if t == "complexType" and ch.get("name"):
                walk(ch, alias.get(ch.get("name"), ch.get("name")))
            elif t == "element" and ch.get("name"):
                name = ch.get("name")
                inline_complex = next((x for x in ch if _tag(x) == "complexType"), None)
                if inline_complex is not None:
                    walk(inline_complex, name)
                    continue
                if table is None:
                    continue
                n += 1
                if int(ch.get("minOccurs", "1") or 1) >= 1 and ch.get("nillable") != "true":
                    f.add("not_null", table, name, None, f"XSD minOccurs {ch.get('minOccurs', '1')}")
                typ = (ch.get("type") or "").split(":")[-1]
                if typ in simple:
                    _apply_restr(f, table, name, simple[typ], f"XSD type {typ}")
                elif typ:
                    f.add("datatype", table, name, {"type": typ, "family": XSD_FAMILY.get(typ.lower())}, f"XSD type {typ}")
                inline = next((x for x in ch if _tag(x) == "simpleType"), None)
                if inline is not None:
                    _apply_restr(f, table, name, _restrictions(inline), "XSD restriction")
                doc = next((x.text for x in ch.iter() if _tag(x) == "documentation" and x.text), None)
                if doc:
                    _comment_facts(f, table, name, doc.strip())
            elif t == "attribute" and ch.get("name") and table:
                n += 1
                name = ch.get("name")
                if ch.get("use") == "required":
                    f.add("not_null", table, name, None, "XSD attribute use=required")
                typ = (ch.get("type") or "").split(":")[-1]
                if typ in simple:
                    _apply_restr(f, table, name, simple[typ], f"XSD type {typ}")
            else:
                walk(ch, table)
    walk(root, None)
    return {"simple_types": len(simple), "elements": n}


def parse_xmi(root, f: Facts) -> dict:
    def xtype(e):
        return next((v for k, v in e.attrib.items() if k.endswith("}type") or k == "xmi:type"), "") or ""

    def xid(e):
        return next((v for k, v in e.attrib.items() if k.endswith("}id") or k == "xmi:id"), None)
    enums = {}
    for e in root.iter():
        if xtype(e).endswith("Enumeration"):
            enums[xid(e)] = [lit.get("name") for lit in e if _tag(lit) == "ownedLiteral" and lit.get("name")]
            enums[e.get("name")] = enums[xid(e)]
    n_cls = n_attr = 0
    for e in root.iter():
        if not xtype(e).endswith(":Class") and xtype(e) != "uml:Class":
            continue
        cls = e.get("name")
        if not cls:
            continue
        n_cls += 1
        for a in e:
            if _tag(a) != "ownedAttribute" or not a.get("name") or a.get("association"):
                continue
            n_attr += 1
            name = a.get("name")
            lower = next((x.get("value") for x in a if _tag(x) == "lowerValue"), None)
            if lower not in (None, "", "0"):
                f.add("not_null", cls, name, None, f"UML multiplicity lower bound {lower}")
            if a.get("isID") == "true":
                f.add("pk", cls, name, [name], "UML isID")
            typ = a.get("type") or next((x.get("href", "").split("#")[-1] for x in a if _tag(x) == "type"), "")
            if typ in enums:
                f.add("values", cls, name, enums[typ][:MAX_LIST], "UML enumeration")
            elif typ:
                f.add("datatype", cls, name, {"type": typ, "family": _sql_family(typ) or XSD_FAMILY.get(typ.lower())}, f"UML type {typ}")
    return {"classes": n_cls, "attributes": n_attr, "enumerations": len(enums) // 2}


def parse_xml_data(root, f: Facts, source: str) -> dict:
    """Generic XML: the most repeated element becomes a reference list (its attributes and leaf children are columns)."""
    counts = Counter(_tag(e) for e in root.iter())
    rec_tag, n = next(((t, c) for t, c in counts.most_common() if c >= 3 and t != _tag(root)), (None, 0))
    if not rec_tag:
        return {"records": 0}
    cols: dict[str, set] = defaultdict(set)
    for e in root.iter():
        if _tag(e) != rec_tag:
            continue
        for k, v in e.attrib.items():
            cols[k.split("}")[-1]].add(v.strip())
        for ch in e:
            if len(ch) == 0 and (ch.text or "").strip():
                cols[_tag(ch)].add(ch.text.strip())
    for col, vals in cols.items():
        _master(f, col, vals, n, source)
    return {"records": n, "fields": len(cols), "record_element": rec_tag}


# ---------------------------------------------------------------------------- PlantUML
_PUML_HEAD = re.compile(r"^\s*(abstract\s+class|class|entity|enum|table|object|interface)\s+\"?([\w.\- ]+?)\"?"
                        r"(?:\s+as\s+\"?(\w+)\"?)?(?:\s*<<[^>]*>>)?\s*\{", re.M)


def _puml_blocks(text: str):
    """(kind, name, alias, body) for each class/entity/enum block; braces are counted so {id} markers and one-line enums work."""
    pos = 0
    while True:
        m = _PUML_HEAD.search(text, pos)
        if not m:
            return
        depth, i = 1, m.end()
        while i < len(text) and depth:
            depth += {"{": 1, "}": -1}.get(text[i], 0)
            i += 1
        yield m.group(1).lower(), m.group(2).strip(), m.group(3), text[m.end():i - 1]
        pos = i


def parse_plantuml(text: str, f: Facts) -> dict:
    enums: dict[str, list[str]] = {}
    attrs = []
    n_cls = 0
    for kind, name, alias, body in _puml_blocks(text):
        if kind == "enum":
            vals = [re.split(r"[\s:=(,]", ln.strip())[0] for ln in body.splitlines() if ln.strip() and not ln.strip().startswith(("'", "--", ".."))]
            enums[name] = enums[alias or name] = [v for v in vals if v]
            continue
        n_cls += 1
        for ln in body.splitlines():
            s = ln.strip()
            if not s or s.startswith(("'", "--", "..", "==", "__")) or "(" in s.split(":")[0]:
                continue
            mandatory = s.startswith("*") or bool(re.search(r"\[1(\.\.1)?\]|<<\s*(NN|not ?null|PK)\s*>>|\{\s*(required|id)\s*\}|\bnot null\b", s, re.I))
            pk = bool(re.search(r"<<\s*(PK|id)\s*>>|\{\s*id\s*\}", s, re.I))
            fk = bool(re.search(r"<<\s*FK\s*>>", s, re.I))
            s2 = re.sub(r"^[*+\-#~{}\s]+|<<[^>]*>>|\{[^}]*\}|\[[^\]]*\]", " ", s).strip()
            if ":" in s2:  # "name : Type"
                col, typ = (x.strip() for x in s2.split(":", 1))
            else:  # "Type name" or just "name"
                toks = s2.split()
                col, typ = (toks[-1], " ".join(toks[:-1])) if len(toks) >= 2 else ((toks[0], "") if toks else ("", ""))
            if not re.fullmatch(r"\w+", col or ""):
                continue
            attrs.append((name, col, typ))
            if mandatory:
                f.add("not_null", name, col, None, f"UML: {s[:120]}")
            if pk:
                f.add("pk", name, col, [col], f"UML: {s[:120]}")
            if fk:
                f.add("description", name, col, None, f"UML foreign key: {s[:120]}")
            lm = re.match(r"(?:n?var)?char\s*\((\d+)\)", typ, re.I)
            if lm:
                f.add("max_length", name, col, int(lm.group(1)), typ)
            if typ:
                f.add("datatype", name, col, {"type": typ, "family": _sql_family(typ) or XSD_FAMILY.get(typ.lower())}, f"UML type {typ}")
    for table, col, typ in attrs:
        if typ in enums:
            f.add("values", table, col, enums[typ][:MAX_LIST], f"UML enum {typ}")
    return {"classes": n_cls, "attributes": len(attrs), "enumerations": len({k for k in enums})}


# ---------------------------------------------------------------------------- tables: glossary and master data
GLOSSARY_COLS = {
    "term": ["term", "businessterm", "termname", "glossaryterm", "name", "businessname", "dataelement", "attribute"],
    "definition": ["definition", "description", "meaning", "businessdefinition", "termdefinition"],
    "column": ["column", "columnname", "physicalcolumn", "field", "fieldname", "technicalname", "physicalname", "attributename"],
    "table": ["table", "tablename", "dataset", "entity", "physicaltable", "object"],
    "synonyms": ["synonyms", "synonym", "aliases", "alias", "alsoknownas", "aka"],
    "domain": ["domain", "businessdomain", "subjectarea", "area"],
    "classification": ["classification", "sensitivity", "dataclassification", "pii", "privacy", "confidentiality", "securityclass"],
    "rule": ["rule", "rules", "businessrule", "businessrules", "validation", "validationrule", "constraint", "dqrule", "qualityrule"],
    "values": ["allowedvalues", "validvalues", "values", "permittedvalues", "domainvalues", "codes"],
    "format": ["format", "pattern", "regex", "mask"],
    "owner": ["owner", "steward", "dataowner", "datasteward"],
}


def _find_col(headers: list[str], role: str) -> int | None:
    keys = [ckey(h) for h in headers]
    for want in GLOSSARY_COLS[role]:
        if want in keys:
            return keys.index(want)
    return None


def is_glossary(headers: list[str]) -> bool:
    return _find_col(headers, "term") is not None and _find_col(headers, "definition") is not None


def parse_glossary_rows(headers: list[str], rows: list[list], f: Facts) -> dict:
    idx = {role: _find_col(headers, role) for role in GLOSSARY_COLS}
    if idx["term"] is None:
        raise ValueError("A glossary needs a term (or name) column")

    def get(row, role):
        i = idx[role]
        return str(row[i]).strip() if i is not None and i < len(row) and row[i] not in (None, "") else ""
    n = 0
    for row in rows:
        term = get(row, "term")
        if not term:
            continue
        n += 1
        definition, column, table = get(row, "definition"), get(row, "column"), get(row, "table") or None
        syn = [s.strip() for s in re.split(r"[;,|]", get(row, "synonyms")) if s.strip()]
        cls = get(row, "classification").lower()
        target = column or term
        f.add("term", table, target, {"term": term, "definition": definition, "synonyms": syn, "domain": get(row, "domain") or None,
                                      "classification": cls or None, "owner": get(row, "owner") or None}, definition or term)
        f.add("business_term", table, target, None, term)
        for s in syn:
            f.add("business_term", table, target, None, s)
        if cls and cls not in ("no", "none", "n", "false", "public", "0"):
            f.add("classification", table, target, "pii" if cls in ("yes", "y", "true", "1") else cls, f"glossary classification {cls}")
        if get(row, "values"):
            f.add("values", table, target, _values(get(row, "values")), f"glossary allowed values for {term}")
        if get(row, "format") and re.search(r"[\\\[\]{}^$]", get(row, "format")):
            f.add("pattern", table, target, get(row, "format"), f"glossary format for {term}")
        for i, t in enumerate([get(row, "rule"), definition]):
            for sentence in re.split(r"(?<=[.;])\s+|\n", t or ""):
                if sentence.strip() and (i == 0 or RULE_WORDS.search(sentence)):
                    f.add("rule_text", table, target, {"governance": bool(GOV_WORDS.search(sentence) or cls), "term": term},
                          sentence.strip())
    return {"terms": n}


def _master(f: Facts, header: str, values: set, rows: int, source: str):
    vals = sorted({v for v in values if v not in ("", None)}, key=str)
    if not vals or len(vals) > MAX_LIST or sum(len(str(v)) for v in vals) / len(vals) > 60:
        return
    f.add("master_values", None, header, {"values": [str(v) for v in vals], "rows": rows, "source": source},
          f"{len(vals)} distinct {header} values in {source}")


def parse_master_rows(headers: list[str], rows: list[list], f: Facts, source: str) -> dict:
    cols: dict[int, set] = defaultdict(set)
    for row in rows:
        for i, v in enumerate(row[:len(headers)]):
            if v not in (None, ""):
                cols[i].add(str(v).strip())
    for i, h in enumerate(headers):
        if h:
            _master(f, str(h), cols.get(i, set()), len(rows), source)
    return {"rows": len(rows), "columns": len(headers)}


def read_table(name: str, raw: bytes) -> list[tuple[str, list[str], list[list]]]:
    """[(sheet, headers, rows)] from CSV/TSV or Excel."""
    ext = Path(name).suffix.lower()
    if ext in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        out = []
        for ws in wb.worksheets:
            it = ws.iter_rows(values_only=True)
            headers = next(it, None)
            if not headers:
                continue
            rows = [list(r) for _, r in zip(range(200_000), it)]
            out.append((ws.title, [str(h).strip() if h is not None else "" for h in headers], rows))
        return out
    text = _decode(raw)
    sample = text[:20000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel_tab if ext == ".tsv" else csv.excel
    reader = csv.reader(io.StringIO(text), dialect)
    headers = next(reader, [])
    rows = [r for _, r in zip(range(200_000), reader)]
    return [(Path(name).stem, [h.strip() for h in headers], rows)]


# ---------------------------------------------------------------------------- JSON
def parse_json(name: str, data, f: Facts, kind: str | None) -> tuple[str, dict]:
    if isinstance(data, dict) and isinstance(data.get("terms") or data.get("glossary"), list):
        data = data.get("terms") or data.get("glossary")
    if isinstance(data, dict) and (isinstance(data.get("properties"), dict) or isinstance(data.get("$defs") or data.get("definitions"), dict)):
        n = 0
        defs = [(data.get("title") or Path(name).stem, data)] + list((data.get("$defs") or data.get("definitions") or {}).items())
        for table, sch in defs:
            req = set(sch.get("required") or [])
            for col, p in (sch.get("properties") or {}).items():
                if not isinstance(p, dict):
                    continue
                n += 1
                if col in req:
                    f.add("not_null", table, col, None, "JSON Schema required")
                if p.get("enum"):
                    f.add("values", table, col, [str(v) for v in p["enum"]][:MAX_LIST], "JSON Schema enum")
                if p.get("pattern"):
                    f.add("pattern", table, col, p["pattern"], "JSON Schema pattern")
                if p.get("maxLength") is not None:
                    f.add("max_length", table, col, int(p["maxLength"]), "JSON Schema maxLength")
                if p.get("minLength"):
                    f.add("min_length", table, col, int(p["minLength"]), "JSON Schema minLength")
                if p.get("minimum") is not None or p.get("maximum") is not None:
                    f.add("range", table, col, {"min": p.get("minimum"), "max": p.get("maximum")}, "JSON Schema minimum/maximum")
                t = p.get("type")
                if isinstance(t, list):
                    t = next((x for x in t if x != "null"), None)
                if t:
                    fam = {"string": "string", "integer": "numeric", "number": "numeric", "boolean": "boolean"}.get(t)
                    if p.get("format") in ("date", "date-time"):
                        fam = "temporal"
                    f.add("datatype", table, col, {"type": p.get("format") or t, "family": fam}, "JSON Schema type")
                if p.get("format") == "email":
                    f.add("classification", table, col, "pii_email", "JSON Schema format email")
                if p.get("description"):
                    _comment_facts(f, table, col, p["description"])
        return "sql_model" if kind in (None, "sql_model") else kind, {"schema_properties": n}
    if isinstance(data, list) and data and all(isinstance(x, dict) for x in data[:50]):
        headers = list(dict.fromkeys(k for x in data[:500] for k in x))
        rows = [[x.get(h) for h in headers] for x in data]
        if kind == "glossary" or (kind is None and is_glossary(headers)):
            return "glossary", parse_glossary_rows(headers, rows, f)
        return "master_data", parse_master_rows(headers, rows, f, name)
    raise ValueError("JSON must be a glossary (a list of terms), a JSON Schema, or a list of records")


# ---------------------------------------------------------------------------- documents
def _decode(raw: bytes) -> str:
    for enc in ("utf-8-sig", "utf-16"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def doc_text(name: str, raw: bytes) -> str:
    ext = Path(name).suffix.lower()
    if ext == ".docx":
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            xml = z.read("word/document.xml")
        root = ET.fromstring(xml)
        paras = []
        for p in root.iter():
            if _tag(p) == "p":
                t = "".join(x.text or "" for x in p.iter() if _tag(x) == "t")
                if t.strip():
                    paras.append(t)
        return "\n\n".join(paras)
    if ext == ".pdf":
        try:
            import pypdf
        except ImportError:
            raise ValueError("Text can't be read from PDF files here because the optional pypdf package isn't installed. "
                             "Install it with `pip install pypdf`, or upload the document as .docx, .md or .txt") from None
        reader = pypdf.PdfReader(io.BytesIO(raw))
        return "\n\n".join((pg.extract_text() or "") for pg in reader.pages)
    text = _decode(raw)
    if ext in (".html", ".htm"):
        text = re.sub(r"(?is)<(script|style).*?</\1>", " ", text)
        text = re.sub(r"(?i)<br\s*/?>|</p>|</li>|</h\d>|</tr>", "\n", text)
        text = re.sub(r"<[^>]+>", " ", text)
        import html as _h
        text = _h.unescape(text)
    return text


def parse_text(text: str, f: Facts, policy: bool) -> dict:
    n = 0
    text = re.sub(r"[ \t]+", " ", text)
    for para in re.split(r"\n\s*\n", text):
        p = re.sub(r"\s+", " ", para).strip(" -*#>")
        if not p:
            continue
        for sentence in re.split(r"(?<=[.;!?])\s+(?=[A-Z0-9\"'(])|\s+[-*•]\s+", p):
            s = sentence.strip(" -*•")
            if 8 <= len(s) <= 600 and RULE_WORDS.search(s):
                n += 1
                f.add("rule_text", None, None, {"governance": policy or bool(GOV_WORDS.search(s))}, s)
    return {"rule_sentences": n, "characters": len(text)}


# ---------------------------------------------------------------------------- detection and ingest
def detect_kind(name: str, raw: bytes) -> str:
    ext = Path(name).suffix.lower()
    head = raw[:4000].decode("utf-8", "ignore").lower()
    if ext in (".ttl", ".n3", ".nt") or "@prefix" in head:
        return "ontology"
    if ext in (".sql", ".ddl") or re.search(r"\bcreate\s+(or\s+replace\s+)?table\b", head):
        return "sql_model"
    if ext in (".puml", ".plantuml", ".pu", ".wsd", ".iuml", ".xmi", ".uml") or "@startuml" in head or "xmi:" in head:
        return "uml"
    if ext in (".png", ".jpg", ".jpeg", ".gif", ".svg", ".drawio"):
        return "uml"
    if ext in (".xml", ".xsd"):
        return "xml"
    if ext in (".csv", ".tsv", ".xlsx", ".xlsm"):
        try:
            sheets = read_table(name, raw)
            if any(is_glossary(h) for _, h, _ in sheets):
                return "glossary"
        except Exception:
            pass
        return "master_data"
    if ext == ".json":
        try:
            data = json.loads(_decode(raw))
            items = data.get("terms") if isinstance(data, dict) else data
            if isinstance(items, list) and items and isinstance(items[0], dict) and is_glossary(list(items[0])):
                return "glossary"
            if isinstance(data, dict) and ("properties" in data or "$defs" in data or "definitions" in data):
                return "sql_model"
        except Exception:
            pass
        return "master_data"
    if re.search(GOV_WORDS.pattern, head, re.I) and re.search(r"\b(policy|regulation|gdpr|retention|privacy)\b", head):
        return "policy"
    return "business_doc"


def extract(name: str, raw: bytes, kind: str | None = None) -> tuple[str, Facts, dict, str]:
    """Parse a file into facts. Returns (kind, facts, summary, text_for_context)."""
    kind = kind or detect_kind(name, raw)
    if kind not in KINDS:
        raise ValueError(f"Unknown file kind {kind!r}")
    ext = Path(name).suffix.lower()
    f = Facts()
    text = ""
    summary: dict[str, Any] = {}
    if ext in (".png", ".jpg", ".jpeg", ".gif", ".drawio"):
        return kind, f, {"note": "Stored for reference. Images aren't read; describe the key rules in the description"}, ""
    if ext == ".json":
        kind, summary = parse_json(name, json.loads(_decode(raw)), f, kind if kind in ("glossary", "master_data", "sql_model") else None)
        text = _decode(raw)[:200_000]
    elif kind == "ontology":
        text = _decode(raw)
        summary = parse_turtle(text, f)
    elif kind == "sql_model":
        text = _decode(raw)
        summary = parse_sql(text, f)
    elif kind in ("uml", "xml") or ext in (".xml", ".xsd", ".xmi", ".svg"):
        txt = _decode(raw)
        if ext in (".xml", ".xsd", ".xmi", ".uml") or txt.lstrip().startswith("<"):
            root = _safe_xml(raw)
            rt = _tag(root).lower()
            if rt == "schema":
                summary = parse_xsd(root, f)
            elif rt in ("xmi", "model") or any(k.endswith("}type") and "XMI" in k.upper() for e in list(root.iter())[:200] for k in e.attrib):
                summary = parse_xmi(root, f)
            elif ext == ".svg":
                summary = {"note": "Stored for reference. SVG drawings aren't read"}
            else:
                summary = parse_xml_data(root, f, name)
            text = txt[:200_000]
        else:
            text = txt
            summary = parse_plantuml(txt, f)
    elif kind in ("glossary", "master_data") and ext in (".csv", ".tsv", ".xlsx", ".xlsm", ".txt"):
        summary = {"sheets": 0}
        for sheet, headers, rows in read_table(name, raw):
            summary["sheets"] += 1
            if kind == "glossary":
                for k, v in parse_glossary_rows(headers, rows, f).items():
                    summary[k] = summary.get(k, 0) + v
            else:
                for k, v in parse_master_rows(headers, rows, f, f"{name}:{sheet}" if ext in (".xlsx", ".xlsm") else name).items():
                    summary[k] = summary.get(k, 0) + v if isinstance(v, int) else v
            text += f"\n# {sheet}\n" + ", ".join(headers) + "\n" + "\n".join(", ".join(str(c) for c in r) for r in rows[:30])
    else:
        text = doc_text(name, raw)
        summary = parse_text(text, f, policy=kind == "policy")
    summary["facts"] = len(f.items)
    summary["tables"] = len(f.tables)
    kinds = Counter(x["kind"] for x in f.items)
    summary["by_kind"] = dict(kinds.most_common())
    return kind, f, summary, text[:MAX_TEXT]


def ingest(db, name: str, raw: bytes, actor: str, kind: str | None = None, domain: str | None = None,
           description: str | None = None) -> ReferenceDoc:
    if not raw:
        raise ValueError("The file is empty")
    if len(raw) > MAX_BYTES:
        raise ValueError(f"The file is {len(raw) / 1048576:.0f} MB; the limit is {MAX_BYTES // 1048576} MB")
    name = Path(name or "file").name[:300]
    kind = kind or None
    if kind and kind not in KINDS:
        raise ValueError(f"Unknown file kind {kind!r}. Choose from {', '.join(KINDS)}")
    doc = ReferenceDoc(name=name, kind=kind or detect_kind(name, raw), domain=(domain or "").strip() or None,
                       description=(description or "").strip() or None, size=len(raw),
                       sha256=hashlib.sha256(raw).hexdigest(), content=raw, uploaded_by=actor,
                       content_type=_content_type(name))
    db.add(doc)
    db.flush()
    _parse_into(db, doc, raw, kind)
    return doc


def _content_type(name: str) -> str:
    import mimetypes
    return mimetypes.guess_type(name)[0] or "application/octet-stream"


def _parse_into(db, doc: ReferenceDoc, raw: bytes, kind: str | None) -> None:
    db.execute(delete(ReferenceFact).where(ReferenceFact.doc_id == doc.id))
    try:
        k, facts, summary, text = extract(doc.name, raw, kind)
        doc.kind, doc.summary, doc.text, doc.error = k, summary, text, None
        doc.status = "parsed" if facts.items else "stored"
        rows = [{"doc_id": doc.id, "table_key": tkey(x["table"]) if x["table"] else "", "column_key": ckey(x["column"]),
                 "table": (x["table"] or None) and x["table"][:300], "column": (x["column"] or None) and x["column"][:200],
                 "kind": x["kind"], "value": x["value"], "text": x["text"]} for x in facts.items]
        for start in range(0, len(rows), 5000):
            db.execute(ReferenceFact.__table__.insert(), rows[start:start + 5000])
    except Exception as e:
        doc.status, doc.error = "error", f"{type(e).__name__}: {e}"[:1000]
        doc.summary = {"facts": 0}
    db.flush()


def reparse(db, doc: ReferenceDoc) -> ReferenceDoc:
    _parse_into(db, doc, doc.content, doc.kind)
    return doc


def delete_doc(db, doc: ReferenceDoc) -> None:
    db.execute(delete(ReferenceFact).where(ReferenceFact.doc_id == doc.id))
    db.delete(doc)
    db.flush()


def decode_upload(content_b64: str) -> bytes:
    if "," in content_b64[:100] and content_b64.startswith("data:"):
        content_b64 = content_b64.split(",", 1)[1]
    try:
        return base64.b64decode(content_b64, validate=False)
    except Exception:
        raise ValueError("The file content isn't valid base64") from None


# ---------------------------------------------------------------------------- matching a dataset
class Context:
    """The reference facts that apply to one dataset."""

    def __init__(self):
        self.docs: dict[int, ReferenceDoc] = {}
        self.by_col: dict[str, list[dict]] = defaultdict(list)   # dataset column name -> facts
        self.table: list[dict] = []                               # table-level facts
        self.sentences: list[dict] = []                           # rule sentences not tied to a table
        self.aliases: dict[str, str] = {}                         # business term (lower) -> column name
        self.model_columns: dict[int, dict[str, dict]] = {}       # doc id -> model column -> datatype (matched table)
        self.used: Counter = Counter()

    def fact_count(self) -> int:
        return sum(len(v) for v in self.by_col.values()) + len(self.table) + len(self.sentences)


def select_docs(db, asset: Asset | None, ids: list[int] | None) -> list[ReferenceDoc]:
    q = select(ReferenceDoc).where(ReferenceDoc.status != "error")
    if ids is not None:
        if not ids:
            return []
        return list(db.scalars(q.where(ReferenceDoc.id.in_(ids))))
    docs = list(db.scalars(q.where(ReferenceDoc.enabled.is_(True))))
    dom = ((asset.domain if asset else None) or "").lower()
    return [d for d in docs if not d.domain or d.domain.lower() in ("all", "any", dom) or (d.kind == "policy" and d.domain.lower() == "governance")]


def gather(db, asset: Asset, ids: list[int] | None = None) -> Context:
    ctx = Context()
    docs = select_docs(db, asset, ids)
    if not docs:
        return ctx
    ctx.docs = {d.id: d for d in docs}
    tkeys = asset_table_keys(asset.fqn)
    cols = {ckey(c["name"]): c["name"] for c in (asset.columns or [])}
    doc_ids = list(ctx.docs)
    q = select(ReferenceFact).where(ReferenceFact.doc_id.in_(doc_ids), or_(
        ReferenceFact.table_key.in_(tkeys),
        (ReferenceFact.table_key == "") & (ReferenceFact.column_key.in_(list(cols)) | (ReferenceFact.column_key == ""))))
    matched_table_cols = set()
    for fx in db.scalars(q):
        if fx.kind == "datatype" and fx.column and fx.table_key in tkeys:
            ctx.model_columns.setdefault(fx.doc_id, {})[fx.column] = fx.value or {}
        # facts with no table (glossary, master data, documents) apply as stated; only other tables' facts are weaker
        d = {"doc": ctx.docs[fx.doc_id].name, "doc_id": fx.doc_id, "doc_kind": ctx.docs[fx.doc_id].kind, "kind": fx.kind,
             "value": fx.value, "text": fx.text, "table": fx.table, "column": fx.column,
             "table_match": fx.table_key in tkeys or fx.table_key == ""}
        if fx.column_key and fx.column_key in cols:
            ctx.by_col[cols[fx.column_key]].append(d)
            if d["table_match"]:
                matched_table_cols.add(fx.column_key)
        elif not fx.column_key and fx.table_key in tkeys:
            ctx.table.append(d)
        elif not fx.column_key and not fx.table_key and fx.kind == "rule_text":
            ctx.sentences.append(d)
        else:
            continue
        ctx.used[fx.doc_id] += 1
    # same column name in other tables of a model: only value lists, patterns, terms and sensitivity carry over
    if cols:
        other = select(ReferenceFact).where(
            ReferenceFact.doc_id.in_(doc_ids), ReferenceFact.column_key.in_([k for k in cols if k not in matched_table_cols]),
            ReferenceFact.table_key != "", ReferenceFact.table_key.notin_(tkeys),
            ReferenceFact.kind.in_(["values", "pattern", "classification", "business_term", "term"])).limit(20000)
        seen = set()
        for fx in db.scalars(other):
            key = (fx.column_key, fx.kind, json.dumps(fx.value, sort_keys=True, default=str), fx.text if fx.kind == "business_term" else "")
            if key in seen:
                continue
            seen.add(key)
            ctx.by_col[cols[fx.column_key]].append({"doc": ctx.docs[fx.doc_id].name, "doc_id": fx.doc_id, "doc_kind": ctx.docs[fx.doc_id].kind,
                                                    "kind": fx.kind, "value": fx.value, "text": fx.text, "table": fx.table,
                                                    "column": fx.column, "table_match": False})
            ctx.used[fx.doc_id] += 1
    for col, facts in ctx.by_col.items():
        for d in facts:
            if d["kind"] == "business_term" and d["text"]:
                ctx.aliases.setdefault(d["text"].lower(), col)
    return ctx


def apply_aliases(text: str, aliases: dict[str, str]) -> str:
    """Replace business terms ("Asset Tag Number") by the column they map to, longest first."""
    for term in sorted(aliases, key=len, reverse=True):
        if len(term) >= 4:
            text = re.sub(rf"(?i)\b{re.escape(term)}\b", aliases[term], text)
    return text


def context_text(ctx: Context, asset: Asset, limit: int = 8000) -> str:
    """Compact reference summary for the LLM prompt."""
    if not ctx.docs:
        return ""
    files = ", ".join("%s (%s)" % (d.name, KINDS[d.kind]["label"]) for d in ctx.docs.values())
    lines = ["Reference files: " + files]
    for d in ctx.table[:8]:
        if d["kind"] in ("table_description", "classification", "pk", "unique", "check"):
            lines.append(f"- table: {d['kind']} {json.dumps(d['value'], default=str) if d['value'] else ''} {d['text'] or ''}".strip())
    for col, facts in ctx.by_col.items():
        parts = []
        for d in facts:
            k, v = d["kind"], d["value"]
            if k in ("not_null", "pk"):
                parts.append("required" if k == "not_null" else "primary key")
            elif k == "values":
                parts.append(f"allowed {v[:25]}" + ("..." if len(v) > 25 else ""))
            elif k == "master_values":
                parts.append(f"master list of {len(v['values'])} values in {v['source']}")
            elif k in ("pattern", "max_length", "min_length", "unit"):
                parts.append(f"{k} {v}")
            elif k == "range":
                parts.append(f"range {v}")
            elif k == "datatype":
                parts.append(f"type {v.get('type')}")
            elif k == "fk":
                parts.append(f"references {v.get('ref_table')}.{v.get('ref_column') or ''}")
            elif k == "classification":
                parts.append(f"sensitivity {v}")
            elif k in ("business_term", "description", "rule_text", "term", "check"):
                parts.append(f"{k.replace('_', ' ')}: {(d['text'] or '')[:220]}")
        if parts:
            lines.append(f"- {col}: " + "; ".join(dict.fromkeys(parts)))
    for d in ctx.sentences[:40]:
        lines.append(f"- rule ({d['doc']}): {d['text'][:300]}")
    # excerpts from documents that mention the table or its columns
    names = {asset.fqn.split(".")[-1].lower()} | {c["name"].lower() for c in (asset.columns or [])}
    for doc in ctx.docs.values():
        if doc.kind not in ("business_doc", "policy") or not doc.text:
            continue
        for para in re.split(r"\n\s*\n", doc.text)[:2000]:
            low = para.lower()
            if any(n in low for n in names if len(n) > 3):
                lines.append("- excerpt (%s): %s" % (doc.name, re.sub(r"\s+", " ", para)[:500]))
    out = "\n".join(lines)
    return out[:limit] + ("\n[truncated]" if len(out) > limit else "")


def summary_view(db, asset: Asset, ids: list[int] | None) -> dict:
    ctx = gather(db, asset, ids)
    return {"asset": asset.fqn, "files": [{"id": d.id, "name": d.name, "kind": d.kind, "facts": ctx.used.get(d.id, 0)}
                                          for d in ctx.docs.values()],
            "facts": ctx.fact_count(), "columns": sorted(ctx.by_col), "table_facts": len(ctx.table),
            "sentences": len(ctx.sentences)}


def list_docs(db) -> list[dict]:
    return [d.public() for d in db.scalars(select(ReferenceDoc).order_by(ReferenceDoc.created.desc()))]


def facts_preview(db, doc_id: int, limit: int = 200) -> list[dict]:
    q = select(ReferenceFact).where(ReferenceFact.doc_id == doc_id).order_by(ReferenceFact.id).limit(limit)
    return [{"table": x.table, "column": x.column, "kind": x.kind, "value": x.value, "text": x.text} for x in db.scalars(q)]


__all__ = ["KINDS", "ingest", "reparse", "delete_doc", "gather", "context_text", "apply_aliases", "summary_view",
           "list_docs", "facts_preview", "decode_upload", "extract", "tkey", "ckey", "asset_table_keys", "utcnow"]
