"""Reset the application database so the app can start fresh.

Only the app's own database (SQLite or Postgres/Lakebase) is touched. Tables in
the monitored platforms (Databricks, Snowflake...) are never changed, and that
includes quarantine tables and fix snapshots: drop those on the platform if you
no longer need them.

After the wipe, what config.yaml and policies.yaml define is loaded again, so
config-defined connections and policies come straight back.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path

from sqlalchemy import func, select

from .config import get_settings
from .db import dialect_name, engine
from .models import AppSetting, AuthSession, Base, Connection, ReferenceDoc, ReferenceFact, User, audit

USER_TABLES = {User.__tablename__, AuthSession.__tablename__}
CONNECTION_TABLES = {Connection.__tablename__, AppSetting.__tablename__}  # platform and LLM setup
REFERENCE_TABLES = {ReferenceDoc.__tablename__, ReferenceFact.__tablename__}
CONFIRM_WORD = "RESET"


def counts(db) -> dict[str, int]:
    """Rows per table, for the confirmation screen."""
    return {t.name: int(db.scalar(select(func.count()).select_from(t)) or 0) for t in Base.metadata.sorted_tables}


def sqlite_path() -> Path | None:
    if dialect_name() != "sqlite":
        return None
    db_path = engine().url.database
    return Path(db_path) if db_path and db_path != ":memory:" else None


def backup_sqlite(dest_dir: Path | None = None) -> str | None:
    """Copy the SQLite database with the online backup API (safe while the app is running)."""
    src = sqlite_path()
    if src is None or not src.exists():
        return None
    dest_dir = dest_dir or src.parent / "backups"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / f"{src.stem}-{datetime.now():%Y%m%d-%H%M%S}{src.suffix or '.db'}"
    with sqlite3.connect(src) as s, sqlite3.connect(dest) as d:
        s.backup(d)
    return str(dest)


def reset_app_data(db, actor: str, keep_users: bool = True, keep_connections: bool = True,
                   backup: bool = True, keep_references: bool = True) -> dict:
    """Delete the app's data. Returns what was removed and kept, and the backup file if one was made."""
    from . import services as S
    from . import scheduler

    keep = set()
    if keep_users:
        keep |= USER_TABLES
    if keep_connections:
        keep |= CONNECTION_TABLES
    if keep_references:
        keep |= REFERENCE_TABLES
    backup_file = backup_sqlite() if backup else None
    before = counts(db)
    for table in reversed(Base.metadata.sorted_tables):  # children first (profiles/rules reference assets)
        if table.name not in keep:
            db.execute(table.delete())
    db.flush()
    if keep_connections:  # keep the definitions, forget the history that belonged to the wiped data
        for row in db.scalars(select(Connection)):
            row.last_sync = row.last_sync_error = None
    S.apply_config(db, get_settings())  # config-defined connections, policies, env admin
    scheduler.reset_state()
    S.reset_llm()
    removed = {t: n for t, n in before.items() if t not in keep and n}
    audit(db, actor, "app.reset", None, kept=sorted(keep), removed_rows=sum(removed.values()),
          backup=backup_file)
    db.flush()
    return {"ok": True, "removed": removed, "kept": sorted(keep), "backup": backup_file,
            "signed_out": not keep_users}
