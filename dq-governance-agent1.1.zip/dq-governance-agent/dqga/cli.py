"""Command line: demo, serve, sync, run, tick, export, contract-check (CI gate)."""
from __future__ import annotations

import argparse
import json
import sys

from .config import load_settings


def default_port() -> int:
    """Databricks Apps tells the app which port to listen on via DATABRICKS_APP_PORT."""
    import os
    return int(os.environ.get("DATABRICKS_APP_PORT") or os.environ.get("PORT") or 8000)


def main(argv: list[str] | None = None) -> int:
    from .dq.exporters import FORMATS

    p = argparse.ArgumentParser(prog="datatrustai", description="TCS DataTrustAI: data quality and governance agent")
    p.add_argument("--config", help="Path to config.yaml (default: ./config.yaml or $DQGA_CONFIG)")
    p.add_argument("--env-file", help="Path to a .env file (default: ./.env; 'none' disables)")
    sub = p.add_subparsers(dest="cmd", required=True)
    dm = sub.add_parser("demo", help="Build the demo warehouse and seed the app (recreates the app database)")
    dm.add_argument("--add", action="store_true", help="Keep the existing app database and add the demo datasets next to your data")
    sv = sub.add_parser("serve", help="Run the web app and API")
    sv.add_argument("--host", default="127.0.0.1")
    sv.add_argument("--port", type=int, default=default_port())
    sub.add_parser("sync", help="Sync catalogs and lineage from all connections")
    rn = sub.add_parser("run", help="Run checks")
    rn.add_argument("--asset", help="Dataset fqn (default: all with active rules)")
    sub.add_parser("tick", help="Run one scheduler tick (cost- and change-aware)")
    ex = sub.add_parser("export", help="Export rules to a native format")
    ex.add_argument("--asset", required=True)
    ex.add_argument("--target", default="dqx", choices=list(FORMATS))
    re_ = sub.add_parser("rules-export", help="Write the rules as one YAML file per dataset (rules as code)")
    re_.add_argument("--out", default="dq-rules", help="Folder to write into (default: dq-rules)")
    re_.add_argument("--asset", help="Only this dataset (fqn)")
    re_.add_argument("--drafts", action="store_true", help="Include saved drafts (default: active and disabled rules)")
    ri = sub.add_parser("rules-import", help="Read rule files (a file, a folder or a zip) and save them as drafts. Without --apply it only shows what would happen")
    ri.add_argument("path")
    ri.add_argument("--apply", action="store_true", help="Save the drafts")
    rv = sub.add_parser("rules-validate", help="Check rule files against the catalog (exit 1 if any file or rule is invalid). Saves nothing; for CI")
    rv.add_argument("path")
    cc = sub.add_parser("contract-check", help="Validate an ODCS contract against the live schema (exit 1 on breaking changes)")
    cc.add_argument("file")
    cu = sub.add_parser("create-user", help="Create a user (e.g. the first administrator) from the command line")
    cu.add_argument("--email", required=True)
    cu.add_argument("--name", default="")
    cu.add_argument("--role", default="admin", choices=["admin", "steward", "viewer"])
    cu.add_argument("--password-env", help="Read the password from this environment variable instead of prompting")
    pk = sub.add_parser("package-app", help="Build a Databricks Apps package (zip) ready to upload and deploy")
    pk.add_argument("--out", default="dist/tcs-datatrustai-databricks-app.zip")
    a = p.parse_args(argv)

    if a.cmd == "package-app":
        from pathlib import Path
        from .deploy import build_app_package, package_files
        out = Path(a.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(build_app_package())
        print(f"Wrote {out} ({len(package_files())} files). Extract it, then follow docs/databricks-setup.md (Path B).")
        return 0

    settings = load_settings(a.config, a.env_file)
    if a.cmd == "demo":
        from .demo.seed import run as seed
        seed(settings, additive=a.add)
        print("\nDone. Start TCS DataTrustAI with:  python -m dqga serve   then open http://127.0.0.1:8000")
        return 0
    if a.cmd == "serve":
        import os
        import uvicorn
        if a.config:
            os.environ["DQGA_CONFIG"] = a.config
        if a.env_file:
            os.environ["DQGA_ENV_FILE"] = a.env_file
        uvicorn.run("dqga.api.main:app", host=a.host, port=a.port)
        return 0

    from . import services as S
    from .db import session_scope
    S.bootstrap(settings)
    if a.cmd == "create-user":
        import getpass
        import os
        from .auth import AuthError, create_user
        if a.password_env:
            pw = os.environ.get(a.password_env, "")
        else:
            pw = getpass.getpass("Password: ")
            if pw != getpass.getpass("Repeat password: "):
                print("Passwords don't match.", file=sys.stderr)
                return 1
        try:
            with session_scope() as db:
                u = create_user(db, a.email, a.name, pw, role=a.role, actor="cli")
                print(f"Created {u.role} {u.email}")
        except AuthError as e:
            print(str(e), file=sys.stderr)
            return 1
        return 0

    with session_scope() as db:
        if a.cmd == "sync":
            print(json.dumps(S.sync_catalog(db), indent=2, default=str))
        elif a.cmd == "run":
            from sqlalchemy import select
            from .dq.runner import run_asset
            from .models import Asset, Rule
            assets = [S.find_asset(db, a.asset)] if a.asset else \
                [x for x in db.scalars(select(Asset)) if db.scalars(select(Rule).where(Rule.asset_id == x.id, Rule.status == "active")).first()]
            failed = 0
            for x in assets:
                r = run_asset(db, x, trigger="cli")
                failed += r["failed"]
                print(f"{x.fqn}: score {r['score']} checks {r['checks']} failed {r['failed']}")
            return 1 if failed else 0
        elif a.cmd == "tick":
            from .scheduler import tick
            print(json.dumps(tick(db), indent=2, default=str))
        elif a.cmd == "export":
            from sqlalchemy import select
            from .dq.exporters import export
            from .models import Rule
            x = S.find_asset(db, a.asset)
            print(export(db.scalars(select(Rule).where(Rule.asset_id == x.id, Rule.status == "active")).all(), a.target, x.fqn))
        elif a.cmd in ("rules-export", "rules-import", "rules-validate"):
            return _rule_files(a, db)
        elif a.cmd == "contract-check":
            from pathlib import Path
            from .connectors import get_connector
            from .governance import contracts
            spec = contracts.parse(Path(a.file).read_text(encoding="utf-8"))
            phys = spec["schema"][0].get("physicalName")
            S.sync_catalog(db)
            x = S.find_asset(db, phys)
            if not x:
                print(f"No dataset matches {phys}", file=sys.stderr)
                return 2
            live = [c.to_dict() for c in get_connector(x.connection).get_columns(x.fqn)]
            res = contracts.validate_against_schema(spec, live)
            for b in res["breaking"]:
                print(f"BREAKING: {b}")
            for w in res["warnings"]:
                print(f"warning: {w}")
            print("Contract OK" if res["ok"] else "Contract check FAILED")
            return 0 if res["ok"] else 1
    return 0


if __name__ == "__main__":
    sys.exit(main())


def _read_rule_files(path: str) -> list[tuple[str, str]]:
    from pathlib import Path
    from . import rulefiles as RF
    p = Path(path)
    if p.is_dir():
        return [(str(f.relative_to(p)), f.read_text(encoding="utf-8")) for f in sorted(p.rglob("*")) if f.suffix.lower() in (".yaml", ".yml")]
    if p.suffix.lower() == ".zip":
        return RF.read_zip(p.read_bytes())
    return [(p.name, p.read_text(encoding="utf-8"))]


def _rule_files(a, db) -> int:
    from pathlib import Path
    from . import rulefiles as RF
    from .models import Asset
    if a.cmd == "rules-export":
        from . import services as S
        ids = [S.find_asset(db, a.asset).id] if a.asset else None
        files = RF.export_files(db, ids, a.drafts)
        for rel, text in files:
            dest = Path(a.out) / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(text, encoding="utf-8")
        print(f"Wrote {len(files)} file(s) to {a.out}")
        return 0
    texts = _read_rule_files(a.path)
    if not texts:
        print(f"No .yaml files found in {a.path}", file=sys.stderr)
        return 2
    plan = RF.plan(db, texts)
    for e in plan["errors"]:
        print(f"ERROR: {e}")
    for d in plan["datasets"]:
        for it in d["items"]:
            if it["action"] != "unchanged":
                print(f"{d['dataset']}: {it['action']}: {it['name']}" + (f" ({it['detail']})" if it.get("detail") else ""))
        for m in d["not_in_file"]:
            print(f"{d['dataset']}: not in file: {m['name']} ({m['status']})")
    t = plan["totals"]
    print(f"{t['datasets']} dataset(s): {t['new']} new, {t['update_draft']} draft update(s), {t['propose_change']} proposed change(s), "
          f"{t['unchanged']} unchanged, {t['invalid']} invalid, {t['not_in_file']} not in file")
    bad = bool(plan["errors"]) or t["invalid"] > 0
    if a.cmd == "rules-import" and a.apply and not bad:
        res = RF.apply(db, texts, "cli")
        print(f"Saved {len(res['created'])} new draft(s) and updated {len(res['updated'])}. Send them for approval in AI Rule Studio.")
    elif a.cmd == "rules-import" and a.apply:
        print("Nothing saved: fix the errors above first.")
    return 1 if bad else 0
