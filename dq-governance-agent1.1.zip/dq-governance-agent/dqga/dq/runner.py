"""Executes an asset's active rules, records results and metrics, updates scores,
then hands failures to incident management."""
from __future__ import annotations

import time
from collections import defaultdict
from datetime import timedelta

from sqlalchemy import select

from ..config import get_settings
from ..connectors import get_connector
from ..models import Asset, CheckResult, MetricPoint, Rule, Run, utcnow
from . import rules as R
from .scoring import refresh_asset_score


def history_fn(db, asset_id: int, baseline_from=None):
    if isinstance(baseline_from, str):
        from datetime import datetime
        baseline_from = datetime.fromisoformat(baseline_from)

    def _h(metric: str, column: str | None):
        q = (select(MetricPoint.ts, MetricPoint.value)
             .where(MetricPoint.asset_id == asset_id, MetricPoint.metric == metric,
                    MetricPoint.ts >= utcnow() - timedelta(days=90)))
        q = q.where(MetricPoint.column == column) if column else q.where(MetricPoint.column.is_(None))
        if baseline_from:
            q = q.where(MetricPoint.ts >= baseline_from)
        return [(t, v) for t, v in db.execute(q.order_by(MetricPoint.ts)).all()]
    return _h


def decide(rule: Rule, o: R.Outcome) -> str:
    if o.status:
        return o.status
    return "pass" if o.pass_rate >= (rule.threshold if rule.threshold is not None else 1.0) - 1e-12 else "fail"


def run_asset(db, asset: Asset, trigger: str = "manual", rule_ids: list[int] | None = None,
              only_types: set[str] | None = None, process_incidents: bool = True, allow_autofix: bool = True,
              schedule_id: int | None = None, actor: str | None = None) -> dict:
    conn = get_connector(asset.connection)
    q = select(Rule).where(Rule.asset_id == asset.id, Rule.status == "active")
    rules = db.scalars(q).all()
    if rule_ids:
        rules = [r for r in rules if r.id in set(rule_ids)]
    if only_types:
        rules = [r for r in rules if r.type in only_types]
    run = Run(asset_id=asset.id, trigger=trigger, schedule_id=schedule_id, actor=actor)
    db.add(run)
    db.flush()
    t_run = time.perf_counter()
    outcomes: dict[int, tuple[R.Outcome, float]] = {}

    # batched row-level rules (one scan per scope)
    groups: dict[str, list[Rule]] = defaultdict(list)
    for r in rules:
        if R.RULE_TYPES[r.type]["row_level"]:
            groups[(r.params or {}).get("where") or ""].append(r)
    for _, grp in groups.items():
        t0 = time.perf_counter()
        try:
            res = R.evaluate_row_batch(conn, asset.fqn, grp)
            cost = (time.perf_counter() - t0) / len(grp)
            for r in grp:
                outcomes[r.id] = (res[r.id], cost)
        except Exception as e:  # one bad rule must not hide the rest: retry individually
            for r in grp:
                t1 = time.perf_counter()
                try:
                    outcomes[r.id] = (R.evaluate_row_batch(conn, asset.fqn, [r])[r.id], time.perf_counter() - t1)
                except Exception as e2:
                    outcomes[r.id] = (R.Outcome(status="error", message=f"{type(e2).__name__}: {e2}"[:1000]),
                                      time.perf_counter() - t1)
            _ = e

    ts_limit = int(get_settings().section("timeseries").get("max_rows", 200000))
    for r in rules:
        if R.RULE_TYPES[r.type]["row_level"]:
            continue
        t0 = time.perf_counter()
        try:
            params_before = dict(r.params or {})
            o = R.evaluate_aggregate(r, asset.fqn, conn,
                                     history_fn(db, asset.id, (r.params or {}).get("baseline_from")),
                                     asset.columns or [], ts_limit=ts_limit)
            if r.params != params_before:  # e.g. PSI baseline captured on first run
                r.params = dict(r.params)
        except Exception as e:
            o = R.Outcome(status="error", message=f"{type(e).__name__}: {e}"[:1000])
        outcomes[r.id] = (o, time.perf_counter() - t0)

    results = []
    recorded_metrics = set()
    for r in rules:
        o, cost = outcomes[r.id]
        status = decide(r, o)
        cr = CheckResult(run_id=run.id, rule_id=r.id, asset_id=asset.id, status=status, total=o.total,
                         failed=o.failed, pass_rate=round(o.pass_rate, 6), observed=o.observed,
                         message=o.message, failing_sql=o.failing_sql, duration_s=round(cost, 4))
        db.add(cr)
        results.append(cr)
        r.last_run, r.last_status = utcnow(), status
        r.est_cost_s = round(0.7 * (r.est_cost_s or cost) + 0.3 * cost, 4)
        if o.metric and o.metric[:2] not in recorded_metrics:
            recorded_metrics.add(o.metric[:2])
            db.add(MetricPoint(asset_id=asset.id, metric=o.metric[0], column=o.metric[1], value=float(o.metric[2])))
        if r.type in ("not_null",) and o.total and ("row_count", None) not in recorded_metrics:
            recorded_metrics.add(("row_count", None))
            db.add(MetricPoint(asset_id=asset.id, metric="row_count", value=float(o.total)))
            asset.row_count = o.total

    db.flush()
    refresh_asset_score(db, asset)
    asset.last_run = utcnow()
    try:
        asset.last_checked_marker = conn.change_marker(asset.fqn)
    except Exception:
        pass
    run.duration_s = round(time.perf_counter() - t_run, 3)
    run.checks = len(results)
    run.failed = sum(1 for c in results if c.status == "fail")
    run.errors = sum(1 for c in results if c.status == "error")
    run.status = "error" if run.errors else "ok"
    db.flush()

    incident_ids = []
    corrections = []
    if process_incidents:
        from ..incidents.manager import process_results
        incident_ids = process_results(db, asset, results)
        failing_ids = [c.rule_id for c in results if c.status == "fail"]
        if allow_autofix and failing_ids:
            from ..incidents.autofix import auto_correct
            fixes = auto_correct(db, asset, failing_ids, incident_ids)
            if fixes:
                recheck = run_asset(db, asset, trigger="auto-correct", rule_ids=sorted({f.rule_id for f in fixes}), allow_autofix=False)
                for f in fixes:
                    st = next((r["status"] for r in recheck["results"] if r["rule_id"] == f.rule_id), None)
                    f.detail = {**(f.detail or {}), "recheck": st}
                    corrections.append({"fix_run": f.id, "title": f.title, "rows": f.rows, "recheck": st})

    return {"run_id": run.id, "asset": asset.fqn, "checks": run.checks, "failed": run.failed,
            "errors": sum(1 for c in results if c.status == "error"), "score": asset.score,
            "duration_s": run.duration_s, "incidents": incident_ids, "auto_corrections": corrections,
            "results": [{"rule_id": c.rule_id, "status": c.status, "pass_rate": c.pass_rate, "message": c.message}
                        for c in results]}
