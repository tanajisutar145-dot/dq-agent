"""Data governance rule proposals: privacy, security, retention, consent, audit trail and regulatory.

Sources, strongest first:
  * sensitivity from reference files (ontology cmm:sensitivity, glossary classification, JSON Schema format email);
  * confirmed or suggested classifications stored for the dataset (Governance > Classification);
  * column-name hints (ssn, card_no, email, birth_date...).

Proposals are checks the data itself can pass or fail:
  * restricted identifiers (SSN, card, IBAN) must not be stored in clear text (pattern must NOT match);
  * contact details only with consent, when a consent column exists;
  * soft-deleted records keep no personal data (right to erasure);
  * personal or financial records are not kept past the retention period;
  * audit columns (created_by, approved_by...) are always filled; maker and checker differ (SOX);
  * regulatory classification and consent columns are always filled (NERC CIP, GDPR lawful basis).
"""
from __future__ import annotations

import re

from sqlalchemy import select

from ..governance.classification import NAME_HINTS, SENSITIVITY
from ..grouping import is_financial
from ..models import Asset, Classification

RAW_PATTERNS = {  # what an unmasked value looks like
    "ssn": r"[0-9]{3}-?[0-9]{2}-?[0-9]{4}",
    "credit_card": r"([0-9][ -]?){13,19}",
    "iban": r"[A-Z]{2}[0-9]{2}[A-Z0-9]{11,30}",
    "national_id": r"[A-Z]{2}[0-9]{6}[A-D]",
}
RESTRICTED = {"ssn", "credit_card", "iban", "national_id", "passport", "pii_financial", "financial", "restricted"}
CONTACT = {"email", "phone", "pii_email", "pii_phone"}
PERSONAL = {"email", "phone", "person_name", "address", "date_of_birth", "pii", "pii_email", "pii_phone", "pii_address",
            "pii_dob", "pii_name", "pii_financial", "pii_health", "pii_device", "ssn", "credit_card", "iban", "national_id",
            "passport", "confidential_personal"}
FRAMEWORK_NOTE = {
    "restricted": "GDPR Art. 32 and PCI DSS 3.4: restricted identifiers are stored masked, tokenized or encrypted",
    "consent": "GDPR Art. 6 and 7: contact details are processed only with a recorded lawful basis or consent",
    "erasure": "GDPR Art. 17 (right to erasure): deleted records keep no personal data",
    "retention": "GDPR Art. 5(1)(e) storage limitation; SOX and utility record-keeping rules set the retention period",
    "audit": "SOX ITGC: changes to financial records are attributable to a user",
    "sod": "SOX segregation of duties: the person who creates a record doesn't approve it",
    "classification": "NERC CIP-002 and data governance policy: every record carries its regulatory classification",
    "lawful_basis": "GDPR Art. 6: the lawful basis or consent status is recorded for every data subject",
}


def _cand(rule: dict, conf: float, *evidence: str, origin: str = "Governance") -> dict:
    return {**rule, "confidence": round(max(0.05, min(conf, 0.99)), 2), "category": origin,
            "evidence": [e for e in evidence if e], "rule_category": "governance"}


def sensitivity_map(db, asset: Asset, cols: list[dict], ref_ctx=None) -> dict[str, tuple[str, str]]:
    """column -> (label, where the label came from)."""
    out: dict[str, tuple[str, str]] = {}
    names = {c["name"] for c in cols}
    if ref_ctx is not None:
        for col, facts in ref_ctx.by_col.items():
            labels = [str(d["value"]).lower() for d in facts if d["kind"] == "classification" and d["value"]]
            if labels:
                best = next((lb for lb in labels if lb in RESTRICTED), next((lb for lb in labels if lb.startswith("pii")), labels[0]))
                out[col] = (best, f"{facts[0]['doc']} marks {col} as {', '.join(dict.fromkeys(labels))}")
    for c in db.scalars(select(Classification).where(Classification.asset_id == asset.id, Classification.status != "rejected")):
        if c.column in names and c.column not in out:
            out[c.column] = (c.label, f"classified as {c.label} ({c.method}, {c.confidence:.0%})")
    for c in cols:
        if c["name"] in out:
            continue
        low = c["name"].lower()
        for label, pats in NAME_HINTS.items():
            if label in ("geo_location", "customer_ref", "ip_address"):
                continue
            if any(re.search(p, low) for p in pats):
                out[c["name"]] = (label, f"the name {c['name']} suggests {label.replace('_', ' ')}")
                break
    return out


_NUMWORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
             "eleven": 11, "twelve": 12, "fifteen": 15, "twenty": 20, "thirty": 30}
_RETAIN = re.compile(r"\b(?:kept|keep|retain(?:ed)?|stored?|held|hold|archived?)\b[^.;]*?\b(?:longer than|more than|beyond|over|for(?: up to)?|up to|at most|maximum of)\s+"
                     r"(\d+|" + "|".join(_NUMWORDS) + r")\s+(years?|months?|days?)", re.I)


def retention_from_policy(ref_ctx) -> tuple[int, str] | None:
    """A retention period stated in a policy or glossary sentence, e.g. 'Personal data must not be kept longer than seven years'."""
    if ref_ctx is None:
        return None
    texts = [d for d in ref_ctx.sentences] + [d for facts in ref_ctx.by_col.values() for d in facts if d["kind"] == "rule_text"]
    for d in texts:
        m = _RETAIN.search(d.get("text") or "")
        if m:
            n = int(m.group(1)) if m.group(1).isdigit() else _NUMWORDS[m.group(1).lower()]
            unit = m.group(2).lower()
            days = n * (365 if unit.startswith("year") else 30 if unit.startswith("month") else 1)
            return days, f"{d['doc']}: “{d['text'][:200]}”"
    return None


def _find(cols, pattern, family=None):
    return next((c for c in cols if re.search(pattern, c["name"].lower()) and (family is None or c.get("family") == family)), None)


def governance_candidates(db, asset: Asset, cols: list[dict], prof: dict, ref_ctx=None, retention_days: int = 2555) -> list[dict]:
    out: list[dict] = []
    sens = sensitivity_map(db, asset, cols, ref_ctx)
    fam = {c["name"]: c.get("family") for c in cols}
    cp = prof.get("columns", {}) if prof else {}
    personal = [c for c, (lb, _) in sens.items() if lb in PERSONAL or lb.startswith("pii") or SENSITIVITY.get(lb) in ("restricted", "confidential")]

    # 1. restricted identifiers never in clear text
    for col, (label, why) in sens.items():
        pat = RAW_PATTERNS.get(label) or (RAW_PATTERNS["credit_card"] if label in ("pii_financial", "financial") and
                                          re.search(r"card|pan|account|iban", col.lower()) else None)
        if pat and fam.get(col) in ("string", None):
            out.append(_cand({"type": "regex", "column": col, "params": {"pattern": pat, "negate": True}, "severity": "critical",
                              "name": f"{col} not stored in clear text"}, 0.75, why, FRAMEWORK_NOTE["restricted"],
                             "Fails for any value that looks like a raw identifier; masked or tokenized values pass"))
    # 2. contact details only with consent
    consent = _find(cols, r"consent|opt_?in|marketing_?(ok|allowed|permission)|gdpr_?(ok|consent)")
    if consent:
        ok = f"{consent['name']} = TRUE" if consent.get("family") == "boolean" else \
            f"UPPER(CAST({consent['name']} AS VARCHAR(10))) IN ('Y', 'YES', 'TRUE', '1', 'GRANTED', 'OPT_IN', 'OPTED_IN')"
        for col, (label, why) in sens.items():
            if label in CONTACT or "email" in label or "phone" in label:
                out.append(_cand({"type": "custom_sql", "column": col, "params": {"expression": f"{col} IS NULL OR {ok}"},
                                  "severity": "high", "name": f"{col} held only with consent ({consent['name']})"}, 0.68,
                                 why, f"{consent['name']} records consent", FRAMEWORK_NOTE["consent"]))
        out.append(_cand({"type": "not_null", "column": consent["name"], "severity": "high"}, 0.72,
                         f"{consent['name']} records consent or lawful basis", FRAMEWORK_NOTE["lawful_basis"]))
    # 3. right to erasure on soft-deleted rows
    deleted = _find(cols, r"^(is_)?deleted$|deleted_flag|is_deleted|delete_flag|erased")
    deleted_at = _find(cols, r"deleted_(at|ts|date|timestamp)|erased_(at|on)", "temporal")
    marker = None
    if deleted_at:
        marker = f"{deleted_at['name']} IS NOT NULL"
    elif deleted:
        marker = f"{deleted['name']} = TRUE" if deleted.get("family") == "boolean" else \
            f"UPPER(CAST({deleted['name']} AS VARCHAR(10))) IN ('Y', 'YES', 'TRUE', '1')"
    if marker:
        for col in personal[:4]:
            out.append(_cand({"type": "custom_sql", "column": col, "params": {"expression": f"NOT ({marker}) OR {col} IS NULL"},
                              "severity": "high", "name": f"deleted records keep no {col}"}, 0.6,
                             sens[col][1], FRAMEWORK_NOTE["erasure"]))
    # 4. retention
    financial = is_financial(asset.domain) or any(lb in ("pii_financial", "financial") for lb, _ in sens.values())
    if personal or financial:
        ts = _find(cols, r"(created|inserted|record|event|transaction|posting|invoice|reading|start)_?(at|ts|date|time|timestamp)?$", "temporal") \
            or next((c for c in cols if c.get("family") == "temporal" and not re.search(r"birth|dob|expir|valid_to|end", c["name"].lower())), None)
        if ts:
            stated = retention_from_policy(ref_ctx)
            days = stated[0] if stated else retention_days
            years = round(days / 365.25, 1)
            out.append(_cand({"type": "retention", "column": ts["name"], "params": {"max_age_days": days}, "severity": "medium",
                              "name": f"no records older than {years:g} years ({ts['name']})" if days >= 365 else f"no records older than {days} days ({ts['name']})"},
                             0.8 if stated else 0.55,
                             *( [stated[1]] if stated else []),
                             ("Holds personal data: " + ", ".join(personal[:5])) if personal else f"Financial records ({asset.domain or 'amounts'})",
                             FRAMEWORK_NOTE["retention"],
                             "" if stated else f"Retention period {retention_days} days (governance.retention_days); confirm with your records schedule"))
    # 5. audit trail and segregation of duties
    makers = [c for c in cols if re.search(r"^(created|inserted|updated|modified|posted|entered)_by$|_by_user$", c["name"].lower())]
    checker = _find(cols, r"^(approved|authori[sz]ed|reviewed|verified)_by$")
    if makers and (financial or checker):
        for c in makers[:3]:
            out.append(_cand({"type": "not_null", "column": c["name"], "severity": "high"}, 0.7,
                             f"{c['name']} records who changed the record", FRAMEWORK_NOTE["audit"]))
    if checker:
        out.append(_cand({"type": "not_null", "column": checker["name"], "severity": "high"}, 0.66,
                         f"{checker['name']} records the approver", FRAMEWORK_NOTE["audit"]))
        maker = next((c for c in makers if c["name"].lower().startswith(("created", "posted", "entered"))), makers[0] if makers else None)
        if maker:
            out.append(_cand({"type": "custom_sql", "column": checker["name"],
                              "params": {"expression": f"{checker['name']} IS NULL OR {maker['name']} IS NULL OR {checker['name']} <> {maker['name']}"},
                              "severity": "high", "name": f"{maker['name']} and {checker['name']} differ"}, 0.62,
                             f"{maker['name']} and {checker['name']} both exist", FRAMEWORK_NOTE["sod"]))
    # 6. regulatory classification columns always filled
    for c in cols:
        low = c["name"].lower()
        if re.search(r"nerc|(^|_)cip(_|$)|critical_asset|bes_|regulatory_class|data_class|sensitivity|security_zone|"
                     r"compliance_(flag|status|class)|privacy_(flag|class)|gdpr|legal_basis", low) and c is not consent:
            p = cp.get(c["name"]) or {}
            out.append(_cand({"type": "not_null", "column": c["name"], "severity": "high"}, 0.7 if p.get("null_rate", 0) == 0 else 0.6,
                             f"{c['name']} is a regulatory or privacy classification", FRAMEWORK_NOTE["classification"]))
    return out
