"""Rule categories: every rule belongs to one of three sets.

  core        Core data: completeness, data types, formats, keys, references,
              freshness, volume and schema. Technical rules any dataset needs.
  business    Business domain: allowed values, business ranges, cross-column
              logic and rules from glossaries, master data and business documents.
  governance  Data governance: privacy, security, retention, consent, audit
              trail and regulatory (GDPR, SOX, NERC CIP...) rules.
"""
from __future__ import annotations

CATEGORIES = {
    "core": {"label": "Core data", "desc": "Nulls, data types, formats, keys, references, freshness, volume and schema"},
    "business": {"label": "Business domain", "desc": "Allowed values, business ranges and logic from domain documents, glossaries and master data"},
    "governance": {"label": "Data governance", "desc": "Privacy, security, retention, consent, audit trail and regulatory compliance"},
}
PRIORITY = {"core": 0, "business": 1, "governance": 2}

CORE_TYPES = {"not_null", "unique", "schema", "length", "regex", "not_future", "freshness", "row_count", "anomaly", "referential"}
BUSINESS_TYPES = {"accepted_values", "custom_sql", "reconciliation", "timeseries"}
BUSINESS_SOURCES = {"nl", "llm", "contract", "glossary", "business", "reference_business"}
GOVERNANCE_SOURCES = {"governance", "policy", "reference_governance"}


def infer(rule: dict) -> str:
    """Category for a rule dict (type, params, source, category)."""
    cat = rule.get("category")
    if cat in CATEGORIES:
        return cat
    t, p, src = rule.get("type"), rule.get("params") or {}, (rule.get("source") or "").lower()
    if t == "retention" or p.get("negate") or src in GOVERNANCE_SOURCES:
        return "governance"
    if t in BUSINESS_TYPES or src in BUSINESS_SOURCES and t not in ("not_null", "unique", "schema", "freshness", "row_count", "anomaly"):
        return "business"
    if t == "range" and src not in ("", "manual", "suggested", "discovery"):
        return "business"
    return "core"


def stronger(a: str | None, b: str | None) -> str:
    """When two sources propose the same rule, the more specific set wins (governance > business > core)."""
    a, b = a or "core", b or "core"
    return a if PRIORITY.get(a, 0) >= PRIORITY.get(b, 0) else b


def backfill(db) -> int:
    """Give existing rules a category (runs at startup; cheap when nothing is missing)."""
    from sqlalchemy import select

    from ..models import Rule
    n = 0
    for r in db.scalars(select(Rule).where(Rule.category.is_(None))):
        r.category = infer({"type": r.type, "params": r.params, "source": r.source})
        n += 1
    return n
