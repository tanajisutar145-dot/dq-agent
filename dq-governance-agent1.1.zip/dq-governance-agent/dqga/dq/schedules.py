"""Run rules on demand, schedule rule sets, and report on runs.

A schedule picks active rules by scope (rule set, minimum severity, datasets,
platform, or explicit rules) and runs them on a cadence: every N minutes, or at
a time of day (UTC) on chosen weekdays. Rules covered by an enabled schedule
follow that schedule; the background scheduler's default interval only applies
to rules no schedule covers.
"""
from __future__ import annotations

import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta

from sqlalchemy import select

from ..connectors import all_connectors, is_disabled
from ..models import Asset, CheckResult, Rule, RuleSchedule, Run, utcnow
from .categories import CATEGORIES
from .rules import SEVERITIES, SEVERITY_WEIGHT

CADENCES = ("interval", "daily")
MIN_INTERVAL = 5
TIME_RE = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")
DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
TRIGGER_LABELS = {"manual": "Run now", "schedule": "Schedule", "agent": "Agent", "cli": "Command line",
                  "demo": "Demo seed", "auto-correct": "Re-check after auto-correct", "correction": "Re-check after a fix",
                  "refresh": "Insights refresh"}


# ------------------------------------------------------------------ validation
def clean_scope(scope: dict | None) -> dict:
    s = scope or {}
    out = {"category": s.get("category") or None, "severity": s.get("severity") or None,
           "asset_ids": sorted({int(x) for x in (s.get("asset_ids") or [])}),
           "platform": s.get("platform") or None, "rule_ids": sorted({int(x) for x in (s.get("rule_ids") or [])})}
    if out["category"] and out["category"] not in CATEGORIES:
        raise ValueError(f"Unknown rule set {out['category']!r}. Use one of: {', '.join(CATEGORIES)}")
    if out["severity"] and out["severity"] not in SEVERITIES:
        raise ValueError(f"Unknown severity {out['severity']!r}. Use one of: {', '.join(SEVERITIES)}")
    return out


def validate(body: dict) -> dict:
    name = (body.get("name") or "").strip()
    if not name:
        raise ValueError("Give the schedule a name")
    cadence = body.get("cadence") or "interval"
    if cadence not in CADENCES:
        raise ValueError("Cadence must be 'interval' (every N minutes) or 'daily' (at a time of day)")
    out = {"name": name[:200], "cadence": cadence, "enabled": bool(body.get("enabled", True)),
           "scope": clean_scope(body.get("scope")), "every_minutes": None, "at_time": None, "weekdays": []}
    if cadence == "interval":
        every = int(body.get("every_minutes") or 0)
        if every < MIN_INTERVAL:
            raise ValueError(f"Run at most every {MIN_INTERVAL} minutes")
        out["every_minutes"] = every
    else:
        at = (body.get("at_time") or "").strip()
        if not TIME_RE.match(at):
            raise ValueError("Give the time of day as HH:MM (24-hour, UTC)")
        days = sorted({int(d) for d in (body.get("weekdays") or [])})
        if any(d < 0 or d > 6 for d in days):
            raise ValueError("Weekdays are 0 (Monday) to 6 (Sunday)")
        out["at_time"], out["weekdays"] = at, days
    return out


# ------------------------------------------------------------------ cadence
def next_after(s: RuleSchedule, after: datetime) -> datetime:
    if s.cadence == "interval":
        return after + timedelta(minutes=max(MIN_INTERVAL, s.every_minutes or 60))
    hh, mm = (int(x) for x in (s.at_time or "00:00").split(":"))
    cand = after.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if cand <= after:
        cand += timedelta(days=1)
    days = set(s.weekdays or [])
    for _ in range(8):
        if not days or cand.weekday() in days:
            return cand
        cand += timedelta(days=1)
    return cand


def cadence_text(s: RuleSchedule) -> str:
    if s.cadence == "interval":
        m = s.every_minutes or 60
        if m % 1440 == 0:
            return "every day" if m == 1440 else f"every {m // 1440} days"
        if m % 60 == 0:
            return "every hour" if m == 60 else f"every {m // 60} hours"
        return f"every {m} minutes"
    days = sorted(s.weekdays or [])
    when = "every day" if not days or len(days) == 7 else ("weekdays" if days == [0, 1, 2, 3, 4] else ", ".join(DAY_NAMES[d] for d in days))
    return f"{when} at {s.at_time} UTC"


# ------------------------------------------------------------------ scope
def matching_rules(db, scope: dict) -> list[Rule]:
    sc = clean_scope(scope)
    q = select(Rule).where(Rule.status == "active")
    if sc["rule_ids"]:
        q = q.where(Rule.id.in_(sc["rule_ids"]))
    if sc["category"]:
        q = q.where(Rule.category == sc["category"])
    if sc["asset_ids"]:
        q = q.where(Rule.asset_id.in_(sc["asset_ids"]))
    if sc["platform"]:
        q = q.where(Rule.asset_id.in_(select(Asset.id).where(Asset.platform == sc["platform"])))
    rules = list(db.scalars(q.order_by(Rule.asset_id, Rule.id)))
    if sc["severity"]:
        floor = SEVERITY_WEIGHT[sc["severity"]]
        rules = [r for r in rules if SEVERITY_WEIGHT.get(r.severity, 2) >= floor]
    return rules


def scope_text(db, scope: dict) -> str:
    sc = clean_scope(scope)
    if sc["rule_ids"]:
        what = f"{len(sc['rule_ids'])} chosen rule(s)"
    else:
        what = (CATEGORIES[sc["category"]]["label"] + " rules") if sc["category"] else "All rule sets"
    parts = [what]
    if sc["severity"]:
        parts.append(f"{sc['severity']} severity" + ("" if sc["severity"] == "critical" else " and above"))
    if sc["asset_ids"]:
        if len(sc["asset_ids"]) == 1:
            a = db.get(Asset, sc["asset_ids"][0])
            parts.append(f"on {a.fqn if a else 'a removed dataset'}")
        else:
            parts.append(f"on {len(sc['asset_ids'])} datasets")
    else:
        parts.append("on all datasets")
    if sc["platform"]:
        parts.append(f"{sc['platform']} only")
    return ", ".join(parts)


def _runnable(asset: Asset) -> str | None:
    """Why this dataset can't run now, or None."""
    if is_disabled(asset.connection):
        return f"connection {asset.connection} is disabled"
    if asset.connection not in all_connectors():
        return f"connection {asset.connection} is not available"
    return None


def _seconds_per_check(db, asset_id: int) -> float | None:
    """Average seconds per check over the dataset's recent runs (row-level checks share one scan, so this beats per-rule sums)."""
    recent = db.execute(select(Run.duration_s, Run.checks).where(Run.asset_id == asset_id, Run.checks > 0)
                        .order_by(Run.ts.desc()).limit(5)).all()
    checks = sum(c for _, c in recent)
    return sum(d or 0 for d, _ in recent) / checks if checks else None


def preview(db, scope: dict) -> dict:
    rules = matching_rules(db, scope)
    by_asset: dict[int, list[Rule]] = defaultdict(list)
    for r in rules:
        by_asset[r.asset_id].append(r)
    rows, skipped = [], []
    for aid, rs in by_asset.items():
        a = db.get(Asset, aid)
        if not a:
            continue
        why = _runnable(a)
        per = _seconds_per_check(db, aid)
        est = per * len(rs) if per is not None else sum(r.est_cost_s or 1.0 for r in rs)
        (skipped if why else rows).append({"asset_id": aid, "fqn": a.fqn, "rules": len(rs), **({"reason": why} if why else {}),
                                           "est_seconds": round(est, 2)})
    return {"rules": sum(x["rules"] for x in rows), "datasets": len(rows), "by_dataset": rows, "skipped": skipped,
            "est_seconds": round(sum(x["est_seconds"] for x in rows), 2), "text": scope_text(db, scope)}


# ------------------------------------------------------------------ running
def run_rules(db, rules: list[Rule], trigger: str = "manual", actor: str | None = None,
              schedule_id: int | None = None) -> dict:
    from .runner import run_asset

    by_asset: dict[int, list[int]] = defaultdict(list)
    for r in rules:
        by_asset[r.asset_id].append(r.id)
    out = {"rules": len(rules), "datasets": 0, "checks": 0, "failed": 0, "errors": 0, "duration_s": 0.0,
           "incidents": 0, "runs": [], "skipped": [], "failures": []}
    for aid, ids in by_asset.items():
        a = db.get(Asset, aid)
        if not a:
            continue
        why = _runnable(a)
        if why:
            out["skipped"].append({"fqn": a.fqn, "reason": why, "rules": len(ids)})
            continue
        try:
            res = run_asset(db, a, trigger=trigger, rule_ids=ids, schedule_id=schedule_id, actor=actor)
        except Exception as e:  # one unreachable dataset must not stop the rest
            out["failures"].append({"fqn": a.fqn, "error": f"{type(e).__name__}: {e}"[:400]})
            continue
        out["datasets"] += 1
        for k in ("checks", "failed", "errors"):
            out[k] += res[k]
        out["duration_s"] += res["duration_s"]
        out["incidents"] += len(res.get("incidents") or [])
        out["runs"].append({"run_id": res["run_id"], "asset_id": a.id, "fqn": a.fqn, "checks": res["checks"],
                            "failed": res["failed"], "errors": res["errors"], "duration_s": res["duration_s"]})
    out["duration_s"] = round(out["duration_s"], 3)
    out["status"] = outcome(out)
    return out


def outcome(summary: dict) -> str:
    if summary["failures"] or summary["errors"]:
        return "error"
    if summary["failed"]:
        return "failures"
    if not summary["checks"]:
        return "empty"
    return "ok"


def run_schedule(db, s: RuleSchedule, actor: str | None = None, manual: bool = False) -> dict:
    res = run_rules(db, matching_rules(db, s.scope), trigger="manual" if manual else "schedule",
                    actor=actor or f"schedule:{s.name}", schedule_id=s.id)
    now = utcnow()
    s.last_run, s.last_status = now, res["status"]
    s.last_summary = {k: res[k] for k in ("rules", "datasets", "checks", "failed", "errors", "duration_s", "incidents")} | {
        "skipped": res["skipped"][:10], "failures": res["failures"][:10], "manual": manual}
    if not manual or s.next_run is None:
        s.next_run = next_after(s, now)
    db.flush()
    return {"schedule_id": s.id, "name": s.name, **res}


def ensure_next(db, s: RuleSchedule) -> None:
    if s.enabled and s.next_run is None:
        s.next_run = next_after(s, utcnow())


def due(db, now: datetime | None = None) -> list[RuleSchedule]:
    now = now or utcnow()
    out = []
    for s in db.scalars(select(RuleSchedule).where(RuleSchedule.enabled.is_(True)).order_by(RuleSchedule.id)):
        ensure_next(db, s)
        if s.next_run and s.next_run <= now:
            out.append(s)
    return out


def covered_rule_ids(db) -> set[int]:
    ids: set[int] = set()
    for s in db.scalars(select(RuleSchedule).where(RuleSchedule.enabled.is_(True))):
        ids |= {r.id for r in matching_rules(db, s.scope)}
    return ids


def view(db, s: RuleSchedule) -> dict:
    p = preview(db, s.scope)
    return {**s.to_dict(), "cadence_text": cadence_text(s), "scope_text": p["text"], "rules": p["rules"],
            "datasets": p["datasets"], "skipped": p["skipped"]}


# ------------------------------------------------------------------ run history
def _status_of(r: Run) -> str:
    if r.status == "error" or (r.errors or 0):
        return "error"
    return "failures" if r.failed else "ok"


def list_runs(db, days: int = 7, asset_id: int | None = None, trigger: str | None = None, status: str | None = None,
              schedule_id: int | None = None, limit: int = 200) -> dict:
    days = max(1, min(int(days or 7), 90))
    since = utcnow() - timedelta(days=days)
    q = select(Run).where(Run.ts >= since)
    if asset_id:
        q = q.where(Run.asset_id == asset_id)
    if trigger:
        q = q.where(Run.trigger == trigger)
    if schedule_id:
        q = q.where(Run.schedule_id == schedule_id)
    runs = list(db.scalars(q.order_by(Run.ts.desc())))
    if status:
        runs = [r for r in runs if _status_of(r) == status]
    assets = {a.id: a for a in db.scalars(select(Asset))}
    scheds = {s.id: s.name for s in db.scalars(select(RuleSchedule))}
    # runs written before the errors column existed: count error results once, in bulk
    missing = [r.id for r in runs if r.errors is None]
    err = Counter()
    if missing:
        for rid in db.scalars(select(CheckResult.run_id).where(CheckResult.run_id.in_(missing[:2000]), CheckResult.status == "error")):
            err[rid] += 1
    by_day: dict = defaultdict(lambda: {"passed": 0, "failed": 0, "errors": 0, "runs": 0})
    rows = []
    for r in runs:
        e = r.errors if r.errors is not None else err.get(r.id, 0)
        d = by_day[r.ts.date().isoformat()]
        d["runs"] += 1
        d["failed"] += r.failed or 0
        d["errors"] += e
        d["passed"] += max(0, (r.checks or 0) - (r.failed or 0) - e)
        if len(rows) < limit:
            a = assets.get(r.asset_id)
            rows.append({"id": r.id, "ts": r.ts.isoformat(timespec="seconds"), "asset_id": r.asset_id, "fqn": a.fqn if a else f"#{r.asset_id}",
                         "platform": a.platform if a else None, "trigger": r.trigger, "trigger_label": TRIGGER_LABELS.get(r.trigger, r.trigger),
                         "schedule_id": r.schedule_id, "schedule": scheds.get(r.schedule_id), "actor": r.actor,
                         "checks": r.checks, "failed": r.failed, "errors": e, "duration_s": r.duration_s, "status": _status_of(r)})
    dates = [(since + timedelta(days=i + 1)).date().isoformat() for i in range(days)]
    total_checks = sum(r.checks or 0 for r in runs)
    stats = {"runs": len(runs), "checks": total_checks, "failed": sum(r.failed or 0 for r in runs),
             "errors": sum(x["errors"] for x in by_day.values()), "datasets": len({r.asset_id for r in runs}),
             "scheduled": sum(1 for r in runs if r.trigger == "schedule"),
             "avg_duration_s": round(sum(r.duration_s or 0 for r in runs) / len(runs), 2) if runs else None,
             "failed_runs": sum(1 for r in runs if _status_of(r) != "ok")}
    return {"days": days, "stats": stats, "runs": rows, "truncated": len(runs) > limit,
            "by_day": [{"date": d, **by_day.get(d, {"passed": 0, "failed": 0, "errors": 0, "runs": 0})} for d in dates],
            "triggers": sorted({r.trigger for r in runs})}


def run_detail(db, run_id: int) -> dict | None:
    r = db.get(Run, run_id)
    if not r:
        return None
    a = db.get(Asset, r.asset_id)
    s = db.get(RuleSchedule, r.schedule_id) if r.schedule_id else None
    results = list(db.scalars(select(CheckResult).where(CheckResult.run_id == r.id).order_by(CheckResult.id)))
    rules = {x.id: x for x in db.scalars(select(Rule).where(Rule.id.in_([c.rule_id for c in results] or [0])))}
    order = {"error": 0, "fail": 1, "warn": 2, "pass": 3}
    checks = sorted(({"rule_id": c.rule_id, "rule": rules[c.rule_id].name if c.rule_id in rules else f"rule #{c.rule_id}",
                      "severity": rules[c.rule_id].severity if c.rule_id in rules else None,
                      "dimension": rules[c.rule_id].dimension if c.rule_id in rules else None,
                      "status": c.status, "pass_rate": c.pass_rate, "failed": c.failed, "total": c.total,
                      "message": c.message, "duration_s": c.duration_s} for c in results),
                    key=lambda x: (order.get(x["status"], 9), x["rule"]))
    return {"id": r.id, "ts": r.ts.isoformat(timespec="seconds"), "asset_id": r.asset_id, "fqn": a.fqn if a else None,
            "trigger": r.trigger, "trigger_label": TRIGGER_LABELS.get(r.trigger, r.trigger), "schedule": s.name if s else None,
            "actor": r.actor, "duration_s": r.duration_s, "status": _status_of(r), "checks": checks}
