"""AI rule discovery: propose rules from schema, data types, statistics, history,
relationships, business context and what other datasets already use.

Every candidate has a confidence (0-1), a category, human-readable evidence, and
a dry-run result on live data. Nothing is saved until a person accepts it.

Evidence sources (category):
  Semantic type      column meaning inferred from name, type and values (ids, emails, amounts, %...)
  Statistics         the current profile (nulls, distincts, ranges, patterns)
  History            stored profiles and metric history (stable ranges, null-rate ceilings, volume, lateness)
  Relationship       cross-column facts that always hold (created <= updated, min <= max)
  Business context   glossary terms, domain, dataset and column descriptions (parsed as plain-English rules)
  Learned            the same rule on the same column name in other datasets
  Observability      volume, freshness, schema and distribution monitors
  Glossary           a business term mapped to the dataset or a column, whose definition states a rule
  Contract           promises in the dataset's active data contract that no active rule covers yet
  Policy             a policy that applies (retention period; minimum rules; protecting sensitive columns)
  Standard           a control of a chosen standard (GDPR, SOX...) that proposals would help meet
  LLM                business rules proposed by the configured model from metadata (never raw rows)
"""
from __future__ import annotations

import json
import re
from collections import defaultdict
from datetime import timedelta
from statistics import pstdev

from sqlalchemy import func, select

from .. import grouping as G
from ..connectors import get_connector
from ..models import Asset, GlossaryLink, GlossaryTerm, MetricPoint, Profile, Rule, utcnow
from . import rules as R
from .categories import CATEGORIES, stronger
from .suggester import EMAIL_RE, heuristic_suggestions, llm_suggestions

PHONE_RE = r"\+?[0-9][0-9 ()\-.]{6,18}[0-9]"
ORDER_HINTS = [("created", "updated"), ("created", "modified"), ("start", "end"), ("begin", "end"), ("from", "to"),
               ("reading", "ingested"), ("order", "ship"), ("ship", "deliver"), ("issued", "paid"), ("open", "close"),
               ("min", "max"), ("low", "high"), ("event", "ingested"), ("event", "loaded"), ("valid_from", "valid_to")]


def _cand(rule: dict, conf: float, category: str, *evidence: str) -> dict:
    return {**rule, "confidence": round(max(0.05, min(conf, 0.99)), 2), "category": category, "evidence": [e for e in evidence if e]}


# ---------------------------------------------------------------------------- semantic types
def semantic_type(c: dict, p: dict) -> tuple[str | None, str]:
    n, fam = c["name"].lower(), c.get("family")
    pats = p.get("patterns") or []
    top = pats[0] if pats else None
    if fam == "string" and (("email" in n) or (top and "@" in top["pattern"] and top["share"] > 0.9)):
        return "email", "email-like name or values"
    if fam == "string" and re.search(r"phone|mobile|\bcell|\btel", n):
        return "phone", "phone-like name"
    if re.search(r"(^|_)(lat|latitude)$", n) and fam == "numeric":
        return "latitude", "latitude name"
    if re.search(r"(^|_)(lon|lng|longitude)$", n) and fam == "numeric":
        return "longitude", "longitude name"
    if fam == "numeric" and re.search(r"pct|percent|rate$|ratio|share", n):
        return "percentage", "percentage-like name"
    if fam == "numeric" and re.search(r"amount|price|cost|revenue|total|fee|charge|balance|bill|tariff|salary", n):
        return "amount", "monetary name"
    if fam == "numeric" and re.search(r"qty|quantity|count|kwh|mwh|volume|weight|duration|usage|consumption|reading|units?$|readings", n):
        return "measure", "quantity or measurement name"
    if fam == "string" and re.search(r"country(_code)?$", n) and p.get("max_length") == 2:
        return "country_code", "2-letter country codes"
    if fam == "string" and re.search(r"currency", n) and p.get("max_length") == 3:
        return "currency_code", "3-letter currency codes"
    if fam == "temporal" and re.search(r"birth|dob", n):
        return "birth_date", "birth date name"
    if fam == "temporal" and re.search(r"ingest|load|updated|modified|inserted|_at$|created", n):
        return "load_time", "load/update timestamp name"
    if fam == "temporal":
        return "event_time", "date or timestamp"
    if n == "id" or re.search(r"(_id|_key|_no|_code|_num|_number)$", n):
        return "identifier", "identifier-like name"
    if fam == "string" and 0 < p.get("distinct", 0) <= 25 and p.get("non_null", 0) > 50:
        return "category", f"{p['distinct']} distinct values"
    if re.search(r"^(is|has|can|should)_|flag$|_flag", n):
        return "flag", "flag-like name"
    if fam == "string" and re.search(r"desc|comment|note|remark|text|message", n):
        return "free_text", "free-text name"
    return None, ""


def semantic_candidates(cols: list[dict], prof: dict) -> tuple[list[dict], dict]:
    out, types = [], {}
    cp = prof.get("columns", {})
    for c in cols:
        p = cp.get(c["name"]) or {}
        st, why = semantic_type(c, p)
        if not st:
            continue
        types[c["name"]] = st
        name, mn = c["name"], p.get("min")
        ev = f"{name} looks like {st.replace('_', ' ')} ({why})"
        if st == "email":
            out.append(_cand({"type": "regex", "column": name, "params": {"pattern": EMAIL_RE}, "threshold": 0.99, "severity": "medium"}, 0.85, "Semantic type", ev))
        elif st == "phone":
            out.append(_cand({"type": "regex", "column": name, "params": {"pattern": PHONE_RE}, "threshold": 0.98, "severity": "low"}, 0.7, "Semantic type", ev))
        elif st == "latitude":
            out.append(_cand({"type": "range", "column": name, "params": {"min": -90, "max": 90}, "severity": "high"}, 0.95, "Semantic type", ev, "Latitude is physically between -90 and 90"))
        elif st == "longitude":
            out.append(_cand({"type": "range", "column": name, "params": {"min": -180, "max": 180}, "severity": "high"}, 0.95, "Semantic type", ev, "Longitude is physically between -180 and 180"))
        elif st == "percentage":
            hi = 1 if isinstance(p.get("max"), (int, float)) and p["max"] <= 1 else 100
            out.append(_cand({"type": "range", "column": name, "params": {"min": 0, "max": hi}, "severity": "medium"}, 0.85, "Semantic type", ev, f"Observed values fit 0..{hi}"))
        elif st in ("amount", "measure"):
            if isinstance(mn, (int, float)) and mn >= 0:
                out.append(_cand({"type": "range", "column": name, "params": {"min": 0}, "threshold": 0.9999, "severity": "high"}, 0.88, "Semantic type", ev,
                                 f"{'Amounts' if st == 'amount' else 'Quantities'} shouldn't be negative; none seen in {p.get('non_null', 0):,} values"))
            elif isinstance(mn, (int, float)):
                out.append(_cand({"type": "range", "column": name, "params": {"min": 0}, "threshold": 0.999, "severity": "medium"}, 0.55, "Semantic type", ev,
                                 f"Negative values exist (min {mn:g}); confirm whether credits or corrections are allowed"))
        elif st == "country_code":
            out.append(_cand({"type": "regex", "column": name, "params": {"pattern": "[A-Z]{2}"}, "severity": "medium"}, 0.85, "Semantic type", ev, "ISO 3166 alpha-2 format"))
        elif st == "currency_code":
            out.append(_cand({"type": "regex", "column": name, "params": {"pattern": "[A-Z]{3}"}, "severity": "medium"}, 0.85, "Semantic type", ev, "ISO 4217 format"))
        elif st in ("event_time", "birth_date", "load_time"):
            out.append(_cand({"type": "not_future", "column": name, "severity": "medium"}, 0.85, "Semantic type", ev, "Recorded times can't be in the future"))
        elif st == "identifier" and p.get("null_rate", 1) == 0:
            out.append(_cand({"type": "not_null", "column": name, "severity": "high"}, 0.9, "Semantic type", ev, "Identifiers must always be present; no nulls today"))
    return out, types


# ---------------------------------------------------------------------------- relationships
def relationship_candidates(conn, fqn: str, cols: list[dict]) -> list[dict]:
    d = conn.dialect
    temporal = [c["name"] for c in cols if c.get("family") == "temporal"]
    numeric = [c["name"] for c in cols if c.get("family") == "numeric"]
    pairs = []
    for i, a in enumerate(temporal):
        for b in temporal[i + 1:]:
            pairs.append((a, b))
    for a in numeric:
        for b in numeric:
            if a != b and any(h1 in a.lower() and h2 in b.lower() for h1, h2 in ORDER_HINTS):
                pairs.append((a, b))
    pairs = pairs[:8]
    if not pairs:
        return []
    exprs = []
    for i, (a, b) in enumerate(pairs):
        qa, qb = d.q(a), d.q(b)
        exprs += [f"SUM(CASE WHEN {qa} IS NOT NULL AND {qb} IS NOT NULL THEN 1 ELSE 0 END) AS n{i}",
                  f"SUM(CASE WHEN {qa} <= {qb} THEN 1 ELSE 0 END) AS le{i}", f"SUM(CASE WHEN {qa} >= {qb} THEN 1 ELSE 0 END) AS ge{i}"]
    row = conn.query(f"SELECT {', '.join(exprs)} FROM {d.table(fqn)}")[0]
    out = []
    for i, (a, b) in enumerate(pairs):
        n, le, ge = int(row[f"n{i}"] or 0), int(row[f"le{i}"] or 0), int(row[f"ge{i}"] or 0)
        if n < 20 or (le == n and ge == n):
            continue
        hinted = any(h1 in a.lower() and h2 in b.lower() for h1, h2 in ORDER_HINTS)
        for share, (x, op, y) in ((le / n, (a, "<=", b)), (ge / n, (a, ">=", b))):
            if share >= 0.999:
                out.append(_cand({"type": "custom_sql", "column": x, "params": {"expression": f"{x} {op} {y}"}, "severity": "medium",
                                  "name": f"{x} {op} {y}"}, 0.88 if hinted else 0.72, "Relationship",
                                 f"{x} {op} {y} holds in {share:.2%} of {n:,} rows", "Column names suggest this order" if hinted else ""))
                break
    return out


# ---------------------------------------------------------------------------- history
def history_candidates(db, asset: Asset, cols: list[dict], prof: dict) -> list[dict]:
    out = []
    since = utcnow() - timedelta(days=90)
    pts = defaultdict(list)
    for m in db.scalars(select(MetricPoint).where(MetricPoint.asset_id == asset.id, MetricPoint.ts >= since)):
        pts[(m.metric, m.column)].append(m.value)
    rc = pts.get(("row_count", None), [])
    if len(rc) >= 7:
        cv = pstdev(rc) / (sum(rc) / len(rc)) if sum(rc) else 0
        sens = 4.0 if cv > 0.15 else 3.0
        out.append(_cand({"type": "anomaly", "params": {"metric": "row_count", "sensitivity": sens}, "severity": "high", "name": "row volume vs learned baseline"},
                         0.9, "History", f"{len(rc)} days of volume history ({min(rc):,.0f} to {max(rc):,.0f} rows)",
                         f"Variation {cv:.1%}, so sensitivity {sens:g}"))
        out.append(_cand({"type": "row_count", "params": {"min": int(min(rc) * 0.5)}, "severity": "high", "name": f"at least {int(min(rc) * 0.5):,} rows"},
                         0.75, "History", f"Never below {min(rc):,.0f} rows in {len(rc)} days; alert under half of that"))
    for c in cols:
        hist = pts.get(("null_rate", c["name"]), [])
        if len(hist) >= 5 and max(hist) <= 0.05:
            thr = round(max(0.9, 1 - max(hist) * 2), 4)
            out.append(_cand({"type": "not_null", "column": c["name"], "threshold": thr, "severity": "medium"}, 0.8, "History",
                             f"Null rate stayed at or below {max(hist):.2%} over {len(hist)} checks; alert if it doubles"))
        fh = pts.get(("freshness_hours", c["name"]), [])
        if len(fh) >= 5:
            sla = round(max(1.0, max(fh) * 1.5), 1)
            out.append(_cand({"type": "freshness", "column": c["name"], "params": {"max_age_hours": sla}, "severity": "high"}, 0.85, "History",
                             f"Data has been at most {max(fh):.1f}h old over {len(fh)} checks; SLA set at 1.5x"))
    # ranges that held across several stored profiles
    profiles = db.scalars(select(Profile).where(Profile.asset_id == asset.id).order_by(Profile.ts.desc()).limit(10)).all()
    if len(profiles) >= 2:
        for c in cols:
            if c.get("family") != "numeric" or re.search(r"(_id|_key|_no)$|^id$", c["name"].lower()):
                continue
            mins = [pp.data["columns"][c["name"]]["min"] for pp in profiles if c["name"] in pp.data.get("columns", {})
                    and isinstance(pp.data["columns"][c["name"]].get("min"), (int, float))]
            maxs = [pp.data["columns"][c["name"]]["max"] for pp in profiles if c["name"] in pp.data.get("columns", {})
                    and isinstance(pp.data["columns"][c["name"]].get("max"), (int, float))]
            if len(mins) >= 2 and len(maxs) >= 2:
                lo, hi = min(mins), max(maxs)
                span = (hi - lo) or abs(hi) or 1
                out.append(_cand({"type": "range", "column": c["name"], "params": {"min": 0 if lo >= 0 else round(lo - 0.1 * span, 3), "max": round(hi + 0.1 * span, 3)},
                                  "threshold": 0.999, "severity": "medium"}, 0.78, "History",
                                 f"{c['name']} stayed within {lo:g}..{hi:g} across {len(mins)} profiles"))
    # freshness from current lateness when there is no history yet
    load = next((c for c in cols if c.get("family") == "temporal" and re.search(r"ingest|load|updated|modified|inserted|_at$", c["name"].lower())), None)
    if load and not pts.get(("freshness_hours", load["name"])):
        latest = (prof.get("columns", {}).get(load["name"]) or {}).get("max")
        if latest:
            from .rules import _age_hours
            age = _age_hours(latest, utcnow())
            if age is not None and 0 <= age < 24 * 30:
                sla = max(1.0, round(age * 3 + 0.5, 1))
                out.append(_cand({"type": "freshness", "column": load["name"], "params": {"max_age_hours": sla}, "severity": "high"}, 0.7, "History",
                                 f"Newest {load['name']} is {age:.1f}h old now; SLA proposed at about 3x"))
    return out


# ---------------------------------------------------------------------------- business context
def context_candidates(db, asset: Asset, cols: list[dict], others: list[dict], glossary: bool = True) -> tuple[list[dict], list[dict]]:
    """glossary=False leaves out the business glossary (a term's definition is read like a rule sentence otherwise)."""
    from .nl_rules import parse
    out, terms = [], []
    seen_terms = set()
    for lk in (db.scalars(select(GlossaryLink).where(GlossaryLink.target_ref.like(f"{asset.fqn}%"))).all() if glossary else []):
        t = db.get(GlossaryTerm, lk.term_id)
        if t and t.id not in seen_terms:
            seen_terms.add(t.id)
            terms.append({"name": t.name, "definition": t.definition})
    texts = []
    if asset.description:
        texts.append(("Dataset description", asset.description, None))
    for c in cols:
        if c.get("comment"):
            texts.append((f"Description of {c['name']}", f"{c['name']} {c['comment']}", None))
    for t in terms:
        texts.append((f"Business term '{t['name']}'", t["definition"], t["name"]))
    for source, text, term in texts:
        for sentence in re.split(r"(?<=[.;])\s+|\n", text):
            if not re.search(r"\b(must|never|always|cannot|required|should|only|unique|not be|non-negative|positive|between|at least|at most)\b", sentence, re.I):
                continue
            r = parse(sentence, cols, others)
            if r:
                interp = r.pop("interpretation", "")
                cand = _cand(r, 0.8, "Glossary" if term else "Business context", f"{source}: “{sentence.strip()}”", f"Read as: {interp}")
                if term:
                    cand["ref_docs"] = [f"term {term}"]
                out.append(cand)
    hint = G.hint_for(asset.domain)
    if hint:
        for c in cols:
            p_name = c["name"].lower()
            if c.get("family") == "numeric" and re.search(r"amount|kwh|value|reading|consumption|energy|total|price", p_name):
                out.append(_cand({"type": "range", "column": c["name"], "params": {"min": 0}, "severity": "high"}, 0.72, "Business context",
                                 f"Domain '{asset.domain}': {hint}"))
            if c.get("family") == "temporal" and G.is_financial(asset.domain) and re.search(r"posting|invoice|bill|date", p_name):
                out.append(_cand({"type": "not_future", "column": c["name"], "severity": "high"}, 0.78, "Business context",
                                 f"Domain '{asset.domain}': {hint}"))
    return out, terms


# ---------------------------------------------------------------------------- learned from other datasets
def learned_candidates(db, asset: Asset, cols: list[dict]) -> list[dict]:
    names = {c["name"].lower(): c["name"] for c in cols}
    seen: dict[tuple, dict] = {}
    for r in db.scalars(select(Rule).where(Rule.asset_id != asset.id, Rule.status == "active")):
        if r.type not in ("not_null", "regex", "range", "accepted_values", "length", "not_future") or not r.column:
            continue
        local = names.get(r.column.lower())
        if not local:
            continue
        other = db.get(Asset, r.asset_id)
        key = (r.type, local, json.dumps(r.params, sort_keys=True, default=str))
        item = seen.setdefault(key, {"rule": {"type": r.type, "column": local, "params": dict(r.params or {}), "severity": r.severity,
                                              "threshold": r.threshold}, "where": []})
        item["where"].append(other.fqn.split(".")[-1] if other else "?")
    out = []
    for item in seen.values():
        n = len(set(item["where"]))
        if (item["rule"]["params"] or {}).get("baseline"):
            continue
        out.append(_cand(item["rule"], 0.6 + 0.08 * min(n, 3), "Learned",
                         f"Teams already apply this rule to {item['rule']['column']} in {', '.join(sorted(set(item['where'])))}"))
    return out


# ---------------------------------------------------------------------------- observability
def observability_candidates(asset: Asset, cols: list[dict], prof: dict) -> list[dict]:
    out = [_cand({"type": "schema", "params": {"expected_columns": [{"name": c["name"], "type": c.get("data_type")} for c in cols]},
                  "severity": "high", "name": "schema matches today's columns"}, 0.82, "Observability",
                 f"Snapshot of {len(cols)} columns; alerts when a column is dropped or changes type")]
    cp = prof.get("columns", {})
    for c in cols:
        p = cp.get(c["name"]) or {}
        if c.get("family") == "string" and 2 <= p.get("distinct", 0) <= 30 and p.get("non_null", 0) >= 100:
            out.append(_cand({"type": "anomaly", "column": c["name"], "params": {"metric": "distribution_psi"}, "severity": "low"}, 0.65,
                             "Observability", f"Category mix of {c['name']} ({p['distinct']} values) is tracked for drift (PSI)"))
        if c.get("family") == "numeric" and p.get("stddev") and not re.search(r"(_id|_key|_no)$|^id$", c["name"].lower()):
            out.append(_cand({"type": "anomaly", "column": c["name"], "params": {"metric": "outlier_rate", "sensitivity": 3.0}, "severity": "low"},
                             0.6, "Observability", f"Share of extreme {c['name']} values (beyond 3x the interquartile range) is tracked"))
    return out


# ---------------------------------------------------------------------------- orchestration
def _key(r: dict) -> tuple:
    p = r.get("params") or {}
    return (r["type"], (r.get("column") or "").lower(), str(p.get("metric")), str(p.get("columns")), str(p.get("expression")),
            str(p.get("check")), str(p.get("model")), str(p.get("negate")))


STATED = {"Policy": 4, "Contract": 3, "Reference": 3, "Governance": 3, "Glossary": 2, "LLM": 2, "Business context": 1}  # higher wins when two sources disagree

# which of the three rule sets each evidence source feeds
ORIGIN_SET = {"Semantic type": "core", "Statistics": None, "History": "core", "Relationship": "business",
              "Business context": "business", "Learned": None, "Observability": "core", "LLM": None}


def _rule_set(c: dict) -> str:
    from .categories import infer
    if c.get("rule_category") in ("core", "business", "governance"):
        return c["rule_category"]
    fixed = ORIGIN_SET.get(c.get("category"))
    if fixed:
        return fixed
    src = "llm" if c.get("category") == "LLM" else "suggested"
    return infer({"type": c["type"], "params": c.get("params"), "source": src,
                  "category": c.get("category_hint") or (c.get("llm_category") if c.get("category") == "LLM" else None)})


class _Tmp:
    def __init__(self, i, v):
        self.id, self.type, self.column, self.params = i, v["type"], v.get("column"), v["params"]
        self.name, self.threshold, self.severity = v["name"], v["threshold"], v["severity"]


class LLMUnavailable(RuntimeError):
    """AI discovery was asked for but there is no working model."""


def discover(db, asset: Asset, use_llm: bool = True, llm=None, dry_run: bool = True,
             reference_ids: list[int] | None = None, use_references: bool = True, context: dict | None = None) -> dict:
    """reference_ids: None = every enabled reference file that applies to the dataset's domain; [] = none.
    context: which governance context to include: {contracts: bool, policies: bool, standards: [keys]}; contracts and policies default to on."""
    from .. import reference as REF
    from .. import services as S
    from ..config import get_settings
    from . import governed_context as GC
    from .governance_rules import governance_candidates
    from .reference_rules import reference_candidates

    cols = asset.columns or []
    prof = S.latest_profile(db, asset.id) or S.profile_asset(db, asset)["profile"]
    other_assets = list(db.scalars(select(Asset).where(Asset.id != asset.id)))
    others = [{"fqn": a.fqn, "columns": a.columns or []} for a in other_assets]
    conn = get_connector(asset.connection)
    ref_ctx = REF.gather(db, asset, reference_ids) if use_references else REF.Context()
    gov_cfg = get_settings().section("governance")

    raw: list[dict] = []
    sem, types = semantic_candidates(cols, prof)
    raw += sem
    for s in heuristic_suggestions(asset.fqn, prof, cols, others):
        raw.append(_cand(s, 0.7 if s["type"] != "anomaly" else 0.66, "Statistics", s.get("reason", "")))
    if conn.supports_sql:
        try:
            raw += relationship_candidates(conn, asset.fqn, cols)
        except Exception:
            pass
    raw += history_candidates(db, asset, cols, prof)
    gc_opts = GC.options(context)
    ctx, terms = context_candidates(db, asset, cols, others, glossary=gc_opts["glossary"])
    raw += ctx
    raw += learned_candidates(db, asset, cols)
    raw += observability_candidates(asset, cols, prof)
    ref_error = None
    try:
        raw += reference_candidates(db, asset, cols, ref_ctx, other_assets)
    except Exception as e:  # a bad reference file must not break discovery
        ref_error = f"{type(e).__name__}: {e}"[:300]
    raw += governance_candidates(db, asset, cols, prof, ref_ctx, int(gov_cfg.get("retention_days") or 2555))
    gov = GC.gather(db, asset, gc_opts)
    raw += GC.candidates(db, asset, cols, gov)
    gov_text = GC.text(gov)
    llm_used, llm_error = False, None
    ref_text = REF.context_text(ref_ctx, asset, int(gov_cfg.get("llm_context_chars") or 8000)) if ref_ctx.docs else ""
    if use_llm:
        if llm is None:
            raise LLMUnavailable("No LLM is configured. Choose a provider and add its API key in Settings > LLM, "
                                 "or untick \"Use the AI model\" to run statistical discovery only.")
        try:
            for s in llm_suggestions(llm, asset.fqn, prof, cols, asset.description, (ref_text + gov_text) or None, getattr(conn.dialect, "name", None)):
                c = _cand(s, 0.7, "LLM", s.get("reason") or "Proposed by the model from metadata and statistics")
                c["llm_category"] = s.get("category")
                raw.append(c)
            llm_used = True
        except Exception as e:
            raise LLMUnavailable(f"The AI model could not be reached ({type(e).__name__}: {str(e)[:240]}). "
                                 "Check it in Settings > LLM with Test connection, or untick \"Use the AI model\".") from e
    for c in raw:
        c["rule_category"] = _rule_set(c)

    # merge duplicates: keep the most confident, combine evidence, small boost for agreeing sources
    merged: dict[tuple, dict] = {}
    for c in raw:
        try:
            v = R.validate_rule({k: c[k] for k in ("type", "column", "params", "severity", "threshold", "name", "dimension") if k in c}, cols)
        except Exception:
            continue
        c = {**c, **v}
        k = _key(c)
        if k in merged:
            m = merged[k]
            m["evidence"] += [e for e in c["evidence"] if e not in m["evidence"]]
            m["sources"] = sorted(set(m["sources"]) | {c["category"]})
            m["ref_docs"] = sorted(set(m.get("ref_docs") or []) | set(c.get("ref_docs") or []))
            m["rule_category"] = stronger(m.get("rule_category"), c.get("rule_category"))
            # a rule someone wrote down (reference file, policy) beats a model's guess, a domain hint, and limits inferred from data
            c_rank, m_rank = STATED.get(c["category"], 0), m.get("_rank", 0)
            if c_rank > m_rank or (c_rank == m_rank and c["confidence"] > m.get("_base_conf", m["confidence"])):
                m.update({kk: c[kk] for kk in ("params", "threshold", "severity", "name", "category")})
                m["_rank"], m["_base_conf"] = c_rank, c["confidence"]
                m["evidence"] = [e for e in c["evidence"]] + [e for e in m["evidence"] if e not in c["evidence"]]
            m["confidence"] = round(min(0.99, max(m["confidence"], c["confidence"]) + 0.04), 2)
        else:
            merged[k] = {**c, "sources": [c["category"]], "ref_docs": list(c.get("ref_docs") or []),
                         "_rank": STATED.get(c["category"], 0), "_base_conf": c["confidence"]}

    existing = db.scalars(select(Rule).where(Rule.asset_id == asset.id)).all()
    live = [r for r in existing if r.status != "disabled"]
    existing_keys = {_key({"type": r.type, "column": r.column, "params": r.params}) for r in live}
    existing_exact = {(_key({"type": r.type, "column": r.column, "params": r.params}), json.dumps(r.params, sort_keys=True, default=str))
                      for r in live}
    noisy = {(r.type, (r.column or "").lower()) for r in existing if (r.fp_count or 0) >= 2 and not r.tp_count}
    cands = []
    for k, c in merged.items():
        if k in existing_keys:
            # explicit business statements still count when they differ from an auto-generated rule
            stated = {"Business context", "LLM", "Reference", "Governance", "Contract", "Policy", "Glossary"} & set(c["sources"])
            if not stated or (k, json.dumps(c["params"], sort_keys=True, default=str)) in existing_exact:
                continue
            c["evidence"].append("Differs from the existing rule of this type on this column")
        if (c["type"], (c.get("column") or "").lower()) in noisy:
            c["confidence"] = round(c["confidence"] * 0.6, 2)
            c["evidence"].append("A similar rule here was marked a false positive before")
        cands.append(c)

    GC.annotate(db, asset, cands, gov)

    dry_stats = {"ran": 0, "errors": 0, "platform": asset.platform, "connection": asset.connection, "unavailable": None}
    if dry_run and not conn.supports_sql:
        dry_stats["unavailable"] = f"{asset.platform} can't run SQL, so proposed rules were not dry-run. Use a SQL platform such as Databricks, Snowflake or Spark."
    if dry_run and conn.supports_sql:
        # Every candidate is run on the platform: unscoped row-level rules share one scan per chunk; the rest run one by one.
        row_level = [c for c in cands if R.RULE_TYPES[c["type"]]["row_level"] and not (c.get("params") or {}).get("where")]
        tmp = [_Tmp(-(i + 1), c) for i, c in enumerate(row_level)]
        for start in range(0, len(tmp), 40):
            chunk = tmp[start:start + 40]
            try:
                res = R.evaluate_row_batch(conn, asset.fqn, chunk)
                for t in chunk:
                    o = res[t.id]
                    row_level[-t.id - 1]["dry_run"] = {"status": o.status or ("pass" if o.pass_rate >= t.threshold - 1e-12 else "fail"),
                                                       "pass_rate": round(o.pass_rate, 6), "message": o.message}
            except Exception:  # a bad rule in the chunk: retry one by one so the others still get a result
                for t in chunk:
                    try:
                        o = R.evaluate_row_batch(conn, asset.fqn, [t])[t.id]
                        row_level[-t.id - 1]["dry_run"] = {"status": o.status or ("pass" if o.pass_rate >= t.threshold - 1e-12 else "fail"),
                                                           "pass_rate": round(o.pass_rate, 6), "message": o.message}
                    except Exception as e2:
                        row_level[-t.id - 1]["dry_run"] = {"status": "error", "message": f"{type(e2).__name__}: {e2}"[:200]}
        from .runner import history_fn
        for c in [c for c in cands if "dry_run" not in c]:
            try:
                t = _Tmp(-999, c)
                if R.RULE_TYPES[c["type"]]["row_level"]:  # scoped by a where clause
                    o = R.evaluate_row_batch(conn, asset.fqn, [t])[-999]
                else:
                    o = R.evaluate_aggregate(t, asset.fqn, conn, history_fn(db, asset.id), cols)
                st = o.status or ("pass" if o.pass_rate >= c["threshold"] - 1e-12 else "fail")
                c["dry_run"] = {"status": st, "pass_rate": round(o.pass_rate, 6), "message": o.message}
            except Exception as e:
                c["dry_run"] = {"status": "error", "message": f"{type(e).__name__}: {e}"[:200]}
        dry_stats["ran"] = sum(1 for c in cands if "dry_run" in c)
        dry_stats["errors"] = sum(1 for c in cands if (c.get("dry_run") or {}).get("status") == "error")
        for c in cands:
            dr = c.get("dry_run")
            if not dr:
                continue
            if dr["status"] == "pass":
                c["confidence"] = round(min(0.99, c["confidence"] + 0.03), 2)
            elif dr["status"] == "fail":
                c["confidence"] = round(c["confidence"] * 0.75, 2)
                c["evidence"].append(f"Fails on today's data ({dr['message']}): either a real issue or a rule to adjust")

    for c in cands:
        c.pop("_rank", None)
        c.pop("_base_conf", None)
    cands.sort(key=lambda c: (-c["confidence"], c["dimension"], c.get("column") or ""))
    before = defaultdict(int)
    for r in existing:
        if r.status == "active":
            before[r.dimension] += 1
    after = dict(before)
    for c in cands:
        if c["confidence"] >= 0.7:
            after[c["dimension"]] = after.get(c["dimension"], 0) + 1
    by_cat = defaultdict(int)
    for c in cands:
        for s in c["sources"]:
            by_cat[s] += 1
    sets = {k: sum(1 for c in cands if c["rule_category"] == k) for k in CATEGORIES}
    ref_terms = sorted({d["text"] for facts in ref_ctx.by_col.values() for d in facts if d["kind"] == "business_term" and d["text"]})
    return {"asset": asset.fqn, "asset_id": asset.id, "candidates": cands, "sets": sets,
            "categories": {k: v["label"] for k, v in CATEGORIES.items()},
            "coverage": {"before": {d: before.get(d, 0) for d in R.DIMENSIONS}, "after": {d: after.get(d, 0) for d in R.DIMENSIONS}},
            "context": {"rows": prof.get("row_count"), "semantic_types": types,
                        "glossary_terms": sorted(set([t["name"] for t in terms] + ref_terms))[:40],
                        "domain": asset.domain, "llm": llm_used, "llm_error": llm_error, "dry_runs": dry_stats, "by_source": dict(by_cat),
                        "reference": {"files": [{"id": d.id, "name": d.name, "kind": d.kind, "facts": ref_ctx.used.get(d.id, 0)}
                                                for d in ref_ctx.docs.values()],
                                      "facts": ref_ctx.fact_count(), "error": ref_error,
                                      "llm_context_chars": len(ref_text) if llm_used else 0},
                        "governed": {**GC.summary(gov), "llm_chars": len(gov_text) if llm_used else 0},
                        "history_points": db.scalar(select(func.count()).select_from(MetricPoint)
                                                    .where(MetricPoint.asset_id == asset.id)) or 0}}


def accept(db, asset: Asset, rules: list[dict], actor: str, activate: bool = False) -> list[Rule]:
    from .. import services as S
    created = []
    existing = {_key({"type": r.type, "column": r.column, "params": r.params}) for r in
                db.scalars(select(Rule).where(Rule.asset_id == asset.id, Rule.status != "disabled"))}
    for r in rules:
        data = {k: r[k] for k in ("type", "column", "params", "severity", "threshold", "name", "dimension", "description") if k in r}
        if _key(data) in existing:
            continue
        data["source"] = "discovery"
        if r.get("rule_category") in CATEGORIES:
            data["category"] = r["rule_category"]
        ev = r.get("evidence") or []
        data["reason"] = f"{r.get('category', 'Discovery')} ({r.get('confidence', '')}): " + "; ".join(ev)[:900]
        rule = S.create_rule(db, asset, data, actor, status="active" if activate else "proposed")
        existing.add(_key(data))
        created.append(rule)
    return created
