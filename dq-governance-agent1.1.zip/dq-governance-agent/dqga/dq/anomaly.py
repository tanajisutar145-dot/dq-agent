"""Statistical anomaly detection for observability metrics.

Robust and dependency-free: median / MAD z-scores with weekly seasonality
when enough history exists (compare Mondays with Mondays), plus PSI for
categorical distribution drift.
"""
from __future__ import annotations

import math
from datetime import datetime
from statistics import median


def _mad(values: list[float], med: float) -> float:
    return median([abs(v - med) for v in values]) if values else 0.0


def detect(history: list[tuple[datetime, float]], current: float, now: datetime,
           sensitivity: float = 3.0, min_points: int = 7) -> dict:
    pts = [(t, float(v)) for t, v in history if v is not None]
    if len(pts) < min_points:
        return {"status": "insufficient", "is_anomaly": False, "value": current, "points": len(pts),
                "message": f"Learning baseline ({len(pts)}/{min_points} points)"}
    span_days = (pts[-1][0] - pts[0][0]).total_seconds() / 86400 if len(pts) > 1 else 0
    seasonal = [v for t, v in pts if t.weekday() == now.weekday()]
    if span_days >= 21 and len(seasonal) >= 3:
        basis, mode = seasonal[-8:], "weekly"
    else:
        basis, mode = [v for _, v in pts[-28:]], "rolling"
    med = median(basis)
    mad = _mad(basis, med)
    if mad == 0:
        # Perfectly stable history: allow a band of 5% of the median, scaled by sensitivity.
        band = max(abs(med) * 0.05 * sensitivity / 3.0, 1e-9)
        z = (current - med) / band * sensitivity
        lo, hi = med - band, med + band
        is_anom = abs(current - med) > band
    else:
        scale = mad / 0.6745
        z = (current - med) / scale
        lo, hi = med - sensitivity * scale, med + sensitivity * scale
        is_anom = abs(z) > sensitivity
    pct = (current - med) / med * 100 if med else 0.0
    msg = (f"{current:,.2f} vs expected {lo:,.2f}..{hi:,.2f} ({pct:+.1f}% from {mode} median {med:,.2f})")
    return {"status": "ok", "is_anomaly": bool(is_anom), "value": current, "expected_low": lo, "expected_high": hi,
            "median": med, "z": round(z, 2), "pct_change": round(pct, 2), "mode": mode, "points": len(basis),
            "message": ("Anomaly: " if is_anom else "Normal: ") + msg}


def psi(expected: dict, actual: dict, eps: float = 1e-4) -> float:
    """Population stability index between two {category: count} distributions."""
    keys = set(expected) | set(actual)
    te = sum(expected.values()) or 1
    ta = sum(actual.values()) or 1
    total = 0.0
    for k in keys:
        e = max(expected.get(k, 0) / te, eps)
        a = max(actual.get(k, 0) / ta, eps)
        total += (a - e) * math.log(a / e)
    return total
