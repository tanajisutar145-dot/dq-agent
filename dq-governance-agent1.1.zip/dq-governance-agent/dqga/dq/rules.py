"""Rule catalog, validation, and SQL compilation.

Row-level rules compile to a *failure condition* so many rules on one table
are evaluated in a single scan:

    SELECT COUNT(*) AS total,
           SUM(CASE WHEN <fail_1> THEN 1 ELSE 0 END) AS f0, ...
    FROM t [WHERE scope]

Aggregate rules (unique, freshness, referential, reconciliation, schema,
anomaly, timeseries) run their own queries. The LLM never decides pass or
fail: it can only propose rules that end up here.
"""
from __future__ import annotations

import re

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from ..connectors.base import Connector, Dialect, lit, safe_expression, type_family
from ..models import utcnow
from . import anomaly as anomaly_mod
from . import timeseries as ts_mod

DIMENSIONS = ["completeness", "validity", "uniqueness", "consistency", "integrity",
              "timeliness", "accuracy", "volume", "schema", "plausibility"]
SEVERITIES = ["critical", "high", "medium", "low"]
SEVERITY_WEIGHT = {"critical": 4, "high": 3, "medium": 2, "low": 1}

RULE_TYPES: dict[str, dict[str, Any]] = {
    "not_null": {"dimension": "completeness", "row_level": True, "column": True,
                 "desc": "Column has no nulls (or pass rate >= threshold)"},
    "accepted_values": {"dimension": "validity", "row_level": True, "column": True, "params": ["values"],
                        "desc": "Column value is in an allowed list"},
    "range": {"dimension": "validity", "row_level": True, "column": True, "params": ["min", "max"],
              "desc": "Numeric or date value within [min, max]"},
    "regex": {"dimension": "validity", "row_level": True, "column": True, "params": ["pattern"],
              "desc": "Value fully matches a regular expression"},
    "length": {"dimension": "validity", "row_level": True, "column": True, "params": ["min", "max"],
               "desc": "String length within [min, max]"},
    "not_future": {"dimension": "validity", "row_level": True, "column": True,
                   "desc": "Timestamp is not in the future"},
    "retention": {"dimension": "timeliness", "row_level": True, "column": True, "params": ["max_age_days"],
                  "desc": "No record is older than the retention period (max_age_days): storage limitation"},
    "custom_sql": {"dimension": "validity", "row_level": True, "params": ["expression"],
                   "desc": "Row is valid when a boolean SQL expression is true"},
    "unique": {"dimension": "uniqueness", "row_level": False, "params": ["columns"],
               "desc": "No duplicate values for the key column(s)"},
    "freshness": {"dimension": "timeliness", "row_level": False, "column": True, "params": ["max_age_hours"],
                  "desc": "Latest timestamp is newer than max_age_hours"},
    "row_count": {"dimension": "volume", "row_level": False, "params": ["min", "max"],
                  "desc": "Row count within [min, max]"},
    "referential": {"dimension": "integrity", "row_level": False, "column": True, "params": ["ref_table", "ref_column"],
                    "desc": "Every non-null value exists in a reference table"},
    "reconciliation": {"dimension": "consistency", "row_level": False,
                       "params": ["expression", "ref_table", "ref_expression", "tolerance_pct"],
                       "desc": "An aggregate matches the same aggregate on another table within tolerance"},
    "schema": {"dimension": "schema", "row_level": False, "params": ["expected_columns"],
               "desc": "Expected columns exist with expected types (schema drift)"},
    "anomaly": {"dimension": "volume", "row_level": False, "params": ["metric", "sensitivity"],
                "desc": "Metric (row_count, null_rate, mean, distinct_count, freshness_hours, distribution_psi) "
                        "is within its learned seasonal range"},
    "timeseries": {"dimension": "plausibility", "row_level": False,
                   "params": ["check", "id_column", "ts_column", "value_column"],
                   "desc": "Industrial sensor checks: gaps, flatline, spikes, bounds, monotonic, sampling_rate"},
}

ANOMALY_METRICS = ["row_count", "null_rate", "mean", "distinct_count", "freshness_hours", "distribution_psi", "outlier_rate"]


def outlier_fences(conn, fqn: str, column: str, k: float = 3.0) -> tuple[float, float] | None:
    """Tukey fences: [p25 - k*IQR, p75 + k*IQR]."""
    d = conn.dialect
    c = d.as_double(d.q(column))
    row = conn.query(f"SELECT {d.quantile(c, 0.25)} AS q1, {d.quantile(c, 0.75)} AS q3 FROM {d.table(fqn)}")[0]
    if row["q1"] is None or row["q3"] is None:
        return None
    iqr = float(row["q3"]) - float(row["q1"])
    return float(row["q1"]) - k * iqr, float(row["q3"]) + k * iqr


@dataclass
class Outcome:
    total: int = 0
    failed: int = 0
    observed: dict = field(default_factory=dict)
    message: str = ""
    status: str | None = None  # force a status (warn / error)
    failing_sql: str | None = None
    metric: tuple[str, str | None, float] | None = None  # (metric, column, value) to record

    @property
    def pass_rate(self) -> float:
        return 1.0 if self.total == 0 else max(0.0, 1.0 - self.failed / self.total)


# ---------------------------------------------------------------------------
# validation
# ---------------------------------------------------------------------------
def _split_list(text: str) -> list[str]:
    return [x for x in re.split(r"\s*,\s*", text.strip().strip("[]()")) if x]


def _unquote(v):
    if isinstance(v, str):
        v = v.strip()
        while len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"`":
            v = v[1:-1].strip()
    return v


def validate_rule(rule: dict, columns: list[dict] | None = None) -> dict:
    """Normalize a rule dict and raise ValueError if it is not executable."""
    r = dict(rule)
    rtype = r.get("type")
    if rtype not in RULE_TYPES:
        raise ValueError(f"Unknown rule type {rtype!r}")
    spec = RULE_TYPES[rtype]
    r.setdefault("params", {})
    r["params"] = dict(r["params"] or {})
    r.setdefault("dimension", spec["dimension"])
    if r["dimension"] not in DIMENSIONS:
        r["dimension"] = spec["dimension"]
    r.setdefault("severity", "medium")
    if r["severity"] not in SEVERITIES:
        r["severity"] = "medium"
    r["threshold"] = float(r.get("threshold") if r.get("threshold") is not None else 1.0)
    col_names = {c["name"].lower(): c for c in (columns or [])}
    if spec.get("column"):
        col = r.get("column")
        if not col:
            raise ValueError(f"Rule {rtype} needs a column")
        if col_names and col.lower() not in col_names:
            raise ValueError(f"Column {col!r} not found")
        if col_names:
            r["column"] = col_names[col.lower()]["name"]
    p = r["params"]
    if rtype == "unique":
        cols = p.get("columns") or ([r["column"]] if r.get("column") else [])
        if not cols:
            raise ValueError("unique needs columns")
        if col_names:
            missing = [c for c in cols if c.lower() not in col_names]
            if missing:
                raise ValueError(f"Columns not found: {missing}")
        p["columns"] = cols
    if rtype == "accepted_values":
        # models and pasted lists often hand over SQL-style literals ("'Austin'"): keep the value, not its quotes
        vals = p.get("values")
        if isinstance(vals, str):
            vals = _split_list(vals)
        p["values"] = [_unquote(v) for v in vals or []]
        if not p["values"]:
            raise ValueError("accepted_values needs values")
    if rtype in ("range", "length", "row_count") and p.get("min") is None and p.get("max") is None:
        raise ValueError(f"{rtype} needs min and/or max")
    if rtype == "regex":
        import re
        re.compile(p.get("pattern") or "")
        if not p.get("pattern"):
            raise ValueError("regex needs pattern")
    if rtype == "custom_sql":
        safe_expression(p.get("expression", ""))
    if rtype == "regex":
        p["negate"] = bool(p.get("negate")) or None
        if p["negate"] is None:
            p.pop("negate")
    if rtype == "retention":
        try:
            p["max_age_days"] = int(float(p.get("max_age_days")))
        except (TypeError, ValueError):
            raise ValueError("retention needs max_age_days (a whole number of days)") from None
        if p["max_age_days"] < 1:
            raise ValueError("retention max_age_days must be at least 1")
    if rtype == "freshness":
        p["max_age_hours"] = float(p.get("max_age_hours") or 24)
    if rtype == "referential" and not (p.get("ref_table") and p.get("ref_column")):
        raise ValueError("referential needs ref_table and ref_column")
    if rtype == "reconciliation":
        safe_expression(p.get("expression", ""))
        safe_expression(p.get("ref_expression", ""))
        if not p.get("ref_table"):
            raise ValueError("reconciliation needs ref_table")
        p["tolerance_pct"] = float(p.get("tolerance_pct") or 0.0)
    if rtype == "anomaly":
        if p.get("metric") not in ANOMALY_METRICS:
            raise ValueError(f"anomaly metric must be one of {ANOMALY_METRICS}")
        if p["metric"] not in ("row_count",) and not r.get("column"):
            raise ValueError(f"anomaly metric {p['metric']} needs a column")
        p["sensitivity"] = float(p.get("sensitivity") or 3.0)
    if rtype == "timeseries":
        if p.get("check") not in ts_mod.CHECKS:
            raise ValueError(f"timeseries check must be one of {list(ts_mod.CHECKS)}")
    if p.get("where"):
        safe_expression(p["where"])
    if not r.get("name"):
        r["name"] = default_name(r)
    return r


def default_name(r: dict) -> str:
    p = r.get("params") or {}
    col = r.get("column") or ""
    t = r["type"]
    if t == "not_null":
        return f"{col} not null" + (f" >= {r.get('threshold', 1.0):.0%}" if r.get("threshold", 1.0) < 1 else "")
    if t == "unique":
        return f"{', '.join(p.get('columns', [col]))} unique"
    if t == "accepted_values":
        return f"{col} in {p.get('values')}"
    if t == "range":
        if p.get("min") is not None and p.get("max") is not None:
            return f"{col} between {p.get('min')} and {p.get('max')}"
        return f"{col} >= {p.get('min')}" if p.get("min") is not None else f"{col} <= {p.get('max')}"
    if t == "freshness":
        return f"fresh within {p.get('max_age_hours')}h ({col})"
    if t == "anomaly":
        return f"{p.get('metric')} anomaly" + (f" on {col}" if col else "")
    if t == "timeseries":
        return f"sensor {p.get('check')}" + (f" per {p['id_column']}" if p.get("id_column") else "")
    if t == "referential":
        return f"{col} exists in {p.get('ref_table')}.{p.get('ref_column')}"
    if t == "regex":
        return f"{col} {'never matches' if p.get('negate') else 'matches'} {p.get('pattern')}"
    if t == "length":
        lo, hi = p.get("min"), p.get("max")
        if lo is not None and hi is not None:
            return f"{col} length {lo}..{hi}" if lo != hi else f"{col} length is {lo}"
        return f"{col} at most {hi} characters" if hi is not None else f"{col} at least {lo} characters"
    if t == "retention":
        return f"{col} within {p.get('max_age_days')} days retention"
    return f"{t} {col}".strip()


# ---------------------------------------------------------------------------
# row-level compilation
# ---------------------------------------------------------------------------
def fail_condition(rule, d: Dialect) -> str:
    t, p = rule.type, rule.params or {}
    col = d.q(rule.column) if rule.column else None
    if t == "not_null":
        return f"{col} IS NULL"
    if t == "accepted_values":
        return f"{col} IS NOT NULL AND {col} NOT IN ({', '.join(lit(_unquote(v)) for v in p['values'])})"
    if t == "range":
        parts = []
        if p.get("min") is not None:
            parts.append(f"{col} < {lit(p['min'])}")
        if p.get("max") is not None:
            parts.append(f"{col} > {lit(p['max'])}")
        return f"{col} IS NOT NULL AND ({' OR '.join(parts)})"
    if t == "regex":
        if p.get("negate"):  # values must NOT look like this, e.g. a raw card number in a masked column
            return f"{col} IS NOT NULL AND ({d.regex(col, p['pattern'])})"
        return f"{col} IS NOT NULL AND NOT ({d.regex(col, p['pattern'])})"
    if t == "retention":
        return f"{col} < {d.days_ago(int(p['max_age_days']))}"
    if t == "length":
        parts = []
        if p.get("min") is not None:
            parts.append(f"{d.length(col)} < {int(p['min'])}")
        if p.get("max") is not None:
            parts.append(f"{d.length(col)} > {int(p['max'])}")
        return f"{col} IS NOT NULL AND ({' OR '.join(parts)})"
    if t == "not_future":
        return f"{col} > {d.now()}"
    if t == "custom_sql":
        return f"NOT COALESCE(({safe_expression(p['expression'])}), FALSE)"
    raise ValueError(f"{t} is not a row-level rule")


def scope_sql(rule) -> str:
    w = (rule.params or {}).get("where")
    return f" WHERE {safe_expression(w)}" if w else ""


def failing_rows_sql(rule, fqn: str, d: Dialect, limit: int = 100) -> str | None:
    if not RULE_TYPES[rule.type]["row_level"]:
        return None
    where = (rule.params or {}).get("where")
    cond = fail_condition(rule, d)
    if where:
        cond = f"({where}) AND ({cond})"
    return f"SELECT * FROM {d.table(fqn)} WHERE {cond} {d.limit(limit)}"


def evaluate_row_batch(conn: Connector, fqn: str, rules: list) -> dict[int, Outcome]:
    d = conn.dialect
    exprs = ["COUNT(*) AS total"]
    for i, r in enumerate(rules):
        exprs.append(f"SUM(CASE WHEN {fail_condition(r, d)} THEN 1 ELSE 0 END) AS f{i}")
    sql = f"SELECT {', '.join(exprs)} FROM {d.table(fqn)}{scope_sql(rules[0])}"
    row = conn.query(sql)[0]
    total = int(row.get("total") or 0)
    out = {}
    for i, r in enumerate(rules):
        failed = int(row.get(f"f{i}") or 0)
        o = Outcome(total=total, failed=failed, failing_sql=failing_rows_sql(r, fqn, d),
                    observed={"total": total, "failed": failed})
        o.message = f"{failed:,} of {total:,} rows failed" if total else "No rows in scope"
        if total == 0:
            o.status = "warn"
        if r.type == "not_null" and total:
            o.metric = ("null_rate", r.column, failed / total)
        out[r.id] = o
    return out


# ---------------------------------------------------------------------------
# aggregate rules
# ---------------------------------------------------------------------------
HistoryFn = Callable[[str, str | None], list[tuple[datetime, float]]]


def _age_hours(latest: Any, now: datetime) -> float | None:
    if latest is None:
        return None
    if isinstance(latest, str):
        latest = datetime.fromisoformat(latest)
    if not isinstance(latest, datetime):
        latest = datetime.combine(latest, datetime.min.time())
    if latest.tzinfo is not None:
        latest = latest.astimezone(timezone.utc).replace(tzinfo=None)
    return (now - latest).total_seconds() / 3600.0


def current_metric(conn: Connector, fqn: str, metric: str, column: str | None, params: dict) -> float:
    d = conn.dialect
    t = d.table(fqn)
    if metric == "row_count":
        return float(conn.query(f"SELECT COUNT(*) AS v FROM {t}")[0]["v"])
    c = d.q(column)
    if metric == "null_rate":
        r = conn.query(f"SELECT COUNT(*) AS n, COUNT({c}) AS nn FROM {t}")[0]
        return 0.0 if not r["n"] else 1.0 - r["nn"] / r["n"]
    if metric == "mean":
        return float(conn.query(f"SELECT AVG({d.as_double(c)}) AS v FROM {t}")[0]["v"] or 0.0)
    if metric == "distinct_count":
        return float(conn.query(f"SELECT COUNT(DISTINCT {c}) AS v FROM {t}")[0]["v"])
    if metric == "freshness_hours":
        latest = conn.query(f"SELECT MAX({c}) AS v FROM {t}")[0]["v"]
        age = _age_hours(latest, utcnow())
        return float(age if age is not None else 1e6)
    if metric == "outlier_rate":
        f = outlier_fences(conn, fqn, column, float(params.get("iqr_k", 3.0)))
        if f is None:
            return 0.0
        x = d.as_double(c)
        r = conn.query(f"SELECT COUNT({c}) AS n, SUM(CASE WHEN {x} < {f[0]} OR {x} > {f[1]} THEN 1 ELSE 0 END) AS o FROM {t}")[0]
        return 0.0 if not r["n"] else float(r["o"] or 0) / float(r["n"])
    if metric == "distribution_psi":
        str_type = "STRING" if d.name == "spark" else "VARCHAR"
        rows = conn.query(f"SELECT CAST({c} AS {str_type}) AS k, COUNT(*) AS n FROM {t} GROUP BY 1 ORDER BY 2 DESC {d.limit(30)}")
        current = {str(r["k"]): r["n"] for r in rows}
        baseline = params.get("baseline")
        if not baseline:
            params["baseline"] = current
            return 0.0
        return anomaly_mod.psi(baseline, current)
    raise ValueError(f"Unknown metric {metric}")


def evaluate_aggregate(rule, fqn: str, conn: Connector, history: HistoryFn, columns: list[dict],
                       ts_limit: int = 200000) -> Outcome:
    d, p, t = conn.dialect, rule.params or {}, rule.type
    now = utcnow()

    if t == "unique":
        cols = ", ".join(d.q(c) for c in p["columns"])
        where = scope_sql(rule)
        row = conn.query(
            f"SELECT (SELECT COUNT(*) FROM {d.table(fqn)}{where}) AS total, "
            f"(SELECT COALESCE(SUM(cnt - 1), 0) FROM (SELECT {cols}, COUNT(*) AS cnt FROM {d.table(fqn)}{where} "
            f"GROUP BY {cols} HAVING COUNT(*) > 1) dup) AS failed")[0]
        total, failed = int(row["total"] or 0), int(row["failed"] or 0)
        return Outcome(total, failed, {"duplicates": failed}, f"{failed:,} duplicate rows on ({', '.join(p['columns'])})",
                       failing_sql=f"SELECT {cols}, COUNT(*) AS cnt FROM {d.table(fqn)} GROUP BY {cols} HAVING COUNT(*) > 1")

    if t == "freshness":
        latest = conn.query(f"SELECT MAX({d.q(rule.column)}) AS latest FROM {d.table(fqn)}")[0]["latest"]
        age = _age_hours(latest, now)
        sla = float(p["max_age_hours"])
        ok = age is not None and age <= sla
        o = Outcome(1, 0 if ok else 1, {"latest": str(latest), "age_hours": round(age, 2) if age is not None else None,
                                        "sla_hours": sla},
                    f"Latest record {age:.1f}h old (SLA {sla:g}h)" if age is not None else "Table is empty")
        if age is not None:
            o.metric = ("freshness_hours", rule.column, age)
        return o

    if t == "row_count":
        n = int(conn.query(f"SELECT COUNT(*) AS n FROM {d.table(fqn)}{scope_sql(rule)}")[0]["n"])
        lo, hi = p.get("min"), p.get("max")
        ok = (lo is None or n >= float(lo)) and (hi is None or n <= float(hi))
        bounds = (f"{lo:,.0f} to {hi:,.0f}" if lo is not None and hi is not None else f"at least {lo:,.0f}" if lo is not None else f"at most {hi:,.0f}")
        o = Outcome(1, 0 if ok else 1, {"row_count": n, "min": lo, "max": hi}, f"{n:,} rows (expected {bounds})")
        o.metric = ("row_count", None, float(n))
        return o

    if t == "referential":
        c, rt, rc = d.q(rule.column), d.table(p["ref_table"]), d.q(p["ref_column"])
        row = conn.query(
            f"SELECT COUNT(*) AS total, SUM(CASE WHEN r.k IS NULL THEN 1 ELSE 0 END) AS failed "
            f"FROM {d.table(fqn)} s LEFT JOIN (SELECT DISTINCT {rc} AS k FROM {rt}) r ON s.{c} = r.k WHERE s.{c} IS NOT NULL")[0]
        total, failed = int(row["total"] or 0), int(row["failed"] or 0)
        return Outcome(total, failed, {"orphans": failed}, f"{failed:,} values missing from {p['ref_table']}.{p['ref_column']}",
                       failing_sql=f"SELECT s.* FROM {d.table(fqn)} s LEFT JOIN {rt} r ON s.{c} = r.{rc} "
                                   f"WHERE s.{c} IS NOT NULL AND r.{rc} IS NULL {d.limit(100)}")

    if t == "reconciliation":
        row = conn.query(f"SELECT (SELECT {p['expression']} FROM {d.table(fqn)}) AS a, "
                         f"(SELECT {p['ref_expression']} FROM {d.table(p['ref_table'])}) AS b")[0]
        a, b = float(row["a"] or 0), float(row["b"] or 0)
        diff_pct = 0.0 if a == b else abs(a - b) / max(abs(b), 1e-9) * 100
        ok = diff_pct <= p["tolerance_pct"]
        return Outcome(1, 0 if ok else 1, {"value": a, "reference": b, "diff_pct": round(diff_pct, 3)},
                       f"{a:,.2f} vs {b:,.2f} on {p['ref_table']} ({diff_pct:.2f}% diff, tolerance {p['tolerance_pct']}%)")

    if t == "schema":
        actual = {c["name"].lower(): c for c in columns}
        problems = []
        for exp in p.get("expected_columns", []):
            got = actual.get(exp["name"].lower())
            if not got:
                problems.append(f"missing {exp['name']}")
            elif exp.get("type") and type_family(exp["type"]) != type_family(got["data_type"]):
                problems.append(f"{exp['name']} type {got['data_type']} (expected {exp['type']})")
        if p.get("allow_extra") is False:
            expected = {e["name"].lower() for e in p.get("expected_columns", [])}
            problems += [f"unexpected {c['name']}" for k, c in actual.items() if k not in expected]
        total = max(len(p.get("expected_columns", [])), 1)
        return Outcome(total, len(problems), {"problems": problems},
                       "Schema matches" if not problems else "; ".join(problems[:5]))

    if t == "anomaly":
        metric = p["metric"]
        value = current_metric(conn, fqn, metric, rule.column, p)
        if metric == "distribution_psi":
            limit = float(p.get("psi_threshold", 0.2))
            ok = value <= limit
            o = Outcome(1, 0 if ok else 1, {"psi": round(value, 4), "threshold": limit},
                        f"Distribution shift PSI {value:.3f} (threshold {limit})")
        else:
            hist = history(metric, rule.column)
            res = anomaly_mod.detect(hist, value, now, sensitivity=float(p.get("sensitivity", 3.0)))
            o = Outcome(1, 1 if res["is_anomaly"] else 0, res, res["message"])
            if res["status"] == "insufficient":
                cap = float(p.get("max_rate", 0.01))
                if metric == "outlier_rate":  # useful from day one: an absolute ceiling until a baseline exists
                    o = Outcome(1, 0 if value <= cap else 1, {**res, "max_rate": cap},
                                f"{value:.2%} of values are extreme outliers (ceiling {cap:.0%} while the baseline is learned)")
                else:
                    o.status = "warn"
        o.metric = (metric, rule.column, value)
        return o

    if t == "timeseries":
        return _evaluate_timeseries(rule, fqn, conn, ts_limit)

    raise ValueError(f"Unsupported aggregate rule {t}")


def _evaluate_timeseries(rule, fqn, conn: Connector, ts_limit: int) -> Outcome:
    p = rule.params
    check = p["check"]
    lookback = int(p.get("lookback_days", 7))
    series: dict[str, list] = {}
    if conn.supports_sql and p.get("ts_column"):
        d = conn.dialect
        id_sel = f"{d.q(p['id_column'])} AS id, " if p.get("id_column") else "'series' AS id, "
        rows = conn.query(
            f"SELECT {id_sel}{d.q(p['ts_column'])} AS ts, {d.as_double(d.q(p.get('value_column', 'value')))} AS value "
            f"FROM {d.table(fqn)} WHERE {d.q(p['ts_column'])} >= {d.days_ago(lookback)} ORDER BY 1, 2 {d.limit(ts_limit)}")
        for r in rows:
            series.setdefault(str(r["id"]), []).append((r["ts"], r["value"]))
    else:
        series["series"] = conn.timeseries(fqn, start=utcnow() - timedelta(days=lookback), limit=ts_limit)

    fn = ts_mod.CHECKS[check]
    bad, details, points = 0, {}, 0
    for sid, pts in series.items():
        points += len(pts)
        res = fn(pts, **{k: v for k, v in p.items() if k in ts_mod.PARAMS[check]})
        if res["failed"]:
            bad += 1
            if len(details) < 25:
                details[sid] = res["issues"][:3]
    multi = len(series) > 1 or p.get("id_column")
    if multi:
        total = len(series)
        label = p.get("entity_label", "series")
        msg = f"{bad:,} of {total:,} {label} with {check} issues"
        return Outcome(total, bad, {"check": check, "points": points, "examples": details}, msg)
    single = series.get("series") or next(iter(series.values()), [])
    res = fn(single, **{k: v for k, v in p.items() if k in ts_mod.PARAMS[check]})
    return Outcome(max(len(single), 1), res["failed"], {"check": check, "issues": res["issues"][:25]},
                   f"{res['failed']:,} {check} issues in {len(single):,} points")
