"""Rule lifecycle: draft -> review -> approved -> active (or rejected, back to the author).

    proposed   a saved draft; the author can edit it, dry-run it and send it for approval
    review     sent for approval; waits in the Review queue for an administrator
    approved   an administrator approved it; it is not running until someone activates it
    rejected   an administrator sent it back with a reason; the author edits it and sends it again
    active     runs on its schedule
    disabled   switched off

Only administrators approve, reject and activate. Anyone who can edit can save drafts and send them for approval.
"""
from __future__ import annotations

from sqlalchemy import select

from ..models import Asset, Rule, audit, utcnow
from ..services import update_rule

DRAFT = ("proposed", "rejected")
WAITING = ("review", "approved")
LIVE_EDIT_FIELDS = ("name", "type", "column", "params", "dimension", "severity", "threshold", "description",
                    "schedule_minutes", "category")


class ReviewError(ValueError):
    pass


def _rules(db, ids: list[int]) -> list[Rule]:
    ids = sorted({int(i) for i in ids or []})
    if not ids:
        raise ReviewError("Pick at least one rule")
    rows = {r.id: r for r in db.scalars(select(Rule).where(Rule.id.in_(ids)))}
    missing = [i for i in ids if i not in rows]
    if missing:
        raise ReviewError(f"No rule with id {', '.join(map(str, missing))}")
    return [rows[i] for i in ids]


def _move(db, rule: Rule, status: str, actor: str, note: str, **fields) -> None:
    update_rule(db, rule, {"status": status}, actor, note)
    for k, v in fields.items():
        setattr(rule, k, v)


def submit(db, ids: list[int], actor: str, note: str | None = None) -> list[Rule]:
    """Send drafts for approval. Rules already waiting, live or disabled are refused with the reason."""
    rules = _rules(db, ids)
    bad = [f"{r.name} is {r.status}" for r in rules if r.status not in DRAFT]
    if bad:
        raise ReviewError("Only saved drafts can be sent for approval: " + "; ".join(bad[:5]))
    for r in rules:
        _move(db, r, "review", actor, "sent for approval", submitted_by=actor, submitted_ts=utcnow(),
              submit_note=(note or "").strip() or None, decided_by=None, decided_ts=None, decision_note=None)
        a = db.get(Asset, r.asset_id)
        audit(db, actor, "rule.submitted", a.fqn if a else None, rule_id=r.id, note=note)
    db.flush()
    return rules


def withdraw(db, ids: list[int], actor: str, is_admin: bool) -> list[Rule]:
    """Take rules back out of review (the author, or an administrator)."""
    rules = _rules(db, ids)
    for r in rules:
        if r.status not in WAITING:
            raise ReviewError(f"{r.name} is {r.status}, not waiting for review")
        if not is_admin and r.submitted_by not in (None, actor):
            raise ReviewError(f"{r.name} was sent by {r.submitted_by}; only they or an administrator can withdraw it")
    for r in rules:
        _move(db, r, "proposed", actor, "withdrawn from review")
    db.flush()
    return rules


def decide(db, ids: list[int], decision: str, actor: str, note: str | None = None) -> list[Rule]:
    """Administrators only (the API checks the role). decision: approve | reject | activate | approve_activate."""
    if decision not in ("approve", "reject", "activate", "approve_activate"):
        raise ReviewError("Decision must be approve, reject, activate or approve_activate")
    note = (note or "").strip() or None
    if decision == "reject" and not note:
        raise ReviewError("Say why the rule is rejected, so the author knows what to change")
    rules = _rules(db, ids)
    for r in rules:
        if decision in ("approve", "reject", "approve_activate") and r.status not in WAITING:
            raise ReviewError(f"{r.name} is {r.status}: only rules sent for approval can be approved or rejected")
        if decision == "activate" and r.status != "approved":
            raise ReviewError(f"{r.name} is {r.status}: approve it first, or use Approve and activate")
        if decision == "approve" and r.status == "approved":
            raise ReviewError(f"{r.name} is already approved")
    now = utcnow()
    for r in rules:
        a = db.get(Asset, r.asset_id)
        if decision == "approve":
            _move(db, r, "approved", actor, "approved", decided_by=actor, decided_ts=now, decision_note=note)
        elif decision == "reject":
            _move(db, r, "rejected", actor, f"rejected: {note}", decided_by=actor, decided_ts=now, decision_note=note)
        else:
            _move(db, r, "active", actor, "approved and activated" if decision == "approve_activate" else "activated",
                  decided_by=actor, decided_ts=now, decision_note=note or r.decision_note)
        audit(db, actor, f"rule.{decision}", a.fqn if a else None, rule_id=r.id, note=note)
    db.flush()
    return rules


def counts(db) -> dict:
    out = {"proposed": 0, "review": 0, "approved": 0, "rejected": 0, "active": 0, "disabled": 0}
    for (st,) in db.execute(select(Rule.status)):
        out[st] = out.get(st, 0) + 1
    return out
