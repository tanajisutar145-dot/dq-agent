"""Custom DQ metrics: user-defined numbers shown as tiles on the Overview page.

A metric is a measure plus optional filters (domain, platform, connection,
dimension, severity, time window), or a read-only SQL query that returns one
number from a connection. Each metric can have a target and a warning level;
the tile turns green, amber or red against them. Every evaluation is kept so
the tile can show a trend.

Built-in measures read the app database only, so they are cheap and refresh on
every Overview load (a history point is stored at most once an hour). SQL
metrics run on the platform, so they refresh on demand and on scheduler ticks.
"""
from __future__ import annotations

import re
from datetime import timedelta
from typing import Any

from sqlalchemy import func, select

from ..connectors import get_connector
from ..connectors.base import FORBIDDEN_SQL, UnsafeSQLError
from ..models import Asset, CheckResult, Connection, CustomMetric, CustomMetricValue, Incident, Rule, utcnow
from .rules import DIMENSIONS, SEVERITIES

ASSET_FILTERS = ["domain", "platform", "connection"]

MEASURES: dict[str, dict[str, Any]] = {
    "avg_score": {"label": "Average DQ score", "unit": "score", "direction": "higher", "filters": ASSET_FILTERS,
                  "help": "Mean DQ score (0-100) of the monitored datasets."},
    "dimension_score": {"label": "Dimension score", "unit": "score", "direction": "higher",
                        "filters": ["dimension", *ASSET_FILTERS], "required": ["dimension"],
                        "help": "Mean score of one quality dimension, e.g. completeness."},
    "pass_rate": {"label": "Check pass rate", "unit": "%", "direction": "higher",
                  "filters": ["window_days", "dimension", "severity", *ASSET_FILTERS],
                  "help": "Share of checks that passed in the time window (errored checks excluded)."},
    "failed_checks": {"label": "Failed checks", "unit": "count", "direction": "lower",
                      "filters": ["window_days", "dimension", "severity", *ASSET_FILTERS],
                      "help": "Number of failed checks in the time window."},
    "failing_rules": {"label": "Rules failing now", "unit": "count", "direction": "lower",
                      "filters": ["dimension", "severity", *ASSET_FILTERS],
                      "help": "Active rules whose latest check failed."},
    "open_incidents": {"label": "Open incidents", "unit": "count", "direction": "lower",
                       "filters": ["severity", *ASSET_FILTERS],
                       "help": "Open or acknowledged incidents."},
    "datasets_below": {"label": "Datasets below a score", "unit": "count", "direction": "lower",
                       "filters": ["threshold", *ASSET_FILTERS],
                       "help": "Monitored datasets whose DQ score is under the threshold."},
    "rule_coverage": {"label": "Rule coverage", "unit": "%", "direction": "higher", "filters": ASSET_FILTERS,
                      "help": "Share of datasets with at least one active rule."},
    "owner_coverage": {"label": "Owner coverage", "unit": "%", "direction": "higher", "filters": ASSET_FILTERS,
                       "help": "Share of datasets with an owner."},
    "certified_share": {"label": "Certified datasets", "unit": "%", "direction": "higher", "filters": ASSET_FILTERS,
                        "help": "Share of datasets marked certified."},
    "sql": {"label": "Custom SQL", "unit": "", "direction": "higher", "filters": ["connection", "sql"],
            "required": ["connection", "sql"],
            "help": "A read-only SELECT on a connection that returns one number (first column of the first row)."},
}
UNITS = ["score", "%", "count", "rows", "hours", "days", ""]
HISTORY_EVERY = timedelta(minutes=60)
TREND_POINTS = 30


# ---------------------------------------------------------------------------- validation
def check_sql(sql: str) -> str:
    s = (sql or "").strip().rstrip(";").strip()
    if not s:
        raise ValueError("Enter a SQL query")
    if not re.match(r"(?is)^\s*(select|with)\b", s):
        raise UnsafeSQLError("Only SELECT (or WITH ... SELECT) queries are allowed")
    if FORBIDDEN_SQL.search(s):
        raise UnsafeSQLError("The query must be a single read-only SELECT (no ;, comments, or DDL/DML keywords)")
    return s


def _num(v, what: str, lo: float | None = None, hi: float | None = None) -> float | None:
    if v in (None, ""):
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        raise ValueError(f"{what} must be a number") from None
    if (lo is not None and f < lo) or (hi is not None and f > hi):
        raise ValueError(f"{what} must be between {lo:g} and {hi:g}")
    return f


def normalize(body: dict) -> dict:
    """Validate a create/update payload and return clean column values."""
    name = str(body.get("name") or "").strip()
    if not name:
        raise ValueError("Give the metric a name")
    measure = body.get("measure")
    if measure not in MEASURES:
        raise ValueError(f"Unknown measure {measure!r}")
    spec = MEASURES[measure]
    raw = body.get("params") or {}
    params: dict[str, Any] = {}
    for k in spec["filters"]:
        v = raw.get(k)
        if v in (None, ""):
            continue
        if k == "window_days":
            params[k] = int(_num(v, "Time window (days)", 1, 365))
        elif k == "threshold":
            params[k] = _num(v, "Score threshold", 0, 100)
        elif k == "dimension":
            if v not in DIMENSIONS:
                raise ValueError(f"Unknown dimension {v!r}")
            params[k] = v
        elif k == "severity":
            if v not in SEVERITIES:
                raise ValueError(f"Unknown severity {v!r}")
            params[k] = v
        elif k == "sql":
            params[k] = check_sql(str(v))
        else:
            params[k] = str(v).strip()
    for k in spec.get("required", []):
        if k not in params:
            raise ValueError(f"{MEASURES[measure]['label']} needs a {k.replace('_', ' ')}")
    direction = body.get("direction") or spec["direction"]
    if direction not in ("higher", "lower"):
        raise ValueError("direction must be 'higher' or 'lower'")
    unit = body.get("unit")
    unit = spec["unit"] if unit is None else str(unit).strip()[:20]
    return {"name": name[:200], "description": (str(body.get("description") or "").strip() or None),
            "measure": measure, "params": params, "unit": unit, "direction": direction,
            "target": _num(body.get("target"), "Target"), "warn_at": _num(body.get("warn_at"), "Warning level"),
            "show_on_overview": bool(body.get("show_on_overview", True))}


# ---------------------------------------------------------------------------- computation
def _asset_where(q, p: dict):
    if p.get("domain"):
        q = q.where(Asset.domain.is_(None) if p["domain"] == "unassigned" else Asset.domain == p["domain"])
    if p.get("platform"):
        q = q.where(Asset.platform == p["platform"])
    if p.get("connection"):
        q = q.where(Asset.connection == p["connection"])
    return q


def _share(part: int, whole: int) -> float | None:
    return round(part / whole * 100, 1) if whole else None


def compute(db, measure: str, p: dict) -> float | None:
    """The metric's current value, or None when there is nothing to measure yet."""
    if measure == "sql":
        conn = get_connector(p["connection"])
        if not getattr(conn, "supports_sql", True):
            raise ValueError(f"Connection {p['connection']!r} does not run SQL")
        rows = conn.query(check_sql(p["sql"]))
        if not rows:
            raise ValueError("The query returned no rows")
        first = next(iter(rows[0].values()), None)
        if first is None:
            return None
        try:
            return float(first)
        except (TypeError, ValueError):
            raise ValueError(f"The query must return a number; got {str(first)[:40]!r}") from None

    assets = db.scalars(_asset_where(select(Asset), p)).all()
    if measure == "avg_score":
        scored = [a.score for a in assets if a.score is not None]
        return round(sum(scored) / len(scored), 1) if scored else None
    if measure == "dimension_score":
        vals = [(a.dimension_scores or {}).get(p["dimension"]) for a in assets]
        vals = [v for v in vals if v is not None]
        return round(sum(vals) / len(vals), 1) if vals else None
    if measure == "datasets_below":
        thr = float(p.get("threshold", 80))
        return float(sum(1 for a in assets if a.score is not None and a.score < thr))
    if measure == "rule_coverage":
        with_rules = set(db.scalars(select(Rule.asset_id).where(Rule.status == "active")))
        return _share(sum(1 for a in assets if a.id in with_rules), len(assets))
    if measure == "owner_coverage":
        return _share(sum(1 for a in assets if (a.owner or "").strip()), len(assets))
    if measure == "certified_share":
        return _share(sum(1 for a in assets if a.certified), len(assets))
    if measure in ("pass_rate", "failed_checks"):
        since = utcnow() - timedelta(days=int(p.get("window_days") or 7))
        q = (select(CheckResult.status, func.count()).join(Rule, Rule.id == CheckResult.rule_id)
             .join(Asset, Asset.id == CheckResult.asset_id).where(CheckResult.ts >= since))
        if p.get("dimension"):
            q = q.where(Rule.dimension == p["dimension"])
        if p.get("severity"):
            q = q.where(Rule.severity == p["severity"])
        by = dict(db.execute(_asset_where(q, p).group_by(CheckResult.status)).all())
        if measure == "failed_checks":
            return float(by.get("fail", 0))
        done = by.get("pass", 0) + by.get("warn", 0) + by.get("fail", 0)
        return _share(by.get("pass", 0) + by.get("warn", 0), done)
    if measure == "failing_rules":
        q = (select(func.count()).select_from(Rule).join(Asset, Asset.id == Rule.asset_id)
             .where(Rule.status == "active", Rule.last_status == "fail"))
        if p.get("dimension"):
            q = q.where(Rule.dimension == p["dimension"])
        if p.get("severity"):
            q = q.where(Rule.severity == p["severity"])
        return float(db.scalar(_asset_where(q, p)) or 0)
    if measure == "open_incidents":
        q = select(Incident).where(Incident.status.in_(["open", "ack"]))
        if p.get("severity"):
            q = q.where(Incident.severity == p["severity"])
        incs = db.scalars(q).all()
        if any(p.get(k) for k in ASSET_FILTERS):
            fqns = {a.fqn for a in assets}
            incs = [i for i in incs if i.root_fqn in fqns]
        return float(len(incs))
    raise ValueError(f"Unknown measure {measure!r}")


def status_of(value: float | None, direction: str, target: float | None, warn_at: float | None) -> str:
    """ok | warn | bad against the target; info when no target is set; nodata when there is no value."""
    if value is None:
        return "nodata"
    if target is None:
        return "info"
    meets = (lambda a, b: a >= b) if direction != "lower" else (lambda a, b: a <= b)
    if meets(value, target):
        return "ok"
    if warn_at is not None and meets(value, warn_at):
        return "warn"
    return "bad"


# ---------------------------------------------------------------------------- persistence
def evaluate(db, m: CustomMetric, record: bool = True) -> float | None:
    """Compute and store the value. On error the previous value is kept and the error is saved."""
    try:
        v = compute(db, m.measure, m.params or {})
    except Exception as e:
        m.last_error = f"{type(e).__name__}: {e}"[:500]
        m.last_evaluated = utcnow()
        return None
    m.last_value, m.last_error, m.last_evaluated = v, None, utcnow()
    if record and v is not None:
        db.add(CustomMetricValue(metric_id=m.id, value=v))
    return v


def _last_point(db, metric_id: int) -> CustomMetricValue | None:
    return db.scalars(select(CustomMetricValue).where(CustomMetricValue.metric_id == metric_id)
                      .order_by(CustomMetricValue.ts.desc()).limit(1)).first()


def refresh_builtin(db) -> None:
    """Live values for built-in measures; store a history point at most once an hour."""
    now = utcnow()
    for m in db.scalars(select(CustomMetric).where(CustomMetric.measure != "sql")):
        last = _last_point(db, m.id)
        evaluate(db, m, record=last is None or now - last.ts >= HISTORY_EVERY)
    db.flush()


def evaluate_all(db, include_sql: bool = True) -> dict:
    evaluated, errors = 0, {}
    for m in db.scalars(select(CustomMetric)):
        if m.measure == "sql" and not include_sql:
            continue
        evaluate(db, m)
        evaluated += 1
        if m.last_error:
            errors[m.name] = m.last_error
    db.flush()
    return {"evaluated": evaluated, "errors": errors}


def describe_filters(m: CustomMetric) -> str:
    p = m.params or {}
    parts = []
    if m.measure == "sql":
        return f"SQL on {p.get('connection')}"
    for k in ("dimension", "severity", "domain", "platform", "connection"):
        if p.get(k):
            parts.append(f"{k} {p[k]}")
    if "window_days" in MEASURES[m.measure]["filters"]:
        parts.append(f"last {p.get('window_days') or 7} days")
    if m.measure == "datasets_below":
        parts.append(f"under {p.get('threshold', 80):g}")
    return ", ".join(parts) or "all datasets"


def view(db, m: CustomMetric) -> dict:
    pts = db.scalars(select(CustomMetricValue).where(CustomMetricValue.metric_id == m.id)
                     .order_by(CustomMetricValue.ts.desc()).limit(TREND_POINTS)).all()
    spec = MEASURES.get(m.measure, {})
    return {**m.to_dict(), "measure_label": spec.get("label", m.measure), "scope": describe_filters(m),
            "status": status_of(m.last_value, m.direction, m.target, m.warn_at),
            "trend": [{"ts": p.ts.isoformat(), "value": p.value} for p in reversed(pts)]}


def list_views(db, only_overview: bool = False) -> list[dict]:
    q = select(CustomMetric).order_by(CustomMetric.position, CustomMetric.id)
    if only_overview:
        q = q.where(CustomMetric.show_on_overview.is_(True))
    return [view(db, m) for m in db.scalars(q)]


def options(db) -> dict:
    domains = sorted({a or "unassigned" for a in db.scalars(select(Asset.domain).distinct())})
    platforms = sorted({p for p in db.scalars(select(Asset.platform).distinct()) if p})
    conns = [{"name": c.name, "type": c.type, "enabled": c.enabled is not False}
             for c in db.scalars(select(Connection).order_by(Connection.name))]
    return {"measures": MEASURES, "units": UNITS, "dimensions": DIMENSIONS, "severities": SEVERITIES,
            "domains": domains, "platforms": platforms, "connections": conns}


def delete_metric(db, m: CustomMetric) -> None:
    from sqlalchemy import delete
    db.execute(delete(CustomMetricValue).where(CustomMetricValue.metric_id == m.id))
    db.delete(m)
    db.flush()
