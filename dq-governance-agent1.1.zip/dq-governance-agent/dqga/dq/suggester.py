"""Rule suggestions and natural-language rule authoring.

Heuristics run on the profile (no LLM needed). If an LLM is configured it
adds business-aware suggestions from metadata + profile statistics only
(never raw rows). Every suggestion is validated against the rule catalog and
lands as `proposed` until a steward approves it.
"""
from __future__ import annotations

import json
import re
from typing import Any

from .rules import RULE_TYPES, validate_rule

EMAIL_RE = r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def heuristic_suggestions(fqn: str, profile: dict, columns: list[dict], other_assets: list[dict]) -> list[dict]:
    sug: list[dict] = []
    n = profile.get("row_count", 0)
    cprof = profile.get("columns", {})
    pk_index = {}
    for a in other_assets:
        for c in a.get("columns", []):
            pk_index.setdefault(_norm(c["name"]), []).append(a["fqn"])

    if n:
        sug.append({"type": "anomaly", "params": {"metric": "row_count", "sensitivity": 3.0}, "severity": "high",
                    "reason": "Volume monitoring: catches dropped loads and duplicated batches"})
    for c in columns:
        name, fam = c["name"], c.get("family")
        p = cprof.get(name)
        if not p or not n:
            continue
        lname = name.lower()
        is_key = lname == "id" or lname.endswith("_id") or lname.endswith("_key") or lname.endswith("_no")
        if p["null_rate"] == 0:
            sug.append({"type": "not_null", "column": name, "severity": "high" if is_key else "medium",
                        "reason": f"0 nulls in {n:,} rows"})
        elif p["null_rate"] < 0.05:
            thr = max(0.0, round(1 - p["null_rate"] * 2, 3))
            sug.append({"type": "not_null", "column": name, "threshold": thr, "severity": "medium",
                        "reason": f"{p['null_rate']:.2%} nulls today; alert if it doubles"})
            sug.append({"type": "anomaly", "column": name, "params": {"metric": "null_rate", "sensitivity": 3.0},
                        "severity": "medium", "reason": "Track null-rate drift"})
        if is_key and p["distinct"] == p["non_null"] and p["non_null"] > 0:
            sug.append({"type": "unique", "params": {"columns": [name]}, "severity": "high",
                        "reason": "Every value is distinct; looks like a key"})
        if 0 < p["distinct"] <= 20 and fam in ("string", "numeric") and p.get("top_values") and not is_key:
            vals = [tv["value"] for tv in p["top_values"]]
            if sum(tv["count"] for tv in p["top_values"]) >= p["non_null"] * 0.999 and len(vals) == p["distinct"]:
                sug.append({"type": "accepted_values", "column": name, "params": {"values": vals}, "severity": "medium",
                            "reason": f"Low cardinality ({p['distinct']} values)"})
                sug.append({"type": "anomaly", "column": name, "params": {"metric": "distribution_psi"},
                            "severity": "low", "reason": "Detect category mix shifts (PSI)"})
        if fam == "numeric" and p.get("p05") is not None and p.get("p95") is not None and not is_key:
            lo, hi = p["min"], p["max"]
            if isinstance(lo, (int, float)) and isinstance(hi, (int, float)):
                span = (hi - lo) or abs(hi) or 1
                rmin = 0 if lo >= 0 else round(lo - 0.5 * span, 3)
                sug.append({"type": "range", "column": name, "params": {"min": rmin, "max": round(hi + 0.5 * span, 3)},
                            "threshold": 0.999, "severity": "medium",
                            "reason": f"Observed {lo:g}..{hi:g}" + ("; negatives never seen" if lo >= 0 else "")})
                sug.append({"type": "anomaly", "column": name, "params": {"metric": "mean", "sensitivity": 4.0},
                            "severity": "low", "reason": "Detect level shifts in the mean"})
        if fam == "temporal":
            sug.append({"type": "not_future", "column": name, "severity": "medium",
                        "reason": "Timestamps should not be in the future"})
            if any(k in lname for k in ("ts", "time", "updated", "loaded", "ingest", "created", "date")):
                sug.append({"type": "freshness", "column": name, "params": {"max_age_hours": 24}, "severity": "high",
                            "reason": "Most recent record should be at most a day old (tune to the load schedule)"})
        if fam == "string" and p.get("patterns"):
            top = p["patterns"][0]
            if "email" in lname:
                sug.append({"type": "regex", "column": name, "params": {"pattern": EMAIL_RE}, "threshold": 0.99,
                            "severity": "medium", "reason": "Email format"})
            elif top["share"] >= 0.98 and re.fullmatch(r"[A9a\-_/.:]+", top["pattern"]) and len(top["pattern"]) >= 4:
                regex = re.escape(top["pattern"]).replace("9", "[0-9]").replace("A", "[A-Z]").replace("a", "[a-z]")
                sug.append({"type": "regex", "column": name, "params": {"pattern": regex}, "threshold": 0.995,
                            "severity": "low", "reason": f"{top['share']:.0%} of values share the shape {top['pattern']}"})
        if is_key and not (p["distinct"] == p["non_null"]):
            for ref_fqn in pk_index.get(_norm(name), []):
                if ref_fqn != fqn:
                    sug.append({"type": "referential", "column": name,
                                "params": {"ref_table": ref_fqn, "ref_column": name}, "severity": "high",
                                "reason": f"{name} also exists in {ref_fqn}; likely a foreign key"})
                    break

    out, seen = [], set()
    for s in sug:
        try:
            v = validate_rule(s, columns)
        except Exception:
            continue
        key = (v["type"], v.get("column"), json.dumps(v["params"].get("metric")), json.dumps(v["params"].get("columns")))
        if key in seen:
            continue
        seen.add(key)
        v["source"] = "suggested"
        out.append(v)
    return out


RULE_CATALOG_TEXT = "\n".join(f"- {k}: {v['desc']}" + (f" params={v.get('params')}" if v.get("params") else "")
                              for k, v in RULE_TYPES.items())

SQL_GUIDANCE = (
    "\nGuidance for rules that run as SQL on the platform:\n"
    "- Prefer the specific rule types (not_null, unique, range, accepted_values, regex, length, referential, freshness, not_future) over custom_sql whenever one fits; "
    "use custom_sql only for cross-column or conditional logic.\n"
    "- custom_sql params.expression is ONE boolean expression that is TRUE for VALID rows, using only columns of this table. "
    "No SELECT, joins, subqueries, semicolons, comments or functions that change data; it must be read-only.\n"
    "- Write it for the sql_dialect given (Spark SQL / Databricks, Snowflake, DuckDB...) and use common functions: COALESCE, CASE WHEN, CAST, LENGTH, TRIM, UPPER, LOWER.\n"
    "- Mind NULLs: a comparison with NULL is unknown, not true. If another rule already requires the column, write the expression so that NULL does not add a second failure "
    "(for example 'ship_date IS NULL OR order_date IS NULL OR ship_date >= order_date').\n"
    "- Respect data types: cast before comparing text to numbers or dates, and never compare a date to a string literal in another format.\n"
    "- Conditional rules read well as CASE WHEN: \"CASE WHEN order_status = 'CANCELLED' THEN ship_date IS NULL ELSE TRUE END\". "
    "To limit a rule to a subset of rows, set params.where (for example \"order_status <> 'CANCELLED'\").\n"
    "- One business statement per rule, with a short clear name. Use threshold 1.0 for hard business rules and 0.95-0.99 only when some noise is expected.\n"
    "- Never invent columns, values or business limits. Use values and limits that appear in the profile or the reference documents, and quote the source in reason. "
    "If you are unsure of a limit, leave the rule out.\n"
    "- Plain values in lists (Austin, not 'Austin'): do not add quotes around allowed values.\n"
)


LLM_SUGGEST_SYSTEM = (
    "You are a senior data quality engineer. Propose data quality rules as JSON only. "
    "Use ONLY these rule types:\n" + RULE_CATALOG_TEXT +
    "\nregex also accepts params.negate=true for values that must NOT match (for example raw card numbers in a masked column)."
    "\nReturn {\"rules\": [{\"type\", \"column\", \"params\", \"severity\" (critical|high|medium|low), "
    "\"threshold\" (0..1), \"category\" (core|business|governance), \"reason\"}]}.\n"
    "Categories: core = nulls, data types, formats, keys and references; business = rules of the business domain "
    "(allowed values, ranges, units, cross-column logic with custom_sql); governance = privacy, security, retention, "
    "consent, audit trail and regulatory compliance. Propose rules in all three categories where the data allows. "
    "When reference_context is given (data models, ontologies, glossaries, master data, business and policy "
    "documents), base rules on it and cite the file in reason. A GOVERNANCE CONTEXT block in it (a data contract, policies, standards, business glossary) holds requirements: "
    "cover each contract promise and policy that a rule can check, and cite 'contract <name>', 'policy <key>' or 'term <name>' in reason. Use only columns of this table. No prose." + SQL_GUIDANCE
)


def llm_suggestions(llm, fqn: str, profile: dict, columns: list[dict], description: str | None,
                    context: str | None = None, dialect: str | None = None) -> list[dict]:
    if llm is None:
        return []
    slim = {c: {k: v for k, v in p.items() if k in ("family", "null_rate", "distinct", "min", "max", "mean",
                                                    "top_values", "patterns", "data_type")}
            for c, p in profile.get("columns", {}).items()}
    payload = {"table": fqn, "description": description, "row_count": profile.get("row_count"), "columns": slim}
    if dialect:
        payload["sql_dialect"] = dialect
    prompt = json.dumps(payload, default=str)[:12000]
    if context:
        prompt = prompt[:-1] + ', "reference_context": ' + json.dumps(context) + "}"
    data = llm.complete_json(LLM_SUGGEST_SYSTEM, prompt)
    out = []
    for s in (data or {}).get("rules", []) if isinstance(data, dict) else []:
        try:
            v = validate_rule(s, columns)
            v["source"] = "llm"
            if s.get("category") in ("core", "business", "governance"):
                v["category"] = s["category"]
            out.append(v)
        except Exception:
            continue
    return out


# ---------------------------------------------------------------------------
# natural language -> rule
# ---------------------------------------------------------------------------
NL_SYSTEM = (
    "Convert the user's data quality requirement into ONE rule as JSON. Rule types:\n" + RULE_CATALOG_TEXT +
    "\nReturn {\"type\", \"column\", \"params\", \"severity\", \"threshold\", \"name\"}. "
    "For custom_sql, params.expression is a boolean SQL expression that is TRUE for valid rows. JSON only." + SQL_GUIDANCE
)

_NUM = r"(-?\d+(?:\.\d+)?)"


def _match_col(word: str, columns: list[dict]) -> str | None:
    w = _norm(word)
    for c in columns:
        if _norm(c["name"]) == w:
            return c["name"]
    for c in columns:
        if w and (w in _norm(c["name"]) or _norm(c["name"]) in w):
            return c["name"]
    return None


def _first_temporal(columns):
    return next((c["name"] for c in columns if c.get("family") == "temporal"), None)


def parse_nl_rule(text: str, columns: list[dict], assets: list[dict] | None = None) -> dict | None:
    """Plain-English rule parser (see nl_rules.py)."""
    from .nl_rules import parse
    r = parse(text, columns, assets)
    if r:
        r.pop("interpretation", None)
    return r


def _legacy_parse_nl_rule(text: str, columns: list[dict]) -> dict | None:
    t = text.strip().rstrip(".").strip()
    low = t.lower()
    col_tok = r"([A-Za-z_][A-Za-z0-9_ ]*?)"
    pats: list[tuple[str, Any]] = [
        (rf"^{col_tok} (?:must|should|cannot|can't|can not|may not) (?:not )?be (?:null|empty|blank|missing)$",
         lambda m: {"type": "not_null", "column": m[1]}),
        (rf"^{col_tok} (?:is|are) (?:required|mandatory)$", lambda m: {"type": "not_null", "column": m[1]}),
        (rf"^{col_tok} (?:must|should) (?:always )?be (?:populated|present|filled)$",
         lambda m: {"type": "not_null", "column": m[1]}),
        (rf"^{col_tok} (?:must|should) be unique$", lambda m: {"type": "unique", "params": {"columns": [m[1]]}}),
        (rf"^no duplicate {col_tok}s?$", lambda m: {"type": "unique", "params": {"columns": [m[1]]}}),
        (rf"^{col_tok} (?:must|should) be between {_NUM} and {_NUM}$",
         lambda m: {"type": "range", "column": m[1], "params": {"min": float(m[2]), "max": float(m[3])}}),
        (rf"^{col_tok} (?:must|should) be (?:>=|at least|greater than or equal to) {_NUM}$",
         lambda m: {"type": "range", "column": m[1], "params": {"min": float(m[2])}}),
        (rf"^{col_tok} (?:must|should) be (?:<=|at most|less than or equal to) {_NUM}$",
         lambda m: {"type": "range", "column": m[1], "params": {"max": float(m[2])}}),
        (rf"^{col_tok} (?:must|should) be (?:positive|greater than zero|> ?0)$",
         lambda m: {"type": "custom_sql", "column": m[1], "params": {"expression": f"{m[1]} > 0"}}),
        (rf"^{col_tok} (?:must|should) (?:not be negative|be non-negative|be >= ?0)$",
         lambda m: {"type": "range", "column": m[1], "params": {"min": 0}}),
        (rf"^{col_tok} (?:must|should|cannot|can't) (?:not )?be in the future$",
         lambda m: {"type": "not_future", "column": m[1]}),
        (rf"^{col_tok} (?:must|should) be (?:a )?valid email(?: address)?$",
         lambda m: {"type": "regex", "column": m[1], "params": {"pattern": EMAIL_RE}}),
        (rf"^{col_tok} (?:must|should) be (?:one of|in) (.+)$",
         lambda m: {"type": "accepted_values", "column": m[1],
                    "params": {"values": [v.strip().strip("'\"[]()") for v in re.split(r",|\bor\b", m[2]) if v.strip()]}}),
        (rf"^{col_tok} (?:must|should) match (?:the )?(?:pattern|regex)? ?['\"]?(.+?)['\"]?$",
         lambda m: {"type": "regex", "column": m[1], "params": {"pattern": m[2]}}),
        (rf"^{col_tok} (?:must|should) (?:be|have) (\d+) (?:characters|chars|digits)(?: long)?$",
         lambda m: {"type": "length", "column": m[1], "params": {"min": int(m[2]), "max": int(m[2])}}),
        (rf"^{col_tok} (?:must|should) (?:exist|be present) in ([\w.]+)\.(\w+)$",
         lambda m: {"type": "referential", "column": m[1], "params": {"ref_table": m[2], "ref_column": m[3]}}),
        (rf"^(?:table|data|it) (?:must|should) (?:be )?(?:refreshed|updated|loaded) (?:every|within) (\d+) ?(hours?|h|minutes?|mins?|days?)$",
         lambda m: {"type": "freshness", "column": _first_temporal(columns),
                    "params": {"max_age_hours": int(m[1]) * (24 if m[2].startswith("d") else 1 / 60 if m[2].startswith("m") else 1)}}),
        (r"^(?:table )?(?:must|should) have (?:at least|more than|minimum of) (\d+) rows$",
         lambda m: {"type": "row_count", "params": {"min": int(m[1])}}),
        (rf"^{col_tok} (?:must|should) be (?:before|earlier than|<=) {col_tok}$",
         lambda m: {"type": "custom_sql", "column": m[1], "params": {"expression": f"{m[1]} <= {m[2]}"}}),
    ]
    for pat, build in pats:
        m = re.match(pat, low, re.IGNORECASE)
        if not m:
            continue
        orig = re.match(pat, t, re.IGNORECASE)
        groups = [orig.group(0)] + [g for g in orig.groups()]
        r = build(groups)
        if r.get("column"):
            mc = _match_col(r["column"], columns)
            if not mc:
                return None
            if r["type"] == "custom_sql":
                r["params"]["expression"] = r["params"]["expression"].replace(r["column"], mc)
                for c in columns:
                    r["params"]["expression"] = re.sub(rf"\b{re.escape(c['name'])}\b", c["name"],
                                                       r["params"]["expression"], flags=re.IGNORECASE)
            r["column"] = mc
        if r["type"] == "unique":
            r["params"]["columns"] = [_match_col(c, columns) or c for c in r["params"]["columns"]]
        if r["type"] == "custom_sql" and r.get("column"):
            r.pop("column", None)
        r["description"] = text
        return r
    return None


def nl_to_rule(text: str, columns: list[dict], llm=None, assets: list[dict] | None = None,
               context: str | None = None, aliases: dict[str, str] | None = None) -> dict:
    """Returns {"rule", "parser": "built-in"|"llm", "interpretation"} or raises ValueError.

    aliases map business terms from reference files to columns ("Asset Tag Number" -> asset_tag);
    context is the reference summary sent to the LLM when the built-in parser can't read the sentence.
    """
    from .nl_rules import find_columns, parse, suggestions_for

    if aliases:
        from ..reference import apply_aliases
        text_for_parser = apply_aliases(text, aliases)
    else:
        text_for_parser = text
    parsed = parse(text_for_parser, columns, assets)
    if parsed:
        interp = parsed.pop("interpretation", "")
        rule = validate_rule(parsed, columns)
        rule["source"] = "nl"
        return {"rule": rule, "parser": "built-in", "interpretation": interp}
    if llm is not None:
        schema = [{"name": c["name"], "type": c.get("data_type")} for c in columns]
        body = {"requirement": text, "columns": schema}
        if context:
            body["reference_context"] = context
        data = llm.complete_json(NL_SYSTEM, json.dumps(body))
        if isinstance(data, dict) and data.get("type"):
            data["description"] = text
            rule = validate_rule(data, columns)
            rule["source"] = "nl"
            from .nl_rules import describe
            return {"rule": rule, "parser": "llm", "interpretation": describe(rule)}
    examples = "; ".join(f"'{s}'" for s in suggestions_for(text, columns)[:4])
    found = ", ".join(c["name"] for c in find_columns(" " + text.lower() + " ", columns))
    hint = f" I recognised the column(s) {found}, but not what to check." if found else \
        " I couldn't find a column of this dataset in the sentence."
    raise ValueError(f"Couldn't turn that into a rule.{hint} Try for example: {examples}.")
