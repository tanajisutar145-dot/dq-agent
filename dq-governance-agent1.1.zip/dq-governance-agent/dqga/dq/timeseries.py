"""Industrial / OT time-series quality checks.

Each check takes a list of (timestamp, value) sorted by time and returns
{"failed": int, "issues": [..]}. Used for CDF time series and for sensor
tables in the lakehouse.
"""
from __future__ import annotations

from datetime import datetime
from statistics import median


def _deltas(points):
    return [(points[i][0] - points[i - 1][0]).total_seconds() for i in range(1, len(points))]


def _iso(t: datetime) -> str:
    return t.isoformat(timespec="seconds") if isinstance(t, datetime) else str(t)


def gaps(points, expected_interval_s: float | None = None, tolerance: float = 3.0, **_):
    if len(points) < 3:
        return {"failed": 0, "issues": []}
    d = _deltas(points)
    expected = float(expected_interval_s or median(d) or 1)
    issues = [{"from": _iso(points[i][0]), "to": _iso(points[i + 1][0]), "gap_s": round(dt)}
              for i, dt in enumerate(d) if dt > expected * tolerance]
    return {"failed": len(issues), "issues": issues, "expected_interval_s": expected}


def flatline(points, flatline_s: float = 6 * 3600, **_):
    issues, start = [], 0
    for i in range(1, len(points) + 1):
        if i == len(points) or points[i][1] != points[start][1]:
            dur = (points[i - 1][0] - points[start][0]).total_seconds()
            if dur >= flatline_s and i - start >= 3:
                issues.append({"from": _iso(points[start][0]), "to": _iso(points[i - 1][0]),
                               "value": points[start][1], "duration_h": round(dur / 3600, 1)})
            start = i
    return {"failed": len(issues), "issues": issues}


def spikes(points, spike_z: float = 8.0, **_):
    if len(points) < 10:
        return {"failed": 0, "issues": []}
    diffs = [points[i][1] - points[i - 1][1] for i in range(1, len(points)) if points[i][1] is not None and points[i - 1][1] is not None]
    if not diffs:
        return {"failed": 0, "issues": []}
    med = median(diffs)
    mad = median([abs(x - med) for x in diffs]) or 1e-9
    issues = []
    for i in range(1, len(points)):
        a, b = points[i - 1][1], points[i][1]
        if a is None or b is None:
            continue
        z = 0.6745 * ((b - a) - med) / mad
        if abs(z) > spike_z:
            issues.append({"at": _iso(points[i][0]), "value": b, "previous": a, "z": round(z, 1)})
    return {"failed": len(issues), "issues": issues}


def bounds(points, min: float | None = None, max: float | None = None, **_):  # noqa: A002
    issues = [{"at": _iso(t), "value": v} for t, v in points
              if v is not None and ((min is not None and v < float(min)) or (max is not None and v > float(max)))]
    return {"failed": len(issues), "issues": issues}


def monotonic(points, **_):
    issues = [{"at": _iso(points[i][0]), "previous": _iso(points[i - 1][0])}
              for i in range(1, len(points)) if points[i][0] <= points[i - 1][0]]
    return {"failed": len(issues), "issues": issues}


def sampling_rate(points, expected_interval_s: float = 60, tolerance_pct: float = 25, **_):
    if len(points) < 3:
        return {"failed": 0, "issues": []}
    actual = median(_deltas(points))
    dev = abs(actual - float(expected_interval_s)) / float(expected_interval_s) * 100
    failed = int(dev > float(tolerance_pct))
    return {"failed": failed, "issues": [{"median_interval_s": actual, "expected_s": expected_interval_s,
                                          "deviation_pct": round(dev, 1)}] if failed else []}


CHECKS = {"gaps": gaps, "flatline": flatline, "spikes": spikes, "bounds": bounds,
          "monotonic": monotonic, "sampling_rate": sampling_rate}
PARAMS = {
    "gaps": {"expected_interval_s", "tolerance"},
    "flatline": {"flatline_s"},
    "spikes": {"spike_z"},
    "bounds": {"min", "max"},
    "monotonic": set(),
    "sampling_rate": {"expected_interval_s", "tolerance_pct"},
}
