"""Push-down profiler.

One aggregate query per batch of columns, one GROUP BY per low-cardinality
column, and one small sample for pattern inference. Raw sample values are
returned to the caller for local PII classification but are never persisted
or sent to an LLM; only derived patterns are stored.
"""
from __future__ import annotations

import re
from collections import Counter
from datetime import date, datetime
from typing import Any

from ..connectors.base import Connector
from ..models import utcnow


def _j(v: Any) -> Any:
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    if isinstance(v, float):
        return round(v, 6)
    if isinstance(v, (int, str, bool)) or v is None:
        return v
    return str(v)


def shape(value: str) -> str:
    s = re.sub(r"[0-9]", "9", value[:40])
    s = re.sub(r"[A-Z]", "A", s)
    return re.sub(r"[a-z]", "a", s)


def profile_table(conn: Connector, fqn: str, columns: list[dict], cfg: dict | None = None) -> tuple[dict, dict]:
    cfg = cfg or {}
    d = conn.dialect
    t = d.table(fqn)
    batch_size = int(cfg.get("column_batch", 20))
    cols = [c for c in columns if c.get("family") != "complex"]
    prof: dict[str, Any] = {"row_count": 0, "columns": {}}

    for start in range(0, max(len(cols), 1), batch_size):
        batch = cols[start:start + batch_size]
        exprs = ["COUNT(*) AS n"]
        for i, c in enumerate(batch):
            q, fam = d.q(c["name"]), c.get("family")
            exprs += [f"COUNT({q}) AS nn_{i}", f"COUNT(DISTINCT {q}) AS d_{i}"]
            if fam in ("numeric", "temporal", "string"):
                exprs += [f"MIN({q}) AS mn_{i}", f"MAX({q}) AS mx_{i}"]
            if fam == "numeric":
                x = d.as_double(q)
                exprs += [f"AVG({x}) AS avg_{i}", f"{d.stddev(x)} AS sd_{i}",
                          f"{d.quantile(x, 0.05)} AS p05_{i}", f"{d.quantile(x, 0.5)} AS p50_{i}",
                          f"{d.quantile(x, 0.95)} AS p95_{i}"]
            if fam == "string":
                exprs += [f"MIN({d.length(q)}) AS lmin_{i}", f"MAX({d.length(q)}) AS lmax_{i}",
                          f"AVG({d.length(q)}) AS lavg_{i}"]
        row = conn.query(f"SELECT {', '.join(exprs)} FROM {t}")[0]
        n = int(row["n"] or 0)
        prof["row_count"] = n
        for i, c in enumerate(batch):
            nn = int(row.get(f"nn_{i}") or 0)
            dc = int(row.get(f"d_{i}") or 0)
            cp: dict[str, Any] = {
                "data_type": c.get("data_type"), "family": c.get("family"),
                "non_null": nn, "nulls": n - nn, "null_rate": round((n - nn) / n, 6) if n else 0.0,
                "distinct": dc, "distinct_rate": round(dc / nn, 6) if nn else 0.0,
                "min": _j(row.get(f"mn_{i}")), "max": _j(row.get(f"mx_{i}")),
            }
            for k, key in (("mean", "avg"), ("stddev", "sd"), ("p05", "p05"), ("p50", "p50"), ("p95", "p95"),
                           ("min_length", "lmin"), ("max_length", "lmax"), ("avg_length", "lavg")):
                if f"{key}_{i}" in row:
                    cp[k] = _j(float(row[f"{key}_{i}"]) if row[f"{key}_{i}"] is not None else None)
            prof["columns"][c["name"]] = cp

    # top values for low-cardinality columns
    low_card = [c for c in cols if 0 < prof["columns"].get(c["name"], {}).get("distinct", 0) <= 50]
    for c in low_card[: int(cfg.get("max_top_value_columns", 15))]:
        q = d.q(c["name"])
        rows = conn.query(f"SELECT {q} AS v, COUNT(*) AS n FROM {t} GROUP BY {q} ORDER BY n DESC {d.limit(10)}")
        prof["columns"][c["name"]]["top_values"] = [{"value": _j(r["v"]), "count": int(r["n"])} for r in rows]

    # small sample for pattern inference and local PII classification
    samples: dict[str, list[str]] = {}
    str_cols = [c for c in cols if c.get("family") == "string"][:40]
    if str_cols:
        sel = ", ".join(d.q(c["name"]) for c in str_cols)
        rows = conn.query(f"SELECT {sel} FROM {t} {d.limit(int(cfg.get('sample_rows', 500)))}")
        for c in str_cols:
            vals = [str(r[c["name"]]) for r in rows if r.get(c["name"]) is not None]
            samples[c["name"]] = vals
            if vals:
                cnt = Counter(shape(v) for v in vals)
                prof["columns"][c["name"]]["patterns"] = [
                    {"pattern": p, "share": round(k / len(vals), 3)} for p, k in cnt.most_common(5)]
    prof["profiled_at"] = utcnow().isoformat(timespec="seconds")
    return prof, samples
