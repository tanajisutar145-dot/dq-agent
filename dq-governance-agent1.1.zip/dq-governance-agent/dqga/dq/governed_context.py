"""Governance context for rule generation: the dataset's data contract, the policies that apply to it, and chosen standards.

Three things come out of it, all optional (the studio has a checkbox for each):
  * deterministic proposals, so rule generation works without a model:
      - every promise in the dataset's active contract that no active rule covers yet (tag "Contract"),
      - the retention period of a retention policy that applies (tag "Policy");
  * tags on proposals that already exist for another reason, when they also serve a policy or a standard
    (a certified dataset short of its minimum rules, a sensitive column a masking policy covers, a gap in a chosen standard);
  * text for the configured model, so its proposals follow the same contract, policies and standards.

Only names, thresholds and requirement text are used or sent: never data values.
"""
from __future__ import annotations

import re

from sqlalchemy import select

from ..governance import compliance
from ..governance import contracts as CT
from ..governance import policies as P
from ..governance import policy_authoring as PA
from ..models import Classification, Contract, GlossaryLink, GlossaryTerm, Policy, Rule
from . import rules as R

DEFAULTS = {"contracts": True, "policies": True, "glossary": True, "standards": []}

# which quality dimensions help a control that is not yet met (controls that are not about rules have no entry)
STANDARD_DIMENSIONS = {
    "gdpr": {"Art. 5(1)(d)": ["validity", "completeness", "accuracy"]},
    "sox": {"ITGC-DI-1": ["completeness", "validity", "consistency"]},
    "iso_8000": {"8000-8": ["completeness", "validity", "consistency"]},
    "dama": {"DQ-Completeness": ["completeness"]},
}
MAX_TAGGED = 3  # proposals tagged per unmet control


def options(raw: dict | None) -> dict:
    raw = raw or {}
    stds = raw.get("standards") or []
    return {"contracts": bool(raw.get("contracts", True)), "policies": bool(raw.get("policies", True)), "glossary": bool(raw.get("glossary", True)),
            "standards": [s for s in (stds if isinstance(stds, list) else []) if s in compliance.FRAMEWORKS]}


def gather(db, asset, opts: dict) -> dict:
    out = {"contract": None, "policies": [], "standards": [], "glossary": []}
    if opts["glossary"]:
        seen = set()
        for lk in db.scalars(select(GlossaryLink).where(GlossaryLink.target_ref.like(f"{asset.fqn}%"))):
            t = db.get(GlossaryTerm, lk.term_id)
            if t and t.id not in seen:
                seen.add(t.id)
                out["glossary"].append({"name": t.name, "definition": t.definition or "", "maps_to": lk.target_ref})
    if opts["contracts"]:
        out["contract"] = db.scalars(select(Contract).where(Contract.asset_id == asset.id, Contract.status == "active").order_by(Contract.id.desc())).first()
    if opts["policies"]:
        labels = {c.label for c in db.scalars(select(Classification).where(Classification.asset_id == asset.id, Classification.status != "rejected"))}
        out["policies"] = [p for p in db.scalars(select(Policy).where(Policy.enabled.is_(True)).order_by(Policy.key))
                           if P.selects((p.spec or {}).get("applies_to", {}), asset, labels)]
    for key in opts["standards"]:
        rep = compliance.report(db, key)
        out["standards"].append({"key": key, "title": rep["title"], "controls": rep["controls"],
                                 "unmet": [c for c in rep["controls"] if c["status"] != "met"]})
    return out


def _policy_text(p: Policy) -> str:
    return PA.describe({**(p.spec or {}), "type": p.type})


def summary(g: dict) -> dict:
    c = g["contract"]
    return {"contract": {"name": c.name, "version": c.version} if c else None,
            "glossary": [{"name": t["name"], "definition": t["definition"]} for t in g["glossary"]],
            "policies": [{"key": p.key, "type": p.type, "description": _policy_text(p)} for p in g["policies"]],
            "standards": [{"key": s["key"], "title": s["title"], "unmet": len(s["unmet"])} for s in g["standards"]]}


def label_of(c: Contract) -> str:
    return f"contract {c.name} v{c.version}"


def text(g: dict) -> str:
    """Requirement text for the model. Names and numbers only."""
    parts = []
    c = g["contract"]
    if c:
        lines = []
        for obj in (c.spec or {}).get("schema", []):
            for prop in obj.get("properties", []) or []:
                flags = [f for f, on in (("required", prop.get("required")), ("unique", prop.get("unique"))) if on]
                q = len(prop.get("quality", []) or [])
                lines.append(f"{prop.get('name')}" + (f" ({', '.join(flags)})" if flags else "") + (f", {q} quality term(s)" if q else ""))
        sla = [f"{s.get('property')} {s.get('value')}{s.get('unit', '')} on {s.get('element')}" for s in (c.spec or {}).get("slaProperties", []) or []]
        parts.append(f"DATA CONTRACT {label_of(c)} (the producer's promises; every one should be checked): " + "; ".join(lines)[:1800] + ("; SLA: " + ", ".join(sla) if sla else ""))
    if g["glossary"]:
        parts.append("BUSINESS GLOSSARY (terms mapped to this dataset; a definition that states a rule should be checked): "
                     + " | ".join(f"{t['name']} = {t['definition'][:200]} [maps to {t['maps_to']}]" for t in g["glossary"])[:1800])
    if g["policies"]:
        parts.append("POLICIES that apply to this dataset (requirements to help meet): " + " | ".join(f"policy {p.key}: {_policy_text(p)}" for p in g["policies"])[:1500])
    for s in g["standards"]:
        if s["unmet"]:
            parts.append(f"STANDARD {s['title']}, controls not yet met: " + "; ".join(f"{c['id']} {c['title']}" for c in s["unmet"])[:900])
    if not parts:
        return ""
    return ("\n\nGOVERNANCE CONTEXT. These are requirements, not suggestions. Cite 'contract <name>', 'policy <key>' or 'term <name>' in each rule's reason when it comes from one.\n"
            + "\n".join(parts))


def _cand(rule: dict, conf: float, category: str, label: str, why: str) -> dict:
    return {**rule, "confidence": conf, "category": category, "evidence": [why], "ref_docs": [label]}


def candidates(db, asset, cols: list[dict], g: dict) -> list[dict]:
    """Proposals that come straight from the contract and the policies; no model needed."""
    out = []
    c = g["contract"]
    if c:
        for v in CT.rules_from_contract(c.spec or {}, cols):
            out.append(_cand(v, 0.85, "Contract", label_of(c), f"Promised in {label_of(c)}"))
    names = {x["name"] for x in cols}
    by_col: dict[str, list[Policy]] = {}
    for p in g["policies"]:
        if p.type == "retention" and (p.spec or {}).get("column") in names:
            by_col.setdefault(p.spec["column"], []).append(p)
    for col, pols in by_col.items():  # several retention policies on one column: the strictest period applies
        try:
            pols.sort(key=lambda p: int(p.spec["max_age_days"]))
            p = pols[0]
            s = p.spec
            v = R.validate_rule({"type": "retention", "column": col, "params": {"max_age_days": int(s["max_age_days"])},
                                 "severity": s.get("severity", "medium"), "name": f"{col} no older than {s['max_age_days']} days (policy {p.key})"}, cols)
        except Exception:
            continue
        c = {**_cand(v, 0.9, "Policy", f"policy {p.key}", f"Policy {p.key}: {_policy_text(p)}"), "rule_category": "governance"}
        for other in pols[1:]:
            c["ref_docs"].append(f"policy {other.key}")
            c["evidence"].append(f"Policy {other.key} allows {other.spec['max_age_days']} days; the stricter period applies")
        out.append(c)
    return out


def annotate(db, asset, cands: list[dict], g: dict) -> None:
    """Tag proposals that also serve a policy, a standard, or were written by the model from this context."""
    def tag(c, source, label, why):
        if source not in c["sources"]:
            c["sources"] = sorted(set(c["sources"]) | {source})
        if label and label not in (c.get("ref_docs") or []):
            c["ref_docs"] = list(c.get("ref_docs") or []) + [label]
        if why not in c["evidence"]:
            c["evidence"].append(why)

    active = db.scalars(select(Rule).where(Rule.asset_id == asset.id, Rule.status == "active")).all()
    labels = {x.column: x.label for x in db.scalars(select(Classification).where(Classification.asset_id == asset.id, Classification.status != "rejected"))}
    pool = sorted([c for c in cands if c["confidence"] >= 0.7 and not ({"Contract", "Policy"} & set(c["sources"]))], key=lambda c: -c["confidence"])
    for p in g["policies"]:
        s = p.spec or {}
        if p.type == "certification" and asset.certified:
            gap = int(s.get("min_rules", 3)) - len(active)
            for c in [c for c in pool if "Policy" not in c["sources"]][:max(0, gap)]:
                tag(c, "Policy", f"policy {p.key}", f"Policy {p.key}: certified datasets need at least {s.get('min_rules', 3)} active rules (this has {len(active)})")
        elif p.type == "masking":
            wanted = set(s.get("labels") or (s.get("applies_to") or {}).get("classification") or [])
            for c in cands:
                if c.get("rule_category") == "governance" and labels.get(c.get("column")) in wanted:
                    tag(c, "Policy", f"policy {p.key}", f"Policy {p.key}: {labels[c['column']]} columns must be protected")
    for st in g["standards"]:
        dims = STANDARD_DIMENSIONS.get(st["key"], {})
        for ctl in st["unmet"]:
            want = dims.get(ctl["id"])
            if not want:
                continue
            for c in [c for c in cands if c.get("dimension") in want and "Standard" not in c["sources"]][:MAX_TAGGED]:
                tag(c, "Standard", f"{st['title'].split(' (')[0]} {ctl['id']}", f"Helps {st['title'].split(' (')[0]} {ctl['id']}: {ctl['title']}")
    # a model proposal that cites the contract, a policy or a business term in its reason
    keys = {p.key for p in g["policies"]}
    for c in cands:
        if "LLM" not in c["sources"]:
            continue
        reason = " ".join(c["evidence"]).lower()
        for k in keys:
            if re.search(rf"\b{re.escape(k.lower())}\b", reason):
                tag(c, "Policy", f"policy {k}", f"Written by the model from policy {k}")
        for t in g["glossary"]:
            if re.search(rf"{re.escape(t['name'].lower())}", reason):
                tag(c, "Glossary", f"term {t['name']}", f"Written by the model from the business term {t['name']}")
        if g["contract"] and "contract" in reason:
            tag(c, "Contract", label_of(g["contract"]), f"Written by the model from {label_of(g['contract'])}")
