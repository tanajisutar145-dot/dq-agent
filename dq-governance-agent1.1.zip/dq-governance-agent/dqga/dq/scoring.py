"""DQ scores (0-100) per asset, dimension, and domain.

Score = severity-weighted mean of the latest pass rate of each active rule,
where a failing check contributes at most 0.5. Errored checks are excluded
(they say nothing about the data).
"""
from __future__ import annotations

from collections import defaultdict
from datetime import timedelta

from sqlalchemy import func, select

from ..models import Asset, CheckResult, MetricPoint, Rule, utcnow
from .rules import SEVERITY_WEIGHT


def latest_results(db, asset_id: int) -> dict[int, CheckResult]:
    rules = db.scalars(select(Rule).where(Rule.asset_id == asset_id, Rule.status == "active")).all()
    out = {}
    for r in rules:
        res = db.scalars(select(CheckResult).where(CheckResult.rule_id == r.id)
                         .order_by(CheckResult.ts.desc(), CheckResult.id.desc()).limit(1)).first()
        if res:
            out[r.id] = res
    return out


def asset_scores(db, asset_id: int) -> tuple[float | None, dict[str, float]]:
    rules = {r.id: r for r in db.scalars(select(Rule).where(Rule.asset_id == asset_id, Rule.status == "active"))}
    latest = latest_results(db, asset_id)
    dim_num, dim_den = defaultdict(float), defaultdict(float)
    num = den = 0.0
    for rid, res in latest.items():
        if res.status == "error":
            continue
        r = rules[rid]
        w = SEVERITY_WEIGHT.get(r.severity, 2)
        # A failing check counts for at most half, so any failure visibly lowers the score;
        # aggregate checks (freshness, anomaly, schema...) that fail count as zero.
        pr = res.pass_rate if res.status != "warn" else 1.0
        if res.status == "fail":
            row_level = r.type in ("not_null", "accepted_values", "range", "regex", "length",
                                   "not_future", "custom_sql", "unique", "referential", "timeseries")
            pr = min(pr, 0.5) if row_level else 0.0
        dim_num[r.dimension] += w * pr
        dim_den[r.dimension] += w
        num += w * pr
        den += w
    dims = {k: round(dim_num[k] / dim_den[k] * 100, 1) for k in dim_den}
    return (round(num / den * 100, 1) if den else None), dims


def refresh_asset_score(db, asset: Asset) -> None:
    asset.score, asset.dimension_scores = asset_scores(db, asset.id)
    if asset.score is not None:
        db.add(MetricPoint(asset_id=asset.id, metric="dq_score", value=asset.score))


def overview(db, assets: list | None = None, days: int = 30) -> dict:
    """Scores, heatmap, trend and lowest datasets; pass `assets` to narrow it (Overview filters)."""
    narrowed = assets is not None
    assets = list(assets) if narrowed else db.scalars(select(Asset)).all()
    scored = [a for a in assets if a.score is not None]
    domains: dict[str, dict] = defaultdict(lambda: defaultdict(list))
    for a in scored:
        for dim, s in (a.dimension_scores or {}).items():
            domains[a.domain or "unassigned"][dim].append(s)
    heatmap = {dom: {dim: round(sum(v) / len(v), 1) for dim, v in dims.items()} for dom, dims in domains.items()}
    since = utcnow() - timedelta(days=days)
    tq = select(func.date(MetricPoint.ts), func.avg(MetricPoint.value)).where(MetricPoint.metric == "dq_score", MetricPoint.ts >= since)
    if narrowed:
        tq = tq.where(MetricPoint.asset_id.in_([a.id for a in assets] or [-1]))
    trend_rows = db.execute(tq.group_by(func.date(MetricPoint.ts)).order_by(func.date(MetricPoint.ts))).all()
    return {
        "overall": round(sum(a.score for a in scored) / len(scored), 1) if scored else None,
        "assets": len(assets),
        "scored_assets": len(scored),
        "heatmap": heatmap,
        "trend": [{"date": str(d), "score": round(s, 1)} for d, s in trend_rows],
        "lowest": [{"id": a.id, "fqn": a.fqn, "score": a.score, "domain": a.domain}
                   for a in sorted(scored, key=lambda a: a.score)[:8]],
    }
