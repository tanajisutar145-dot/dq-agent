"""Rule proposals from reference files (models, ontologies, glossaries, master data, documents).

Facts on the dataset's own table count most. A fact found only on a column with
the same name in another table of the model is weaker evidence and gets a lower
confidence (only value lists, patterns, terms and sensitivity carry over).
"""
from __future__ import annotations

import re

from .. import reference as REF
from ..models import Asset

CONF_TABLE, CONF_OTHER = 0.9, 0.62
TYPE_SQL = {"numeric": "DOUBLE", "temporal": "TIMESTAMP", "boolean": "BOOLEAN"}


def _cand(rule: dict, conf: float, cat: str, d: dict, *evidence: str) -> dict:
    where = f"{d['doc']}" + (f" ({d['table']}.{d['column']})" if d.get("table") and d.get("column") else "")
    return {**rule, "confidence": round(max(0.05, min(conf, 0.99)), 2), "category": "Reference",
            "evidence": [f"{where}: {evidence[0]}" if evidence else where, *[e for e in evidence[1:] if e]],
            "rule_category": cat, "ref_docs": [d["doc"]]}


def _conf(d: dict, base: float = CONF_TABLE) -> float:
    return base if d.get("table_match") else min(base, CONF_OTHER)


def _resolve_table(ref_table: str, assets: list[Asset], asset: Asset) -> Asset | None:
    if not ref_table:
        return None
    key = REF.tkey(ref_table)
    for a in assets:
        if key and key in REF.asset_table_keys(a.fqn):
            return a
    return None


def reference_candidates(db, asset: Asset, cols: list[dict], ctx: REF.Context, others: list[Asset]) -> list[dict]:
    from .nl_rules import parse

    out: list[dict] = []
    fam = {c["name"]: c.get("family") for c in cols}
    others_meta = [{"fqn": a.fqn, "columns": a.columns or []} for a in others]
    for col, facts in ctx.by_col.items():
        for d in facts:
            k, v = d["kind"], d["value"]
            if k in ("not_null", "pk") and d["table_match"]:
                out.append(_cand({"type": "not_null", "column": col, "severity": "high"}, _conf(d), "core", d,
                                 "mandatory in the model" if k == "not_null" else "primary key in the model", d.get("text") or ""))
            if k in ("pk", "unique") and d["table_match"] and isinstance(v, list) and len(v) == 1:
                out.append(_cand({"type": "unique", "params": {"columns": [col]}, "severity": "high"}, _conf(d), "core", d,
                                 "primary key in the model" if k == "pk" else "unique in the model"))
            elif k == "pattern" and v and fam.get(col) in ("string", None):
                out.append(_cand({"type": "regex", "column": col, "params": {"pattern": str(v)}, "severity": "medium"},
                                 _conf(d, 0.86), "core", d, f"format {v}"))
            elif k in ("max_length", "min_length") and fam.get(col) in ("string", None) and d["table_match"]:
                params = {"max": int(v)} if k == "max_length" else {"min": int(v)}
                out.append(_cand({"type": "length", "column": col, "params": params, "severity": "low"}, _conf(d, 0.82), "core", d,
                                 f"{k.replace('_', ' ')} {v}"))
            elif k == "values" and v and isinstance(v, list):
                candidate = "candidate values" in (d.get("text") or "")
                vals = [x for x in v if str(x).strip()]
                if 1 <= len(vals) <= 1000:
                    out.append(_cand({"type": "accepted_values", "column": col, "params": {"values": vals}, "severity": "medium"},
                                     _conf(d, 0.6 if candidate else 0.88), "business", d,
                                     f"{'suggested' if candidate else 'allowed'} values: {', '.join(map(str, vals[:12]))}{'...' if len(vals) > 12 else ''}"))
            elif k == "master_values" and isinstance(v, dict) and fam.get(col) in ("string", None):
                vals = v.get("values") or []
                if 1 <= len(vals) <= 1000:
                    out.append(_cand({"type": "accepted_values", "column": col, "params": {"values": vals}, "severity": "medium"},
                                     0.78, "business", d, f"master list of {len(vals)} valid {d['column']} values ({v.get('source')})"))
            elif k == "range" and isinstance(v, dict) and (v.get("min") is not None or v.get("max") is not None) and d["table_match"]:
                params = {kk: v[kk] for kk in ("min", "max") if v.get(kk) is not None}
                geo = re.search(r"lat|lon|lng", col.lower())
                out.append(_cand({"type": "range", "column": col, "params": params, "severity": "high" if geo else "medium"},
                                 _conf(d, 0.88), "core" if geo else "business", d, f"range {params}"))
            elif k == "fk" and isinstance(v, dict) and d["table_match"]:
                ref = _resolve_table(v.get("ref_table"), others, asset)
                ref_col = v.get("ref_column")
                if ref and not ref_col:
                    ref_col = next((c["name"] for c in (ref.columns or []) if c["name"].lower() in (col.lower(), "id")
                                    or c["name"].lower() == ref.fqn.split(".")[-1].lower() + "_id"), None)
                if ref and ref_col:
                    out.append(_cand({"type": "referential", "column": col, "params": {"ref_table": ref.fqn, "ref_column": ref_col},
                                      "severity": "high"}, _conf(d, 0.85), "core", d, f"foreign key to {v.get('ref_table')}"))
            elif k == "datatype" and isinstance(v, dict) and d["table_match"] and fam.get(col) == "string" and v.get("family") in TYPE_SQL:
                out.append(_cand({"type": "custom_sql", "column": col, "severity": "high",
                                  "params": {"expression": f"{col} IS NULL OR TRY_CAST({col} AS {TYPE_SQL[v['family']]}) IS NOT NULL"},
                                  "name": f"{col} values are valid {v['family']} ({v.get('type')})"}, 0.8, "core", d,
                                 f"the model types {col} as {v.get('type')}, but the data stores text"))
            elif k in ("rule_text", "term", "description", "check"):
                text = d.get("text") or ""
                if k == "check" and v:
                    try:
                        from ..connectors.base import safe_expression
                        safe_expression(str(v))
                        out.append(_cand({"type": "custom_sql", "column": col, "params": {"expression": str(v)}, "severity": "medium"},
                                         _conf(d, 0.86), "business", d, f"CHECK ({str(v)[:200]})"))
                    except Exception:
                        pass
                    continue
                if k == "description" and not REF.RULE_WORDS.search(text):
                    continue
                for sentence in re.split(r"(?<=[.;])\s+", text):
                    if not REF.RULE_WORDS.search(sentence):
                        continue
                    r = parse(REF.apply_aliases(f"{col} {sentence}" if col.lower() not in sentence.lower() else sentence, ctx.aliases),
                              cols, others_meta)
                    if r:
                        interp = r.pop("interpretation", "")
                        gov = bool((v or {}).get("governance")) if isinstance(v, dict) else bool(REF.GOV_WORDS.search(sentence))
                        base = 0.82 if k == "rule_text" else 0.74  # an explicit rule beats a sentence inside a definition
                        out.append(_cand(r, _conf(d, base), "governance" if gov else "business", d, f"“{sentence.strip()[:240]}”",
                                         f"Read as: {interp}" if interp else ""))
    # rule sentences from documents (not tied to a table): keep the ones that mention this dataset's columns
    for d in ctx.sentences:
        sentence = REF.apply_aliases(d["text"] or "", ctx.aliases)
        r = parse(sentence, cols, others_meta)
        if not r:
            continue
        interp = r.pop("interpretation", "")
        gov = d["doc_kind"] == "policy" or bool((d.get("value") or {}).get("governance"))
        out.append(_cand(r, 0.8, "governance" if gov else "business", d, f"“{(d['text'] or '')[:240]}”",
                         f"Read as: {interp}" if interp else ""))
    # schema conforms to the model (data types and missing columns)
    for doc_id, model in ctx.model_columns.items():
        present = {c["name"].lower() for c in cols}
        exp = [{"name": n, "type": (t or {}).get("type")} for n, t in model.items()]
        overlap = sum(1 for e in exp if e["name"].lower() in present)
        if len(exp) >= 3 and overlap >= max(2, len(exp) // 3):
            d = {"doc": ctx.docs[doc_id].name, "table": None, "column": None}
            missing = [e["name"] for e in exp if e["name"].lower() not in present]
            out.append(_cand({"type": "schema", "params": {"expected_columns": exp, "model": ctx.docs[doc_id].name},
                              "severity": "high", "name": f"schema matches {ctx.docs[doc_id].name}"},
                             0.8 if not missing else 0.6, "core", d,
                             f"{len(exp)} columns with types from the model",
                             f"Missing today: {', '.join(missing[:8])}{'...' if len(missing) > 8 else ''}" if missing else "All model columns exist today"))
    return out
