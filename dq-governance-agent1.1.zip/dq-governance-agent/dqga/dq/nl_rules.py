"""Plain-English rule drafting without an LLM.

Intent-based rather than whole-sentence patterns:
  1. find the columns mentioned anywhere (also human forms: "meter id", "reading timestamp"),
  2. find numbers, quoted values, lists, time windows and percentages,
  3. pick the intent (ordering, freshness, future, uniqueness, reference, allowed values,
     format, length, comparison, completeness, row count, not-equal),
  4. return a rule plus a sentence explaining how the text was read.
"""
from __future__ import annotations

import difflib
import re
from typing import Any

EMAIL_RE = r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"
FORMATS = {
    "email": EMAIL_RE,
    "url": r"https?://[^\s/$.?#].[^\s]*",
    "uuid": r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
    "phone": r"\+?[0-9][0-9 ()\-.]{6,18}[0-9]",
}
ABBREV = {"ts": ["timestamp", "time"], "dt": ["date"], "no": ["number", "num"], "num": ["number"], "nbr": ["number"],
          "qty": ["quantity"], "amt": ["amount"], "desc": ["description"], "pct": ["percent", "percentage"],
          "cnt": ["count"], "addr": ["address"], "id": ["identifier"]}
WORDNUM = {"zero": "0", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6", "seven": "7",
           "eight": "8", "nine": "9", "ten": "10", "twelve": "12", "fifteen": "15", "twenty": "20", "thirty": "30",
           "fifty": "50", "hundred": "100", "thousand": "1000"}
NUM = r"(-?\d[\d,]*(?:\.\d+)?)(\s*[km](?![a-z]))?"
UNIT_H = {"m": 1 / 60, "min": 1 / 60, "mins": 1 / 60, "minute": 1 / 60, "minutes": 1 / 60, "h": 1, "hr": 1, "hrs": 1,
          "hour": 1, "hours": 1, "d": 24, "day": 24, "days": 24, "week": 168, "weeks": 168}


def _num(s: str, suffix: str | None = None) -> float:
    v = float(s.replace(",", ""))
    if suffix:
        v *= {"k": 1000, "m": 1_000_000}[suffix.strip().lower()]
    return int(v) if v.is_integer() else v


def _variants(name: str) -> set[str]:
    toks = [t for t in re.split(r"[_\s\-]+", name.lower()) if t]
    out = {name.lower(), " ".join(toks), "".join(toks)}
    expanded = [[t] + ABBREV.get(t, []) for t in toks]
    combos = [[]]
    for opts in expanded:
        combos = [c + [o] for c in combos for o in opts][:16]
    out |= {" ".join(c) for c in combos}
    return {v for v in out if len(v) >= 2}


def find_columns(low: str, columns: list[dict]) -> list[dict]:
    """Columns mentioned in the text, in order of appearance, longest non-overlapping matches."""
    hits = []
    for c in columns:
        for v in _variants(c["name"]):
            for m in re.finditer(rf"(?<![a-z0-9_]){re.escape(v)}(?:s|es)?(?![a-z0-9_])", low):
                hits.append((m.start(), m.end(), c))
    hits.sort(key=lambda h: (h[0], -(h[1] - h[0])))
    chosen, end = [], -1
    for s, e, c in hits:
        if s >= end and all(c["name"] != x["name"] for x in chosen):
            chosen.append(c)
            end = e
    if not chosen:  # fuzzy fallback for typos like "voltge"
        names = {c["name"].lower(): c for c in columns}
        for w in re.findall(r"[a-z_][a-z0-9_]{2,}", low):
            m = difflib.get_close_matches(w, names, n=1, cutoff=0.85)
            if m and names[m[0]] not in chosen:
                chosen.append(names[m[0]])
    return chosen


def _values_list(s: str) -> list[str]:
    s = re.split(r"[.;](?:\s|$)", s.strip())[0]
    s = s.strip().strip("[](){}")
    parts = re.split(r"\s*(?:,|/|\bor\b|\band\b|\|)\s*", s)
    vals = [p.strip().strip("'\"`").strip() for p in parts]
    return [v for v in vals if v and v not in ("etc", "...")]


def _severity(low: str) -> str:
    if "critical" in low:
        return "critical"
    if re.search(r"\b(must|never|always|cannot|required|mandatory)\b", low):
        return "high"
    return "medium"


def describe(r: dict) -> str:
    t, p, c = r["type"], r.get("params", {}), r.get("column")
    if t == "not_null":
        return f"Completeness: {c} must be populated" + (f" in at least {r['threshold']:.0%} of rows" if r.get("threshold", 1) < 1 else "")
    if t == "unique":
        return f"Uniqueness: one row per ({', '.join(p['columns'])})"
    if t == "range":
        lo, hi = p.get("min"), p.get("max")
        return f"Validity: {c} " + (f"between {lo} and {hi}" if lo is not None and hi is not None else f"≥ {lo}" if lo is not None else f"≤ {hi}")
    if t == "accepted_values":
        return f"Validity: {c} is one of {', '.join(map(str, p['values']))}"
    if t == "regex":
        return f"Validity: {c} matches the pattern {p['pattern']}"
    if t == "length":
        return f"Validity: length of {c} " + (f"is {p['min']}" if p.get("min") == p.get("max") else f"between {p.get('min')} and {p.get('max')}")
    if t == "not_future":
        return f"Validity: {c} is not in the future"
    if t == "freshness":
        return f"Timeliness: newest {c} is at most {p['max_age_hours']:g} hours old"
    if t == "referential":
        return f"Integrity: every {c} exists in {p['ref_table']}.{p['ref_column']}"
    if t == "row_count":
        return f"Volume: at least {p.get('min')} rows" if p.get("max") is None else f"Volume: {p.get('min')} to {p.get('max')} rows"
    if t == "custom_sql":
        return f"Validity: rows must satisfy {p['expression']}"
    return t


def parse(text: str, columns: list[dict], assets: list[dict] | None = None) -> dict | None:
    raw = (text or "").strip().rstrip(".!")
    low = " " + raw.lower() + " "
    low = re.sub(r"\b(can't|can not|cant)\b", "cannot", low)
    low = re.sub(r"\b(shouldn't|should not)\b", "should not", low)
    low = re.sub(r"\b(mustn't)\b", "must not", low)
    low = re.sub(r"^\s*(please\s+)?(ensure|make sure|check|verify|validate|rule:?|add (a )?rule:?)(\s+that)?\s+", " ", low)
    for w, d in WORDNUM.items():
        low = re.sub(rf"\b{w}\b", d, low)
    low = re.sub(r"\b(at least|more than|exactly|minimum of|no fewer than)\s+one\b", r"\1 1", low)
    # a percentage applies to the share of rows, not to the values ("at least 99% of kwh values ...")
    thr = None
    m = re.search(r"(?:(?:in|for)\s+)?(?:at least\s+)?(\d+(?:\.\d+)?)\s*%\s*(?:of\s+)?(?:the\s+)?(?:rows|records|values|entries|cases|time)?", low)
    if m and float(m.group(1)) <= 100 and not re.search(r"\bpercent(age)?\b", low):
        thr = float(m.group(1)) / 100
        low = low[:m.start()] + " " + low[m.end():]
    cols = find_columns(low, columns)
    temporal = [c for c in cols if c.get("family") == "temporal"]
    numeric = [c for c in cols if c.get("family") == "numeric"]
    col = cols[0] if cols else None
    quoted = re.findall(r"['\"`]([^'\"`]+)['\"`]", raw)
    sev = _severity(low)
    rule: dict[str, Any] | None = None

    def cmp_num(patterns: str):
        mm = re.search(rf"(?:{patterns})\s*(?:to\s+|of\s+|than\s+)?{NUM}", low)
        return _num(mm.group(1), mm.group(2)) if mm else None

    # 1. ordering between two columns
    if len(temporal) >= 2 and re.search(r"\b(before|after|earlier|later|precede|precedes|follow|follows|prior to)\b|<=|>=|<|>", low):
        a, b = temporal[0]["name"], temporal[1]["name"]
        op = ">=" if re.search(r"\b(after|later|follow|follows)\b|>=|>", low) else "<="
        rule = {"type": "custom_sql", "column": a, "params": {"expression": f"{a} {op} {b}"}}
    elif len(numeric) >= 2 and not re.search(NUM, low.replace(numeric[0]["name"], "").replace(numeric[1]["name"], "")) and \
            re.search(r"\b(less|lower|smaller|greater|more|higher|larger|exceed|below|above)\b|<=|>=|<|>", low):
        a, b = numeric[0]["name"], numeric[1]["name"]
        neg = re.search(r"\b(not|never|cannot)\b", low)
        if re.search(r"\b(greater|more|higher|larger|exceed|above)\b|>", low):
            op = "<=" if neg else ">"
        else:
            op = ">=" if neg else "<"
        if re.search(r"or equal", low):
            op = op if "=" in op else op + "="
        rule = {"type": "custom_sql", "column": a, "params": {"expression": f"{a} {op} {b}"}}

    # 2. freshness
    if rule is None:
        mm = re.search(r"(\d+(?:\.\d+)?)\s*(minutes?|mins?|hours?|hrs?|h|days?|d|weeks?)\b", low)
        if mm and re.search(r"\b(fresh|freshness|stale|old|older|age|updated|update|refresh|refreshed|load|loaded|arrive|arrives|arrived|latency|lag|late|recent|within|every|ingest|ingested|delay|delayed)\b", low):
            all_t = [c for c in columns if c.get("family") == "temporal"]
            load_t = next((c for c in all_t if re.search(r"ingest|load|updated|modified|created|inserted|_at$", c["name"].lower())), None)
            tcol = temporal[0] if temporal else (load_t or (all_t[0] if all_t else None))
            if tcol:
                hours = round(float(mm.group(1)) * UNIT_H[mm.group(2)], 4)
                rule = {"type": "freshness", "column": tcol["name"], "params": {"max_age_hours": hours}}

    # 3. future
    if rule is None and "future" in low and (temporal or col):
        rule = {"type": "not_future", "column": (temporal or [col])[0]["name"]}

    # 4. uniqueness
    if rule is None and re.search(r"\b(unique|uniquely|duplicate|duplicates|duplicated|dupes?|distinct|one row per|only once|once per)\b", low) and cols:
        rule = {"type": "unique", "params": {"columns": [c["name"] for c in cols]}}

    # 5. reference to another table
    if rule is None and col and re.search(r"\b(exist|exists|present|found|match|matches|matching|reference|references|referencing|foreign key|lookup|known|valid)\b.*\b(in|from|of)\b", low):
        for a in sorted(assets or [], key=lambda a: -len(a["fqn"])):
            short = a["fqn"].split(".")[-1].lower()
            mm = re.search(rf"{re.escape(a['fqn'].lower())}(?:\.([a-z0-9_]+))?|\b{re.escape(short)}(?:\.([a-z0-9_]+))?\b", low)
            if mm:
                ref_col = mm.group(1) or mm.group(2)
                names = {c["name"].lower(): c["name"] for c in a.get("columns", [])}
                ref_col = names.get((ref_col or "").lower()) or names.get(col["name"].lower()) or \
                    next((n for k, n in names.items() if k.endswith("_id") and k.startswith(short.rstrip("s"))), None)
                if ref_col:
                    rule = {"type": "referential", "column": col["name"], "params": {"ref_table": a["fqn"], "ref_column": ref_col}}
                    break
        if rule is None:  # explicit catalog.schema.table[.column] without a known asset list
            mm = re.search(r"\b([a-z_]\w*\.[a-z_]\w*\.[a-z_]\w*)(?:\.([a-z_]\w*))?\b", raw.lower())
            if mm:
                rule = {"type": "referential", "column": col["name"],
                        "params": {"ref_table": mm.group(1), "ref_column": mm.group(2) or col["name"]}}

    # 6. allowed values
    if rule is None and col:
        mm = re.search(r"\b(?:one of|either|only (?:be|contain|have|allow|take|accept)|allowed values?(?: are| of)?|valid values?(?: are| of)?|"
                       r"limited to|restricted to|must be in|should be in|be in|values? (?:are|of)|set to one of)\b\s*:?\s*(.+)$", low)
        if mm:
            # locate the same keyword in the original text so values keep their case ("SUB-01")
            om = re.search(r"\b(?:one of|either|only (?:be|contain|have|allow|take|accept)|allowed values?(?: are| of)?|valid values?(?: are| of)?|"
                           r"limited to|restricted to|must be in|should be in|be in|values? (?:are|of)|set to one of)\b\s*:?\s*(.+)$", raw, re.IGNORECASE)
            vals = quoted or _values_list(om.group(1) if om else mm.group(1))
            vals = [v for v in vals if v.lower() not in (col["name"].lower(),)]
            if vals:
                rule = {"type": "accepted_values", "column": col["name"], "params": {"values": vals}}

    # 7. formats and patterns
    if rule is None and col:
        fmt = next((k for k in FORMATS if re.search(rf"\b{k}s?\b", low) and re.search(r"\b(valid|format|formatted|proper|correct|well formed|look like|be an?)\b", low)), None)
        if fmt and not (fmt == "email" and col["name"].lower() != "email" and "valid" not in low and "format" not in low):
            rule = {"type": "regex", "column": col["name"], "params": {"pattern": FORMATS[fmt]}}
        elif re.search(r"\b(only digits|digits only|numeric only|only numbers|all digits)\b", low):
            rule = {"type": "regex", "column": col["name"], "params": {"pattern": "[0-9]+"}}
        elif re.search(r"\b(upper ?case|capital letters|all caps)\b", low):
            rule = {"type": "custom_sql", "column": col["name"], "params": {"expression": f"{col['name']} = UPPER({col['name']})"}}
        elif re.search(r"\blower ?case\b", low):
            rule = {"type": "custom_sql", "column": col["name"], "params": {"expression": f"{col['name']} = LOWER({col['name']})"}}
        else:
            mm = re.search(r"\b(start|starts|begin|begins|end|ends|contain|contains)\s+with\s+(\S+)|\b(contain|contains)\s+(\S+)", low)
            if mm:
                verb = mm.group(1) or mm.group(3)
                token = (quoted[0] if quoted else (mm.group(2) or mm.group(4))).strip("'\"`")
                orig = re.search(re.escape(token), raw, re.IGNORECASE)
                token = orig.group(0) if orig else token
                esc = re.escape(token)
                pat = f"{esc}.*" if verb.startswith(("start", "begin")) else f".*{esc}" if verb.startswith("end") else f".*{esc}.*"
                rule = {"type": "regex", "column": col["name"], "params": {"pattern": pat}}
            elif re.search(r"\b(match|matches|pattern|regex|format)\b", low):
                mm = re.search(r"\b(?:match|matches|pattern|regex|format)\b\s*(?:the\s+)?(?:pattern|regex|format)?\s*:?\s*(\S.*)$", raw, re.IGNORECASE)
                pat = quoted[0] if quoted else (mm.group(1).strip() if mm else None)
                if pat:
                    rule = {"type": "regex", "column": col["name"], "params": {"pattern": pat}}

    # 8. length
    if rule is None and col and re.search(r"\b(length|characters?|chars?|long|digits?|letters)\b", low):
        nums = [_num(a, b) for a, b in re.findall(NUM, low)]
        if nums:
            if re.search(r"\bbetween\b", low) and len(nums) >= 2:
                rule = {"type": "length", "column": col["name"], "params": {"min": int(nums[0]), "max": int(nums[1])}}
            elif re.search(r"\b(at least|minimum|min|no less than)\b", low):
                rule = {"type": "length", "column": col["name"], "params": {"min": int(nums[0])}}
            elif re.search(r"\b(at most|maximum|max|up to|no more than|not exceed|cannot exceed)\b", low):
                rule = {"type": "length", "column": col["name"], "params": {"max": int(nums[0])}}
            else:
                rule = {"type": "length", "column": col["name"], "params": {"min": int(nums[0]), "max": int(nums[0])}}

    # 9. numeric comparisons
    if rule is None and col:
        c = col["name"]
        mm = re.search(rf"\b(?:between|from)\s+{NUM}\s*(?:and|to|-)\s*{NUM}", low)
        if mm:
            rule = {"type": "range", "column": c, "params": {"min": _num(mm.group(1), mm.group(2)), "max": _num(mm.group(3), mm.group(4))}}
        elif re.search(r"\b(non-?negative|not (?:be )?negative|cannot be negative|never (?:be )?negative|0 or (?:more|greater|above)|no negative)\b", low):
            rule = {"type": "range", "column": c, "params": {"min": 0}}
        elif re.search(r"\b(positive|greater than 0|above 0|more than 0|larger than 0)\b|>\s*0(?![\d.])", low):
            rule = {"type": "custom_sql", "column": c, "params": {"expression": f"{c} > 0"}}
        else:
            lo_inc = cmp_num(r">=|at least|minimum(?: of)?|min(?:imum)? value(?: of)?|no less than|not less than|not (?:be )?below|greater than or equal(?: to)?|more than or equal(?: to)?")
            hi_inc = cmp_num(r"<=|at most|maximum(?: of)?|max(?:imum)? value(?: of)?|up to|no more than|not more than|not (?:be )?(?:greater|higher|larger) than|not exceed|cannot exceed|never exceed|less than or equal(?: to)?|not (?:be )?above")
            lo_str = None if lo_inc is not None else cmp_num(r"(?<![<=!])>(?!=)|(?<!not )(?<!no )\b(?:greater than|more than|higher than|larger than|above|over|exceed|exceeds)\b")
            hi_str = None if hi_inc is not None else cmp_num(r"(?<![>=!])<(?!=)|(?<!not )(?<!no )\b(?:less than|lower than|smaller than|below|under)\b")
            if lo_inc is not None or hi_inc is not None:
                p = {}
                if lo_inc is not None:
                    p["min"] = lo_inc
                if hi_inc is not None:
                    p["max"] = hi_inc
                rule = {"type": "range", "column": c, "params": p}
                if lo_str is not None or hi_str is not None:
                    rule = None
            if rule is None and (lo_str is not None or hi_str is not None):
                parts = ([f"{c} > {lo_str}"] if lo_str is not None else []) + ([f"{c} < {hi_str}"] if hi_str is not None else [])
                if lo_inc is not None:
                    parts.append(f"{c} >= {lo_inc}")
                if hi_inc is not None:
                    parts.append(f"{c} <= {hi_inc}")
                rule = {"type": "custom_sql", "column": c, "params": {"expression": " AND ".join(parts)}}
            if rule is None and re.search(r"\bpercent(age)?\b", low):
                rule = {"type": "range", "column": c, "params": {"min": 0, "max": 100}}

    # 10. completeness
    if rule is None and col and re.search(r"\b(null|nulls|empty|blank|missing|required|mandatory|populated|filled|provided|present|"
                                          r"must have|should have|always have|has a value|have a value|complete|none)\b", low):
        rule = {"type": "not_null", "column": col["name"]}

    # 11. not-equal
    if rule is None and col:
        mm = re.search(r"\b(?:must not be|cannot be|should not be|never be|not equal(?: to)?|is not)\s+['\"`]?([\w\-]+)['\"`]?", low)
        if mm or re.search(r"<>|!=", low):
            val = quoted[0] if quoted else (mm.group(1) if mm else None)
            if val:
                rule = {"type": "custom_sql", "column": col["name"], "params": {"expression": f"{col['name']} <> '{val.replace(chr(39), '')}'"}}

    # 12. table-level volume
    if rule is None:
        mm = re.search(rf"(?:at least|more than|minimum(?: of)?|>=|no fewer than)\s*{NUM}\s*(?:rows|records)", low)
        if mm:
            rule = {"type": "row_count", "params": {"min": _num(mm.group(1), mm.group(2))}}
        elif re.search(r"\b(table|data|dataset)\b.*\bnot (?:be )?empty\b|\bnever (?:be )?empty\b", low) and not cols:
            rule = {"type": "row_count", "params": {"min": 1}}

    if rule is None:
        return None
    rule.setdefault("params", {})
    rule["severity"] = sev
    if thr is not None and rule["type"] in ("not_null", "accepted_values", "range", "regex", "length", "custom_sql", "not_future"):
        rule["threshold"] = thr
    rule["description"] = raw
    rule["interpretation"] = describe(rule)
    return rule


def suggestions_for(text: str, columns: list[dict]) -> list[str]:
    """Example phrasings using this dataset's own columns, for error messages."""
    def plain(c):
        return not re.search(r"(^id$|_id$|_key$|_no$|_code$)", c["name"].lower())
    num = next((c["name"] for c in columns if c.get("family") == "numeric" and plain(c)), "amount")
    txt = next((c["name"] for c in columns if c.get("family") == "string" and plain(c)), "status")
    ts = next((c["name"] for c in columns if c.get("family") == "temporal"), "updated_at")
    return [f"{num} must be between 0 and 500", f"{num} cannot be negative", f"{txt} must not be empty",
            f"{txt} must be one of A, B, C", f"{ts} must not be in the future", f"data must be refreshed every 6 hours",
            f"no duplicate {txt}"]
