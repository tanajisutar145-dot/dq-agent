"""Anomaly detection across all datasets: expected bands over time, spikes, drops and level shifts.

Works on the metric history every check run records (row count, null rate, mean,
freshness, outlier rate, distinct count, DQ score). For each point it learns the
expected band from earlier points only (weekly seasonality when available), so the
chart shows exactly what the detector expected at the time.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import timedelta
from statistics import median

from sqlalchemy import select

from ..incidents.lineage import downstream
from ..models import Asset, CheckResult, MetricPoint, Rule, utcnow

METRIC_LABEL = {"row_count": "Row count", "null_rate": "Null rate", "mean": "Mean", "freshness_hours": "Age (hours)",
                "outlier_rate": "Outlier rate", "distinct_count": "Distinct values", "dq_score": "DQ score"}


def band_series(points: list[tuple], sensitivity: float = 3.0, min_points: int = 7) -> list[dict]:
    out = []
    for i, (ts, v) in enumerate(points):
        prior = points[max(0, i - 35):i]
        item = {"ts": ts.isoformat(timespec="minutes"), "value": float(v), "low": None, "high": None, "anomaly": False, "z": None}
        if len(prior) >= min_points:
            same = [pv for pt, pv in prior if pt.weekday() == ts.weekday()]
            span = (prior[-1][0] - prior[0][0]).days
            basis = same[-8:] if span >= 21 and len(same) >= 3 else [pv for _, pv in prior[-28:]]
            med = median(basis)
            mad = median([abs(x - med) for x in basis])
            scale = mad / 0.6745 if mad else max(abs(med) * 0.05 / 3, 1e-9)
            item["low"], item["high"] = med - sensitivity * scale, med + sensitivity * scale
            z = (float(v) - med) / scale
            item["z"], item["median"] = round(z, 2), med
            item["anomaly"] = abs(z) > sensitivity
        out.append(item)
    return out


def level_shift(points: list[tuple], recent: int = 5, base: int = 20) -> dict | None:
    """Sustained change: the median of the last few points sits outside the earlier band."""
    if len(points) < recent + base:
        return None
    vals = [v for _, v in points]
    prev, last = vals[-(recent + base):-recent], vals[-recent:]
    pm, lm = median(prev), median(last)
    mad = median([abs(x - pm) for x in prev]) or max(abs(pm) * 0.02, 1e-9)
    z = (lm - pm) / (mad / 0.6745)
    if abs(z) > 4 and all((x - pm) * z > 0 for x in last):
        return {"from": pm, "to": lm, "pct": round((lm - pm) / pm * 100, 1) if pm else None, "z": round(z, 1)}
    return None


def _series(db, asset_id: int, days: int) -> dict[tuple, list]:
    since = utcnow() - timedelta(days=days)
    s = defaultdict(list)
    for m in db.scalars(select(MetricPoint).where(MetricPoint.asset_id == asset_id, MetricPoint.ts >= since).order_by(MetricPoint.ts)):
        s[(m.metric, m.column)].append((m.ts, m.value))
    return s


def asset_view(db, asset: Asset, days: int = 45) -> dict:
    out = []
    for (metric, col), pts in sorted(_series(db, asset.id, days).items(), key=lambda kv: (kv[0][0] != "row_count", kv[0][0], kv[0][1] or "")):
        if len(pts) < 2:
            continue
        sens = 3.0
        rule = db.scalars(select(Rule).where(Rule.asset_id == asset.id, Rule.type == "anomaly", Rule.status == "active")).all()
        for r in rule:
            if (r.params or {}).get("metric") == metric and (r.column or None) == col:
                sens = float((r.params or {}).get("sensitivity", 3.0))
        series = band_series(pts, sens)
        out.append({"metric": metric, "column": col, "label": METRIC_LABEL.get(metric, metric) + (f" · {col}" if col else ""),
                    "sensitivity": sens, "points": series, "anomalies": sum(1 for p in series if p["anomaly"]),
                    "level_shift": level_shift(pts)})
    monitors = [r.to_dict() for r in db.scalars(select(Rule).where(Rule.asset_id == asset.id, Rule.type == "anomaly"))]
    return {"asset_id": asset.id, "fqn": asset.fqn, "series": out, "monitors": monitors}


def scan(db, days: int = 30, platform: str | None = None) -> dict:
    items, monitored = [], 0
    assets = [a for a in db.scalars(select(Asset)) if not platform or a.platform == platform]
    since = utcnow() - timedelta(days=days)
    for a in assets:
        has_monitor = db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.type == "anomaly", Rule.status == "active")).first()
        monitored += bool(has_monitor)
        blast = len(downstream(db, a.fqn))
        for (metric, col), pts in _series(db, a.id, days + 40).items():
            if metric == "dq_score" or len(pts) < 8:
                continue
            for p in band_series(pts):
                if not p["anomaly"] or p["ts"] < since.isoformat():
                    continue
                z = abs(p["z"] or 0)
                sev = "critical" if z > 12 and (a.certified or blast >= 3) else "high" if z > 8 or a.certified else "medium" if z > 5 else "low"
                med = p.get("median")
                items.append({"asset_id": a.id, "fqn": a.fqn, "domain": a.domain, "metric": metric, "column": col,
                              "label": METRIC_LABEL.get(metric, metric) + (f" · {col}" if col else ""), "ts": p["ts"], "value": p["value"],
                              "expected_low": p["low"], "expected_high": p["high"], "z": p["z"],
                              "pct_change": round((p["value"] - med) / med * 100, 1) if med else None,
                              "kind": "spike" if (p["z"] or 0) > 0 else "drop", "severity": sev, "downstream": blast})
            ls = level_shift(pts)
            if ls:
                items.append({"asset_id": a.id, "fqn": a.fqn, "domain": a.domain, "metric": metric, "column": col,
                              "label": METRIC_LABEL.get(metric, metric) + (f" · {col}" if col else ""), "ts": pts[-1][0].isoformat(timespec="minutes"),
                              "value": ls["to"], "expected_low": None, "expected_high": None, "z": ls["z"], "pct_change": ls["pct"],
                              "kind": "level_shift", "severity": "high" if abs(ls["z"]) > 8 else "medium", "downstream": blast})
    for cr in db.scalars(select(CheckResult).where(CheckResult.ts >= since, CheckResult.status == "fail")):
        r = db.get(Rule, cr.rule_id)
        if r and r.type in ("anomaly", "timeseries"):
            a = db.get(Asset, cr.asset_id)
            if platform and a.platform != platform:
                continue
            items.append({"asset_id": a.id, "fqn": a.fqn, "domain": a.domain, "metric": (r.params or {}).get("metric") or (r.params or {}).get("check"),
                          "column": r.column, "label": r.name, "ts": cr.ts.isoformat(timespec="minutes"), "value": None,
                          "expected_low": (cr.observed or {}).get("expected_low"), "expected_high": (cr.observed or {}).get("expected_high"),
                          "z": (cr.observed or {}).get("z"), "pct_change": (cr.observed or {}).get("pct_change"),
                          "kind": "sensor" if r.type == "timeseries" else "monitor", "severity": r.severity, "downstream": 0, "message": cr.message})
    seen, uniq = set(), []
    for it in sorted(items, key=lambda x: x["ts"], reverse=True):
        k = (it["asset_id"], it["metric"], it["column"], it["ts"][:13], it["kind"])
        if k not in seen:
            seen.add(k)
            uniq.append(it)
    by_kind = defaultdict(int)
    for it in uniq:
        by_kind[it["kind"]] += 1
    unmonitored = [{"id": a.id, "fqn": a.fqn, "domain": a.domain} for a in assets
                   if not db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.type == "anomaly", Rule.status == "active")).first()]
    return {"items": uniq[:300], "summary": {"total": len(uniq), "by_kind": dict(by_kind), "monitored": monitored,
                                            "datasets": len(assets), "datasets_affected": len({i["asset_id"] for i in uniq})},
            "unmonitored": unmonitored, "days": days}


def monitor_pack(db, asset: Asset, actor: str, activate: bool = True) -> list:
    """One click: volume, freshness, null-rate, outlier, category-drift and schema monitors (active)."""
    from .. import services as S
    from .discovery import observability_candidates
    prof = S.latest_profile(db, asset.id) or S.profile_asset(db, asset)["profile"]
    cols = asset.columns or []
    wanted = [{"type": "anomaly", "params": {"metric": "row_count", "sensitivity": 3.0}, "severity": "high", "name": "row volume anomaly"}]
    load = next((c for c in cols if c.get("family") == "temporal"), None)
    if load:
        wanted.append({"type": "anomaly", "column": load["name"], "params": {"metric": "freshness_hours", "sensitivity": 3.0},
                       "severity": "high", "name": f"lateness anomaly on {load['name']}"})
    cp = prof.get("columns", {})
    for c in cols:
        p = cp.get(c["name"]) or {}
        if 0 < p.get("null_rate", 0) < 0.2:
            wanted.append({"type": "anomaly", "column": c["name"], "params": {"metric": "null_rate", "sensitivity": 3.0}, "severity": "medium"})
    wanted += [{k: v for k, v in cand.items() if k in ("type", "column", "params", "severity", "name")} for cand in observability_candidates(asset, cols, prof)]
    existing = {(r.type, r.column, str((r.params or {}).get("metric"))) for r in db.scalars(select(Rule).where(Rule.asset_id == asset.id))}
    created = []
    for w in wanted:
        k = (w["type"], w.get("column"), str((w.get("params") or {}).get("metric")))
        if k in existing:
            continue
        existing.add(k)
        try:
            created.append(S.create_rule(db, asset, {**w, "source": "monitor"}, actor, status="active" if activate else "proposed"))
        except Exception:
            continue
    return created
