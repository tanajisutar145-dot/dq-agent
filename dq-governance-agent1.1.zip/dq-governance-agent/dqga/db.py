"""Database engine and session helpers.

Supported targets:
- SQLite (default, local use; ephemeral inside Databricks Apps)
- Any SQLAlchemy Postgres URL
- `lakebase`: Databricks Lakebase (managed Postgres) from inside a Databricks App.
  The app's database resource injects PGHOST / PGPORT / PGDATABASE / PGUSER; the
  password is a short-lived OAuth token, fetched fresh for every new connection.
"""
from __future__ import annotations

import os
import re
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator
from urllib.parse import quote

from sqlalchemy import create_engine, event, inspect, text
from sqlalchemy.orm import Session, sessionmaker

from .models import Base

_engine = None
_Session: sessionmaker | None = None


def lakebase_url() -> str:
    host = os.environ.get("PGHOST")
    if not host:
        raise ValueError("database_url is 'lakebase' but PGHOST is not set. "
                         "Add a Lakebase database resource to the Databricks App.")
    user = os.environ.get("PGUSER") or os.environ.get("DATABRICKS_CLIENT_ID")
    if not user:
        raise ValueError("database_url is 'lakebase' but neither PGUSER nor DATABRICKS_CLIENT_ID is set.")
    port = os.environ.get("PGPORT", "5432")
    db = os.environ.get("PGDATABASE", "databricks_postgres")
    ssl = os.environ.get("PGSSLMODE", "require")
    return f"postgresql+psycopg://{quote(user, safe='')}@{host}:{port}/{db}?sslmode={ssl}"


def init_db(url: str, root: Path | None = None, schema: str | None = None) -> None:
    global _engine, _Session
    lakebase = url == "lakebase"
    if lakebase:
        url = lakebase_url()
    connect_args: dict = {}
    kwargs: dict = {"future": True, "pool_pre_ping": True}
    if url.startswith("sqlite"):
        connect_args = {"check_same_thread": False, "timeout": 30}
        prefix = "sqlite:///"
        path = url[len(prefix):] if url.startswith(prefix) else ""
        if path and path != ":memory:":
            p = Path(path)
            if not p.is_absolute() and root is not None:
                p = root / p
            p.parent.mkdir(parents=True, exist_ok=True)
            url = prefix + p.as_posix()
    is_pg = url.startswith("postgresql")
    if is_pg:
        kwargs["pool_recycle"] = 2700  # reconnect before OAuth tokens (1h) expire
        if schema:
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", schema):
                raise ValueError(f"Invalid db_schema {schema!r}")
            connect_args["options"] = f"-csearch_path={schema}"
    _engine = create_engine(url, connect_args=connect_args, **kwargs)
    if lakebase:
        from databricks.sdk import WorkspaceClient

        ws = WorkspaceClient()

        @event.listens_for(_engine, "do_connect")
        def _provide_token(dialect, conn_rec, cargs, cparams):  # noqa: ARG001
            cparams["password"] = ws.config.oauth_token().access_token
    if is_pg and schema:
        with _engine.begin() as c:
            c.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}"'))
    Base.metadata.create_all(_engine)
    add_missing_columns(_engine)
    _Session = sessionmaker(bind=_engine, expire_on_commit=False, future=True)


def add_missing_columns(engine) -> list[str]:
    """Light schema upgrade: add columns that newer versions declare but an existing database lacks.

    create_all() makes new tables but never alters existing ones. New columns are
    always nullable, so ALTER TABLE ... ADD COLUMN is safe on SQLite and Postgres.
    """
    insp = inspect(engine)
    added = []
    existing_tables = set(insp.get_table_names())
    with engine.begin() as c:
        for table in Base.metadata.sorted_tables:
            if table.name not in existing_tables:
                continue
            have = {col["name"] for col in insp.get_columns(table.name)}
            for col in table.columns:
                if col.name in have or col.primary_key:
                    continue
                ddl_type = col.type.compile(dialect=engine.dialect)
                c.execute(text(f'ALTER TABLE "{table.name}" ADD COLUMN "{col.name}" {ddl_type}'))
                added.append(f"{table.name}.{col.name}")
    return added


def engine():
    if _engine is None:
        raise RuntimeError("init_db() has not been called")
    return _engine


def dialect_name() -> str | None:
    return _engine.dialect.name if _engine is not None else None


def get_session() -> Session:
    if _Session is None:
        raise RuntimeError("init_db() has not been called")
    return _Session()


@contextmanager
def session_scope() -> Iterator[Session]:
    s = get_session()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()
