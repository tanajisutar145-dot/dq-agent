"""Agent tools. Read tools return facts. Tools that would change data only suggest (a person applies the change in the
UI); the one write the agent makes on request is opening a ticket."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from sqlalchemy import select

from .. import services as S
from ..dq import scoring
from ..dq.exporters import EXPORTERS, export_with_report
from ..dq.runner import run_asset
from ..governance import compliance, contracts, glossary, policies
from ..incidents import lineage as L
from ..incidents import manager as M
from ..incidents.remediation import suggestions_for_incident
from ..learning import feedback
from ..models import Asset, CheckResult, Classification, Incident, IncidentEvent, MetricPoint, Rule


@dataclass
class Ctx:
    db: Any
    actor: str
    context: dict
    actions: list


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    fn: Callable[..., Any]

    def schema(self) -> dict:
        return {"name": self.name, "description": self.description, "parameters": self.parameters}


def _obj(props: dict, required: list[str] | None = None) -> dict:
    return {"type": "object", "properties": props, "required": required or []}


ASSET = {"type": "string", "description": "Table name or fqn (e.g. utility.gold.meter_readings_daily) or asset id"}


def _asset(ctx: Ctx, ref) -> Asset:
    ref = ref or ctx.context.get("asset_id")
    a = S.find_asset(ctx.db, ref) if ref else None
    if not a:
        raise ValueError(f"Asset {ref!r} not found. Use search_assets first.")
    return a


def _run(ctx: Ctx, kind, title, payload):
    a = S.perform(ctx.db, kind, title, payload, f"agent ({ctx.actor})")
    card = {"id": a.id, "kind": kind, "title": title, "status": a.status, "error": (a.result or {}).get("error") if a.status == "failed" else None}
    ctx.actions.append(card)
    return card


# --------------------------------------------------------------------------- read tools
def t_overview(ctx: Ctx):
    ov = scoring.overview(ctx.db)
    incs = ctx.db.scalars(select(Incident).where(Incident.status.in_(["open", "ack"]))).all()
    ov["open_incidents"] = [{"id": i.id, "title": i.title, "severity": i.severity} for i in incs][:10]
    return ov


def t_search_assets(ctx: Ctx, query: str = ""):
    q = (query or "").lower()
    rows = [a for a in ctx.db.scalars(select(Asset)) if not q or q in a.fqn.lower() or q in (a.domain or "").lower()
            or q in (a.description or "").lower()]
    return [{"id": a.id, "fqn": a.fqn, "platform": a.platform, "domain": a.domain, "score": a.score,
             "owner": a.owner} for a in rows[:30]]


def t_get_asset(ctx: Ctx, asset: str = None):
    a = _asset(ctx, asset)
    out = S.asset_summary(ctx.db, a)
    out["columns"] = [{"name": c["name"], "type": c["data_type"]} for c in a.columns or []][:60]
    latest = scoring.latest_results(ctx.db, a.id)
    out["latest_checks"] = [{"rule": ctx.db.get(Rule, rid).name, "status": r.status, "message": r.message,
                             "at": r.ts.isoformat(timespec="seconds")} for rid, r in latest.items()]
    return out


def t_profile(ctx: Ctx, asset: str = None):
    a = _asset(ctx, asset)
    res = S.profile_asset(ctx.db, a)
    prof = res["profile"]
    cols = {c: {k: v for k, v in p.items() if k in ("family", "null_rate", "distinct", "min", "max", "mean", "patterns")}
            for c, p in prof.get("columns", {}).items()}
    return {"asset": a.fqn, "row_count": prof.get("row_count"), "columns": cols,
            "sensitive_columns": res["classifications"]}


def t_list_rules(ctx: Ctx, asset: str = None, status: str = None):
    q = select(Rule)
    try:
        q = q.where(Rule.asset_id == _asset(ctx, asset).id)
    except Exception:
        if asset:  # a dataset was named but not found
            raise  # with none named, list rules across all datasets
    if status:
        q = q.where(Rule.status == status)
    return [{"id": r.id, "name": r.name, "type": r.type, "dimension": r.dimension, "severity": r.severity,
             "status": r.status, "last_status": r.last_status} for r in ctx.db.scalars(q)]


def t_run_checks(ctx: Ctx, asset: str = None):
    a = _asset(ctx, asset)
    res = run_asset(ctx.db, a, trigger="agent")
    for r in res["results"]:
        r["rule"] = ctx.db.get(Rule, r["rule_id"]).name
    return res


def t_lineage(ctx: Ctx, asset: str = None, direction: str = "both", depth: int = 3):
    a = _asset(ctx, asset)
    dist = L.traverse(ctx.db, a.fqn, direction, int(depth))
    nodes = []
    for f, d in sorted(dist.items(), key=lambda x: x[1]):
        x = ctx.db.scalars(select(Asset).where(Asset.fqn == f)).first()
        nodes.append({"fqn": f, "distance": d, "score": x.score if x else None,
                      "failing_rules": sum(1 for r in ctx.db.scalars(select(Rule).where(Rule.asset_id == x.id))
                                           if r.last_status == "fail") if x else None})
    return {"focus": a.fqn, "nodes": nodes, "note": "negative distance = upstream, positive = downstream"}


def t_list_incidents(ctx: Ctx, status: str = "open"):
    q = select(Incident).order_by(Incident.created.desc())
    if status and status != "all":
        q = q.where(Incident.status.in_(["open", "ack"] if status == "open" else [status]))
    return [{"id": i.id, "title": i.title, "severity": i.severity, "status": i.status, "root": i.root_fqn,
             "assets": i.assets, "assignee": i.assignee, "created": i.created.isoformat(timespec="minutes")}
            for i in ctx.db.scalars(q.limit(25))]


def t_get_incident(ctx: Ctx, incident_id: int = None):
    iid = incident_id or ctx.context.get("incident_id")
    inc = ctx.db.get(Incident, int(iid)) if iid else None
    if not inc:
        raise ValueError("Incident not found")
    inc.rca = M.analyze(ctx.db, inc)
    events = ctx.db.scalars(select(IncidentEvent).where(IncidentEvent.incident_id == inc.id)).all()
    return {**inc.to_dict(), "events": [{"at": e.ts.isoformat(timespec="minutes"), "kind": e.kind, "text": e.text}
                                        for e in events][-15:]}


def t_root_cause(ctx: Ctx, asset: str = None, incident_id: int = None):
    if incident_id or ctx.context.get("incident_id") and not asset:
        return t_get_incident(ctx, incident_id)["rca"]
    a = _asset(ctx, asset)
    for inc in ctx.db.scalars(select(Incident).where(Incident.status.in_(["open", "ack"]))):
        if a.fqn in inc.assets or inc.root_fqn == a.fqn:
            return {"incident_id": inc.id, **M.analyze(ctx.db, inc)}
    root, chain = M.find_root(ctx.db, a.fqn)
    return {"root": root, "upstream_failing": chain, "note": "No open incident for this asset"}


def t_metric_history(ctx: Ctx, asset: str = None, metric: str = "row_count", column: str = None):
    a = _asset(ctx, asset)
    q = select(MetricPoint).where(MetricPoint.asset_id == a.id, MetricPoint.metric == metric)
    q = q.where(MetricPoint.column == column) if column else q
    pts = ctx.db.scalars(q.order_by(MetricPoint.ts.desc()).limit(60)).all()
    return [{"at": p.ts.isoformat(timespec="minutes"), "value": round(p.value, 4)} for p in reversed(pts)]


def t_check_policies(ctx: Ctx, asset: str = None):
    v = policies.evaluate(ctx.db)
    if asset or ctx.context.get("asset_id"):
        a = _asset(ctx, asset)
        v = [x for x in v if x["asset_id"] == a.id]
    return v[:50]


def t_compliance(ctx: Ctx, framework: str = "gdpr"):
    r = compliance.report(ctx.db, framework.lower().replace("-", "_").replace(" ", "_"))
    r.pop("facts", None)
    return r


def t_glossary(ctx: Ctx, term: str):
    return [glossary.term_detail(ctx.db, t) for t in glossary.find_terms(ctx.db, term)][:5]


def t_export_rules(ctx: Ctx, asset: str = None, target: str = "dqx"):
    from ..connectors import get_connector
    a = _asset(ctx, asset)
    rules = ctx.db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status == "active")).all()
    try:
        dialect = get_connector(a.connection).dialect
    except KeyError:
        dialect = None
    rep = export_with_report(rules, target, a.fqn, dialect)
    return {"target": target, "label": rep["label"], "code": rep["code"], "not_expressible": rep["skipped"]}


def t_export_contract(ctx: Ctx, asset: str = None):
    a = _asset(ctx, asset)
    rules = ctx.db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status == "active")).all()
    return {"yaml": contracts.dump(contracts.export_contract(a, rules))}


# --------------------------------------------------------------------------- write tools
def t_suggest_rules(ctx: Ctx, asset: str = None):
    a = _asset(ctx, asset)
    created = S.suggest_rules(ctx.db, a, actor=ctx.actor)  # saved as drafts; the rule studio review decides what goes live
    return [{"id": r.id, "name": r.name, "type": r.type, "severity": r.severity, "reason": r.reason} for r in created]


def t_rule_from_text(ctx: Ctx, text: str, asset: str = None):
    a = _asset(ctx, asset)
    res = S.nl_rule(ctx.db, a, text, ctx.actor)  # saved as a draft; the rule studio review decides what goes live
    return res


def t_classify(ctx: Ctx, asset: str = None):
    a = _asset(ctx, asset)
    S.profile_asset(ctx.db, a)
    cls = ctx.db.scalars(select(Classification).where(Classification.asset_id == a.id,
                                                      Classification.applied.is_(False),
                                                      Classification.status != "rejected")).all()
    return [{"column": c.column, "label": c.label, "sensitivity": c.sensitivity, "confidence": c.confidence,
             "method": c.method} for c in cls]


def t_propose_remediation(ctx: Ctx, incident_id: int = None):
    iid = incident_id or ctx.context.get("incident_id")
    inc = ctx.db.get(Incident, int(iid)) if iid else None
    if not inc:
        raise ValueError("Incident not found")
    sugg = suggestions_for_incident(ctx.db, inc)
    return sugg


def t_open_ticket(ctx: Ctx, incident_id: int = None):
    iid = incident_id or ctx.context.get("incident_id")
    inc = ctx.db.get(Incident, int(iid)) if iid else None
    if not inc:
        raise ValueError("Incident not found")
    return _run(ctx, "ticket", f"Open ticket for incident #{inc.id}", {"incident_id": inc.id})


def t_feedback(ctx: Ctx, verdict: str, rule_id: int = None, incident_id: int = None, note: str = None):
    return feedback.record(ctx.db, verdict, ctx.actor, rule_id=rule_id,
                           incident_id=incident_id or ctx.context.get("incident_id"), note=note)


def t_discover(ctx: Ctx, asset: str = None, min_confidence: float = 0.8):
    from ..dq.discovery import accept, discover
    a = _asset(ctx, asset)
    try:
        llm = S.get_llm()
    except Exception:
        llm = None
    res = discover(ctx.db, a, use_llm=llm is not None, llm=llm)  # no model: statistical discovery, and the answer says so
    top = [c for c in res["candidates"] if c["confidence"] >= float(min_confidence) and (c.get("dry_run") or {}).get("status", "pass") == "pass"]
    created = accept(ctx.db, a, top, ctx.actor) if top else []  # saved as drafts
    return {"asset": a.fqn, "candidates": len(res["candidates"]), "proposed": len(created),
            **({} if llm is not None else {"note": "No LLM is configured, so this used statistics, history and reference files only. Set one in Settings > LLM for model suggestions."}), "sources": res["context"]["by_source"],
            "top": [{"rule": c["name"], "confidence": c["confidence"], "category": c["category"], "why": c["evidence"][:2],
                     "dry_run": (c.get("dry_run") or {}).get("status")} for c in res["candidates"][:10]],
            "coverage": res["coverage"]}


def t_anomalies(ctx: Ctx, asset: str = None, days: int = 30):
    from ..dq.anomaly_scan import scan
    res = scan(ctx.db, int(days))
    items = res["items"]
    if asset or ctx.context.get("asset_id"):
        a = _asset(ctx, asset)
        items = [i for i in items if i["asset_id"] == a.id]
    return {"summary": res["summary"], "items": items[:15], "unmonitored": [u["fqn"] for u in res["unmonitored"]]}


def t_impact(ctx: Ctx, asset: str = None, columns: str = "", change: str = "data"):
    from ..impact import analyze
    a = _asset(ctx, asset)
    rep = analyze(ctx.db, a, [c.strip() for c in (columns or "").split(",") if c.strip()], change if change in ("data", "drop", "retype") else "data")
    return {k: rep[k] for k in ("summary", "score", "level", "owners", "contracts", "rules")} | {
        "impacted": [{"fqn": i["fqn"], "distance": i["distance"], "certified": i["certified"], "owner": i["owner"], "columns": i["columns"]}
                     for i in rep["impacted"]]}


def t_insights(ctx: Ctx, days: int = 30):
    from ..insights import compute
    r = compute(ctx.db, int(days))
    return {"highlights": r["highlights"], "recurring": r["recurring"][:5], "learnings": {k: r["learnings"][k] for k in
            ("precision", "feedback", "rows_corrected", "auto_corrections", "rows_quarantined")}}


def t_corrections(ctx: Ctx, asset: str = None):
    from ..incidents.autofix import analyze_asset, analyze_incident
    if ctx.context.get("incident_id") and not asset:
        inc = ctx.db.get(Incident, int(ctx.context["incident_id"]))
        fixes = analyze_incident(ctx.db, inc) if inc else []
    else:
        fixes = analyze_asset(ctx.db, _asset(ctx, asset))
    return [{"title": f["title"], "risk": f["risk"], "rows": f["rows"], "preview": f["preview"][:5], "why": f["risk_reasons"]} for f in fixes]


def t_quarantine(ctx: Ctx):
    from ..incidents.quarantine import summary
    from ..models import QuarantineBatch
    bs = ctx.db.scalars(select(QuarantineBatch).order_by(QuarantineBatch.created.desc()).limit(10)).all()
    return {"summary": summary(ctx.db), "recent": [{"batch": b.batch_key, "asset": ctx.db.get(Asset, b.asset_id).fqn, "rows": b.rows,
                                                    "released": b.released, "mode": b.mode, "status": b.status, "table": b.target_table} for b in bs]}


TOOLS: list[Tool] = [
    Tool("overview", "Overall DQ health: scores, domain x dimension heatmap, trend, open incidents.", _obj({}), t_overview),
    Tool("search_assets", "Find datasets by name, domain or description.", _obj({"query": {"type": "string"}}), t_search_assets),
    Tool("get_asset", "Dataset details: owner, score by dimension, columns, latest check results.", _obj({"asset": ASSET}), t_get_asset),
    Tool("profile_asset", "Profile a dataset (push-down stats) and detect sensitive columns.", _obj({"asset": ASSET}), t_profile),
    Tool("list_rules", "List DQ rules on a dataset.", _obj({"asset": ASSET, "status": {"type": "string", "enum": ["active", "proposed", "disabled"]}}), t_list_rules),
    Tool("run_checks", "Run all active checks on a dataset now (read-only queries).", _obj({"asset": ASSET}), t_run_checks),
    Tool("get_lineage", "Upstream/downstream lineage with health of each node.",
         _obj({"asset": ASSET, "direction": {"type": "string", "enum": ["upstream", "downstream", "both"]},
               "depth": {"type": "integer"}}), t_lineage),
    Tool("list_incidents", "List incidents.", _obj({"status": {"type": "string", "enum": ["open", "resolved", "muted", "all"]}}), t_list_incidents),
    Tool("get_incident", "Incident details with root-cause evidence and timeline.", _obj({"incident_id": {"type": "integer"}}), t_get_incident),
    Tool("root_cause", "Root-cause analysis for a failing dataset or an incident, using lineage and check history.",
         _obj({"asset": ASSET, "incident_id": {"type": "integer"}}), t_root_cause),
    Tool("metric_history", "History of an observability metric (row_count, null_rate, mean, freshness_hours, dq_score).",
         _obj({"asset": ASSET, "metric": {"type": "string"}, "column": {"type": "string"}}), t_metric_history),
    Tool("check_policies", "Evaluate governance policies (masking, retention, ownership, quality gates).", _obj({"asset": ASSET}), t_check_policies),
    Tool("compliance_report", "Control-by-control compliance evidence.",
         _obj({"framework": {"type": "string", "enum": list(compliance.FRAMEWORKS)}}, ["framework"]), t_compliance),
    Tool("glossary_lookup", "Look up a business term and what data it maps to.", _obj({"term": {"type": "string"}}, ["term"]), t_glossary),
    Tool("export_rules", "Export active rules to another DQ tool's format (DQX, Lakeflow, SQL, Great Expectations, "
                         "Soda, dbt, PyDeequ, Snowflake DMF, Glue DQDL, JSON).",
         _obj({"asset": ASSET, "target": {"type": "string", "enum": list(EXPORTERS)}}), t_export_rules),
    Tool("export_contract", "Generate an ODCS v3 data contract for a dataset.", _obj({"asset": ASSET}), t_export_contract),
    Tool("suggest_rules", "Propose DQ rules from the profile (saved as drafts for the review queue).", _obj({"asset": ASSET}), t_suggest_rules),
    Tool("create_rule_from_text", "Turn a plain-English requirement into a draft rule and dry-run it.",
         _obj({"text": {"type": "string"}, "asset": ASSET}, ["text"]), t_rule_from_text),
    Tool("classify_pii", "Detect sensitive columns (tagging them is done in Governance > Sensitive data).", _obj({"asset": ASSET}), t_classify),
    Tool("propose_remediation", "Suggest fixes for an incident (a person runs them from the incident).", _obj({"incident_id": {"type": "integer"}}), t_propose_remediation),
    Tool("open_ticket", "Open a Jira/ServiceNow ticket for an incident (runs at once).", _obj({"incident_id": {"type": "integer"}}), t_open_ticket),
    Tool("discover_rules", "AI rule discovery: propose rules from schema, types, statistics, history, relationships, business context and other "
                           "datasets, with confidence and evidence; high-confidence passing ones are saved as draft proposals.",
         _obj({"asset": ASSET, "min_confidence": {"type": "number"}}), t_discover),
    Tool("anomalies", "Detected anomalies (spikes, drops, level shifts, failing monitors) across datasets or for one dataset.",
         _obj({"asset": ASSET, "days": {"type": "integer"}}), t_anomalies),
    Tool("impact_analysis", "Impact of a data problem or a schema change (drop/retype columns): downstream datasets, rules, contracts, owners, score.",
         _obj({"asset": ASSET, "columns": {"type": "string", "description": "comma-separated"},
               "change": {"type": "string", "enum": ["data", "drop", "retype"]}}), t_impact),
    Tool("insights", "Patterns (recurring incidents, failure timing, hotspots, root causes) and what has been learned.",
         _obj({"days": {"type": "integer"}}), t_insights),
    Tool("suggest_corrections", "Risk-scored data corrections with before/after previews (standardize values, fix misspellings, trim, "
                                "remove exact duplicates); suggestions only, nothing is changed.", _obj({"asset": ASSET}), t_corrections),
    Tool("quarantine_status", "Quarantined rows: batches, rows held and released.", _obj({}), t_quarantine),
    Tool("record_feedback", "Record steward feedback on a rule or incident so thresholds adapt.",
         _obj({"verdict": {"type": "string", "enum": ["false_positive", "true_positive", "expected_change"]},
               "rule_id": {"type": "integer"}, "incident_id": {"type": "integer"}, "note": {"type": "string"}}, ["verdict"]), t_feedback),
]
TOOL_MAP = {t.name: t for t in TOOLS}
