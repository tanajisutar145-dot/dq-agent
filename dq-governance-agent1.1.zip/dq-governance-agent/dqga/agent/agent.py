"""The TCS DataTrustAI agent: an LLM tool loop with a deterministic fallback.

- With an LLM: the model plans, calls tools, and writes the answer. Facts
  only come from tool results; changes to data are suggestions that a person applies.
- Without an LLM (provider: rules), or if the LLM errors: a keyword router
  picks the right tool(s) and renders a templated answer, so the product
  works fully offline.
"""
from __future__ import annotations

import json
import re
import time

from sqlalchemy import select

from .. import services as S
from ..config import get_settings
from ..models import Asset, ChatMessage
from .tools import TOOL_MAP, TOOLS, Ctx


def FIXES_ON() -> bool:
    from ..config import feature_on
    return feature_on("fixes_and_quarantine")


def HIDDEN_TOOLS() -> set:
    return set() if FIXES_ON() else {"suggest_corrections", "quarantine_status"}

SYSTEM_PROMPT = """You are TCS DataTrustAI, a senior data quality and governance engineer embedded in a DQ platform that spans
Databricks, Snowflake, Spark, Cognite Data Fusion, AWS and Azure.

How you work:
- Get every fact from tools. Never invent numbers, table names, owners or results.
- For "why" questions, use root_cause / get_incident / get_lineage: walk upstream to the first failing node
  before blaming the table the user is looking at. Separate root cause from symptoms.
- Think in DQ dimensions: completeness, validity, uniqueness, consistency, integrity, timeliness, accuracy,
  volume, schema, plausibility (sensor data). Name the dimension when you explain a failure.
- You cannot change data or settings yourself. Corrections, remediations and tagging are suggestions: say clearly
  that a person applies them (incident page, Fixes, Governance > Sensitive data). New rules are saved as drafts
  that go through the review queue in the AI Rule Studio. Opening a ticket is the only action you run.
- Prefer native platform features (Databricks DQX / Lakeflow expectations, Snowflake DMFs, Glue DQ, Purview)
  when recommending how to enforce a rule.
- Never ask for or reveal raw sensitive values; work with profiles and aggregates.

Answer format: a direct answer first (1-3 sentences), then evidence as short bullets citing rule names,
numbers and timestamps from tool results, then "Next steps" if any. Keep it under 250 words unless asked."""


def _short(obj, limit=7000) -> str:
    s = json.dumps(obj, default=str)
    return s if len(s) <= limit else s[:limit] + '..."(truncated)"'


def _summarize(result) -> str:
    if isinstance(result, list):
        return f"{len(result)} item(s)"
    if isinstance(result, dict):
        if "error" in result:
            return f"error: {result['error']}"[:160]
        for k in ("message", "narrative", "status", "title"):
            if isinstance(result.get(k), str):
                return result[k][:160]
        return ", ".join(list(result.keys())[:6])
    return str(result)[:160]


def run_tool(ctx: Ctx, name: str, args: dict, trace: list) -> dict | list:
    tool = TOOL_MAP.get(name)
    t0 = time.perf_counter()
    if not tool:
        res = {"error": f"Unknown tool {name}"}
    else:
        try:
            res = tool.fn(ctx, **{k: v for k, v in (args or {}).items() if v not in (None, "")})
            ctx.db.flush()
        except Exception as e:
            res = {"error": f"{type(e).__name__}: {e}"[:500]}
    trace.append({"tool": name, "args": args, "ms": round((time.perf_counter() - t0) * 1000),
                  "summary": _summarize(res), "ok": not (isinstance(res, dict) and "error" in res)})
    return res


def _history(db, session_id: str, limit: int = 10) -> list[dict]:
    rows = db.scalars(select(ChatMessage).where(ChatMessage.session_id == session_id)
                      .order_by(ChatMessage.id.desc()).limit(limit)).all()
    return [{"role": r.role, "content": r.content.get("text", "")} for r in reversed(rows)]


def chat(db, session_id: str, message: str, context: dict | None = None, actor: str = "steward") -> dict:
    context = context or {}
    ctx = Ctx(db=db, actor=actor, context=context, actions=[])
    trace: list = []
    llm = S.get_llm()
    provider = llm.describe() if llm else {"provider": "rules", "model": None}
    answer, note = None, None
    if llm is not None:
        try:
            answer = _llm_loop(ctx, llm, session_id, message, trace)
        except Exception as e:
            detail = type(e).__name__
            resp = getattr(e, "response", None)
            if resp is not None:  # say what the provider answered, e.g. an unknown model name or a rejected key
                detail = f"HTTP {resp.status_code}: {(resp.text or '')[:200]}".strip()
            note = f"LLM unavailable ({detail}). Check the model in Settings > LLM with Test connection. Answered with the built-in router."
            provider = {"provider": "rules", "model": None, "fallback_from": llm.name}
    if answer is None:
        answer = route(ctx, message, trace)
        if note:
            answer = f"{answer}\n\n_{note}_"
    db.add(ChatMessage(session_id=session_id, role="user", content={"text": message, "context": context}))
    db.add(ChatMessage(session_id=session_id, role="assistant",
                       content={"text": answer, "trace": trace, "actions": ctx.actions}))
    db.flush()
    return {"answer": answer, "trace": trace, "actions": ctx.actions, "provider": provider}


def _llm_loop(ctx: Ctx, llm, session_id: str, message: str, trace: list) -> str:
    max_steps = int(get_settings().section("llm").get("max_steps", 8))
    ctx_line = ""
    if ctx.context.get("asset_id"):
        a = ctx.db.get(Asset, int(ctx.context["asset_id"]))
        if a:
            ctx_line = f"[User is viewing dataset {a.fqn} (id {a.id})] "
    if ctx.context.get("incident_id"):
        ctx_line += f"[User is viewing incident #{ctx.context['incident_id']}] "
    messages = _history(ctx.db, session_id) + [{"role": "user", "content": ctx_line + message}]
    schemas = [t.schema() for t in TOOLS if t.name not in HIDDEN_TOOLS()]
    for _ in range(max_steps):
        resp = llm.chat(SYSTEM_PROMPT, messages, schemas)
        if not resp.tool_calls:
            return resp.text.strip() or "(no answer)"
        messages.append({"role": "assistant", "content": resp.text, "tool_calls": resp.tool_calls})
        for tc in resp.tool_calls:
            res = run_tool(ctx, tc["name"], tc["args"], trace)
            messages.append({"role": "tool", "tool_call_id": tc["id"], "name": tc["name"], "content": _short(res)})
    resp = llm.chat(SYSTEM_PROMPT + "\nYou have used all tool steps. Answer now with what you have.", messages, [])
    return resp.text.strip()


# ---------------------------------------------------------------------------
# deterministic router (no LLM)
# ---------------------------------------------------------------------------
def _mentioned_asset(db, text: str, context: dict):
    low = text.lower()
    best = None
    for a in db.scalars(select(Asset)):
        short = a.fqn.split(".")[-1].split(":")[-1].lower()
        if a.fqn.lower() in low or re.search(rf"\b{re.escape(short)}\b", low):
            if best is None or len(a.fqn) > len(best.fqn):
                best = a
    if best:
        return str(best.id)
    return str(context["asset_id"]) if context.get("asset_id") else None


def _incident_ref(text: str, context: dict):
    m = re.search(r"(?:incident|inc)[\s#-]*(\d+)|#(\d+)", text, re.IGNORECASE)
    if m:
        return int(m.group(1) or m.group(2))
    return context.get("incident_id")


def _bullets(items, fmt, limit=8):
    lines = [f"- {fmt(i)}" for i in items[:limit]]
    if len(items) > limit:
        lines.append(f"- ...and {len(items) - limit} more")
    return "\n".join(lines)


def route(ctx: Ctx, message: str, trace: list) -> str:
    low = message.lower().strip()
    aref = _mentioned_asset(ctx.db, message, ctx.context)
    iid = _incident_ref(message, ctx.context)

    def call(name, **args):
        return run_tool(ctx, name, args, trace)

    def err(res):
        return isinstance(res, dict) and "error" in res

    # plain-English rule authoring
    rule_text = re.sub(r"^(add|create|new)\s+(a\s+)?rule\s*[:\-]?\s*", "", message.strip(), flags=re.IGNORECASE)
    if aref and re.search(r"\b(must|should|cannot|can't|never|always|ensure|is required|are required|no duplicate|at least|at most)\b", low):
        from ..dq.nl_rules import parse as parse_rule
        target = ctx.db.get(Asset, int(aref))
        short = target.fqn.split(".")[-1].lower()
        rule_text = re.sub(rf"\b(on|in|for)\s+(\S+\.)*{re.escape(short)}\b", "", rule_text, flags=re.IGNORECASE).strip()
        others = [{"fqn": a.fqn, "columns": a.columns or []} for a in ctx.db.scalars(select(Asset)) if a.id != target.id]
        if parse_rule(rule_text, target.columns or [], others):
            res = call("create_rule_from_text", text=rule_text, asset=aref)
            if err(res):
                return res["error"]
            d = res["dry_run"]
            return (f"Drafted rule **{res['rule']['name']}**. I read it as: {res.get('interpretation') or res['rule']['type']}.\n\n"
                    f"Dry run on current data: **{d['status']}**: {d['message']}.\n\n"
                    "It is saved as a draft; send it for approval from the AI Rule Studio.")

    if re.search(r"\b(why|root cause|rca|what happened|cause|caused|explain)\b", low):
        res = call("root_cause", asset=aref, incident_id=iid) if (aref or iid) else call("list_incidents", status="open")
        if isinstance(res, list):
            return ("Which one? Open incidents:\n" + _bullets(res, lambda i: f"#{i['id']} [{i['severity']}] {i['title']}")
                    if res else "There are no open incidents.")
        if err(res):
            return res["error"]
        if res.get("narrative"):
            ev = res.get("evidence", [])
            return (f"{res['narrative']}\n\n**Evidence**\n" +
                    _bullets(ev, lambda e: f"{e['at']} `{e['asset'].split('.')[-1]}` {e['rule']} ({e['dimension']}): {e['message']}")
                    + ("\n\n**Downstream at risk:** " + ", ".join(f"`{d}`" for d in res["downstream"][:8]) if res.get("downstream") else "")
                    + "\n\n**Next steps:** ask me to propose a fix or open a ticket.")
        return f"No open incident. Root candidate: `{res.get('root')}`; failing upstream: {res.get('upstream_failing') or 'none'}."

    if re.search(r"\b(impact|what if|what happens if|blast radius|break if)\b", low) and aref:
        cols = [c["name"] for c in (ctx.db.get(Asset, int(aref)).columns or []) if re.search(rf"\b{re.escape(c['name'].lower())}\b", low)]
        change = ("drop" if re.search(r"\b(drop\w*|remov\w*|delet\w*)\b", low) and cols
                  else "retype" if re.search(r"\b(types?|retyp\w*|chang\w*|alter\w*|cast\w*)\b", low) and cols else "data")
        res = call("impact_analysis", asset=aref, columns=",".join(cols), change=change)
        if err(res):
            return res["error"]
        return (f"{res['summary']} (score {res['score']}/100)\n\n**Downstream:**\n" +
                _bullets(res["impacted"], lambda i: f"{i['distance']} hop(s): `{i['fqn']}`{' (certified)' if i['certified'] else ''}"
                                                    f"{' · columns ' + ', '.join(i['columns']) if i['columns'] else ''} · owner {i['owner'] or 'none'}", 10)
                + ("\n\n**Breaking contracts:** " + ", ".join(f"`{c['asset']}`" for c in res["contracts"] if c.get("breaking")) if any(c.get("breaking") for c in res["contracts"]) else "")
                + "\n\nOpen **Impact analysis** to notify the owners.")

    if re.search(r"\b(discover|discovery)\b", low) and aref:
        res = call("discover_rules", asset=aref)
        if err(res):
            return res["error"]
        return (f"Found {res['candidates']} candidate rules from {', '.join(f'{k} ({v})' for k, v in res['sources'].items())}. "
                f"{res['proposed']} high-confidence, passing ones are saved as drafts in the AI Rule Studio.\n\n" +
                _bullets(res["top"], lambda c: f"{int(c['confidence'] * 100)}% **{c['rule']}** ({c['category']}): {c['why'][0] if c['why'] else ''}", 8))

    if re.search(r"\b(anomal\w*|unusual|spikes?|level shift)\b", low):
        res = call("anomalies", asset=aref)
        if err(res):
            return res["error"]
        s = res["summary"]
        return (f"{s['total']} anomalies in the last 30 days across {s['datasets_affected']} dataset(s); {s['monitored']}/{s['datasets']} datasets monitored.\n" +
                _bullets(res["items"], lambda i: f"{i['ts'][:16]} `{i['fqn'].split('.')[-1]}` {i['label']}: {i['kind'].replace('_', ' ')}"
                                                 f"{' ' + str(i['pct_change']) + '%' if i.get('pct_change') is not None else ''} [{i['severity']}]", 10))

    if re.search(r"\b(insights?|patterns?|recurring|learned|learnings?|trends?)\b", low):
        res = call("insights")
        if err(res):
            return res["error"]
        return "**Patterns and learnings (30 days):**\n" + _bullets(res["highlights"], lambda h: f"{h['text']} _{h['tip']}_", 8)

    if FIXES_ON() and re.search(r"\b(correct\w*|auto-?fix|standardi[sz]e|clean up|typos?)\b", low) and (aref or iid):
        res = call("suggest_corrections", asset=aref if not iid else None)
        if err(res):
            return res["error"]
        return (("Corrections I can suggest (apply them from Fixes):\n" + _bullets(res, lambda f: f"**{f['title']}** · {f['risk']} risk · "
                 + ", ".join(f"{p['before']} → {p['after']}" for p in f['preview'][:3]), 6)) if res
                else "No safe corrections: the intended values aren't clear. Consider quarantine instead.")

    if FIXES_ON() and re.search(r"\bquarantin\w*", low):
        res = call("quarantine_status")
        s = res["summary"]
        return (f"{s['rows_held']:,} rows held in {s['open_batches']} open batch(es); {s['released_rows']:,} released so far.\n" +
                _bullets(res["recent"], lambda b: f"`{b['batch']}` {b['asset'].split('.')[-1]} · {b['rows']} rows · {b['mode']} · {b['status']}", 8)
                + "\n\nManage them under **Fixes and quarantine**.")

    if re.search(r"\b(lineage|upstream|downstream|depends on|feeds)\b", low) and aref:
        direction = "upstream" if "upstream" in low else "downstream" if re.search(r"downstream", low) else "both"
        res = call("get_lineage", asset=aref, direction=direction)
        if err(res):
            return res["error"]
        nodes = [n for n in res["nodes"] if n["distance"] != 0]
        return (f"Lineage for `{res['focus']}` ({direction}):\n" +
                _bullets(nodes, lambda n: f"{'up' if n['distance'] < 0 else 'down'} {abs(n['distance'])}: `{n['fqn']}` "
                                          f"score {n['score'] if n['score'] is not None else 'n/a'}"
                                          + (f", {n['failing_rules']} failing" if n.get('failing_rules') else ""), 15)
                if nodes else f"No {direction} lineage recorded for `{res['focus']}`.")

    if re.search(r"\b(pii|sensitive|classif|personal data|gdpr tag)", low) and aref:
        res = call("classify_pii", asset=aref)
        if err(res):
            return res["error"]
        return ("Sensitive columns found:\n" + _bullets(res, lambda c: f"`{c['column']}`: {c['label']} ({c['sensitivity']}, "
                                                                     f"{c['confidence']:.0%} by {c['method']})")
                + "\n\nTag them from Governance > Sensitive data.") if res else "No new sensitive columns detected."

    m = re.search(r"\b(gdpr|sox|nerc|cip|iso\s?8000|dama)\b", low)
    if m or "compliance" in low:
        fw = {"gdpr": "gdpr", "sox": "sox", "nerc": "nerc_cip", "cip": "nerc_cip", "dama": "dama"}.get(
            (m.group(1) if m else "gdpr").replace(" ", ""), "iso_8000")
        res = call("compliance_report", framework=fw)
        if err(res):
            return res["error"]
        s = res["summary"]
        return (f"**{res['title']}**: {s['met']} met, {s['partial']} partial, {s['gap']} gaps.\n" +
                _bullets(res["controls"], lambda c: f"{c['id']} {c['title']}: **{c['status']}** ({c['evidence']})", 10)
                + f"\n\n_{res['disclaimer']}_")

    if re.search(r"\bpolic(y|ies)\b", low):
        res = call("check_policies", asset=aref)
        return ("Policy violations:\n" + _bullets(res, lambda v: f"[{v['severity']}] {v['policy']}: `{v['asset'].split('.')[-1]}`"
                                                                  f"{'.' + v['column'] if v['column'] else ''}: {v['message']}", 12)
                if res else "No policy violations.")

    if re.search(r"\b(fix|remediat|quarantine|resolve it|clean)", low) and iid:
        res = call("propose_remediation", incident_id=iid)
        if err(res):
            return res["error"]
        return ("Proposed fixes (run them from the incident):\n" +
                _bullets(res, lambda s: f"{s['title']} (risk {s.get('risk')}, {'reversible' if s.get('reversible') else 'not reversible'})")
                if res else "No automatic fix applies; this one needs the data owner.")

    if re.search(r"\b(ticket|jira|servicenow|snow)\b", low) and iid:
        res = call("open_ticket", incident_id=iid)
        return (f"Ticket opened for incident #{iid}." if res.get("status") == "approved" else f"The ticket could not be opened: {res.get('error')}") if not err(res) else res["error"]

    if re.search(r"\b(false positive|not an issue|expected|true positive|real issue)\b", low) and (iid or aref):
        verdict = ("expected_change" if "expected" in low else "true_positive" if re.search(r"true positive|real issue", low)
                   else "false_positive")
        res = call("record_feedback", verdict=verdict, incident_id=iid)
        return f"Recorded **{verdict.replace('_', ' ')}**. Effects: {res.get('effects') or 'none'}." if not err(res) else res["error"]

    if re.search(r"\b(suggest|recommend|propose)\b.*\brules?\b|\brules?\b.*\b(suggest|recommend)", low) and aref:
        res = call("suggest_rules", asset=aref)
        if err(res):
            return res["error"]
        return (f"Proposed {len(res)} rules:\n" + _bullets(res, lambda r: f"**{r['name']}** [{r['severity']}]: {r['reason']}", 12)
                + "\n\nThey are saved as drafts; send them for approval from the AI Rule Studio.") if res else "No new rules to suggest; coverage looks complete."

    if re.search(r"\bprofile\b", low) and aref:
        res = call("profile_asset", asset=aref)
        if err(res):
            return res["error"]
        cols = res["columns"]
        return (f"`{res['asset']}`: {res['row_count']:,} rows, {len(cols)} columns.\n" +
                _bullets(list(cols.items()), lambda kv: f"`{kv[0]}` {kv[1].get('family')}: nulls {kv[1].get('null_rate', 0):.1%}, "
                                                        f"distinct {kv[1].get('distinct')}, range {kv[1].get('min')}..{kv[1].get('max')}", 12)
                + (f"\n\nSensitive columns: {', '.join(c['column'] + ' (' + c['label'] + ')' for c in res['sensitive_columns'])}"
                   if res["sensitive_columns"] else ""))

    if re.search(r"\b(export|dqx|dmf|dqdl|lakeflow|great expectations|gx|soda|sodacl|dbt|deequ|pydeequ)\b", low) and aref:
        target = ("snowflake_dmf" if "dmf" in low or "snowflake" in low else "glue_dqdl" if re.search("dqdl|glue", low)
                  else "great_expectations" if re.search(r"great|\bgx\b", low) else "soda" if "soda" in low
                  else "dbt" if re.search(r"\bdbt\b", low) else "pydeequ" if "deequ" in low
                  else "lakeflow" if re.search("lakeflow|dlt|expectation", low)
                  else "sql" if re.search(r"\bsql\b", low) else "json" if re.search(r"\bjson\b", low) else "dqx")
        res = call("export_rules", asset=aref, target=target)
        if err(res):
            return res["error"]
        note = (f"\n\n_Not expressible in this format: {', '.join(res['not_expressible'])}_"
                if res.get("not_expressible") else "")
        return f"{res['label']}:\n```\n{res['code']}\n```{note}"

    if "contract" in low and aref:
        res = call("export_contract", asset=aref)
        return f"ODCS v3 data contract:\n```yaml\n{res['yaml']}\n```" if not err(res) else res["error"]

    if re.search(r"\b(run|check|validate|test)\b", low) and aref:
        res = call("run_checks", asset=aref)
        if err(res):
            return res["error"]
        fails = [r for r in res["results"] if r["status"] in ("fail", "error")]
        return (f"Ran {res['checks']} checks on `{res['asset']}` in {res['duration_s']}s: score **{res['score']}**, "
                f"{res['failed']} failed." + ("\n" + _bullets(fails, lambda r: f"{r['rule']}: {r['status']}: {r['message']}") if fails else ""))

    if re.search(r"\b(define|definition|glossary|meaning|what does|what is)\b", low):
        term = re.sub(r".*\b(define|definition of|glossary|meaning of|what does|what is)\b", "", low).strip(" ?.'\"")
        term = re.sub(r"\bmean\b$", "", term).strip()
        res = call("glossary_lookup", term=term or low)
        if isinstance(res, list) and res:
            t = res[0]
            return (f"**{t['name']}** ({t.get('domain') or 'no domain'}): {t['definition']}\n\nMapped to: " +
                    (", ".join(f"`{l['ref']}`" for l in t["links"]) or "nothing yet"))

    if re.search(r"\b(incident|alert|issue|problem|broken|failing)s?\b", low) and not aref:
        res = call("list_incidents", status="open")
        return ("Open incidents:\n" + _bullets(res, lambda i: f"#{i['id']} [{i['severity']}] {i['title']} (assignee {i['assignee'] or 'none'})", 10)
                if res else "No open incidents.")

    if aref:
        res = call("get_asset", asset=aref)
        if err(res):
            return res["error"]
        dims = ", ".join(f"{k} {v}" for k, v in (res.get("dimension_scores") or {}).items())
        fails = [c for c in res["latest_checks"] if c["status"] == "fail"]
        return (f"`{res['fqn']}` ({res['platform']}, domain {res.get('domain') or 'unassigned'}, owner {res.get('owner') or 'none'}): "
                f"score **{res.get('score')}**{' (' + dims + ')' if dims else ''}. {res['rules_active']} active rules, "
                f"{res['open_incidents']} open incidents." +
                ("\n\nFailing:\n" + _bullets(fails, lambda c: f"{c['rule']}: {c['message']}") if fails else ""))

    res = call("overview")
    inc = res.get("open_incidents", [])
    return (f"Overall DQ score **{res.get('overall')}** across {res.get('scored_assets')} monitored datasets; "
            f"{len(inc)} open incidents.\n" + (_bullets(inc, lambda i: f"#{i['id']} [{i['severity']}] {i['title']}") if inc else "")
            + "\n\nTry: \"why is meter_readings_daily failing?\", \"suggest rules for customers\", "
              "\"kwh must be between 0 and 500 on ami_raw\", \"GDPR report\", \"export DQX for billing_mart\".")
