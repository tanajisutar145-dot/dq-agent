"""Where the app is running, and which environment variables it knows about.

The environment report never returns secret values: names that look like
secrets (token, secret, password, key, webhook) only report whether they are set.
"""
from __future__ import annotations

import os
import re

from .config import APP_NAME, Settings, dotenv_info

SECRET_RE = re.compile(r"TOKEN|SECRET|PASSWORD|PWD|KEY|WEBHOOK|CREDENTIAL", re.IGNORECASE)

KNOWN_ENV: list[tuple[str, str, str]] = [
    # (group, name, description)
    ("App", "DQGA_CONFIG", "Path to the YAML config file"),
    ("App", "DQGA_ENV_FILE", "Path to a .env file (or 'none' to disable .env loading)"),
    ("App", "DQGA_DATABASE_URL", "App database: sqlite:///..., postgresql+psycopg://..., or 'lakebase'"),
    ("App", "DQGA_LLM_PROVIDER", "rules | ollama | anthropic | anthropic_bedrock | databricks | openai_compatible"),
    ("App", "DQGA_LLM_MODEL", "Model or serving endpoint name"),
    ("App", "DQGA_LLM_BASE_URL", "LLM endpoint URL (Ollama / OpenAI-compatible)"),
    ("Access", "DQGA_ADMIN_EMAIL", "Creates this administrator at startup if it doesn't exist (headless installs)"),
    ("Access", "DQGA_ADMIN_PASSWORD", "Password for DQGA_ADMIN_EMAIL (remove it after first start)"),
    ("Access", "DQGA_ADMIN_NAME", "Display name for DQGA_ADMIN_EMAIL"),
    ("Databricks", "DATABRICKS_HOST", "Workspace URL, e.g. https://adb-123.4.azuredatabricks.net"),
    ("Databricks", "DATABRICKS_TOKEN", "Personal access token (local use; not needed in Databricks Apps)"),
    ("Databricks", "DATABRICKS_CONFIG_PROFILE", "Databricks CLI profile for OAuth login"),
    ("Databricks", "DATABRICKS_WAREHOUSE_ID", "SQL warehouse that runs checks"),
    ("Databricks", "DATABRICKS_CLIENT_ID", "Service principal client ID (injected by Databricks Apps)"),
    ("Databricks", "DATABRICKS_CLIENT_SECRET", "Service principal secret (injected by Databricks Apps)"),
    ("Databricks Apps", "DATABRICKS_APP_NAME", "Set by Databricks Apps"),
    ("Databricks Apps", "DATABRICKS_APP_PORT", "Port the app must listen on (set by Databricks Apps)"),
    ("Databricks Apps", "DATABRICKS_APP_URL", "Public URL of the app (set by Databricks Apps)"),
    ("Lakebase", "PGHOST", "Lakebase host (injected by the app's database resource)"),
    ("Lakebase", "PGDATABASE", "Lakebase database name"),
    ("Lakebase", "PGUSER", "Lakebase user (the app's service principal)"),
    ("Snowflake", "SNOWFLAKE_ACCOUNT", "Account identifier"),
    ("Snowflake", "SNOWFLAKE_USER", "User"),
    ("Snowflake", "SNOWFLAKE_PASSWORD", "Password (prefer key-pair)"),
    ("Snowflake", "SNOWFLAKE_KEY_FILE", "Path to the private key for key-pair auth"),
    ("Cognite", "CDF_PROJECT", "CDF project"),
    ("Cognite", "CDF_CLIENT_ID", "OAuth client ID"),
    ("Cognite", "CDF_CLIENT_SECRET", "OAuth client secret"),
    ("Azure", "AZURE_TENANT_ID", "Entra ID tenant"),
    ("Azure", "PURVIEW_CLIENT_ID", "Purview app registration client ID"),
    ("Azure", "PURVIEW_CLIENT_SECRET", "Purview app registration secret"),
    ("Azure", "AZURE_OPENAI_KEY", "Azure OpenAI / AI Foundry key"),
    ("AWS", "AWS_PROFILE", "AWS named profile"),
    ("AWS", "AWS_REGION", "AWS region"),
    ("AWS", "GLUE_DQ_ROLE_ARN", "IAM role for Glue Data Quality runs"),
    ("LLM", "ANTHROPIC_API_KEY", "Anthropic API key"),
    ("Alerts", "DQ_SLACK_WEBHOOK", "Slack incoming webhook URL"),
    ("Alerts", "DQ_TEAMS_WEBHOOK", "Microsoft Teams Workflows webhook URL"),
    ("Alerts", "SMTP_USER", "SMTP user"),
    ("Alerts", "SMTP_PASSWORD", "SMTP password"),
    ("Ticketing", "JIRA_URL", "Jira base URL"),
    ("Ticketing", "JIRA_USER", "Jira user (email)"),
    ("Ticketing", "JIRA_TOKEN", "Jira API token"),
    ("Ticketing", "SNOW_INSTANCE", "ServiceNow instance URL"),
    ("Ticketing", "SNOW_USER", "ServiceNow user"),
    ("Ticketing", "SNOW_PASSWORD", "ServiceNow password"),
    ("Graph", "NEO4J_URI", "Neo4j bolt URI for glossary sync"),
    ("Graph", "NEO4J_USER", "Neo4j user"),
    ("Graph", "NEO4J_PASSWORD", "Neo4j password"),
]


def is_databricks_app() -> bool:
    return bool(os.environ.get("DATABRICKS_APP_NAME") or os.environ.get("DATABRICKS_APP_URL")
                or (os.environ.get("DATABRICKS_APP_PORT") and os.environ.get("DATABRICKS_CLIENT_ID")))


def runtime_info() -> dict:
    if is_databricks_app():
        return {"platform": "databricks_apps", "label": "Databricks Apps",
                "app_name": os.environ.get("DATABRICKS_APP_NAME"), "app_url": os.environ.get("DATABRICKS_APP_URL"),
                "workspace": os.environ.get("DATABRICKS_HOST")}
    return {"platform": "local", "label": "Local", "app_name": APP_NAME, "app_url": None, "workspace": None}


def _referenced_env_names(obj, out: set[str]) -> None:
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(k, str) and k.endswith("_env") and isinstance(v, str):
                out.add(v)
            _referenced_env_names(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _referenced_env_names(v, out)


def env_report(settings: Settings) -> dict:
    from_file = set(dotenv_info()["keys"])
    referenced: set[str] = set()
    _referenced_env_names(settings.data, referenced)
    rows, seen = [], set()
    entries = list(KNOWN_ENV) + [("Referenced in config", n, "Referenced by a *_env key in the config")
                                 for n in sorted(referenced) if n not in {k[1] for k in KNOWN_ENV}]
    entries += [("Overrides", k, "DQGA__ setting override") for k in sorted(os.environ) if k.startswith("DQGA__")]
    for group, name, desc in entries:
        if name in seen:
            continue
        seen.add(name)
        val = os.environ.get(name)
        secret = bool(SECRET_RE.search(name))
        rows.append({"group": group, "name": name, "description": desc, "set": val is not None and val != "",
                     "source": (".env" if name in from_file else "environment") if val else None,
                     "secret": secret, "referenced": name in referenced,
                     "value": None if (secret or not val) else (val if len(val) <= 120 else val[:117] + "...")})
    return {"runtime": runtime_info(), "dotenv": dotenv_info(), "config_file": str(settings.path) if settings.path else None,
            "variables": rows}
