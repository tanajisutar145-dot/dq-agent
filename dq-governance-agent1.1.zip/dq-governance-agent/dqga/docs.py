"""In-app Guide: serves the Markdown files listed in docs/index.yaml.

Only files named in the manifest and located inside docs/ are served.
"""
from __future__ import annotations

from pathlib import Path

import yaml

from .config import ROOT

DOCS_DIR = ROOT / "docs"


def load_index(docs_dir: Path = DOCS_DIR) -> list[dict]:
    idx = docs_dir / "index.yaml"
    if not idx.is_file():
        return []
    entries = (yaml.safe_load(idx.read_text(encoding="utf-8")) or {}).get("docs", [])
    out, root = [], docs_dir.resolve()
    for e in entries:
        p = (docs_dir / e["file"]).resolve()
        if root not in p.parents or not p.is_file():
            continue
        out.append({"id": e["id"], "title": e["title"], "file": e["file"], "group": e.get("group", "Docs"),
                    "summary": e.get("summary", ""), "path": p})
    return out


def list_docs(with_content: bool = True, docs_dir: Path = DOCS_DIR) -> list[dict]:
    out = []
    for e in load_index(docs_dir):
        d = {k: v for k, v in e.items() if k != "path"}
        if with_content:
            d["markdown"] = e["path"].read_text(encoding="utf-8")
        out.append(d)
    return out


def get_doc(doc_id: str, docs_dir: Path = DOCS_DIR) -> dict | None:
    return next((d for d in list_docs(True, docs_dir) if d["id"] == doc_id), None)
