"""Encrypt secrets (such as an LLM API key) that are stored in the app database.

The key that encrypts them comes from, in order:
  1. the DQGA_SECRET_KEY environment variable (any string; use this on Databricks Apps or in containers,
     where local files don't survive a restart), or
  2. a key file `data/.secret_key`, created the first time a secret is saved.

Without the same key, stored secrets can't be read back: they show as "not set" and must be entered again.
Anyone who can read both the database and the key can read the secrets, so keep them apart and limit access.
"""
from __future__ import annotations

import base64
import hashlib
import os
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

from .config import get_settings

ENV_VAR = "DQGA_SECRET_KEY"


def _key_file() -> Path:
    return Path(get_settings().root) / "data" / ".secret_key"


def key_source() -> str:
    if os.environ.get(ENV_VAR):
        return f"the {ENV_VAR} environment variable"
    return str(_key_file())


def _fernet(create: bool) -> Fernet | None:
    env = os.environ.get(ENV_VAR)
    if env:
        return Fernet(base64.urlsafe_b64encode(hashlib.sha256(env.encode("utf-8")).digest()))
    f = _key_file()
    if f.exists():
        return Fernet(f.read_bytes().strip())
    if not create:
        return None
    f.parent.mkdir(parents=True, exist_ok=True)
    key = Fernet.generate_key()
    f.write_bytes(key)
    try:
        f.chmod(0o600)
    except OSError:
        pass
    return Fernet(key)


def encrypt(text: str) -> str:
    return _fernet(True).encrypt(text.encode("utf-8")).decode("ascii")


def decrypt(token: str | None) -> str | None:
    """The secret, or None when there is none or this installation's key can't open it."""
    if not token:
        return None
    try:
        f = _fernet(False)
        return f.decrypt(token.encode("ascii")).decode("utf-8") if f else None
    except (InvalidToken, ValueError):
        return None


def hint(secret: str | None) -> str | None:
    """A safe way to recognise a key: only its last four characters."""
    return ("…" + secret[-4:]) if secret and len(secret) >= 8 else ("set" if secret else None)
