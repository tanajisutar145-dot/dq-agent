"""Insights: recurring patterns in failures and incidents, and what the system has learned.

Everything here is computed from records the app already keeps (check results,
incidents, feedback, corrections, quarantine, rules), so it improves as the app is used.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import timedelta

from sqlalchemy import select

from .models import Asset, CheckResult, Feedback, FixRun, Incident, QuarantineBatch, Rule, utcnow

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def compute(db, days: int = 30, platform: str | None = None) -> dict:
    """platform: only datasets on that platform (rules, checks and incidents rooted in them)."""
    now = utcnow()
    since = now - timedelta(days=days)
    assets = {a.id: a for a in db.scalars(select(Asset)) if not platform or a.platform == platform}
    by_fqn = {a.fqn: a for a in assets.values()}
    rules = {r.id: r for r in db.scalars(select(Rule)) if r.asset_id in assets}
    runs = [c for c in db.scalars(select(CheckResult).where(CheckResult.ts >= since)) if c.asset_id in assets]
    fails = [c for c in runs if c.status == "fail"]
    incs = [i for i in db.scalars(select(Incident).where(Incident.created >= since - timedelta(days=days))) if i.root_fqn in by_fqn]

    # failure timing
    heat = [[0] * 24 for _ in range(7)]
    for c in fails:
        heat[c.ts.weekday()][c.ts.hour] += 1
    by_day = [sum(r) for r in heat]
    by_hour = [sum(heat[d][h] for d in range(7)) for h in range(24)]

    # hotspots
    per_asset = defaultdict(lambda: {"fails": 0, "checks": 0})
    for c in runs:
        per_asset[c.asset_id]["checks"] += 1
        per_asset[c.asset_id]["fails"] += c.status == "fail"
    hotspots = sorted(({"asset_id": aid, "fqn": assets[aid].fqn, "domain": assets[aid].domain, "fails": v["fails"],
                        "fail_rate": round(v["fails"] / v["checks"], 3) if v["checks"] else 0}
                       for aid, v in per_asset.items() if aid in assets and v["fails"]), key=lambda x: -x["fails"])[:10]

    # dimensions and rules
    dim = Counter(rules[c.rule_id].dimension for c in fails if c.rule_id in rules)
    top_rules = Counter(c.rule_id for c in fails)
    flaky = []
    for rid, n in top_rules.most_common(30):
        seq = [c.status for c in sorted((c for c in runs if c.rule_id == rid), key=lambda c: c.ts)]
        flips = sum(1 for a, b in zip(seq, seq[1:]) if a != b and "warn" not in (a, b))
        if rid in rules and len(seq) >= 4 and flips >= 3:
            flaky.append({"rule_id": rid, "name": rules[rid].name, "asset": assets.get(rules[rid].asset_id).fqn, "flips": flips, "runs": len(seq)})

    # recurring incidents and root-cause patterns
    by_root = defaultdict(list)
    for i in incs:
        by_root[i.root_fqn].append(i)
    recurring = []
    for root, lst in by_root.items():
        if len(lst) >= 2:
            wd = Counter(i.created.weekday() for i in lst).most_common(1)[0]
            res = [i for i in lst if i.resolved_at]
            mttr = round(sum((i.resolved_at - i.created).total_seconds() for i in res) / len(res) / 3600, 1) if res else None
            a = by_fqn.get(root)
            recurring.append({"root": root, "asset_id": a.id if a else None, "count": len(lst), "last": max(i.created for i in lst).isoformat(timespec="minutes"),
                              "common_day": DAYS[wd[0]] if wd[1] >= 2 else None, "mttr_hours": mttr,
                              "hypotheses": Counter((i.rca or {}).get("hypothesis", "unknown") for i in lst).most_common(2),
                              "downstream": max(len(i.downstream or []) for i in lst)})
    recurring.sort(key=lambda r: (-r["count"], r["root"]))
    hyp = Counter(((i.rca or {}).get("hypothesis") or "Not analysed").split(" (")[0] for i in incs)
    sources = sorted(({"root": root, "incidents": len(lst), "downstream_hit": len({d for i in lst for d in (i.downstream or [])})}
                      for root, lst in by_root.items()), key=lambda x: (-x["downstream_hit"], -x["incidents"]))[:6]

    # learnings
    fb = db.scalars(select(Feedback).where(Feedback.ts >= since - timedelta(days=60))).all()
    fbc = Counter(f.verdict for f in fb)
    tuned = [{"at": f.ts.isoformat(timespec="minutes"), "verdict": f.verdict, "effect": f.effect, "actor": f.actor,
              "rule": rules[f.rule_id].name if f.rule_id in rules else None} for f in sorted(fb, key=lambda f: f.ts, reverse=True)
             if f.effect and f.effect != "recorded"][:12]
    judged = [r for r in rules.values() if (r.fp_count or 0) + (r.tp_count or 0) > 0]
    precision = round(sum(r.tp_count or 0 for r in judged) / max(1, sum((r.tp_count or 0) + (r.fp_count or 0) for r in judged)), 2) if judged else None
    noisy = [{"rule_id": r.id, "name": r.name, "asset": assets[r.asset_id].fqn if r.asset_id in assets else "", "fp": r.fp_count}
             for r in rules.values() if (r.fp_count or 0) >= 2 and not r.tp_count]
    fixes = db.scalars(select(FixRun)).all()
    qb = db.scalars(select(QuarantineBatch)).all()
    src = Counter(r.source for r in rules.values() if r.status == "active")
    created_weeks = Counter(((now - r.created).days // 7) for r in rules.values() if r.created and (now - r.created).days < 56)
    learn = {"feedback": dict(fbc), "precision": precision, "noisy_rules": noisy, "tuned": tuned,
             "auto_corrections": sum(1 for f in fixes if f.auto and f.status == "applied"),
             "manual_corrections": sum(1 for f in fixes if not f.auto and f.status == "applied"),
             "rows_corrected": sum(f.rows for f in fixes if f.status == "applied"), "undone": sum(1 for f in fixes if f.status == "undone"),
             "rows_quarantined": sum(b.rows for b in qb), "rows_released": sum(b.released or 0 for b in qb),
             "rules_by_source": dict(src), "rules_added_per_week": [created_weeks.get(w, 0) for w in range(7, -1, -1)]}

    # plain-language highlights
    hi = []
    for r in recurring[:3]:
        txt = f"{r['root'].split('.')[-1]} caused {r['count']} incidents in {days} days"
        if r["common_day"]:
            txt += f", most often on {DAY_NAMES[DAYS.index(r['common_day'])]}s"
        if r["hypotheses"]:
            txt += f". Usual cause: {r['hypotheses'][0][0].lower()}"
        tip = "Run its checks earlier on that day, or add a freshness SLA ahead of the load." if r["common_day"] else \
            "Consider a data contract with the producer of this table."
        hi.append({"kind": "recurring", "severity": "high" if r["count"] >= 3 else "medium", "text": txt + ".", "tip": tip,
                   "link": f"#/asset/{r['asset_id']}" if r["asset_id"] else None})
    if fails and max(by_day) >= 2 * (sum(by_day) / 7 or 1):
        d = by_day.index(max(by_day))
        hi.append({"kind": "timing", "severity": "medium", "text": f"{by_day[d]} of {len(fails)} failures happened on {DAY_NAMES[d]}s.",
                   "tip": "Check what loads or upstream jobs run on that day.", "link": "#/insights"})
    peak_h = by_hour.index(max(by_hour)) if fails else None
    if fails and max(by_hour) >= 0.25 * len(fails):
        hi.append({"kind": "timing", "severity": "low", "text": f"{max(by_hour)} failures cluster around {peak_h:02d}:00 UTC.",
                   "tip": "Align the check schedule with the loading window.", "link": "#/insights"})
    if dim:
        dname, n = dim.most_common(1)[0]
        hi.append({"kind": "dimension", "severity": "medium", "text": f"{dname.capitalize()} is the most common failure type ({n} of {len(fails)}).",
                   "tip": {"completeness": "Ask producers for not-null guarantees in their contracts.",
                           "volume": "Investigate partial loads; consider anomaly monitors upstream.",
                           "timeliness": "Review pipeline schedules and SLAs.", "uniqueness": "Look for duplicate loads or broken merge keys.",
                           "validity": "Standardize values at the source; low-risk corrections can run automatically.",
                           "plausibility": "Check sensors and extractors with the OT team."}.get(dname, "Review the rules in this dimension."),
                   "link": "#/insights"})
    if sources and sources[0]["downstream_hit"]:
        s = sources[0]
        hi.append({"kind": "source", "severity": "high", "text": f"Issues starting in {s['root'].split('.')[-1]} reached {s['downstream_hit']} downstream dataset(s).",
                   "tip": "Prioritise monitoring and contracts at this source.", "link": f"#/impact/{by_fqn[s['root']].id}" if s["root"] in by_fqn else None})
    if noisy:
        hi.append({"kind": "learning", "severity": "low", "text": f"{len(noisy)} rule(s) were repeatedly marked false positives.",
                   "tip": "Loosen their thresholds or disable them in the AI Rule Studio.", "link": "#/rules"})
    from .config import feature_on
    if feature_on("fixes_and_quarantine") and (learn["auto_corrections"] or learn["rows_corrected"]):
        hi.append({"kind": "learning", "severity": "low", "text": f"{learn['rows_corrected']:,} rows were corrected ({learn['auto_corrections']} automatic correction(s)).",
                   "tip": "Fix the source system so the same values stop arriving.", "link": "#/fixes"})
    if precision is not None:
        hi.append({"kind": "learning", "severity": "low", "text": f"Alert precision from steward feedback is {precision:.0%}.",
                   "tip": "Keep marking alerts as real or false positive; sensitivity adapts.", "link": "#/governance/learning"})
    return {"days": days, "highlights": hi[:8], "heat": heat, "by_day": by_day, "by_hour": by_hour, "hotspots": hotspots,
            "dimensions": dict(dim), "recurring": recurring[:10], "root_causes": hyp.most_common(8), "sources": sources,
            "flaky": flaky[:8], "learnings": learn, "totals": {"failures": len(fails), "checks": len(runs), "incidents": len(incs)}}


# ---------------------------------------------------------------------------- refresh from the platforms
REFRESH_MODES = {"sync": "Sync metadata only", "due": "Sync metadata and run due checks", "all": "Sync metadata and run every active check"}


def refresh(db, mode: str = "due", actor: str = "system") -> dict:
    """Pull the latest from the connected platforms so the patterns reflect them.

    sync  re-read tables, columns, tags and lineage from every enabled connection
    due   also run the checks and rule schedules that are due (what the scheduler would do now)
    all   also run every active rule on every reachable dataset, whether due or not
    """
    import time

    from . import services as S
    from .models import audit

    if mode not in REFRESH_MODES:
        raise ValueError(f"Unknown refresh mode {mode!r}. Use one of: {', '.join(REFRESH_MODES)}")
    t0 = time.perf_counter()
    sync = S.sync_catalog(db)
    out: dict = {"mode": mode, "sync": {"datasets": sync["assets"], "new": sync["new"], "errors": sync["errors"]}}
    if mode == "due":
        from .scheduler import tick
        t = tick(db)
        out["checks"] = {"datasets": len([r for r in t["ran"] if "error" not in r]), "checks": sum(r.get("checks", 0) for r in t["ran"]) +
                         sum(s.get("checks", 0) for s in t["schedules"]), "failed": sum(r.get("failed", 0) for r in t["ran"]) +
                         sum(s.get("failed", 0) for s in t["schedules"]), "schedules": len(t["schedules"]),
                         "skipped": len(t["skipped"]), "deferred": len(t["deferred"]),
                         "errors": [r["fqn"] + ": " + r["error"] for r in t["ran"] if "error" in r][:10]}
    elif mode == "all":
        from .dq.custom_metrics import evaluate_all
        from .dq.schedules import matching_rules, run_rules
        from .incidents.quarantine import expire
        res = run_rules(db, matching_rules(db, {}), trigger="refresh", actor=actor)
        expire(db)
        evaluate_all(db, include_sql=True)
        out["checks"] = {"datasets": res["datasets"], "checks": res["checks"], "failed": res["failed"], "schedules": 0,
                         "skipped": len(res["skipped"]), "deferred": 0, "errors": [f["fqn"] + ": " + f["error"] for f in res["failures"]][:10]}
    no_rules = [a.fqn for a in db.scalars(select(Asset)) if not db.scalar(select(Rule.id).where(Rule.asset_id == a.id, Rule.status == "active").limit(1))]
    out["datasets_without_rules"] = len(no_rules)
    out["duration_s"] = round(time.perf_counter() - t0, 2)
    out["at"] = utcnow().isoformat(timespec="seconds")
    audit(db, actor, "insights.refreshed", mode, **{k: v for k, v in out.items() if k != "at"})
    db.flush()
    return out


def last_refresh(db) -> dict | None:
    from .models import AuditLog
    row = db.scalars(select(AuditLog).where(AuditLog.action == "insights.refreshed").order_by(AuditLog.ts.desc()).limit(1)).first()
    if not row:
        return None
    return {"at": row.ts.isoformat(timespec="seconds"), "actor": row.actor, "mode": row.target, **(row.detail or {})}
