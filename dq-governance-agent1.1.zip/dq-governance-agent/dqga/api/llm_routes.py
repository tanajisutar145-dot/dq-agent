"""API for the LLM settings (Settings > LLM). Reading is open to everyone signed in; changing it needs the administrator role.

    GET    /api/llm           the providers, the current choice, where it came from, and whether a key is set (never the key)
    PUT    /api/llm           save the choice; it applies to the whole app at once
    POST   /api/llm/test      try the form's settings with one small request (nothing is saved)
    DELETE /api/llm           forget the saved choice and go back to config.yaml / environment variables
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from .. import services as S
from ..llm import settings as LS
from .routes import actor_dep, db_dep

router = APIRouter()


def _active() -> dict:
    try:
        llm = S.get_llm()
        return llm.describe() if llm else {"provider": "rules"}
    except Exception as e:
        return {"provider": "error", "model": f"{type(e).__name__}: {e}"[:200]}


@router.get("/llm")
def get_llm_settings(db=Depends(db_dep)):
    return {**LS.view(db), "active": _active()}


@router.put("/llm")
def save_llm_settings(body: dict, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    try:
        LS.save(db, body, actor)
    except ValueError as e:
        raise HTTPException(400, str(e))
    db.commit()  # the new choice must be visible before the app builds its model from it
    S.reset_llm()
    return {**LS.view(db), "active": _active()}


@router.post("/llm/test")
def test_llm_settings(body: dict, db=Depends(db_dep)):
    try:
        return LS.test(db, body)
    except Exception as e:  # a test must report a problem, never crash
        return {"ok": False, "error": f"{type(e).__name__}: {e}"[:400]}


@router.post("/llm/profiles/{pid}/activate")
def activate_profile(pid: str, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    try:
        LS.activate(db, pid, actor)
    except ValueError as e:
        raise HTTPException(404, str(e))
    db.commit()
    S.reset_llm()
    return {**LS.view(db), "active": _active()}


@router.delete("/llm/profiles/{pid}")
def delete_profile(pid: str, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    try:
        LS.delete(db, pid, actor)
    except ValueError as e:
        raise HTTPException(404, str(e))
    db.commit()
    S.reset_llm()
    return {**LS.view(db), "active": _active()}


@router.delete("/llm")
def reset_llm_settings(db=Depends(db_dep), actor: str = Depends(actor_dep)):
    LS.clear(db, actor)
    db.commit()
    S.reset_llm()
    return {**LS.view(db), "active": _active()}
