"""Reference library API: upload, list, inspect, download, re-read and delete reference files.

Uploads are JSON with base64 content, so no multipart parser is needed:
    POST /api/references {"name": "model.sql", "content_b64": "...", "kind": null, "domain": null, "description": null}
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

from .. import reference as REF
from ..dq.categories import CATEGORIES
from ..models import ReferenceDoc, audit
from .routes import _asset, actor_dep, db_dep

router = APIRouter()


def _doc(db, doc_id: int) -> ReferenceDoc:
    d = db.get(ReferenceDoc, doc_id)
    if not d:
        raise HTTPException(404, "Reference file not found")
    return d


@router.get("/references")
def list_references(db=Depends(db_dep)):
    return REF.list_docs(db)


@router.get("/references/kinds")
def reference_kinds():
    return {"kinds": REF.KINDS, "max_mb": REF.MAX_BYTES // 1048576, "categories": CATEGORIES}


class UploadIn(BaseModel):
    name: str
    content_b64: str
    kind: str | None = None
    domain: str | None = None
    description: str | None = None


@router.post("/references")
def upload_reference(body: UploadIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    raw = REF.decode_upload(body.content_b64)
    doc = REF.ingest(db, body.name, raw, actor, kind=body.kind or None, domain=body.domain, description=body.description)
    audit(db, actor, "reference.uploaded", doc.name, kind=doc.kind, status=doc.status, facts=(doc.summary or {}).get("facts"))
    return doc.public()


@router.get("/references/{doc_id}")
def get_reference(doc_id: int, limit: int = 200, db=Depends(db_dep)):
    d = _doc(db, doc_id)
    return {**d.public(), "facts": REF.facts_preview(db, d.id, min(max(limit, 1), 2000))}


@router.get("/references/{doc_id}/download")
def download_reference(doc_id: int, db=Depends(db_dep)):
    d = _doc(db, doc_id)
    safe = d.name.replace('"', "")
    return Response(d.content, media_type=d.content_type or "application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{safe}"'})


class RefPatch(BaseModel):
    kind: str | None = None
    domain: str | None = None
    description: str | None = None
    enabled: bool | None = None


@router.patch("/references/{doc_id}")
def patch_reference(doc_id: int, body: RefPatch, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    d = _doc(db, doc_id)
    changes = body.model_dump(exclude_unset=True)
    if "kind" in changes and changes["kind"] not in REF.KINDS:
        raise HTTPException(400, f"Unknown file kind {changes['kind']!r}")
    reread = "kind" in changes and changes["kind"] != d.kind
    for k, v in changes.items():
        setattr(d, k, (v.strip() or None) if isinstance(v, str) and k in ("domain", "description") else v)
    if reread:
        REF.reparse(db, d)
    audit(db, actor, "reference.updated", d.name, **{k: v for k, v in changes.items() if k != "description"})
    return d.public()


@router.post("/references/{doc_id}/reparse")
def reparse_reference(doc_id: int, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    d = REF.reparse(db, _doc(db, doc_id))
    audit(db, actor, "reference.reparsed", d.name, status=d.status)
    return d.public()


@router.delete("/references/{doc_id}")
def delete_reference(doc_id: int, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    d = _doc(db, doc_id)
    name = d.name
    REF.delete_doc(db, d)
    audit(db, actor, "reference.deleted", name)
    return {"deleted": doc_id}


@router.post("/assets/{asset_id}/reference-context")
def reference_context(asset_id: int, body: dict | None = None, db=Depends(db_dep)):
    """What the selected reference files say about this dataset (counts, matched columns, model context text)."""
    a = _asset(db, asset_id)
    ids = (body or {}).get("reference_ids")
    view = REF.summary_view(db, a, ids)
    ctx = REF.gather(db, a, ids)
    view["context_text"] = REF.context_text(ctx, a)
    return view
