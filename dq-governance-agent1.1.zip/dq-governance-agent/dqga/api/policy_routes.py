"""API for policies, standards and policy scans (Build > Governance, Operate > Violations).

    GET    /api/policies                       policies with description, source and violations from the last scan
    POST   /api/policies                       save (create or replace); validated        [admin]
    PATCH  /api/policies/{key}                 {"enabled": bool}                           [admin]
    DELETE /api/policies/{key}                                                             [admin]
    POST   /api/policies/draft                 {"text"}  a policy from plain English        [admin]
    POST   /api/policies/suggest               {"standards": [...], "use_uploads": bool}   [admin]
    GET    /api/standards                      frameworks with controls, status, coverage; uploaded standards
    POST   /api/policy-scans/run               run a scan now
    GET    /api/policy-scans/latest            the last scan with its violations
    GET    /api/policy-scans?limit             history
    GET    /api/policy-scans/schedule          schedule
    PUT    /api/policy-scans/schedule          change it                                    [admin]
"""
from __future__ import annotations

from fastapi import APIRouter, Body, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select

from .. import services as S
from ..governance import compliance, policy_authoring as PA, scans
from ..models import Policy, ReferenceDoc, audit
from .routes import actor_dep, db_dep

router = APIRouter()


def _view(p: Policy, counts: dict) -> dict:
    d = p.to_dict()
    spec = p.spec or {}
    d["description"] = p.description or spec.get("description") or PA.describe({**spec, "type": p.type})
    d["severity"] = spec.get("severity") or PA.P.SEVERITY.get(p.type, "medium")
    d["violations"] = counts.get(p.key)
    return d


@router.get("/policies")
def list_policies(db=Depends(db_dep)):
    last = scans.latest(db)
    counts = dict(last.by_policy or {}) if last else {}
    out = []
    for p in db.scalars(select(Policy).order_by(Policy.key)):
        v = _view(p, counts)
        v["violations"] = counts.get(p.key, 0) if last else None
        out.append(v)
    return out


@router.post("/policies")
def save_policy(spec: dict = Body(...), db=Depends(db_dep), actor: str = Depends(actor_dep)):
    clean = PA.validate(spec)
    p = db.scalars(select(Policy).where(Policy.key == clean["id"])).first() or Policy(key=clean["id"])
    p.type, p.spec, p.enabled = clean["type"], clean, clean["enabled"]
    p.description = clean.get("description")
    p.source = spec.get("source") if spec.get("source") in ("manual", "nl", "suggested", "standard", "upload") else (p.source or "manual")
    p.updated_by = actor
    db.add(p)
    audit(db, actor, "policy.saved", clean["id"], spec=clean)
    db.flush()
    return _view(p, {})


class EnableIn(BaseModel):
    enabled: bool


@router.patch("/policies/{key}")
def enable_policy(key: str, body: EnableIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    p = db.scalars(select(Policy).where(Policy.key == key)).first()
    if not p:
        raise HTTPException(404, f"No policy {key!r}")
    p.enabled = body.enabled
    p.spec = {**(p.spec or {}), "enabled": body.enabled}
    p.updated_by = actor
    audit(db, actor, "policy.enabled" if body.enabled else "policy.disabled", key)
    return _view(p, {})


@router.delete("/policies/{key}")
def delete_policy(key: str, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    p = db.scalars(select(Policy).where(Policy.key == key)).first()
    if not p:
        raise HTTPException(404, f"No policy {key!r}")
    db.delete(p)
    audit(db, actor, "policy.deleted", key)
    return {"deleted": key}


class DraftIn(BaseModel):
    text: str


@router.post("/policies/draft")
def draft_policy(body: DraftIn, db=Depends(db_dep)):
    """A policy from a plain-English requirement, validated and dry-run. Nothing is saved."""
    text = body.text.strip()
    llm = None
    if text and PA.parse(db, text) is None:  # only free-form text needs the model
        try:
            llm = S.get_llm()
        except Exception as e:
            raise HTTPException(502, f"The LLM in Settings > LLM could not start: {type(e).__name__}: {str(e)[:240]}")
    return PA.draft(db, text, llm)


class SuggestIn(BaseModel):
    standards: list[str] = []
    use_uploads: bool = True


@router.post("/policies/suggest")
def suggest_policies(body: SuggestIn, db=Depends(db_dep)):
    llm = None
    if body.use_uploads and db.scalars(select(ReferenceDoc.id).where(ReferenceDoc.kind == "policy")).first():
        try:
            llm = S.get_llm()
        except Exception:
            llm = None
    return PA.suggest(db, body.standards, body.use_uploads, llm)


@router.get("/standards")
def standards(db=Depends(db_dep)):
    """Each reference standard with its controls and status, and what its policies cover."""
    have = {p.type for p in db.scalars(select(Policy).where(Policy.enabled.is_(True)))}
    out = []
    for key in compliance.FRAMEWORKS:
        r = compliance.report(db, key)
        types = PA.STANDARD_POLICIES.get(key, ())
        r.pop("facts", None)
        out.append({**r, "recommended_types": list(types), "covered_types": [t for t in types if t in have], "missing_types": [t for t in types if t not in have]})
    docs = db.scalars(select(ReferenceDoc).where(ReferenceDoc.kind == "policy").order_by(ReferenceDoc.id.desc())).all()
    uploads = [{"id": d.id, "name": d.name, "size": d.size, "status": d.status, "domain": d.domain, "enabled": d.enabled} for d in docs]
    return {"frameworks": out, "uploads": uploads, "disclaimer": "Mapping guidance to organize evidence; not legal advice."}


# ------------------------------------------------------------------ scans
@router.post("/policy-scans/run")
def run_scan(db=Depends(db_dep), actor: str = Depends(actor_dep)):
    return scans.view(scans.run_scan(db, actor, "manual"))


@router.get("/policy-scans/latest")
def latest_scan(db=Depends(db_dep)):
    return {"scan": scans.view(scans.latest(db)), "schedule": scans.get_schedule(db)}


@router.get("/policy-scans/schedule")
def get_schedule(db=Depends(db_dep)):
    return scans.get_schedule(db)


@router.put("/policy-scans/schedule")
def put_schedule(body: dict = Body(...), db=Depends(db_dep), actor: str = Depends(actor_dep)):
    return scans.set_schedule(db, body, actor)


@router.get("/policy-scans")
def scan_history(limit: int = 30, db=Depends(db_dep)):
    return scans.history(db, limit)
