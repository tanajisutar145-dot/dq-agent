"""API for sensitive-data scans and bulk review (Governance > Sensitive data).

    GET  /api/pii-scans/status                 last scan, what is unscanned or waiting for review, schedule
    POST /api/pii-scans/run                    {platform?, asset_ids?, only_unscanned?}   steward or admin
    GET  /api/pii-scans/schedule
    PUT  /api/pii-scans/schedule               {enabled, cadence, every_minutes, at_time, weekdays, after_sync}   admin
    POST /api/classifications/decide-bulk      {ids: [...], approve: bool}   tag in the platform, or mark Not PII
"""
from __future__ import annotations

from collections import defaultdict

from fastapi import APIRouter, Body, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select

from .. import services as S
from ..governance import pii_scans as PS
from ..models import Classification, audit
from .routes import actor_dep, db_dep

router = APIRouter()


class RunIn(BaseModel):
    platform: str | None = None
    asset_ids: list[int] | None = None
    only_unscanned: bool = False


@router.get("/pii-scans/status")
def scan_status(db=Depends(db_dep)):
    return PS.status(db)


@router.post("/pii-scans/run")
def run_scan(body: RunIn | None = None, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    body = body or RunIn()
    return PS.run_scan(db, actor, "manual", body.platform or None, body.asset_ids, body.only_unscanned)


@router.get("/pii-scans/schedule")
def get_schedule(db=Depends(db_dep)):
    return PS.get_schedule(db)


@router.put("/pii-scans/schedule")
def put_schedule(body: dict = Body(...), db=Depends(db_dep), actor: str = Depends(actor_dep)):
    return PS.set_schedule(db, body, actor)


class BulkIn(BaseModel):
    ids: list[int]
    approve: bool


@router.post("/classifications/decide-bulk")
def decide_bulk(body: BulkIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    """Tag the chosen columns in the platform (one tagging step per dataset), or dismiss them as not sensitive."""
    if not body.ids:
        raise HTTPException(400, "Pick at least one column")
    rows = [c for c in db.scalars(select(Classification).where(Classification.id.in_(body.ids))) if c.status != "rejected"]
    if not body.approve:
        for c in rows:
            c.status = "rejected"
        audit(db, actor, "classification.rejected", None, ids=[c.id for c in rows])
        return {"rejected": len(rows), "tagged": 0, "failed": []}
    by_asset: dict[int, list[Classification]] = defaultdict(list)
    for c in rows:
        if not c.applied:
            by_asset[c.asset_id].append(c)
    tagged, failed = 0, []
    for asset_id, cols in by_asset.items():
        items = [{"column": c.column, "classification_id": c.id, "tags": {"pii": c.label, "sensitivity": c.sensitivity}} for c in cols]
        res = S.perform(db, "apply_tags", f"Tag {len(items)} sensitive column(s)", {"asset_id": asset_id, "items": items}, actor)
        if res.status == "approved":
            tagged += len(items)
        else:
            failed.append({"asset_id": asset_id, "error": str((res.result or {}).get("error", "failed"))[:200]})
    return {"rejected": 0, "tagged": tagged, "failed": failed}
