"""API for the optional GitHub sync of rule files (Settings > Git, AI Rule Studio > Rule catalog > Export to Git).
All of it answers 404 unless `features: git_sync: true`.

    GET    /api/git          the saved settings (never the token), and whether it is configured
    PUT    /api/git          {repo, branch, folder, mode, token, api_url}   [admin]
    DELETE /api/git          remove the repository and the token            [admin]
    POST   /api/git/test     check the token, repository and branch         [admin]
    POST   /api/git/export   {asset_ids?, include_drafts?, message?}  write rule files as a pull request or commit  [steward or admin]
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from .. import gitsync as G
from ..config import feature_on
from .routes import actor_dep, db_dep


def _on():
    if not feature_on("git_sync"):
        raise HTTPException(404, "Git sync is not enabled. Set features: git_sync: true in config.yaml")


router = APIRouter(dependencies=[Depends(_on)])


class GitIn(BaseModel):
    repo: str | None = None
    branch: str | None = None
    folder: str | None = None
    mode: str | None = None
    api_url: str | None = None
    token: str | None = None


class ExportIn(BaseModel):
    asset_ids: list[int] | None = None
    include_drafts: bool = False
    message: str | None = None


@router.get("/git")
def get_git(db=Depends(db_dep)):
    return G.view(db)


@router.put("/git")
def put_git(body: GitIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    return G.save(db, body.model_dump(), actor)


@router.delete("/git")
def delete_git(db=Depends(db_dep), actor: str = Depends(actor_dep)):
    G.clear(db, actor)
    return {"ok": True}


@router.post("/git/test")
def test_git(db=Depends(db_dep), actor: str = Depends(actor_dep)):
    return G.test(db, actor)


@router.post("/git/export")
def export_git(body: ExportIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    return G.export(db, actor, body.asset_ids, body.include_drafts, body.message)
