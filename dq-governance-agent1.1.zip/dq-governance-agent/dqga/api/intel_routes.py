"""API for rule discovery, anomalies, corrections, quarantine, impact analysis and insights."""
from __future__ import annotations

from fastapi import APIRouter, Body, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select

from .. import services as S
from ..config import get_settings
from ..models import Asset, FixRun, Incident, QuarantineBatch, Rule
from .routes import _asset, actor_dep, db_dep

router = APIRouter()


def _is_admin(request: Request) -> bool:
    u = getattr(request.state, "user", None)
    return u is None or u.get("role") == "admin"


# ---------------------------------------------------------------- rule discovery
class DiscoverIn(BaseModel):
    reference_ids: list[int] | None = None  # None = every enabled reference file for the dataset's domain
    use_references: bool = True
    context: dict | None = None  # {contracts, policies, glossary, standards}: governance context to include (contracts, policies and glossary default to on)


@router.post("/assets/{asset_id}/discover")
def discover(asset_id: int, use_llm: bool = True, body: DiscoverIn | None = None, db=Depends(db_dep)):
    from ..dq.discovery import LLMUnavailable, discover as run
    a = _asset(db, asset_id)
    body = body or DiscoverIn()
    llm = None
    if use_llm:  # the one LLM from Settings > LLM; no model is an error, not a quiet fallback
        try:
            llm = S.get_llm()
        except Exception as e:
            raise HTTPException(502, f"The LLM in Settings > LLM could not start: {type(e).__name__}: {str(e)[:240]}")
    try:
        return run(db, a, use_llm=use_llm, llm=llm, reference_ids=body.reference_ids, use_references=body.use_references, context=body.context)
    except LLMUnavailable as e:
        raise HTTPException(400 if llm is None else 502, str(e))


@router.get("/assets/{asset_id}/governed-context")
def governed_context(asset_id: int, contracts: bool = True, policies: bool = True, glossary: bool = True, standards: str = "", db=Depends(db_dep)):
    """What the governance context holds for this dataset: its contract, the policies that apply, and unmet controls of the chosen standards."""
    from ..dq import governed_context as GC
    a = _asset(db, asset_id)
    return GC.summary(GC.gather(db, a, GC.options({"contracts": contracts, "policies": policies, "glossary": glossary, "standards": [x for x in standards.split(",") if x]})))


class AcceptIn(BaseModel):
    rules: list[dict]
    activate: bool = False  # ignored: discovered rules are always saved as drafts and go through review


@router.post("/assets/{asset_id}/discover/accept")
def discover_accept(asset_id: int, body: AcceptIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    from ..dq.discovery import accept
    created = accept(db, _asset(db, asset_id), body.rules, actor, activate=False)
    return {"created": [r.to_dict() for r in created]}


# ---------------------------------------------------------------- anomalies
@router.get("/anomalies")
def anomalies(days: int = 30, platform: str | None = None, db=Depends(db_dep)):
    from ..dq.anomaly_scan import scan
    return scan(db, days, platform or None)


@router.get("/assets/{asset_id}/anomalies")
def asset_anomalies(asset_id: int, days: int = 45, db=Depends(db_dep)):
    from ..dq.anomaly_scan import asset_view
    return asset_view(db, _asset(db, asset_id), days)


@router.post("/assets/{asset_id}/monitor")
def monitor(asset_id: int, request: Request, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    from ..dq.anomaly_scan import monitor_pack
    created = monitor_pack(db, _asset(db, asset_id), actor, activate=_is_admin(request))  # others save drafts for approval
    return {"created": [r.to_dict() for r in created], "as_drafts": not _is_admin(request)}


# ---------------------------------------------------------------- corrections
@router.get("/fixes")
def fixes(db=Depends(db_dep)):
    from ..incidents.autofix import analyze_asset
    sugg = []
    failing_assets = {r.asset_id for r in db.scalars(select(Rule).where(Rule.status == "active", Rule.last_status == "fail"))}
    for aid in sorted(failing_assets):
        a = db.get(Asset, aid)
        for f in analyze_asset(db, a):
            sugg.append({**f, "asset": a.fqn, "certified": a.certified})
    runs = db.scalars(select(FixRun).order_by(FixRun.ts.desc()).limit(100)).all()
    rem = get_settings().section("remediation")
    return {"suggestions": sugg, "history": [{**r.to_dict(), "asset": db.get(Asset, r.asset_id).fqn} for r in runs],
            "settings": {"auto_correct_low_risk": bool(rem.get("auto_correct_low_risk")),
                         "auto_correct_max_rows": rem.get("auto_correct_max_rows", 1000)}}


@router.get("/incidents/{incident_id}/fixes")
def incident_fixes(incident_id: int, db=Depends(db_dep)):
    from ..incidents.autofix import analyze_incident
    inc = db.get(Incident, incident_id)
    if not inc:
        raise HTTPException(404, "Incident not found")
    return analyze_incident(db, inc)


class FixIn(BaseModel):
    fix_id: str
    incident_id: int | None = None


@router.post("/fixes/apply")
def fix_apply(body: FixIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    from ..incidents.autofix import analyze_rule, apply
    kind, _, rid = body.fix_id.partition(":")
    rule = db.get(Rule, int(rid)) if rid.isdigit() else None
    if not rule:
        raise HTTPException(404, "Rule not found")
    fix = next((f for f in analyze_rule(db, rule) if f["kind"] == kind), None)
    if not fix:
        raise HTTPException(409, "This correction no longer applies. Refresh the suggestions.")
    fr = apply(db, body.fix_id, actor, incident_id=body.incident_id)
    from ..dq.runner import run_asset
    res = run_asset(db, db.get(Asset, fr.asset_id), trigger="correction", rule_ids=[fr.rule_id], allow_autofix=False)
    fr.detail = {**(fr.detail or {}), "recheck": res["results"][0]["status"] if res["results"] else None}
    return {"status": "applied", "fix_run": fr.to_dict()}


class UndoIn(BaseModel):
    force: bool = False


@router.post("/fixes/{run_id}/undo")
def fix_undo(run_id: int, body: UndoIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    from ..incidents.autofix import undo
    fr = db.get(FixRun, run_id)
    if not fr:
        raise HTTPException(404, "Correction not found")
    return undo(db, fr, actor, force=body.force).to_dict()


# ---------------------------------------------------------------- quarantine
def _batch_view(db, b: QuarantineBatch) -> dict:
    a = db.get(Asset, b.asset_id)
    r = db.get(Rule, b.rule_id) if b.rule_id else None
    return {**b.to_dict(), "asset": a.fqn if a else None, "rule": r.name if r else None, "held": b.rows - (b.released or 0)}


@router.get("/quarantine")
def quarantine_list(status: str = "open", asset_id: int | None = None, db=Depends(db_dep)):
    from ..incidents.quarantine import summary
    q = select(QuarantineBatch).order_by(QuarantineBatch.created.desc())
    if status == "open":
        q = q.where(QuarantineBatch.status.in_(["quarantined", "partially_released"]))
    elif status != "all":
        q = q.where(QuarantineBatch.status == status)
    if asset_id:
        q = q.where(QuarantineBatch.asset_id == asset_id)
    rem = get_settings().section("remediation")
    return {"batches": [_batch_view(db, b) for b in db.scalars(q.limit(300))], "summary": summary(db),
            "retention_days": rem.get("quarantine_retention_days", 30)}


@router.get("/quarantine/{batch_id}")
def quarantine_get(batch_id: int, request: Request, unmask: bool = False, db=Depends(db_dep)):
    from ..incidents.quarantine import rows
    b = db.get(QuarantineBatch, batch_id)
    if not b:
        raise HTTPException(404, "Batch not found")
    return {**_batch_view(db, b), **rows(db, b, 50, unmask=unmask and _is_admin(request))}


class QuarantineIn(BaseModel):
    rule_id: int
    mode: str = "move"
    target: str | None = None
    clean_table: str | None = None
    incident_id: int | None = None
    note: str | None = None


@router.post("/quarantine/plan")
def quarantine_plan(body: QuarantineIn, db=Depends(db_dep)):
    from ..incidents.quarantine import default_clean, default_target, plan
    r = db.get(Rule, body.rule_id)
    if not r:
        raise HTTPException(404, "Rule not found")
    a = db.get(Asset, r.asset_id)
    p = plan(db, a, r, body.mode, body.target, body.clean_table)
    return {**p, "default_target": default_target(a), "default_clean": default_clean(a), "asset": a.fqn, "rule": r.name}


@router.post("/quarantine")
def quarantine_create(body: QuarantineIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    from ..incidents.quarantine import plan, quarantine
    r = db.get(Rule, body.rule_id)
    if not r:
        raise HTTPException(404, "Rule not found")
    a = db.get(Asset, r.asset_id)
    p = plan(db, a, r, body.mode, body.target, body.clean_table)
    b = quarantine(db, a, r, actor, body.mode, p["target"], p["clean_table"], body.incident_id, body.note)
    return {"status": "quarantined", "batch": _batch_view(db, b)}


class ReleaseIn(BaseModel):
    revalidate: bool = True


@router.post("/quarantine/{batch_id}/release")
def quarantine_release(batch_id: int, body: ReleaseIn, request: Request, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    from ..incidents.quarantine import release
    b = db.get(QuarantineBatch, batch_id)
    if not b:
        raise HTTPException(404, "Batch not found")
    if not body.revalidate and not _is_admin(request):
        raise HTTPException(403, "Only administrators can release rows without re-checking them.")
    return release(db, b, actor, body.revalidate)


@router.post("/quarantine/{batch_id}/purge")
def quarantine_purge(batch_id: int, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    from ..incidents.quarantine import purge
    b = db.get(QuarantineBatch, batch_id)
    if not b:
        raise HTTPException(404, "Batch not found")
    return purge(db, b, actor)


# ---------------------------------------------------------------- impact analysis
@router.get("/impact")
def impact(asset_id: int, columns: str = "", change: str = "data", db=Depends(db_dep)):
    from ..impact import analyze
    if change not in ("data", "drop", "retype"):
        raise HTTPException(400, "change must be data, drop or retype")
    cols = [c for c in columns.split(",") if c]
    return analyze(db, _asset(db, asset_id), cols, change)


class NotifyIn(BaseModel):
    asset_id: int
    columns: list[str] = []
    change: str = "data"
    note: str | None = None


@router.post("/impact/notify")
def impact_notify(body: NotifyIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    from ..impact import analyze, notify_owners
    rep = analyze(db, _asset(db, body.asset_id), body.columns, body.change)
    return notify_owners(db, rep, actor, body.note)


# ---------------------------------------------------------------- insights
@router.get("/insights")
def insights(days: int = 30, platform: str | None = None, db=Depends(db_dep)):
    from ..insights import compute, last_refresh
    return {**compute(db, days, platform or None), "last_refresh": last_refresh(db)}


class RefreshIn(BaseModel):
    mode: str = "due"  # sync | due | all


@router.post("/insights/refresh")
def insights_refresh(body: RefreshIn | None = None, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    from ..insights import refresh
    try:
        return refresh(db, (body or RefreshIn()).mode, actor)
    except ValueError as e:
        raise HTTPException(400, str(e))


__all__ = ["router", "Body"]


# ---------------------------------------------------------------- AI-written Patterns and Insights
@router.get("/ai-insights")
def ai_insights_state(platform: str | None = None, db=Depends(db_dep)):
    """The saved write-up for this scope, whether the facts changed since it was made, and which model would write the next one."""
    from ..ai_insights import state, with_links
    st = state(db, platform or None)
    try:
        llm = S.get_llm()
        model = llm.describe() if llm else None
    except Exception as e:
        model = {"provider": "error", "model": f"{type(e).__name__}: {e}"[:160]}
    return {"report": with_links(db, st["report"]), "fresh": st["fresh"], "fingerprint": st["fingerprint"], "configured": bool(model and model.get("provider") != "error"),
            "model": model}


class AIInsightsIn(BaseModel):
    platform: str | None = None
    force: bool = False


@router.post("/ai-insights/generate")
def ai_insights_generate(body: AIInsightsIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    """Write up the current facts with the model chosen in Settings > LLM. Unchanged facts return the saved text without a model call."""
    from ..ai_insights import AIInsightsError, generate, with_links
    try:
        llm = S.get_llm()
    except Exception as e:
        raise HTTPException(502, f"The LLM in Settings > LLM could not start: {type(e).__name__}: {str(e)[:240]}")
    try:
        rep = generate(db, llm, actor, body.platform or None, force=body.force)
    except AIInsightsError as e:
        raise HTTPException(400 if llm is None else 502, str(e))
    return with_links(db, rep)
