"""API for running rules now, rule schedules, and run history (Operate > Runs).

    POST   /api/rules/run                {"scope": {...}}            run matching active rules now
    POST   /api/rules/run/preview        {"scope": {...}}            what a run would cover
    GET    /api/schedules                                            schedules with next/last run
    POST   /api/schedules                {name, cadence, ...}        create
    PATCH  /api/schedules/{id}           {...}                       change, enable or disable
    DELETE /api/schedules/{id}
    POST   /api/schedules/{id}/run                                   run a schedule now
    GET    /api/runs?days&asset_id&trigger&status&schedule_id        run history and stats
    GET    /api/runs/{id}                                            one run with its check results
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select

from ..config import get_settings
from ..dq import schedules as SCH
from ..models import RuleSchedule, audit, utcnow
from .routes import actor_dep, db_dep

router = APIRouter()


class ScopeIn(BaseModel):
    scope: dict = {}


class ScheduleIn(BaseModel):
    name: str
    cadence: str = "interval"
    every_minutes: int | None = None
    at_time: str | None = None
    weekdays: list[int] = []
    scope: dict = {}
    enabled: bool = True


class SchedulePatch(BaseModel):
    name: str | None = None
    cadence: str | None = None
    every_minutes: int | None = None
    at_time: str | None = None
    weekdays: list[int] | None = None
    scope: dict | None = None
    enabled: bool | None = None


def _bad(e: Exception):
    raise HTTPException(400, str(e))


def _sched(db, sid: int) -> RuleSchedule:
    s = db.get(RuleSchedule, sid)
    if not s:
        raise HTTPException(404, f"No schedule #{sid}")
    return s


@router.post("/rules/run/preview")
def run_preview(body: ScopeIn, db=Depends(db_dep)):
    try:
        return SCH.preview(db, body.scope)
    except ValueError as e:
        _bad(e)


@router.post("/rules/run")
def run_now(body: ScopeIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    try:
        rules = SCH.matching_rules(db, body.scope)
    except ValueError as e:
        _bad(e)
    if not rules:
        raise HTTPException(400, "No active rules match. Activate saved rules first, or widen the selection.")
    res = SCH.run_rules(db, rules, trigger="manual", actor=actor)
    audit(db, actor, "rules.run", SCH.scope_text(db, body.scope), rules=res["rules"], datasets=res["datasets"],
          checks=res["checks"], failed=res["failed"], errors=res["errors"])
    return res


@router.get("/schedules")
def list_schedules(db=Depends(db_dep)):
    cfg = get_settings().section("scheduler")
    rows = list(db.scalars(select(RuleSchedule).order_by(RuleSchedule.name)))
    for s in rows:
        SCH.ensure_next(db, s)
    return {"schedules": [SCH.view(db, s) for s in rows], "now": utcnow().isoformat(timespec="seconds"),
            "background": {"enabled": bool(cfg.get("enabled")), "tick_seconds": cfg.get("tick_seconds"),
                           "default_interval_minutes": cfg.get("default_interval_minutes"),
                           "daily_budget_seconds": cfg.get("daily_budget_seconds")}}


@router.post("/schedules")
def create_schedule(body: ScheduleIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    try:
        v = SCH.validate(body.model_dump())
    except ValueError as e:
        _bad(e)
    s = RuleSchedule(**v, created_by=actor)
    db.add(s)
    db.flush()
    s.next_run = SCH.next_after(s, utcnow()) if s.enabled else None
    audit(db, actor, "schedule.created", s.name, cadence=SCH.cadence_text(s), scope=s.scope)
    db.flush()
    return SCH.view(db, s)


@router.patch("/schedules/{sid}")
def patch_schedule(sid: int, body: SchedulePatch, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    s = _sched(db, sid)
    cur = {"name": s.name, "cadence": s.cadence, "every_minutes": s.every_minutes, "at_time": s.at_time,
           "weekdays": s.weekdays, "scope": s.scope, "enabled": s.enabled}
    cur.update({k: v for k, v in body.model_dump().items() if v is not None})
    try:
        v = SCH.validate(cur)
    except ValueError as e:
        _bad(e)
    timing_changed = any(v[k] != getattr(s, k) for k in ("cadence", "every_minutes", "at_time", "weekdays"))
    was_enabled = s.enabled
    for k, val in v.items():
        setattr(s, k, val)
    if not s.enabled:
        s.next_run = None
    elif timing_changed or not was_enabled or s.next_run is None:
        s.next_run = SCH.next_after(s, utcnow())
    audit(db, actor, "schedule.changed", s.name, **{k: (val if k != "scope" else s.scope) for k, val in body.model_dump().items() if val is not None})
    db.flush()
    return SCH.view(db, s)


@router.delete("/schedules/{sid}")
def delete_schedule(sid: int, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    s = _sched(db, sid)
    audit(db, actor, "schedule.deleted", s.name)
    db.delete(s)
    db.flush()
    return {"ok": True}


@router.post("/schedules/{sid}/run")
def run_schedule_now(sid: int, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    s = _sched(db, sid)
    res = SCH.run_schedule(db, s, actor=actor, manual=True)
    audit(db, actor, "schedule.run", s.name, checks=res["checks"], failed=res["failed"], errors=res["errors"])
    return res


@router.get("/runs")
def runs(days: int = 7, asset_id: int | None = None, trigger: str | None = None, status: str | None = None,
         schedule_id: int | None = None, limit: int = 200, db=Depends(db_dep)):
    return SCH.list_runs(db, days, asset_id, trigger or None, status or None, schedule_id, min(max(limit, 1), 1000))


@router.get("/runs/{run_id}")
def run_detail(run_id: int, db=Depends(db_dep)):
    d = SCH.run_detail(db, run_id)
    if not d:
        raise HTTPException(404, f"No run #{run_id}")
    return d
