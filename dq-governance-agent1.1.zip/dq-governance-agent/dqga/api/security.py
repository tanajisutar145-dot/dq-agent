"""Request guard: who is calling, and are they allowed to.

Every /api call except the public auth endpoints needs a signed-in user
(local mode: session cookie; sso mode: X-Forwarded-Email). Then:
  - accounts with a reset password may only call /api/auth/* until they change it;
  - state-changing requests must carry X-Requested-With: DataTrustAI (CSRF guard,
    in addition to SameSite=Lax cookies);
  - admin-only endpoints need the admin role; viewers can't change anything.
"""
from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from .. import auth
from ..config import feature_on
from ..db import get_session

PUBLIC = {"/api/health", "/api/auth/config", "/api/auth/login", "/api/auth/signup", "/api/auth/setup"}
UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}
ADMIN_ONLY = [("*", "/api/admin/"), ("POST", "/api/connections"), ("PATCH", "/api/connections"),
              ("DELETE", "/api/connections"), ("POST", "/api/policies"), ("PATCH", "/api/policies"),
              ("DELETE", "/api/policies"), ("PUT", "/api/policy-scans/schedule"), ("PUT", "/api/pii-scans/schedule"), ("PUT", "/api/git"), ("DELETE", "/api/git"), ("POST", "/api/git/test"), ("POST", "/api/grouping"),
              ("PUT", "/api/llm"), ("POST", "/api/llm"), ("DELETE", "/api/llm"),
              ("GET", "/api/settings/env"), ("GET", "/api/deploy/package/"), ("GET", "/api/deploy/databricks-app.zip")]
VIEWER_MAY_POST = ("/api/auth/", "/api/agent/chat")
CSRF_HEADER = ("x-requested-with", "datatrustai")


def _fixes_path(path: str) -> bool:
    return path.startswith(("/api/fixes", "/api/quarantine")) or (path.startswith("/api/incidents/") and path.endswith("/fixes"))


def is_admin(request: Request) -> bool:
    """True for administrators, and when sign-in is off (every request is then trusted)."""
    u = getattr(request.state, "user", None)
    return u is None or u.get("role") == "admin"


def require_admin(request: Request, what: str = "do this") -> None:
    if not is_admin(request):
        from fastapi import HTTPException
        raise HTTPException(403, f"Only administrators can {what}.")


def _deny(status: int, detail: str, code: str | None = None) -> JSONResponse:
    return JSONResponse(status_code=status, content={"detail": detail, **({"code": code} if code else {})})


def is_admin_only(method: str, path: str) -> bool:
    for m, prefix in ADMIN_ONLY:
        if (m == "*" or m == method) and (path == prefix.rstrip("/") or path.startswith(prefix)):
            return True
    return False


def _resolve(request: Request, mode: str):
    db = get_session()
    try:
        if mode == "sso":
            email = request.headers.get("x-forwarded-email")
            if not email:
                return None, _deny(401, "No single sign-on identity was received. Open the app from your workspace.", "sso_missing")
            name = request.headers.get("x-forwarded-preferred-username") or request.headers.get("x-forwarded-user")
            u = auth.sso_user(db, email, name)
            if u.status != "active":
                db.commit()
                return None, _deny(403, "Your access to TCS DataTrustAI is disabled. Contact an administrator.", "disabled")
        else:
            u = auth.session_user(db, request.cookies.get(auth.COOKIE))
            if u is None:
                return None, _deny(401, "Sign in to continue.", "unauthenticated")
        info = {"id": u.id, "email": u.email, "name": u.name, "role": u.role, "status": u.status,
                "must_change_password": u.must_change_password, "auth_source": u.auth_source}
        db.commit()
        return info, None
    except auth.AuthError as e:
        db.rollback()
        return None, _deny(e.status, str(e))
    finally:
        db.close()


async def guard(request: Request, call_next):
    path = request.url.path
    if not path.startswith("/api/"):
        return await call_next(request)
    if _fixes_path(path) and not feature_on("fixes_and_quarantine"):
        return _deny(404, "Fixes and quarantine are not available in this version.", "feature_off")
    mode = auth.mode()
    request.state.user = None
    if mode == "none":
        return await call_next(request)
    if mode == "local" and request.method in UNSAFE and request.headers.get(CSRF_HEADER[0], "").lower() != CSRF_HEADER[1]:
        return _deny(403, "Missing request header X-Requested-With: DataTrustAI.", "csrf")
    if path in PUBLIC:
        return await call_next(request)
    user, err = await run_in_threadpool(_resolve, request, mode)
    if err:
        return err
    request.state.user = user
    if user["must_change_password"] and not path.startswith("/api/auth/"):
        return _deny(403, "Choose a new password to continue.", "password_change_required")
    if is_admin_only(request.method, path) and user["role"] != "admin":
        return _deny(403, "Only administrators can do this.", "admin_only")
    if user["role"] == "viewer" and request.method in UNSAFE and not path.startswith(VIEWER_MAY_POST):
        return _deny(403, "Viewers can't make changes. Ask an administrator for the steward role.", "viewer")
    return await call_next(request)
