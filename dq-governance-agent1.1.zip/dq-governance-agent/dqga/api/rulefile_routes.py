"""API for rules as files (AI Rule Studio > Rule catalog): download rule files, preview and import them as drafts.

    GET  /api/rules/files/download?asset_id&include_drafts   one YAML file for a dataset, or a zip with a file per dataset
    POST /api/rules/files/preview   {files: [{name, text}], zip_b64}   what an import would do; nothing is saved
    POST /api/rules/files/apply     same body; saves drafts (never changes a live rule, never deletes)  [steward or admin]
"""
from __future__ import annotations

import base64

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel
from sqlalchemy import select

from .. import rulefiles as RF
from ..models import Asset, audit
from .routes import actor_dep, db_dep

router = APIRouter()


class FileIn(BaseModel):
    name: str = "rules.yaml"
    text: str


class FilesIn(BaseModel):
    files: list[FileIn] = []
    zip_b64: str | None = None


def _texts(body: FilesIn) -> list[tuple[str, str]]:
    out = [(f.name, f.text) for f in body.files]
    if body.zip_b64:
        try:
            out += RF.read_zip(base64.b64decode(body.zip_b64))
        except Exception as e:  # a corrupt upload is the caller's problem, not a server error
            raise HTTPException(400, f"The zip file could not be read: {e}") from None
    if not out:
        raise HTTPException(400, "Choose at least one rule file")
    if len(out) > 500 or sum(len(t) for _, t in out) > 20_000_000:
        raise HTTPException(400, "Too many or too large files for one import")
    return out


@router.get("/rules/files/download")
def download(asset_id: int | None = None, include_drafts: bool = False, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    files = RF.export_files(db, [asset_id] if asset_id else None, include_drafts)
    if not files:
        raise HTTPException(400, "No rules to export. Only active and disabled rules are exported unless you include drafts.")
    audit(db, actor, "rules.files_exported", None, datasets=len(files), drafts=include_drafts)
    if asset_id:
        path, text = files[0]
        return Response(text, media_type="text/yaml; charset=utf-8",
                        headers={"Content-Disposition": f'attachment; filename="{path.rsplit("/", 1)[-1]}"'})
    return Response(RF.zip_files(files), media_type="application/zip",
                    headers={"Content-Disposition": 'attachment; filename="datatrustai-rule-files.zip"'})


@router.post("/rules/files/preview")
def preview(body: FilesIn, db=Depends(db_dep)):
    return RF.plan(db, _texts(body))


@router.post("/rules/files/apply")
def apply(body: FilesIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    res = RF.apply(db, _texts(body), actor)
    res.pop("plan", None)
    return res
