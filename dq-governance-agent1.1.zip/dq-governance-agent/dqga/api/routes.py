"""REST routes. Every mutating route records the acting user in the audit log.

User identity: X-Forwarded-Email (set by Databricks Apps and most SSO proxies),
then X-User, then app.actor from config.
"""
from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy import func, select

from .. import connectors as C
from .. import grouping
from .. import scheduler, services as S
from ..agent import agent as A
from ..config import feature_on, get_settings
from ..db import get_session
from ..dq import custom_metrics as CM
from ..dq import review
from ..dq import scoring
from ..dq.exporters import EXPORTERS, FORMATS, export_with_report, export_zip
from ..dq.rules import DIMENSIONS, RULE_TYPES, SEVERITIES
from ..dq.runner import run_asset
from ..governance import compliance, contracts, glossary, policies
from .security import is_admin, require_admin
from ..incidents import lineage as L
from ..incidents import manager as M
from ..incidents.remediation import suggestions_for_incident
from ..learning import feedback
from ..models import (Approval, Asset, AuditLog, CheckResult, Classification, Connection, Contract, CustomMetric,
                      CustomMetricValue, Feedback, GlossaryLink, GlossaryTerm, Incident, IncidentEvent, MetricPoint,
                      Notification, Policy, Rule, RuleHistory, audit)

router = APIRouter()


def db_dep():
    s = get_session()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def actor_dep(request: Request) -> str:
    user = getattr(request.state, "user", None)
    if user:
        return user["email"]
    h = request.headers
    return (h.get("x-forwarded-email") or h.get("x-forwarded-preferred-username") or h.get("x-user")
            or get_settings().section("app").get("actor", "steward"))


def _asset(db, asset_id: int) -> Asset:
    a = db.get(Asset, asset_id)
    if not a:
        raise HTTPException(404, "Asset not found")
    return a


# --------------------------------------------------------------------------- meta
@router.get("/health")
def health():
    return {"ok": True}


@router.get("/meta")
def meta(actor: str = Depends(actor_dep)):
    from .. import __version__
    from ..runtime import runtime_info
    try:
        llm = S.get_llm()
        llm_info = llm.describe() if llm else {"provider": "rules"}
    except Exception as e:  # misconfigured LLM must not break the UI
        llm_info = {"provider": "error", "model": f"{type(e).__name__}: {e}"[:120]}
    return {"rule_types": RULE_TYPES, "dimensions": DIMENSIONS, "severities": SEVERITIES, "exporters": EXPORTERS,
            "export_formats": FORMATS, "frameworks": {k: v["title"] for k, v in compliance.FRAMEWORKS.items()},
            "connector_types": list(C.CONNECTOR_TYPES), "llm": llm_info,
            "app": get_settings().section("app").get("name"), "version": __version__,
            "runtime": runtime_info(), "user": actor, "grouping": grouping.public(),
            "features": {"fixes_and_quarantine": feature_on("fixes_and_quarantine"), "git_sync": feature_on("git_sync")}}


@router.get("/grouping")
def grouping_settings(db=Depends(db_dep)):
    return {**grouping.public(), "groups": sorted({a.domain for a in db.scalars(select(Asset)) if a.domain}),
            "unassigned": sum(1 for a in db.scalars(select(Asset)) if not a.domain),
            "locked": sum(1 for a in db.scalars(select(Asset)) if a.domain_locked)}


@router.post("/grouping/reapply")
def grouping_reapply(db=Depends(db_dep), actor: str = Depends(actor_dep)):
    res = grouping.regroup_all(db)
    audit(db, actor, "grouping.reapplied", None, **res)
    return res


@router.get("/settings/env")
def env_settings():
    from ..runtime import env_report
    return env_report(get_settings())


@router.get("/docs")
def docs_list(content: bool = True):
    from ..docs import list_docs
    return {"docs": list_docs(with_content=content)}


@router.get("/docs/{doc_id}")
def docs_get(doc_id: str):
    from ..docs import get_doc
    d = get_doc(doc_id)
    if not d:
        raise HTTPException(404, f"No document {doc_id!r}")
    return d


@router.get("/deploy/targets")
def deploy_targets():
    from ..deploy import targets_view
    from ..runtime import runtime_info
    return targets_view(runtime_info())


@router.get("/deploy/package/{target_id}.zip")
def deploy_package(target_id: str, actor: str = Depends(actor_dep), db=Depends(db_dep)):
    from ..deploy import build_app_package, load_targets
    t = next((t for t in load_targets() if t["id"] == target_id), None)
    if not t or not t.get("package"):
        raise HTTPException(404, f"No package for deploy target {target_id!r}")
    audit(db, actor, "deploy.package_downloaded", target_id)
    return Response(build_app_package(), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="tcs-datatrustai-{target_id}.zip"'})


@router.get("/deploy/databricks-app.zip")
def deploy_package_databricks(actor: str = Depends(actor_dep), db=Depends(db_dep)):
    return deploy_package("databricks_apps", actor, db)


@router.get("/overview")
def overview(db=Depends(db_dep)):
    ov = scoring.overview(db)
    incs = db.scalars(select(Incident).where(Incident.status.in_(["open", "ack"]))).all()
    sev = {s: 0 for s in ["critical", "high", "medium", "low"]}
    for i in incs:
        sev[i.severity] = sev.get(i.severity, 0) + 1
    fresh_breaches = []
    for r in db.scalars(select(Rule).where(Rule.type == "freshness", Rule.status == "active", Rule.last_status == "fail")):
        fresh_breaches.append({"rule_id": r.id, "asset_id": r.asset_id, "asset": db.get(Asset, r.asset_id).fqn, "name": r.name})
    ov.update({"incidents_by_severity": sev, "open_incidents": len(incs), "sla_breaches": fresh_breaches,
               "policy_violations": len(policies.evaluate(db)), "mttr_hours": M.mttr_hours(db)})
    CM.refresh_builtin(db)
    ov["custom_metrics"] = CM.list_views(db, only_overview=True)
    return ov


# Filtered Overview tabs (Summary, Rules, Incidents): platform, domain, asset_id, severity, category, days (7|30|90)
def _ov_filter(platform: str | None = None, domain: str | None = None, asset_id: int | None = None,
               severity: str | None = None, category: str | None = None, days: int = 30):
    from ..overview import OvFilter
    return OvFilter.of(platform, domain, asset_id, severity, category, days)


@router.get("/overview/options")
def overview_options(db=Depends(db_dep)):
    from .. import overview as OV
    return OV.options(db)


@router.get("/overview/summary")
def overview_summary(f=Depends(_ov_filter), db=Depends(db_dep)):
    from .. import overview as OV
    ov = OV.summary(db, f)
    CM.refresh_builtin(db)
    ov["custom_metrics"] = CM.list_views(db, only_overview=True)  # custom metrics keep their own definitions
    return ov


@router.get("/overview/rules")
def overview_rules(f=Depends(_ov_filter), db=Depends(db_dep)):
    from .. import overview as OV
    return OV.rules_view(db, f)


@router.get("/overview/incidents")
def overview_incidents(f=Depends(_ov_filter), db=Depends(db_dep)):
    from .. import overview as OV
    return OV.incidents_view(db, f)


# --------------------------------------------------------------------------- custom DQ metrics
@router.get("/custom-metrics")
def list_custom_metrics(db=Depends(db_dep)):
    return CM.list_views(db)


@router.get("/custom-metrics/options")
def custom_metric_options(db=Depends(db_dep)):
    return CM.options(db)


@router.post("/custom-metrics/preview")
def preview_custom_metric(body: dict = Body(...), db=Depends(db_dep)):
    vals = CM.normalize(body)
    try:
        v = CM.compute(db, vals["measure"], vals["params"])
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"[:500]}
    return {"ok": True, "value": v, "status": CM.status_of(v, vals["direction"], vals["target"], vals["warn_at"])}


def _metric(db, metric_id: int) -> CustomMetric:
    m = db.get(CustomMetric, metric_id)
    if not m:
        raise HTTPException(404, "Metric not found")
    return m


@router.post("/custom-metrics")
def create_custom_metric(body: dict = Body(...), db=Depends(db_dep), actor: str = Depends(actor_dep)):
    vals = CM.normalize(body)
    pos = (db.scalar(select(func.max(CustomMetric.position))) or 0) + 1
    m = CustomMetric(**vals, position=pos, created_by=actor)
    db.add(m)
    db.flush()
    CM.evaluate(db, m)
    audit(db, actor, "custom_metric.created", m.name, measure=m.measure)
    db.flush()
    return CM.view(db, m)


@router.patch("/custom-metrics/{metric_id}")
def update_custom_metric(metric_id: int, body: dict = Body(...), db=Depends(db_dep), actor: str = Depends(actor_dep)):
    m = _metric(db, metric_id)
    current = {k: getattr(m, k) for k in ("name", "description", "measure", "params", "unit", "direction",
                                           "target", "warn_at", "show_on_overview")}
    vals = CM.normalize({**current, **body})
    redefined = (vals["measure"], vals["params"]) != (m.measure, m.params or {})
    for k, v in vals.items():
        setattr(m, k, v)
    if redefined:  # a different calculation: old history no longer compares
        from sqlalchemy import delete
        db.execute(delete(CustomMetricValue).where(CustomMetricValue.metric_id == m.id))
        m.last_value = None
    CM.evaluate(db, m)
    audit(db, actor, "custom_metric.updated", m.name, redefined=redefined)
    db.flush()
    return CM.view(db, m)


@router.delete("/custom-metrics/{metric_id}")
def delete_custom_metric(metric_id: int, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    m = _metric(db, metric_id)
    name = m.name
    CM.delete_metric(db, m)
    audit(db, actor, "custom_metric.deleted", name)
    return {"deleted": metric_id}


@router.post("/custom-metrics/{metric_id}/evaluate")
def evaluate_custom_metric(metric_id: int, db=Depends(db_dep)):
    m = _metric(db, metric_id)
    CM.evaluate(db, m)
    db.flush()
    return CM.view(db, m)


@router.post("/custom-metrics/evaluate")
def evaluate_custom_metrics(db=Depends(db_dep)):
    return CM.evaluate_all(db, include_sql=True)


# --------------------------------------------------------------------------- maintenance (admin only)
@router.get("/admin/maintenance")
def maintenance_info(db=Depends(db_dep)):
    from .. import maintenance as MT
    from ..db import dialect_name
    p = MT.sqlite_path()
    return {"dialect": dialect_name(), "database": str(p) if p else None,
            "size_bytes": p.stat().st_size if p and p.exists() else None, "counts": MT.counts(db),
            "confirm_word": MT.CONFIRM_WORD, "backups_dir": str(p.parent / "backups") if p else None,
            "demo_loaded": bool(db.scalars(select(Asset.id).where(Asset.connection == "demo").limit(1)).first())}


@router.post("/admin/demo/load")
def load_demo_data(actor: str = Depends(actor_dep)):
    """Add the demo datasets (utility lakehouse on a local DuckDB file) and their history next to the existing data."""
    from ..demo.seed import run as seed
    try:
        res = seed(get_settings(), verbose=False, additive=True, rebootstrap=False)
    except ValueError as e:
        raise HTTPException(409, str(e))
    from ..db import session_scope
    with session_scope() as db:
        audit(db, actor, "demo.loaded", "demo", datasets=res.get("assets"))
    return {"loaded": True, "datasets": res.get("assets"), "open_incidents": len(res.get("incidents", []))}


class ResetIn(BaseModel):
    confirm: str
    keep_users: bool = True
    keep_connections: bool = True
    keep_references: bool = True
    backup: bool = True


@router.post("/admin/reset")
def reset_application(body: ResetIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    from .. import maintenance as MT
    if body.confirm.strip().upper() != MT.CONFIRM_WORD:
        raise HTTPException(400, f"Type {MT.CONFIRM_WORD} to confirm")
    return MT.reset_app_data(db, actor, keep_users=body.keep_users, keep_connections=body.keep_connections,
                             backup=body.backup, keep_references=body.keep_references)


# --------------------------------------------------------------------------- connections
class ConnIn(BaseModel):
    name: str
    type: str
    config: dict = {}


@router.get("/connections")
def list_connections(db=Depends(db_dep)):
    names = S.config_connection_names()
    return [S.connection_view(db, c, names) for c in db.scalars(select(Connection).order_by(Connection.name))]


@router.post("/connections")
def add_connection(body: ConnIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    name = body.name.strip()
    if not name:
        raise HTTPException(400, "Give the connection a name")
    if body.type not in C.CONNECTOR_TYPES:
        raise HTTPException(400, f"Unknown connection type {body.type!r}. Known: {', '.join(sorted(C.CONNECTOR_TYPES))}")
    cfg = {**body.config, "name": name, "type": body.type}
    row = db.scalars(select(Connection).where(Connection.name == name)).first() or Connection(name=name)
    row.type, row.config, row.enabled = body.type, cfg, True
    row.last_test_ok = row.last_test_at = row.last_test_detail = row.last_sync_error = None
    db.add(row)
    try:  # save even when it can't start, so the error shows on the connection and can be fixed
        C.register(C.build_connector(name, body.type, cfg))
        row.status = "registered"
    except Exception as e:
        C.unregister(name)
        row.status = f"error: {type(e).__name__}: {e}"[:200]
    audit(db, actor, "connection.saved", name, type=body.type)
    db.flush()
    return S.connection_view(db, row)


@router.post("/connections/{name}/test")
def test_connection(name: str, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    res = S.run_connection_test(db, name)
    audit(db, actor, "connection.tested", name, ok=res["ok"])
    return res


class ConnPatch(BaseModel):
    enabled: bool


@router.patch("/connections/{name}")
def patch_connection(name: str, body: ConnPatch, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    view = S.set_connection_enabled(db, name, body.enabled)
    audit(db, actor, "connection.enabled" if body.enabled else "connection.disabled", name)
    return view


@router.delete("/connections/{name}")
def delete_connection(name: str, purge: bool = True, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    res = S.delete_connection(db, name, purge=purge)
    audit(db, actor, "connection.deleted", name, purge=purge, assets_removed=res["assets_removed"])
    return res


@router.post("/catalog/sync")
def sync_catalog(connection: str | None = None, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    res = S.sync_catalog(db, connection)
    audit(db, actor, "catalog.synced", connection, **{k: v for k, v in res.items() if k != "lineage"})
    return res


# --------------------------------------------------------------------------- assets
@router.get("/assets")
def list_assets(q: str = "", domain: str | None = None, platform: str | None = None, db=Depends(db_dep)):
    out = []
    sensitive: dict[int, int] = {}
    for c in db.scalars(select(Classification).where(Classification.status != "rejected")):
        sensitive[c.asset_id] = sensitive.get(c.asset_id, 0) + 1
    for a in db.scalars(select(Asset).order_by(Asset.fqn)):
        if q and q.lower() not in a.fqn.lower() and q.lower() not in (a.description or "").lower():
            continue
        if domain and a.domain != domain or platform and a.platform != platform:
            continue
        out.append({**S.asset_summary(db, a), "sensitive_columns": sensitive.get(a.id, 0)})
    return out


@router.get("/assets/{asset_id}")
def get_asset(asset_id: int, db=Depends(db_dep)):
    a = _asset(db, asset_id)
    latest = scoring.latest_results(db, a.id)
    return {**S.asset_summary(db, a), "latest": {rid: r.to_dict() for rid, r in latest.items()},
            "classifications": [c.to_dict() for c in db.scalars(select(Classification).where(Classification.asset_id == a.id))],
            "contract": next((c.to_dict() for c in db.scalars(select(Contract).where(Contract.asset_id == a.id))), None),
            "glossary": [{"term": db.get(GlossaryTerm, l.term_id).name, "ref": l.target_ref} for l in
                         db.scalars(select(GlossaryLink).where(GlossaryLink.target_ref.like(f"{a.fqn}%")))]}


class AssetPatch(BaseModel):
    owner: str | None = None
    steward: str | None = None
    domain: str | None = None
    certified: bool | None = None
    description: str | None = None


@router.patch("/assets/{asset_id}")
def patch_asset(asset_id: int, body: AssetPatch, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    a = _asset(db, asset_id)
    changes = body.model_dump(exclude_none=True)
    for k, v in changes.items():
        setattr(a, k, v)
    if "domain" in changes:
        a.domain = changes["domain"].strip() or None
        a.domain_locked = bool(a.domain)  # a typed value stays through syncs; clearing it hands the dataset back to the configured source
        if not a.domain:
            a.domain = grouping.derive(a.fqn, a.connection, a.owner, a.tags)
    audit(db, actor, "asset.updated", a.fqn, **changes)
    return S.asset_summary(db, a)


@router.post("/assets/{asset_id}/profile")
def profile(asset_id: int, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    a = _asset(db, asset_id)
    res = S.profile_asset(db, a)
    audit(db, actor, "asset.profiled", a.fqn)
    return res


@router.get("/assets/{asset_id}/profile")
def get_profile(asset_id: int, db=Depends(db_dep)):
    return S.latest_profile(db, asset_id) or {}


@router.get("/assets/{asset_id}/metrics")
def metrics(asset_id: int, metric: str = "row_count", column: str | None = None, db=Depends(db_dep)):
    q = select(MetricPoint).where(MetricPoint.asset_id == asset_id, MetricPoint.metric == metric)
    if column:
        q = q.where(MetricPoint.column == column)
    return [{"ts": p.ts.isoformat(timespec="minutes"), "value": p.value} for p in db.scalars(q.order_by(MetricPoint.ts))][-200:]


@router.post("/assets/{asset_id}/run")
def run(asset_id: int, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    a = _asset(db, asset_id)
    res = run_asset(db, a, trigger="manual")
    audit(db, actor, "checks.run", a.fqn, run_id=res["run_id"], failed=res["failed"])
    return res


@router.post("/assets/{asset_id}/suggest")
def suggest(asset_id: int, use_llm: bool = True, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    a = _asset(db, asset_id)
    rules = S.suggest_rules(db, a, use_llm=use_llm, actor=actor)
    return [r.to_dict() for r in rules]


@router.post("/assets/{asset_id}/classify")
def classify(asset_id: int, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    a = _asset(db, asset_id)
    S.profile_asset(db, a)
    return [c.to_dict() for c in db.scalars(select(Classification).where(Classification.asset_id == a.id))]


@router.get("/assets/{asset_id}/results")
def results(asset_id: int, limit: int = 200, db=Depends(db_dep)):
    rows = db.scalars(select(CheckResult).where(CheckResult.asset_id == asset_id)
                      .order_by(CheckResult.ts.desc()).limit(limit)).all()
    return [r.to_dict() for r in rows]


@router.get("/assets/{asset_id}/remediations")
def asset_remediations(asset_id: int, db=Depends(db_dep)):
    from ..incidents.remediation import suggestions_for_rule
    a = _asset(db, asset_id)
    out = []
    for r in db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.last_status == "fail")):
        out += suggestions_for_rule(r, a)
    return out


# --------------------------------------------------------------------------- rules
class RuleIn(BaseModel):
    asset_id: int
    type: str
    column: str | None = None
    params: dict = {}
    name: str | None = None
    severity: str = "medium"
    threshold: float | None = None
    dimension: str | None = None
    description: str | None = None
    schedule_minutes: int | None = None
    status: str = "proposed"
    category: str | None = None  # core | business | governance; inferred from the type when empty
    source: str | None = None  # manual | nl | discovery ...; manual when empty
    reason: str | None = None


@router.get("/rules")
def list_rules(asset_id: int | None = None, status: str | None = None, category: str | None = None,
               severity: str | None = None, dimension: str | None = None, platform: str | None = None, db=Depends(db_dep)):
    q = select(Rule)
    if asset_id:
        q = q.where(Rule.asset_id == asset_id)
    if platform:
        q = q.where(Rule.asset_id.in_(select(Asset.id).where(Asset.platform == platform)))
    if status:  # one status, or several separated by commas (e.g. active,disabled)
        q = q.where(Rule.status.in_([s.strip() for s in status.split(",") if s.strip()]))
    if category:
        q = q.where(Rule.category == category)
    if severity:
        q = q.where(Rule.severity == severity)
    if dimension:
        q = q.where(Rule.dimension == dimension)
    assets = {a.id: a.fqn for a in db.scalars(select(Asset))}
    return [{**r.to_dict(), "asset": assets.get(r.asset_id)} for r in db.scalars(q.order_by(Rule.asset_id, Rule.id))]


@router.post("/rules")
def create_rule(body: RuleIn, request: Request, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    a = _asset(db, body.asset_id)
    d = body.model_dump(exclude_none=True)
    status = d.pop("status", "proposed")
    if status != "proposed":  # new rules start as saved drafts; going live takes the review steps (administrators only)
        require_admin(request, "create a rule that is already live. Save it as a draft and send it for approval")
    d.pop("asset_id")
    return S.create_rule(db, a, {**d, "source": d.get("source") or "manual"}, actor, status=status).to_dict()


@router.post("/rules/dry-run")
def dry_run(body: RuleIn, db=Depends(db_dep)):
    a = _asset(db, body.asset_id)
    d = body.model_dump(exclude_none=True)
    d.pop("asset_id")
    d.pop("status", None)
    return S.dry_run_rule(db, a, d)


class NLIn(BaseModel):
    asset_id: int
    text: str
    reference_ids: list[int] | None = None  # None = every enabled reference file for the dataset's domain
    use_references: bool = True
    category: str | None = None
    save: bool = False  # False: draft and dry-run only; the caller saves it as a draft when the person agrees


@router.post("/rules/nl")
def nl_rule(body: NLIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    return S.nl_rule(db, _asset(db, body.asset_id), body.text, actor, body.reference_ids, body.use_references, body.category,
                     save=body.save)


@router.patch("/rules/{rule_id}")
def patch_rule(rule_id: int, request: Request, changes: dict = Body(...), db=Depends(db_dep), actor: str = Depends(actor_dep)):
    r = db.get(Rule, rule_id)
    if not r:
        raise HTTPException(404, "Rule not found")
    new_status = changes.get("status")
    if new_status and new_status != r.status:
        if new_status == "review":  # the same step as Send for approval
            try:
                return review.submit(db, [r.id], actor)[0].to_dict()
            except review.ReviewError as e:
                raise HTTPException(400, str(e))
        if new_status in ("active", "approved", "rejected"):
            require_admin(request, "approve, reject or activate rules. Send the rule for approval instead")
    if r.status not in review.DRAFT and any(k in changes for k in review.LIVE_EDIT_FIELDS):
        require_admin(request, f"change a rule that is {r.status}. Withdraw it from review first, or ask an administrator")
    return S.update_rule(db, r, changes, actor).to_dict()


@router.post("/rules/{rule_id}/activate")
def activate(rule_id: int, request: Request, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    require_admin(request, "activate rules")
    r = db.get(Rule, rule_id)
    if not r:
        raise HTTPException(404, "Rule not found")
    return S.update_rule(db, r, {"status": "active"}, actor, "activated").to_dict()


@router.get("/rules/{rule_id}/history")
def rule_history(rule_id: int, db=Depends(db_dep)):
    versions = [h.to_dict() for h in db.scalars(select(RuleHistory).where(RuleHistory.rule_id == rule_id).order_by(RuleHistory.version))]
    res = [r.to_dict() for r in db.scalars(select(CheckResult).where(CheckResult.rule_id == rule_id)
                                           .order_by(CheckResult.ts.desc()).limit(100))]
    return {"versions": versions, "results": res}


def _export_rules_for(db, a: Asset, include_proposed: bool) -> list[Rule]:
    statuses = ["active", "proposed"] if include_proposed else ["active"]
    return db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status.in_(statuses)).order_by(Rule.id)).all()


def _dialect_for(a: Asset):
    try:
        return C.get_connector(a.connection).dialect
    except KeyError:
        return None


def _selected_rules(db, rule_ids: str) -> list[tuple[Asset, list[Rule]]]:
    """Exactly the rules picked in the Rule catalog (any status), grouped by dataset."""
    ids = sorted({int(x) for x in rule_ids.split(",") if x.strip().isdigit()})
    if not ids:
        raise HTTPException(400, "No rules selected")
    rules = list(db.scalars(select(Rule).where(Rule.id.in_(ids)).order_by(Rule.asset_id, Rule.id)))
    if not rules:
        raise HTTPException(404, "None of the selected rules exist any more")
    by: dict[int, list[Rule]] = {}
    for r in rules:
        by.setdefault(r.asset_id, []).append(r)
    return [(db.get(Asset, aid), rs) for aid, rs in by.items()]


@router.get("/rules/export")
def export_rules(asset_id: int | None = None, target: str = "dqx", include_proposed: bool = False, download: bool = False,
                 rule_ids: str | None = None, db=Depends(db_dep)):
    if rule_ids:  # only the selected rules: one dataset -> one file; several -> a zip with a folder per dataset
        groups = _selected_rules(db, rule_ids)
        if len(groups) > 1:
            if not download:
                return {"multi": True, "datasets": len(groups), "rules": sum(len(rs) for _, rs in groups), "code": "", "skipped": [],
                        "label": FORMATS[target]["label"] if target in FORMATS else target, "filename": "datatrustai-rules.zip", "proposed_excluded": 0}
            items = [(a.fqn, rs, _dialect_for(a)) for a, rs in groups]
            return Response(export_zip(items, [target]), media_type="application/zip",
                            headers={"Content-Disposition": 'attachment; filename="datatrustai-selected-rules.zip"'})
        a, rules = groups[0]
        rep = export_with_report(rules, target, a.fqn, _dialect_for(a))
        rep["proposed_excluded"] = 0
        rep["selected"] = len(rules)
        if download:
            return Response(rep["code"], media_type="text/plain; charset=utf-8",
                            headers={"Content-Disposition": f'attachment; filename="{rep["filename"]}"'})
        return rep
    if not asset_id:
        raise HTTPException(400, "Give asset_id, or rule_ids for the selected rules")
    a = _asset(db, asset_id)
    rep = export_with_report(_export_rules_for(db, a, include_proposed), target, a.fqn, _dialect_for(a))
    rep["proposed_excluded"] = 0 if include_proposed else len(db.scalars(
        select(Rule.id).where(Rule.asset_id == a.id, Rule.status == "proposed")).all())
    if download:
        return Response(rep["code"], media_type="text/plain; charset=utf-8",
                        headers={"Content-Disposition": f'attachment; filename="{rep["filename"]}"'})
    return rep


@router.get("/rules/export/bundle")
def export_bundle(asset_id: int | None = None, formats: str = "", include_proposed: bool = False, rule_ids: str | None = None,
                  db=Depends(db_dep), actor: str = Depends(actor_dep)):
    fmts = [f for f in formats.split(",") if f] or list(FORMATS)
    bad = [f for f in fmts if f not in FORMATS]
    if bad:
        raise HTTPException(400, f"Unknown formats: {bad}")
    if rule_ids:
        groups = _selected_rules(db, rule_ids)
        audit(db, actor, "rules.exported", None, formats=fmts, datasets=len(groups), selected=sum(len(rs) for _, rs in groups))
        return Response(export_zip([(a.fqn, rs, _dialect_for(a)) for a, rs in groups], fmts), media_type="application/zip",
                        headers={"Content-Disposition": 'attachment; filename="datatrustai-selected-rules.zip"'})
    assets = [_asset(db, asset_id)] if asset_id else db.scalars(select(Asset).order_by(Asset.fqn)).all()
    items = [(a.fqn, rules, _dialect_for(a)) for a in assets if (rules := _export_rules_for(db, a, include_proposed))]
    if not items:
        raise HTTPException(400, "No rules to export")
    audit(db, actor, "rules.exported", None if not asset_id else assets[0].fqn, formats=fmts, datasets=len(items))
    name = f"datatrustai-rules-{assets[0].fqn.split('.')[-1] if asset_id else 'all'}.zip"
    return Response(export_zip(items, fmts), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


# --------------------------------------------------------------------------- lineage
@router.get("/lineage")
def lineage(fqn: str | None = None, depth: int = 3, db=Depends(db_dep)):
    return L.graph(db, fqn, depth)


@router.post("/lineage/sync")
def lineage_sync(db=Depends(db_dep)):
    return L.sync_from_connectors(db, C.all_connectors())


@router.post("/lineage/openlineage")
def openlineage(event: dict = Body(...), db=Depends(db_dep)):
    return {"added": L.ingest_openlineage(db, event)}


@router.post("/lineage/dbt")
def dbt_manifest(manifest: dict = Body(...), db=Depends(db_dep)):
    return {"added": L.ingest_dbt_manifest(db, manifest)}


class EdgeIn(BaseModel):
    source: str
    target: str


@router.post("/lineage/edges")
def add_edge(body: EdgeIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    added = L.upsert_edge(db, body.source, body.target, "manual")
    audit(db, actor, "lineage.edge_added", body.target, source=body.source)
    return {"added": added}


# --------------------------------------------------------------------------- incidents
@router.get("/incidents")
def list_incidents(status: str = "open", severity: str | None = None, asset_id: int | None = None,
                   domain: str | None = None, platform: str | None = None, db=Depends(db_dep)):
    q = select(Incident).order_by(Incident.created.desc())
    if status != "all":
        q = q.where(Incident.status.in_(["open", "ack"] if status == "open" else [status]))
    if severity:
        q = q.where(Incident.severity == severity)
    incs = db.scalars(q).all() if (asset_id or domain or platform) else db.scalars(q.limit(200)).all()
    if asset_id or domain or platform:  # drill-down from an Overview chart: incidents rooted in (or touching) those datasets
        from ..overview import OvFilter, assets_for
        fqns = {a.fqn for a in assets_for(db, OvFilter.of(platform, domain, asset_id))}
        incs = [i for i in incs if i.root_fqn in fqns or any(x in fqns for x in (i.assets or []))][:200]
    return [i.to_dict() for i in incs]


@router.get("/incidents/{incident_id}")
def get_incident(incident_id: int, db=Depends(db_dep)):
    inc = db.get(Incident, incident_id)
    if not inc:
        raise HTTPException(404, "Incident not found")
    rules = []
    for rid in inc.rule_ids:
        r = db.get(Rule, rid)
        if r:
            last = db.scalars(select(CheckResult).where(CheckResult.rule_id == rid).order_by(CheckResult.ts.desc())).first()
            rules.append({**r.to_dict(), "asset": db.get(Asset, r.asset_id).fqn, "last": last.to_dict() if last else None})
    return {**inc.to_dict(), "rules": rules,
            "events": [e.to_dict() for e in db.scalars(select(IncidentEvent).where(IncidentEvent.incident_id == inc.id)
                                                       .order_by(IncidentEvent.ts))],
            "remediations": suggestions_for_incident(db, inc),
            "root_asset_id": (db.scalars(select(Asset).where(Asset.fqn == inc.root_fqn)).first() or Asset(id=None)).id}


class IncidentAction(BaseModel):
    action: str
    assignee: str | None = None
    note: str | None = None


@router.post("/incidents/{incident_id}/action")
def incident_action(incident_id: int, body: IncidentAction, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    inc = db.get(Incident, incident_id)
    return M.act(db, inc, body.action, actor, body.assignee, body.note).to_dict()


@router.post("/incidents/{incident_id}/ticket")
def incident_ticket(incident_id: int, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    inc = db.get(Incident, incident_id)
    return S.run_action(db, "ticket", f"Open ticket for incident #{inc.id}", {"incident_id": inc.id}, actor).to_dict()


@router.post("/incidents/{incident_id}/remediate")
def incident_remediate(incident_id: int, index: int = 0, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    inc = db.get(Incident, incident_id)
    sugg = suggestions_for_incident(db, inc)
    if not sugg or index >= len(sugg):
        raise HTTPException(400, "No such remediation")
    return S.run_action(db, "remediation", sugg[index]["title"], sugg[index], actor).to_dict()


class FeedbackIn(BaseModel):
    verdict: str
    rule_id: int | None = None
    incident_id: int | None = None
    note: str | None = None


@router.post("/feedback")
def post_feedback(body: FeedbackIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    return feedback.record(db, body.verdict, actor, body.rule_id, body.incident_id, body.note)


@router.get("/feedback")
def get_feedback(db=Depends(db_dep)):
    return {"items": [f.to_dict() for f in db.scalars(select(Feedback).order_by(Feedback.ts.desc()).limit(100))],
            "precision": feedback.precision(db)}


class Decision(BaseModel):
    approve: bool


# --------------------------------------------------------------------------- governance
@router.get("/governance/summary")
def governance_summary(db=Depends(db_dep)):
    f = compliance.facts(db)
    pii = []
    for c in db.scalars(select(Classification).where(Classification.status != "rejected")):
        a = db.get(Asset, c.asset_id)
        pii.append({**c.to_dict(), "asset": a.fqn, "platform": a.platform, "domain": a.domain})
    return {"facts": f, "pii": pii, "violations": policies.evaluate(db),
            "unowned": [{"id": a.id, "fqn": a.fqn} for a in db.scalars(select(Asset).where(Asset.owner.is_(None)))]}


@router.post("/classifications/{cid}/decide")
def decide_classification(cid: int, body: Decision, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    c = db.get(Classification, cid)
    if not body.approve:
        c.status = "rejected"
        audit(db, actor, "classification.rejected", None, id=cid)
        return c.to_dict()
    act = S.run_action(db, "apply_tags", f"Tag {c.column} as {c.label}",
                       {"asset_id": c.asset_id, "items": [{"column": c.column, "classification_id": c.id,
                                                           "tags": {"pii": c.label, "sensitivity": c.sensitivity}}]}, actor)
    return {**c.to_dict(), "action": act.to_dict()}


@router.get("/policies")
def list_policies(db=Depends(db_dep)):
    return [p.to_dict() for p in db.scalars(select(Policy))]


@router.post("/policies")
def save_policy(spec: dict = Body(...), db=Depends(db_dep), actor: str = Depends(actor_dep)):
    if not spec.get("id") or not spec.get("type"):
        raise HTTPException(400, "Policy needs id and type")
    p = db.scalars(select(Policy).where(Policy.key == spec["id"])).first() or Policy(key=spec["id"])
    p.type, p.spec, p.enabled = spec["type"], spec, spec.get("enabled", True)
    db.add(p)
    audit(db, actor, "policy.saved", spec["id"], spec=spec)
    return p.to_dict()


@router.get("/policies/violations")
def violations(db=Depends(db_dep)):
    return policies.evaluate(db)


class EnforceIn(BaseModel):
    policy: str
    asset_id: int
    column: str | None = None


@router.post("/policies/enforce")
def enforce(body: EnforceIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    pol = db.scalars(select(Policy).where(Policy.key == body.policy)).first()
    a = _asset(db, body.asset_id)
    vio = next((v for v in policies.evaluate(db, [pol]) if v["asset_id"] == a.id and v.get("column") == body.column), None)
    if not vio or not vio["enforceable"]:
        raise HTTPException(400, "No enforceable violation for that policy and asset")
    stmts = policies.enforcement_sql(pol, vio, C.get_connector(a.connection).dialect.name, a)
    act = S.run_action(db, "enforce_policy", f"Enforce {pol.key} on {a.fqn}{'.' + body.column if body.column else ''}",
                       {"policy": pol.key, "policy_type": pol.type, "asset_id": a.id, "column": body.column,
                        "statements": stmts}, actor)
    return act.to_dict()


@router.get("/compliance/{framework}")
def compliance_report(framework: str, db=Depends(db_dep)):
    return compliance.report(db, framework)


# --------------------------------------------------------------------------- contracts
@router.get("/contracts")
def list_contracts(db=Depends(db_dep)):
    return [{**c.to_dict(), "asset": db.get(Asset, c.asset_id).fqn if c.asset_id else None} for c in db.scalars(select(Contract))]


@router.get("/assets/{asset_id}/contract")
def asset_contract(asset_id: int, db=Depends(db_dep)):
    a = _asset(db, asset_id)
    rules = db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status == "active")).all()
    spec = contracts.export_contract(a, rules)
    return {"spec": spec, "yaml": contracts.dump(spec)}


@router.post("/contracts")
def import_contract(request: Request, body: dict = Body(...), db=Depends(db_dep), actor: str = Depends(actor_dep)):
    spec = contracts.parse(body["yaml"])
    phys = spec["schema"][0].get("physicalName")
    a = S.find_asset(db, phys) if phys else None
    if not a:
        raise HTTPException(400, f"No asset matches physicalName {phys!r}; sync the catalog first")
    validation = contracts.validate_against_schema(spec, a.columns or [])
    existing = {S._rule_key(r) for r in db.scalars(select(Rule).where(Rule.asset_id == a.id, Rule.status != "disabled"))}
    created = []
    for rd in contracts.rules_from_contract(spec, a.columns or []):
        if S._rule_key(rd) not in existing:
            created.append(S.create_rule(db, a, rd, actor, status="active" if is_admin(request) else "proposed").id)
    for m in spec.get("team", []) or []:
        if m.get("role") == "owner" and not a.owner:
            a.owner = m.get("username")
        if m.get("role") in ("data steward", "steward") and not a.steward:
            a.steward = m.get("username")
    c = db.scalars(select(Contract).where(Contract.asset_id == a.id)).first() or Contract(asset_id=a.id)
    c.name, c.version, c.status, c.spec, c.last_validation = spec.get("name", a.fqn), str(spec.get("version", "1.0.0")), \
        spec.get("status", "active"), spec, validation
    db.add(c)
    audit(db, actor, "contract.imported", a.fqn, version=c.version, rules_created=len(created))
    return {"contract": c.to_dict(), "rules_created": created, "validation": validation}


@router.post("/contracts/{contract_id}/validate")
def validate_contract(contract_id: int, db=Depends(db_dep)):
    c = db.get(Contract, contract_id)
    a = db.get(Asset, c.asset_id)
    live = [col.to_dict() for col in C.get_connector(a.connection).get_columns(a.fqn)]
    c.last_validation = contracts.validate_against_schema(c.spec, live)
    return c.last_validation


# --------------------------------------------------------------------------- glossary
class TermIn(BaseModel):
    name: str
    definition: str = ""
    domain: str | None = None
    owner: str | None = None
    synonyms: list[str] = []


@router.get("/glossary")
def list_terms(db=Depends(db_dep)):
    return [glossary.term_detail(db, t) for t in db.scalars(select(GlossaryTerm).order_by(GlossaryTerm.name))]


@router.post("/glossary")
def save_term(body: TermIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    t = db.scalars(select(GlossaryTerm).where(GlossaryTerm.name == body.name)).first() or GlossaryTerm(name=body.name)
    t.definition, t.domain, t.owner, t.synonyms = body.definition, body.domain, body.owner, body.synonyms
    db.add(t)
    audit(db, actor, "glossary.saved", body.name)
    return t.to_dict()


class LinkIn(BaseModel):
    target_type: str
    target_ref: str


@router.post("/glossary/{term_id}/link")
def link_term(term_id: int, body: LinkIn, db=Depends(db_dep)):
    l = GlossaryLink(term_id=term_id, target_type=body.target_type, target_ref=body.target_ref)
    db.add(l)
    return {"ok": True}


@router.get("/glossary/graph")
def glossary_graph(db=Depends(db_dep)):
    return glossary.graph(db)


@router.post("/glossary/sync-neo4j")
def sync_neo4j(db=Depends(db_dep)):
    return glossary.sync_neo4j(db)


# --------------------------------------------------------------------------- scheduler / audit / agent
@router.get("/scheduler")
def sched_status(db=Depends(db_dep)):
    return {**scheduler.status(), "plan": scheduler.plan(db)[:30], "budget_used_today_s": scheduler.budget_used_today(db)}


@router.post("/scheduler/tick")
def sched_tick(db=Depends(db_dep)):
    return scheduler.tick(db)


@router.get("/audit")
def audit_log(limit: int = 200, db=Depends(db_dep)):
    return [a.to_dict() for a in db.scalars(select(AuditLog).order_by(AuditLog.ts.desc()).limit(limit))]


@router.get("/notifications")
def notifications(db=Depends(db_dep)):
    return [n.to_dict() for n in db.scalars(select(Notification).order_by(Notification.ts.desc()).limit(100))]


class ChatIn(BaseModel):
    message: str
    session_id: str = "default"
    context: dict[str, Any] = {}


@router.post("/agent/chat")
def agent_chat(body: ChatIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    return A.chat(db, body.session_id, body.message, body.context, actor)


__all__ = ["router", "json"]
