"""FastAPI app: REST API under /api and the single-page web UI at /."""
from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .. import scheduler, services
from ..config import get_settings
from .routes import router

WEB = Path(__file__).resolve().parent.parent / "web"


@asynccontextmanager
async def lifespan(app: FastAPI):
    services.bootstrap(get_settings())
    scheduler.start_background()
    yield
    scheduler.stop_background()


def create_app(bootstrap: bool = True) -> FastAPI:
    from .. import __version__
    app = FastAPI(title="TCS DataTrustAI", version=__version__, lifespan=lifespan if bootstrap else None)
    from .auth_routes import router as auth_router
    from .intel_routes import router as intel_router
    from .llm_routes import router as llm_router
    from .pii_routes import router as pii_router
    from .policy_routes import router as policy_router
    from .reference_routes import router as reference_router
    from .review_routes import router as review_router
    from .rulefile_routes import router as rulefile_router
    from .git_routes import router as git_router
    from .run_routes import router as run_router
    from .security import guard

    app.include_router(auth_router, prefix="/api")
    app.include_router(intel_router, prefix="/api")
    app.include_router(llm_router, prefix="/api")
    app.include_router(reference_router, prefix="/api")
    app.include_router(run_router, prefix="/api")
    app.include_router(review_router, prefix="/api")
    app.include_router(git_router, prefix="/api")
    app.include_router(rulefile_router, prefix="/api")  # before `router`: /rules/files must not be read as a rule id
    app.include_router(pii_router, prefix="/api")
    app.include_router(policy_router, prefix="/api")  # before `router`: its /policies routes replace the basic ones
    app.include_router(router, prefix="/api")
    app.middleware("http")(guard)

    @app.exception_handler(ValueError)
    async def value_error(_, exc: ValueError):
        return JSONResponse(status_code=400, content={"detail": str(exc)})

    @app.exception_handler(KeyError)
    async def key_error(_, exc: KeyError):
        return JSONResponse(status_code=404, content={"detail": str(exc).strip("'")})

    app.mount("/static", StaticFiles(directory=WEB), name="static")

    @app.api_route("/", methods=["GET", "HEAD"], include_in_schema=False)
    def index():
        # Version the script and stylesheet by their file times, so browsers never run a stale copy after an upgrade.
        html = (WEB / "index.html").read_text(encoding="utf-8")
        for name in ("app.js", "styles.css"):
            html = html.replace(f"/static/{name}\"", f"/static/{name}?v={int((WEB / name).stat().st_mtime)}\"")
        return HTMLResponse(html, headers={"Cache-Control": "no-cache"})

    return app


app = create_app()
