"""API for sending rules for approval and the review queue (AI Rule Studio > Review queue).

    POST /api/rules/submit            {rule_ids, note}                     saved drafts -> waiting for approval (anyone who can edit)
    POST /api/rules/withdraw          {rule_ids}                           take rules back out of review
    GET  /api/rules/review?status=&asset_id=&platform=&category=&severity=  the queue, with counts
    POST /api/rules/review/decide     {rule_ids, decision, note}           administrators: approve | reject | activate | approve_activate
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select

from ..dq import review
from ..models import Asset, Rule
from .routes import actor_dep, db_dep
from .security import is_admin, require_admin

router = APIRouter()

QUEUE_STATUSES = {"waiting": ("review",), "approved": ("approved",), "rejected": ("rejected",),
                  "all": ("review", "approved", "rejected")}


class SubmitIn(BaseModel):
    rule_ids: list[int]
    note: str | None = None


class DecideIn(BaseModel):
    rule_ids: list[int]
    decision: str
    note: str | None = None


def _view(db, rules: list[Rule]) -> list[dict]:
    assets = {a.id: a for a in db.scalars(select(Asset))}
    out = []
    for r in rules:
        a = assets.get(r.asset_id)
        out.append({**r.to_dict(), "asset": a.fqn if a else None, "platform": a.platform if a else None})
    return out


@router.post("/rules/submit")
def submit(body: SubmitIn, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    try:
        rules = review.submit(db, body.rule_ids, actor, body.note)
    except review.ReviewError as e:
        raise HTTPException(400, str(e))
    return {"submitted": [r.id for r in rules], "rules": _view(db, rules)}


@router.post("/rules/withdraw")
def withdraw(body: SubmitIn, request: Request, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    try:
        rules = review.withdraw(db, body.rule_ids, actor, is_admin(request))
    except review.ReviewError as e:
        raise HTTPException(400, str(e))
    return {"withdrawn": [r.id for r in rules]}


@router.get("/rules/review")
def queue(status: str = "waiting", asset_id: int | None = None, platform: str | None = None, category: str | None = None,
          severity: str | None = None, db=Depends(db_dep)):
    statuses = QUEUE_STATUSES.get(status)
    if not statuses:
        raise HTTPException(400, f"status must be one of {', '.join(QUEUE_STATUSES)}")
    q = select(Rule).where(Rule.status.in_(statuses))
    if asset_id:
        q = q.where(Rule.asset_id == asset_id)
    if platform:
        q = q.where(Rule.asset_id.in_(select(Asset.id).where(Asset.platform == platform)))
    if category:
        q = q.where(Rule.category == category)
    if severity:
        q = q.where(Rule.severity == severity)
    rules = list(db.scalars(q.order_by(Rule.submitted_ts.desc().nullslast(), Rule.id.desc())))
    c = review.counts(db)
    return {"status": status, "rules": _view(db, rules),
            "counts": {"waiting": c["review"], "approved": c["approved"], "rejected": c["rejected"], "drafts": c["proposed"]}}


@router.post("/rules/review/decide")
def decide(body: DecideIn, request: Request, db=Depends(db_dep), actor: str = Depends(actor_dep)):
    require_admin(request, "approve, reject or activate rules")
    try:
        rules = review.decide(db, body.rule_ids, body.decision, actor, body.note)
    except review.ReviewError as e:
        raise HTTPException(400, str(e))
    return {"decision": body.decision, "rules": _view(db, rules)}
