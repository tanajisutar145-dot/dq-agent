"""Sign-up, sign-in, administrator sign-in, first-run setup, and the Admin console API."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel
from sqlalchemy import select

from .. import __version__, auth
from ..config import get_settings
from ..db import get_session
from ..models import AuthSession, User, audit, utcnow

router = APIRouter()


def db_dep():
    s = get_session()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def _err(e: auth.AuthError):
    return HTTPException(e.status, str(e))


def _https(request: Request) -> bool:
    return request.url.scheme == "https" or request.headers.get("x-forwarded-proto", "").lower() == "https"


def _start_session(request: Request, response: Response, db, u: User) -> None:
    token = auth.create_session(db, u, request.client.host if request.client else None, request.headers.get("user-agent"))
    response.set_cookie(auth.COOKIE, token, httponly=True, samesite="lax", secure=_https(request), path="/",
                        max_age=int(float(auth.cfg().get("session_hours", 12)) * 3600))


def _me(request: Request) -> dict:
    u = getattr(request.state, "user", None)
    if not u:
        raise HTTPException(401, "Sign in to continue.")
    return u


def _require_local():
    if auth.mode() != "local":
        raise HTTPException(409, f"Built-in accounts are off (auth.mode is {auth.mode()}).")


class Creds(BaseModel):
    email: str
    password: str
    admin: bool = False


class NewAccount(BaseModel):
    name: str
    email: str
    password: str


class PasswordChange(BaseModel):
    current: str
    new: str


# ------------------------------------------------------------------ public
@router.get("/auth/config")
def auth_config(db=Depends(db_dep)):
    return {**auth.public_config(db), "app": get_settings().section("app").get("name"), "version": __version__}


@router.post("/auth/setup")
def setup(body: NewAccount, request: Request, response: Response, db=Depends(db_dep)):
    _require_local()
    if auth.user_count(db) > 0:
        raise HTTPException(409, "Setup is already complete. Sign in instead.")
    try:
        u = auth.create_user(db, body.email, body.name, body.password, role="admin", actor="setup")
    except auth.AuthError as e:
        raise _err(e)
    u.last_login = utcnow()
    _start_session(request, response, db, u)
    audit(db, u.email, "auth.setup_admin", u.email)
    return u.public()


@router.post("/auth/signup")
def signup(body: NewAccount, request: Request, response: Response, db=Depends(db_dep)):
    _require_local()
    policy = auth.cfg().get("signup", "approval")
    if policy == "disabled":
        raise HTTPException(403, "Sign-up is turned off. Ask an administrator to create your account.")
    if auth.user_count(db) == 0:
        raise HTTPException(409, "Create the administrator account first.")
    status = "active" if policy == "open" else "pending"
    try:
        u = auth.create_user(db, body.email, body.name, body.password, role=auth.cfg().get("default_role", "steward"),
                             status=status, actor=body.email.strip().lower())
    except auth.AuthError as e:
        raise _err(e)
    audit(db, u.email, "auth.signup", u.email, status=status)
    if status == "active":
        u.last_login = utcnow()
        _start_session(request, response, db, u)
    return {"status": status, "user": u.public()}


@router.post("/auth/login")
def login(body: Creds, request: Request, response: Response, db=Depends(db_dep)):
    _require_local()
    try:
        u = auth.authenticate(db, body.email, body.password)
    except auth.AuthError as e:
        db.commit()  # keep failed-attempt counters and audit entries
        raise _err(e)
    if body.admin and u.role != "admin":
        audit(db, u.email, "auth.admin_login_denied", u.email)
        db.commit()
        raise HTTPException(403, "This account isn't an administrator. Use the regular sign-in.")
    _start_session(request, response, db, u)
    audit(db, u.email, "auth.login", u.email, admin_console=body.admin)
    return u.public()


# ------------------------------------------------------------------ signed in
@router.get("/auth/me")
def me(request: Request, db=Depends(db_dep)):
    if auth.mode() == "none":
        from .routes import actor_dep
        return {"id": None, "email": actor_dep(request), "name": "Local user", "role": "admin", "status": "active",
                "must_change_password": False, "auth_source": "none", "mode": "none"}
    u = db.get(User, _me(request)["id"])
    return {**u.public(), "mode": auth.mode()}


@router.post("/auth/logout")
def logout(request: Request, response: Response, db=Depends(db_dep)):
    auth.revoke_session(db, request.cookies.get(auth.COOKIE))
    response.delete_cookie(auth.COOKIE, path="/")
    u = getattr(request.state, "user", None)
    if u:
        audit(db, u["email"], "auth.logout", u["email"])
    return {"ok": True}


@router.post("/auth/password")
def password(body: PasswordChange, request: Request, db=Depends(db_dep)):
    _require_local()
    u = db.get(User, _me(request)["id"])
    try:
        auth.change_password(db, u, body.current, body.new)
    except auth.AuthError as e:
        raise _err(e)
    return u.public()


# ------------------------------------------------------------------ admin console (middleware enforces admin)
class NewUser(BaseModel):
    name: str
    email: str
    role: str = "steward"


class UserPatch(BaseModel):
    name: str | None = None
    role: str | None = None
    status: str | None = None


@router.get("/admin/summary")
def admin_summary(db=Depends(db_dep)):
    users = db.scalars(select(User)).all()
    c = auth.cfg()
    return {"users": len(users), "pending": sum(1 for u in users if u.status == "pending"),
            "admins": sum(1 for u in users if u.role == "admin" and u.status == "active"),
            "disabled": sum(1 for u in users if u.status == "disabled"), "sessions": auth.active_sessions(db),
            "settings": {"mode": auth.mode(), "signup": c.get("signup", "approval"), "default_role": c.get("default_role", "steward"),
                         "session_hours": c.get("session_hours", 12), "max_failed_logins": c.get("max_failed_logins", 5),
                         "lockout_minutes": c.get("lockout_minutes", 15), "min_password_length": c.get("min_password_length", 10),
                         "sso_admins": c.get("admins") or []}}


@router.get("/admin/users")
def admin_users(db=Depends(db_dep)):
    order = {"pending": 0, "active": 1, "disabled": 2}
    users = sorted(db.scalars(select(User)).all(), key=lambda u: (order.get(u.status, 3), u.email))
    sessions = {}
    for s in db.scalars(select(AuthSession).where(AuthSession.expires > utcnow())):
        sessions[s.user_id] = sessions.get(s.user_id, 0) + 1
    return [{**u.public(), "sessions": sessions.get(u.id, 0)} for u in users]


@router.post("/admin/users")
def admin_create_user(body: NewUser, request: Request, db=Depends(db_dep)):
    _require_local()
    temp = auth.temporary_password()
    try:
        u = auth.create_user(db, body.email, body.name, temp, role=body.role, must_change=True, actor=_me(request)["email"])
    except auth.AuthError as e:
        raise _err(e)
    return {"user": u.public(), "temporary_password": temp}


def _target(db, user_id: int) -> User:
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "User not found")
    return u


@router.patch("/admin/users/{user_id}")
def admin_update_user(user_id: int, body: UserPatch, request: Request, db=Depends(db_dep)):
    me_ = _me(request)
    u = _target(db, user_id)
    changes = body.model_dump(exclude_none=True)
    if "role" in changes and changes["role"] not in auth.ROLES:
        raise HTTPException(400, f"Role must be one of {', '.join(auth.ROLES)}.")
    if "status" in changes and changes["status"] not in auth.STATUSES:
        raise HTTPException(400, f"Status must be one of {', '.join(auth.STATUSES)}.")
    losing_admin = u.role == "admin" and u.status == "active" and (
        changes.get("role", "admin") != "admin" or changes.get("status", "active") != "active")
    if losing_admin and auth.active_admins(db, exclude_id=u.id) == 0:
        raise HTTPException(400, "There must be at least one active administrator.")
    if u.id == me_["id"] and changes.get("status") == "disabled":
        raise HTTPException(400, "You can't disable your own account.")
    was = u.status
    for k, v in changes.items():
        setattr(u, k, v.strip() if isinstance(v, str) else v)
    if changes.get("status") == "disabled":
        auth.revoke_user_sessions(db, u.id)
    if was == "pending" and u.status == "active":
        audit(db, me_["email"], "user.approved", u.email, role=u.role)
    elif was == "pending" and u.status == "disabled":
        audit(db, me_["email"], "user.rejected", u.email)
    else:
        audit(db, me_["email"], "user.updated", u.email, **changes)
    return u.public()


@router.post("/admin/users/{user_id}/reset-password")
def admin_reset_password(user_id: int, request: Request, db=Depends(db_dep)):
    _require_local()
    u = _target(db, user_id)
    temp = auth.temporary_password()
    u.password_hash, u.must_change_password, u.failed_logins, u.locked_until = auth.hash_password(temp), True, 0, None
    revoked = auth.revoke_user_sessions(db, u.id)
    audit(db, _me(request)["email"], "user.password_reset", u.email, sessions_revoked=revoked)
    return {"user": u.public(), "temporary_password": temp}


@router.post("/admin/users/{user_id}/unlock")
def admin_unlock(user_id: int, request: Request, db=Depends(db_dep)):
    u = _target(db, user_id)
    u.failed_logins, u.locked_until = 0, None
    audit(db, _me(request)["email"], "user.unlocked", u.email)
    return u.public()


@router.delete("/admin/users/{user_id}")
def admin_delete_user(user_id: int, request: Request, db=Depends(db_dep)):
    me_ = _me(request)
    u = _target(db, user_id)
    if u.id == me_["id"]:
        raise HTTPException(400, "You can't delete your own account.")
    if u.role == "admin" and u.status == "active" and auth.active_admins(db, exclude_id=u.id) == 0:
        raise HTTPException(400, "There must be at least one active administrator.")
    auth.revoke_user_sessions(db, u.id)
    audit(db, me_["email"], "user.deleted", u.email)
    db.delete(u)
    return {"ok": True}
