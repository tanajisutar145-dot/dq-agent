"""Application services shared by the API, the agent tools, and the CLI."""
from __future__ import annotations

from typing import Any

import yaml
from sqlalchemy import select

from . import connectors as C
from . import grouping as G
from .config import Settings, get_settings, set_settings
from .db import init_db
from .dq import rules as R
from .dq.profiler import profile_table
from .dq.suggester import heuristic_suggestions, llm_suggestions, nl_to_rule
from .governance.classification import classify_asset
from .governance.policies import seed_policies
from .incidents import lineage as L
from .models import (Approval, Asset, Classification, Connection, Incident, Policy, Profile, Rule, RuleHistory,
                     audit, utcnow)

_llm = None


# ---------------------------------------------------------------------------
# bootstrap
# ---------------------------------------------------------------------------
def bootstrap(settings: Settings | None = None) -> Settings:
    from .db import session_scope

    s = settings or get_settings()
    set_settings(s)
    init_db(s.section("app")["database_url"], s.root, s.section("app").get("db_schema"))
    with session_scope() as db:
        apply_config(db, s)
    global _llm
    _llm = None
    return s


def apply_config(db, s: Settings) -> None:
    """Load what config.yaml and policies.yaml define into the app database, then register connectors.

    Runs at startup and after a reset. A connection's enabled flag lives in the
    database, so disabling one in the UI survives restarts.
    """
    for cfg in s.data.get("connections", []) or []:
        cfg = dict(cfg)
        if cfg.get("type") == "duckdb" and cfg.get("path"):
            cfg["path"] = str(s.abspath(cfg["path"]))
        row = db.scalars(select(Connection).where(Connection.name == cfg["name"])).first()
        if not row:
            db.add(Connection(name=cfg["name"], type=cfg["type"], config=cfg, enabled=True))
        else:
            row.type, row.config = cfg["type"], cfg
    db.flush()
    register_connections(db)
    pfile = s.abspath(s.section("governance").get("policies_file", "policies.yaml"))
    if pfile.exists():
        specs = (yaml.safe_load(pfile.read_text(encoding="utf-8")) or {}).get("policies", [])
        seed_policies(db, specs)
    from .auth import bootstrap_admin_from_env
    bootstrap_admin_from_env(db)
    from .dq.categories import backfill
    backfill(db)  # rules created before categories existed


def register_connections(db) -> None:
    C.clear()
    for row in db.scalars(select(Connection)):
        if row.enabled is False:
            C.mark_disabled(row.name)
            row.status = "disabled"
            continue
        try:
            C.register(C.build_connector(row.name, row.type, row.config))
            row.status = "registered"
        except Exception as e:
            row.status = f"error: {type(e).__name__}: {e}"[:200]


# ---------------------------------------------------------------------------
# connections: status, test, enable/disable, delete
# ---------------------------------------------------------------------------
_SECRET_HINTS = ("secret", "password", "token", "key")


def config_connection_names(s: Settings | None = None) -> set[str]:
    s = s or get_settings()
    return {c.get("name") for c in (s.data.get("connections") or []) if isinstance(c, dict)}


def connection_health(row: Connection) -> tuple[str, str]:
    """(health, detail) where health is disabled | error | ok | untested."""
    if row.enabled is False:
        return "disabled", "Turned off. Checks and syncs skip this connection."
    if (row.status or "").startswith("error"):
        return "error", row.status[len("error: "):] if row.status.startswith("error: ") else row.status
    if row.last_sync_error:
        return "error", f"Last sync failed: {row.last_sync_error}"
    tested_after_sync = row.last_test_at and (row.last_sync is None or row.last_test_at >= row.last_sync)
    if row.last_test_ok is False and tested_after_sync:
        return "error", row.last_test_detail or "Last test failed"
    if row.last_test_ok or row.last_sync:
        return "ok", (row.last_test_detail if row.last_test_ok and tested_after_sync else "Last sync succeeded")
    return "untested", "Not tested yet. Use Test to check it."


def connection_view(db, row: Connection, in_config: set[str] | None = None) -> dict:
    reg = C.all_connectors()
    safe = {k: v for k, v in (row.config or {}).items() if not any(s in k for s in _SECRET_HINTS) or k.endswith("_env")}
    health, detail = connection_health(row)
    n_assets = len(db.scalars(select(Asset.id).where(Asset.connection == row.name)).all())
    names = in_config if in_config is not None else config_connection_names()
    return {**row.to_dict(), "config": safe, "health": health, "health_detail": detail, "assets": n_assets,
            "in_config": row.name in names,
            "capabilities": reg[row.name].describe() if row.name in reg else None}


def _connection_row(db, name: str) -> Connection:
    row = db.scalars(select(Connection).where(Connection.name == name)).first()
    if not row:
        raise KeyError(f"No connection named {name!r}")
    return row


def run_connection_test(db, name: str) -> dict:
    """Test a connection and keep the outcome on its row. Disabled connections are tested with a temporary connector."""
    row = _connection_row(db, name)
    conn, temporary = C.all_connectors().get(name), False
    try:
        if conn is None:
            conn, temporary = C.build_connector(row.name, row.type, row.config), True
        res = conn.test() or {}
        ok, detail = bool(res.get("ok")), str(res.get("detail") or "")
    except Exception as e:
        ok, detail = False, f"{type(e).__name__}: {e}"
    finally:
        if temporary and conn is not None and hasattr(conn, "close"):
            try:
                conn.close()
            except Exception:
                pass
    row.last_test_ok, row.last_test_at, row.last_test_detail = ok, utcnow(), detail[:1000]
    if ok and row.enabled and (row.status or "").startswith("error"):
        try:  # a registration error that has since been fixed (e.g. an env var was set)
            C.register(C.build_connector(row.name, row.type, row.config))
            row.status = "registered"
        except Exception as e:
            row.status = f"error: {type(e).__name__}: {e}"[:200]
    db.flush()
    return {"ok": ok, "detail": detail[:1000], "connection": connection_view(db, row)}


def set_connection_enabled(db, name: str, enabled: bool) -> dict:
    row = _connection_row(db, name)
    row.enabled = enabled
    if enabled:
        try:
            C.register(C.build_connector(row.name, row.type, row.config))
            row.status = "registered"
        except Exception as e:
            C.unregister(name)
            row.status = f"error: {type(e).__name__}: {e}"[:200]
    else:
        C.unregister(name, disabled=True)
        row.status = "disabled"
    db.flush()
    return connection_view(db, row)


def purge_assets(db, asset_ids: list[int]) -> int:
    """Delete datasets and everything recorded about them (rules, results, profiles, incidents, lineage...)."""
    from sqlalchemy import delete, or_

    from .models import Base, Feedback, IncidentEvent, LineageEdge

    ids = list(asset_ids)
    if not ids:
        return 0
    for start in range(0, len(ids), 400):
        chunk = ids[start:start + 400]
        fqns = list(db.scalars(select(Asset.fqn).where(Asset.id.in_(chunk))))
        rule_ids = list(db.scalars(select(Rule.id).where(Rule.asset_id.in_(chunk))))
        if rule_ids:
            db.execute(delete(RuleHistory).where(RuleHistory.rule_id.in_(rule_ids)))
            db.execute(delete(Feedback).where(Feedback.rule_id.in_(rule_ids)))
        if fqns:
            inc_ids = list(db.scalars(select(Incident.id).where(Incident.root_fqn.in_(fqns))))
            if inc_ids:
                db.execute(delete(IncidentEvent).where(IncidentEvent.incident_id.in_(inc_ids)))
                db.execute(delete(Feedback).where(Feedback.incident_id.in_(inc_ids)))
                db.execute(delete(Incident).where(Incident.id.in_(inc_ids)))
            db.execute(delete(LineageEdge).where(or_(LineageEdge.source.in_(fqns), LineageEdge.target.in_(fqns))))
        for table in reversed(Base.metadata.sorted_tables):  # children before assets (profiles/rules have FKs)
            if table.name != "assets" and "asset_id" in table.c:
                db.execute(table.delete().where(table.c.asset_id.in_(chunk)))
        db.execute(delete(Asset).where(Asset.id.in_(chunk)))
    db.flush()
    return len(ids)


def delete_connection(db, name: str, purge: bool = True) -> dict:
    row = _connection_row(db, name)
    asset_ids = list(db.scalars(select(Asset.id).where(Asset.connection == name)))
    removed = purge_assets(db, asset_ids) if purge else 0
    C.unregister(name)
    db.delete(row)
    db.flush()
    return {"deleted": name, "assets_removed": removed, "assets_kept": 0 if purge else len(asset_ids),
            "in_config": name in config_connection_names()}


def get_llm():
    """The one LLM for the whole app: what an administrator saved in Settings > LLM, else config.yaml / environment."""
    global _llm
    if _llm is None:
        from .llm import build_llm
        from .llm.settings import effective_now
        _llm = build_llm(effective_now()[0])
    return _llm


def reset_llm() -> None:
    global _llm
    _llm = None


# ---------------------------------------------------------------------------
# catalog
# ---------------------------------------------------------------------------
def sync_catalog(db, connection: str | None = None) -> dict:
    out = {"assets": 0, "new": 0, "errors": {}}
    # Naming a connection that is disabled or unknown is an error, not a silent "synced 0".
    conns = {connection: C.get_connector(connection)} if connection else C.all_connectors()
    for name, conn in conns.items():
        row = db.scalars(select(Connection).where(Connection.name == name)).first()
        try:
            infos = conn.list_assets()
        except Exception as e:
            out["errors"][name] = f"{type(e).__name__}: {e}"[:500]
            if row:
                row.last_sync_error = out["errors"][name]
            continue
        for info in infos:
            a = db.scalars(select(Asset).where(Asset.connection == name, Asset.fqn == info.fqn)).first()
            cols = [c.to_dict() for c in info.columns]
            if a is None:
                a = Asset(connection=name, platform=conn.type, fqn=info.fqn, kind=info.kind)
                db.add(a)
                out["new"] += 1
            a.columns = cols
            a.description = info.description or a.description
            a.tags = {**(a.tags or {}), **(info.tags or {})}
            a.change_marker = info.change_marker
            a.owner = a.owner or (info.tags or {}).get("owner")
            G.apply_on_sync(a, info.domain)
            if info.row_count is not None:
                a.row_count = info.row_count
            out["assets"] += 1
        if row:
            row.last_sync, row.last_sync_error = utcnow(), None
    db.flush()
    out["lineage"] = L.sync_from_connectors(db, {k: v for k, v in conns.items() if k not in out["errors"]})
    try:  # optional: scan datasets that were never scanned for sensitive data (Governance > Sensitive data > Schedule)
        from .governance import pii_scans
        res = pii_scans.after_sync(db)
        if res:
            out["pii_scan"] = {"scanned": res["scanned"], "new": res["new"]}
    except Exception as e:
        out["pii_scan"] = {"error": f"{type(e).__name__}: {e}"[:200]}
    return out


def find_asset(db, ref: str | int) -> Asset | None:
    if isinstance(ref, int) or (isinstance(ref, str) and ref.isdigit()):
        return db.get(Asset, int(ref))
    ref = str(ref).strip().strip("`\"")
    a = db.scalars(select(Asset).where(Asset.fqn == ref)).first()
    if a:
        return a
    low = ref.lower()
    cands = [a for a in db.scalars(select(Asset)) if a.fqn.lower().endswith(low) or low in a.fqn.lower()]
    return sorted(cands, key=lambda a: len(a.fqn))[0] if cands else None


# ---------------------------------------------------------------------------
# profiling + classification
# ---------------------------------------------------------------------------
def profile_asset(db, asset: Asset) -> dict:
    conn = C.get_connector(asset.connection)
    if not conn.supports_sql:
        pts = conn.timeseries(asset.fqn, limit=50000)
        vals = [v for _, v in pts if v is not None]
        prof = {"row_count": len(pts), "columns": {"value": {
            "family": "numeric", "non_null": len(vals), "nulls": len(pts) - len(vals),
            "null_rate": round((len(pts) - len(vals)) / len(pts), 6) if pts else 0,
            "min": min(vals) if vals else None, "max": max(vals) if vals else None,
            "mean": sum(vals) / len(vals) if vals else None}}, "kind": "timeseries"}
        samples = {}
    else:
        prof, samples = profile_table(conn, asset.fqn, asset.columns or [], get_settings().section("profiling"))
    db.add(Profile(asset_id=asset.id, data=prof))
    asset.last_profiled = utcnow()
    asset.row_count = prof.get("row_count")
    found = classify_asset(asset.columns or [], samples)
    existing = {(c.column, c.label) for c in db.scalars(select(Classification).where(Classification.asset_id == asset.id))}
    new = []
    for f in found:
        if (f["column"], f["label"]) not in existing:
            db.add(Classification(asset_id=asset.id, **f))
            new.append(f)
    db.flush()
    return {"profile": prof, "classifications": found, "new_classifications": new}


def latest_profile(db, asset_id: int) -> dict | None:
    p = db.scalars(select(Profile).where(Profile.asset_id == asset_id).order_by(Profile.ts.desc())).first()
    return p.data if p else None


# ---------------------------------------------------------------------------
# rules
# ---------------------------------------------------------------------------
def _rule_key(r: dict | Rule) -> tuple:
    g = (lambda k: r.get(k)) if isinstance(r, dict) else (lambda k: getattr(r, k))
    p = g("params") or {}
    return (g("type"), g("column"), str(p.get("metric")), str(p.get("columns")), str(p.get("check")))


def create_rule(db, asset: Asset, rule: dict, actor: str, status: str = "proposed") -> Rule:
    from .dq.categories import infer
    v = R.validate_rule(rule, asset.columns or [])
    r = Rule(asset_id=asset.id, name=v["name"][:300], type=v["type"], column=v.get("column"), params=v["params"],
             dimension=v["dimension"], severity=v["severity"], threshold=v["threshold"], status=status,
             source=v.get("source", "manual"), description=v.get("description"), reason=v.get("reason"),
             created_by=actor, schedule_minutes=v.get("schedule_minutes"), category=infer(v))
    db.add(r)
    db.flush()
    db.add(RuleHistory(rule_id=r.id, version=1, snapshot=r.to_dict(), changed_by=actor, change=f"created ({status})"))
    audit(db, actor, "rule.created", asset.fqn, rule_id=r.id, status=status, type=r.type)
    return r


RULE_STATUSES = ("proposed", "review", "approved", "rejected", "active", "disabled")
RULE_EDITABLE = ("name", "type", "column", "params", "dimension", "severity", "threshold", "status", "description",
                 "schedule_minutes", "category")


def update_rule(db, rule: Rule, changes: dict, actor: str, note: str | None = None) -> Rule:
    from .dq.categories import CATEGORIES
    asset = db.get(Asset, rule.asset_id)
    changes = {k: v for k, v in changes.items() if k in RULE_EDITABLE}
    if "severity" in changes and changes["severity"] not in R.SEVERITIES:
        raise ValueError(f"Severity must be one of {', '.join(R.SEVERITIES)}")
    if "dimension" in changes and changes["dimension"] not in R.DIMENSIONS:
        raise ValueError(f"Dimension must be one of {', '.join(R.DIMENSIONS)}")
    if "status" in changes and changes["status"] not in RULE_STATUSES:
        raise ValueError("Status must be one of " + ", ".join(RULE_STATUSES))
    if "category" in changes and changes["category"] not in CATEGORIES:
        raise ValueError(f"Category must be one of {', '.join(CATEGORIES)}")
    if "threshold" in changes:
        try:
            changes["threshold"] = float(changes["threshold"])
        except (TypeError, ValueError):
            raise ValueError("Min pass rate must be a number between 0 and 1") from None
        if not 0 <= changes["threshold"] <= 1:
            raise ValueError("Min pass rate must be between 0 and 1")
    if "name" in changes and not str(changes["name"] or "").strip():
        raise ValueError("The rule needs a name")
    merged = {**rule.to_dict(), **changes}
    if any(k in changes for k in ("type", "column", "params")):
        keys = ["type", "column", "params", "dimension", "severity", "threshold", "name"]
        if "type" in changes and "dimension" not in changes:
            keys.remove("dimension")  # a new type brings its own dimension unless one was chosen
        v = R.validate_rule({k: merged.get(k) for k in keys}, asset.columns or [])
        merged.update({k: v[k] for k in ("params", "column")})
        if "type" in changes and "dimension" not in changes:
            merged["dimension"], changes["dimension"] = v["dimension"], v["dimension"]
    for k in RULE_EDITABLE:
        if k in changes:
            setattr(rule, k, merged[k])
    rule.version = (rule.version or 1) + 1
    db.add(RuleHistory(rule_id=rule.id, version=rule.version, snapshot=rule.to_dict(), changed_by=actor,
                       change=note or ", ".join(f"{k}={changes[k]}" for k in changes)[:300]))
    audit(db, actor, "rule.updated", asset.fqn, rule_id=rule.id, changes=changes)
    db.flush()
    return rule


def suggest_rules(db, asset: Asset, use_llm: bool = True, actor: str = "agent") -> list[Rule]:
    prof = latest_profile(db, asset.id) or profile_asset(db, asset)["profile"]
    others = [{"fqn": a.fqn, "columns": a.columns or []} for a in db.scalars(select(Asset).where(Asset.id != asset.id))]
    sugg = heuristic_suggestions(asset.fqn, prof, asset.columns or [], others)
    if use_llm:
        llm = get_llm()
        if llm is not None:
            try:
                sugg += llm_suggestions(llm, asset.fqn, prof, asset.columns or [], asset.description)
            except Exception:
                pass
    existing = {_rule_key(r) for r in db.scalars(select(Rule).where(Rule.asset_id == asset.id, Rule.status != "disabled"))}
    created = []
    for s in sugg:
        if _rule_key(s) in existing:
            continue
        existing.add(_rule_key(s))
        created.append(create_rule(db, asset, s, actor, status="proposed"))
    return created


class _TmpRule:
    """Unsaved rule used for dry runs."""
    def __init__(self, v: dict):
        self.id = -1
        self.type, self.column, self.params = v["type"], v.get("column"), v["params"]
        self.name, self.threshold, self.severity = v["name"], v["threshold"], v["severity"]


class _Traced:
    """Wraps a connector and remembers every query it ran, so a dry run can show what ran on the platform."""

    def __init__(self, conn):
        self._c = conn
        self.queries: list[dict] = []

    def __getattr__(self, name):
        return getattr(self._c, name)

    def query(self, sql, *a, **kw):
        import time
        t0 = time.perf_counter()
        try:
            return self._c.query(sql, *a, **kw)
        finally:
            self.queries.append({"sql": sql, "seconds": round(time.perf_counter() - t0, 3)})


def dry_run_rule(db, asset: Asset, rule: dict) -> dict:
    """Run a rule that is not saved (or not live) against the real dataset on its platform.

    Nothing is stored. The result says where it ran, how long it took and which queries ran, so
    a pass is evidence from the platform, not a guess. Platforms that can't run SQL raise an error.
    """
    import time

    from .dq.runner import history_fn
    v = R.validate_rule(rule, asset.columns or [])
    conn = C.get_connector(asset.connection)
    if not getattr(conn, "supports_sql", True):
        raise ValueError(f"{asset.platform} connection '{asset.connection}' can't run SQL, so this rule can't be dry-run there. "
                         "Dry runs need a SQL platform such as Databricks, Snowflake or Spark.")
    traced = _Traced(conn)
    tmp = _TmpRule(v)
    t0 = time.perf_counter()
    if R.RULE_TYPES[tmp.type]["row_level"]:
        o = R.evaluate_row_batch(traced, asset.fqn, [tmp])[-1]
    else:
        o = R.evaluate_aggregate(tmp, asset.fqn, traced, history_fn(db, asset.id), asset.columns or [])
    status = o.status or ("pass" if o.pass_rate >= tmp.threshold - 1e-12 else "fail")
    return {"status": status, "total": o.total, "failed": o.failed, "pass_rate": round(o.pass_rate, 6),
            "message": o.message, "failing_sql": o.failing_sql, "observed": o.observed,
            "ran_on": {"platform": asset.platform, "connection": asset.connection, "dataset": asset.fqn,
                       "seconds": round(time.perf_counter() - t0, 3), "queries": len(traced.queries),
                       "sql": [q["sql"] for q in traced.queries][:3]}}


def nl_rule(db, asset: Asset, text: str, actor: str, reference_ids: list[int] | None = None,
            use_references: bool = True, category: str | None = None, save: bool = True) -> dict:
    from . import reference as REF
    from .dq.categories import CATEGORIES
    others = [{"fqn": a.fqn, "columns": a.columns or []} for a in db.scalars(select(Asset).where(Asset.id != asset.id))]
    llm = None
    try:
        llm = get_llm()
    except Exception:
        pass
    ctx = REF.gather(db, asset, reference_ids) if use_references else REF.Context()
    context = REF.context_text(ctx, asset, int(get_settings().section("governance").get("llm_context_chars") or 8000)) if ctx.docs else None
    res = nl_to_rule(text, asset.columns or [], llm, others, context=context, aliases=ctx.aliases)
    if category in CATEGORIES:
        res["rule"]["category"] = category
    elif REF.GOV_WORDS.search(text):
        res["rule"]["category"] = "governance"
    preview = dry_run_rule(db, asset, res["rule"])
    if save:
        rule = create_rule(db, asset, res["rule"], actor, status="proposed").to_dict()
    else:  # a draft the person has not saved yet: validated, normalised, dry-run, not stored
        v = R.validate_rule(res["rule"], asset.columns or [])
        from .dq.categories import infer
        rule = {**v, "id": None, "asset_id": asset.id, "status": None, "category": res["rule"].get("category") or infer(v),
                "source": v.get("source", "nl")}
    return {"rule": rule, "saved": save, "parser": res["parser"], "interpretation": res.get("interpretation"), "dry_run": preview,
            "reference_files": len(ctx.docs), "aliases_used": [t for t in ctx.aliases if t in text.lower()][:10]}


# ---------------------------------------------------------------------------
# approvals
# ---------------------------------------------------------------------------
def perform(db, kind: str, title: str, payload: dict, actor: str) -> Approval:
    """Run a change now. There is no approval step; the record (status approved or failed, with its result) is the action history."""
    a = Approval(kind=kind, title=title[:500], payload=payload, requested_by=actor, decided_by=actor, decided_ts=utcnow())
    db.add(a)
    db.flush()
    try:
        a.result = execute_approval(db, a, actor)
        a.status = "approved"
    except Exception as e:
        a.status, a.result = "failed", {"error": f"{type(e).__name__}: {e}"[:1000]}
    audit(db, actor, "action.run" if a.status == "approved" else "action.failed", None, action_id=a.id, kind=kind, title=title[:200],
          **({"error": a.result["error"]} if a.status == "failed" else {}))
    db.flush()
    return a


def run_action(db, kind: str, title: str, payload: dict, actor: str) -> Approval:
    """perform(), but a failure is raised so the caller reports it."""
    a = perform(db, kind, title, payload, actor)
    if a.status == "failed":
        raise ValueError(a.result["error"])
    return a


def execute_approval(db, appr: Approval, actor: str) -> dict:
    p = appr.payload
    k = appr.kind
    if k == "rule_activate":
        out = []
        for rid in p.get("rule_ids") or [p["rule_id"]]:
            rule = db.get(Rule, rid)
            update_rule(db, rule, {"status": "active"}, actor, "approved")
            out.append(rid)
        return {"activated": out}
    if k == "rule_update":
        rule = db.get(Rule, p["rule_id"])
        update_rule(db, rule, p["changes"], actor, p.get("why"))
        return {"rule_id": rule.id, "changes": p["changes"]}
    if k == "remediation":
        from .incidents.remediation import execute
        return execute(db, p, actor, auto=False)
    if k == "autofix":
        from .incidents.autofix import apply
        fr = apply(db, p["fix_id"], actor, incident_id=p.get("incident_id"))
        return {"fix_run": fr.id, "rows": fr.rows, "title": fr.title}
    if k == "ticket":
        from .incidents.ticketing import create_ticket
        inc = db.get(Incident, p["incident_id"])
        t = create_ticket(inc)
        inc.ticket = t
        from .incidents.manager import add_event
        add_event(db, inc, "ticket", f"{t.get('provider')} {t.get('key') or t.get('status')}", actor)
        return t
    if k == "apply_tags":
        asset = db.get(Asset, p["asset_id"])
        conn = C.get_connector(asset.connection)
        stmts = []
        for item in p["items"]:
            stmts += conn.set_tags(asset.fqn, item["tags"], item.get("column"))
            tags = dict(asset.tags or {})
            if item.get("column"):
                cols = dict(tags.get("columns") or {})
                cols[item["column"]] = {**cols.get(item["column"], {}), **item["tags"]}
                tags["columns"] = cols
            else:
                tags.update(item["tags"])
            asset.tags = tags
            if item.get("classification_id"):
                c = db.get(Classification, item["classification_id"])
                if c:
                    c.applied, c.status = True, "confirmed"
        return {"statements": stmts}
    if k == "enforce_policy":
        asset = db.get(Asset, p["asset_id"])
        conn = C.get_connector(asset.connection)
        res = conn.execute(p["statements"])
        tags = dict(asset.tags or {})
        if p.get("policy_type") == "masking" and p.get("column"):
            cols = dict(tags.get("columns") or {})
            cols[p["column"]] = {**cols.get(p["column"], {}), "masked": "true"}
            tags["columns"] = cols
        if p.get("policy_type") == "retention":
            tags["retention_enforced"] = "true"
        asset.tags = tags
        return {"executed": len(res), "statements": p["statements"]}
    raise ValueError(f"Unknown approval kind {k}")


def asset_summary(db, a: Asset) -> dict[str, Any]:
    rules = db.scalars(select(Rule).where(Rule.asset_id == a.id)).all()
    open_inc = [i for i in db.scalars(select(Incident).where(Incident.status.in_(["open", "ack"])))
                if a.fqn in i.assets or i.root_fqn == a.fqn]
    return {**a.to_dict(), "rules_active": sum(1 for r in rules if r.status == "active"),
            "rules_proposed": sum(1 for r in rules if r.status == "proposed"),
            "rules_failing": sum(1 for r in rules if r.status == "active" and r.last_status == "fail"),
            "open_incidents": len(open_inc)}


__all__ = ["bootstrap", "sync_catalog", "find_asset", "profile_asset", "latest_profile", "create_rule",
           "update_rule", "suggest_rules", "dry_run_rule", "nl_rule", "perform", "run_action",
           "asset_summary", "get_llm", "reset_llm", "Policy", "apply_config", "register_connections",
           "connection_view", "run_connection_test", "set_connection_enabled", "delete_connection", "purge_assets"]
