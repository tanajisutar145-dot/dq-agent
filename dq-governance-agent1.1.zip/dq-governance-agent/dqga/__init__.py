"""TCS DataTrustAI: data quality and governance agent."""
__version__ = "1.1.0"
